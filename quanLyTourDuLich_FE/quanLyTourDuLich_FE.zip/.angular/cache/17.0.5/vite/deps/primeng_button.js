import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-EZTW7KX4.js";
import "./chunk-JT6O4I5J.js";
import "./chunk-5KXMCARW.js";
import "./chunk-MRLHSI7V.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-VEQSBVUE.js";
import "./chunk-YZEMK44K.js";
import "./chunk-PA7AHZKQ.js";
import "./chunk-AFRS2OIU.js";
import "./chunk-J5XZNU7V.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map

import {
  CommonModule,
  NgStyle
} from "./chunk-YZEMK44K.js";
import {
  Component,
  EventEmitter,
  Input,
  NgModule,
  Output,
  setClassMetadata,
  ɵɵNgOnChangesFeature,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵelement,
  ɵɵproperty,
  ɵɵpropertyInterpolate
} from "./chunk-PA7AHZKQ.js";
import "./chunk-AFRS2OIU.js";
import {
  __commonJS
} from "./chunk-J5XZNU7V.js";

// node_modules/@canvasjs/charts/canvasjs.min.js
var require_canvasjs_min = __commonJS({
  "node_modules/@canvasjs/charts/canvasjs.min.js"(exports, module) {
    (function() {
      function oa(h, n) {
        h.prototype = db(n.prototype);
        h.prototype.constructor = h;
        h.base = n.prototype;
      }
      function db(h) {
        function n() {
        }
        n.prototype = h;
        return new n();
      }
      function Xa(h, n, E) {
        "millisecond" === E ? h.setMilliseconds(h.getMilliseconds() + 1 * n) : "second" === E ? h.setSeconds(h.getSeconds() + 1 * n) : "minute" === E ? h.setMinutes(h.getMinutes() + 1 * n) : "hour" === E ? h.setHours(h.getHours() + 1 * n) : "day" === E ? h.setDate(h.getDate() + 1 * n) : "week" === E ? h.setDate(h.getDate() + 7 * n) : "month" === E ? h.setMonth(h.getMonth() + 1 * n) : "year" === E && h.setFullYear(h.getFullYear() + 1 * n);
        return h;
      }
      function ca(h, n) {
        var E = false;
        0 > h && (E = true, h *= -1);
        h = "" + h;
        for (n = n ? n : 1; h.length < n; )
          h = "0" + h;
        return E ? "-" + h : h;
      }
      function Ha(h) {
        if (!h)
          return h;
        h = h.replace(/^\s\s*/, "");
        for (var n = /\s/, E = h.length; n.test(h.charAt(--E)); )
          ;
        return h.slice(0, E + 1);
      }
      function Da(h) {
        h.roundRect = function(h2, E, s2, w2, qa, A, B2, v2) {
          B2 && (this.fillStyle = B2);
          v2 && (this.strokeStyle = v2);
          "undefined" === typeof qa && (qa = 5);
          this.lineWidth = A;
          this.beginPath();
          this.moveTo(h2 + qa, E);
          this.lineTo(h2 + s2 - qa, E);
          this.quadraticCurveTo(h2 + s2, E, h2 + s2, E + qa);
          this.lineTo(h2 + s2, E + w2 - qa);
          this.quadraticCurveTo(h2 + s2, E + w2, h2 + s2 - qa, E + w2);
          this.lineTo(h2 + qa, E + w2);
          this.quadraticCurveTo(h2, E + w2, h2, E + w2 - qa);
          this.lineTo(h2, E + qa);
          this.quadraticCurveTo(h2, E, h2 + qa, E);
          this.closePath();
          B2 && this.fill();
          v2 && 0 < A && this.stroke();
        };
      }
      function Ra(h, n) {
        return h - n;
      }
      function X(h) {
        var n = ((h & 16711680) >> 16).toString(16), E = ((h & 65280) >> 8).toString(16);
        h = ((h & 255) >> 0).toString(16);
        n = 2 > n.length ? "0" + n : n;
        E = 2 > E.length ? "0" + E : E;
        h = 2 > h.length ? "0" + h : h;
        return "#" + n + E + h;
      }
      function eb(h, n) {
        var E = this.length >>> 0, s2 = Number(n) || 0, s2 = 0 > s2 ? Math.ceil(s2) : Math.floor(s2);
        for (0 > s2 && (s2 += E); s2 < E; s2++)
          if (s2 in this && this[s2] === h)
            return s2;
        return -1;
      }
      function s(h) {
        return null === h || "undefined" === typeof h;
      }
      function Ea(h) {
        h.indexOf || (h.indexOf = eb);
        return h;
      }
      function fb(h) {
        if (va.fSDec)
          h[ia("`eeDwdouMhrudods")](ia("e`u`@ohl`uhnoHuds`uhnoDoe"), function() {
            va._fTWm && va._fTWm(h);
          });
      }
      function Ya(h, n, E) {
        E = E || "normal";
        var s2 = h + "_" + n + "_" + E, w2 = Za[s2];
        if (isNaN(w2)) {
          try {
            if (!ra) {
              var qa = document.body;
              ra = document.createElement("span");
              ra.innerHTML = "";
              var A = document.createTextNode("Mpgyi");
              ra.appendChild(A);
              qa.appendChild(ra);
            }
            ra.style.display = "";
            V(ra, { position: "absolute", left: "0px", top: "-20000px", padding: "0px", margin: "0px", border: "none", whiteSpace: "pre", lineHeight: "normal", fontFamily: h, fontSize: n + "px", fontWeight: E });
            w2 = Math.round(ra.offsetHeight);
            ra.style.display = "none";
          } catch (B2) {
            w2 = Math.ceil(1.1 * n);
          }
          w2 = Math.max(w2, n);
          Za[s2] = w2;
        }
        return w2;
      }
      function J(h, n) {
        var E = [];
        if (E = { solid: [], shortDash: [3, 1], shortDot: [1, 1], shortDashDot: [3, 1, 1, 1], shortDashDotDot: [3, 1, 1, 1, 1, 1], dot: [1, 2], dash: [4, 2], dashDot: [
          4,
          2,
          1,
          2
        ], longDash: [8, 2], longDashDot: [8, 2, 1, 2], longDashDotDot: [8, 2, 1, 2, 1, 2] }[h || "solid"])
          for (var s2 = 0; s2 < E.length; s2++)
            E[s2] *= n;
        else
          E = [];
        return E;
      }
      function P(h, n, E, w2, ha) {
        w2 = w2 || [];
        ha = s(ha) ? gb ? { passive: false, capture: false } : false : ha;
        w2.push([h, n, E, ha]);
        return h.addEventListener ? (h.addEventListener(n, E, ha), E) : h.attachEvent ? (w2 = function(n2) {
          n2 = n2 || window.event;
          n2.preventDefault = n2.preventDefault || function() {
            n2.returnValue = false;
          };
          n2.stopPropagation = n2.stopPropagation || function() {
            n2.cancelBubble = true;
          };
          E.call(h, n2);
        }, h.attachEvent(
          "on" + n,
          w2
        ), w2) : false;
      }
      function hb(h) {
        if (h._menuButton)
          h.exportEnabled ? (V(h._menuButton, { backgroundColor: h.toolbar.itemBackgroundColor, color: h.toolbar.fontColor }), Ma(h._menuButton), sa(h, h._menuButton, "menu")) : wa(h._menuButton);
        else if (h.exportEnabled && w) {
          var n = false;
          h._menuButton = document.createElement("button");
          sa(h, h._menuButton, "menu");
          h._toolBar.appendChild(h._menuButton);
          P(h._menuButton, "touchstart", function(h2) {
            n = true;
          }, h.allDOMEventHandlers);
          P(h._menuButton, "click", function() {
            "none" !== h._dropdownMenu.style.display || h._dropDownCloseTime && 500 >= (/* @__PURE__ */ new Date()).getTime() - h._dropDownCloseTime.getTime() || (h._dropdownMenu.style.display = "block", h._menuButton.blur(), h._dropdownMenu.focus());
          }, h.allDOMEventHandlers, true);
          P(h._menuButton, "mousemove", function() {
            n || (V(h._menuButton, { backgroundColor: h.toolbar.itemBackgroundColorOnHover, color: h.toolbar.fontColorOnHover }), 0 >= navigator.userAgent.search("MSIE") && V(h._menuButton.childNodes[0], { WebkitFilter: "invert(100%)", filter: "invert(100%)" }));
          }, h.allDOMEventHandlers, true);
          P(
            h._menuButton,
            "mouseout",
            function() {
              n || (V(h._menuButton, { backgroundColor: h.toolbar.itemBackgroundColor, color: h.toolbar.fontColor }), 0 >= navigator.userAgent.search("MSIE") && V(h._menuButton.childNodes[0], { WebkitFilter: "invert(0%)", filter: "invert(0%)" }));
            },
            h.allDOMEventHandlers,
            true
          );
        }
        if (h.exportEnabled && h._dropdownMenu) {
          V(h._dropdownMenu, { backgroundColor: h.toolbar.itemBackgroundColor, color: h.toolbar.fontColor });
          for (var E = h._dropdownMenu.childNodes, s2 = [h._cultureInfo.printText, h._cultureInfo.saveJPGText, h._cultureInfo.savePNGText], ha = 0; ha < E.length; ha++)
            V(E[ha], { backgroundColor: h.toolbar.itemBackgroundColor, color: h.toolbar.fontColor }), E[ha].innerHTML = s2[ha];
        } else
          !h._dropdownMenu && (h.exportEnabled && w) && (n = false, h._dropdownMenu = document.createElement("div"), h._dropdownMenu.setAttribute("tabindex", -1), E = -1 !== h.theme.indexOf("dark") ? "black" : "#888888", V(h._dropdownMenu, {
            position: "absolute",
            zIndex: 1,
            userSelect: "none",
            MozUserSeelct: "none",
            WebkitUserSelect: "none",
            msUserSelect: "none",
            cursor: "pointer",
            right: "0px",
            top: "25px",
            minWidth: "120px",
            outline: 0,
            fontSize: "14px",
            fontFamily: "Arial, Helvetica, sans-serif",
            padding: "5px 0px 5px 0px",
            textAlign: "left",
            lineHeight: "10px",
            backgroundColor: h.toolbar.itemBackgroundColor,
            boxShadow: "2px 2px 10px" + E
          }), h._dropdownMenu.style.display = "none", h._toolBar.appendChild(h._dropdownMenu), P(h._dropdownMenu, "blur", function() {
            wa(h._dropdownMenu);
            h._dropDownCloseTime = /* @__PURE__ */ new Date();
          }, h.allDOMEventHandlers, true), E = document.createElement("div"), V(E, { padding: "12px 8px 12px 8px" }), E.innerHTML = h._cultureInfo.printText, E.style.backgroundColor = h.toolbar.itemBackgroundColor, E.style.color = h.toolbar.fontColor, h._dropdownMenu.appendChild(E), P(E, "touchstart", function(h2) {
            n = true;
          }, h.allDOMEventHandlers), P(E, "mousemove", function() {
            n || (this.style.backgroundColor = h.toolbar.itemBackgroundColorOnHover, this.style.color = h.toolbar.fontColorOnHover);
          }, h.allDOMEventHandlers, true), P(E, "mouseout", function() {
            n || (this.style.backgroundColor = h.toolbar.itemBackgroundColor, this.style.color = h.toolbar.fontColor);
          }, h.allDOMEventHandlers, true), P(E, "click", function() {
            h.print();
            wa(h._dropdownMenu);
          }, h.allDOMEventHandlers, true), E = document.createElement("div"), V(E, { padding: "12px 8px 12px 8px" }), E.innerHTML = h._cultureInfo.saveJPGText, E.style.backgroundColor = h.toolbar.itemBackgroundColor, E.style.color = h.toolbar.fontColor, h._dropdownMenu.appendChild(E), P(E, "touchstart", function(h2) {
            n = true;
          }, h.allDOMEventHandlers), P(E, "mousemove", function() {
            n || (this.style.backgroundColor = h.toolbar.itemBackgroundColorOnHover, this.style.color = h.toolbar.fontColorOnHover);
          }, h.allDOMEventHandlers, true), P(
            E,
            "mouseout",
            function() {
              n || (this.style.backgroundColor = h.toolbar.itemBackgroundColor, this.style.color = h.toolbar.fontColor);
            },
            h.allDOMEventHandlers,
            true
          ), P(E, "click", function() {
            h.exportChart({ format: "jpeg", fileName: h.exportFileName });
            wa(h._dropdownMenu);
          }, h.allDOMEventHandlers, true), E = document.createElement("div"), V(E, { padding: "12px 8px 12px 8px" }), E.innerHTML = h._cultureInfo.savePNGText, E.style.backgroundColor = h.toolbar.itemBackgroundColor, E.style.color = h.toolbar.fontColor, h._dropdownMenu.appendChild(E), P(
            E,
            "touchstart",
            function(h2) {
              n = true;
            },
            h.allDOMEventHandlers
          ), P(E, "mousemove", function() {
            n || (this.style.backgroundColor = h.toolbar.itemBackgroundColorOnHover, this.style.color = h.toolbar.fontColorOnHover);
          }, h.allDOMEventHandlers, true), P(E, "mouseout", function() {
            n || (this.style.backgroundColor = h.toolbar.itemBackgroundColor, this.style.color = h.toolbar.fontColor);
          }, h.allDOMEventHandlers, true), P(E, "click", function() {
            h.exportChart({ format: "png", fileName: h.exportFileName });
            wa(h._dropdownMenu);
          }, h.allDOMEventHandlers, true));
      }
      function $a(h, n, E) {
        h *= la;
        n *= la;
        h = E.getImageData(h, n, 2, 2).data;
        n = true;
        for (E = 0; 4 > E; E++)
          if (h[E] !== h[E + 4] | h[E] !== h[E + 8] | h[E] !== h[E + 12]) {
            n = false;
            break;
          }
        return n ? h[0] << 16 | h[1] << 8 | h[2] : 0;
      }
      function ma(h, n, E) {
        return h in n ? n[h] : E[h];
      }
      function Na(h, n, E, xa) {
        w && ab ? (xa = !s(xa) && xa ? h.getContext("2d", { willReadFrequently: true }) : h.getContext("2d"), Oa = xa.webkitBackingStorePixelRatio || xa.mozBackingStorePixelRatio || xa.msBackingStorePixelRatio || xa.oBackingStorePixelRatio || xa.backingStorePixelRatio || 1, la = Sa / Oa, h.width = n * la, h.height = E * la, Sa !== Oa && (h.style.width = n + "px", h.style.height = E + "px", xa.scale(la, la))) : (h.width = n, h.height = E);
      }
      function ib(h) {
        if (!jb) {
          var n = false, E = false;
          "undefined" === typeof pa.Chart.creditHref ? (h.creditHref = ia("iuuqr;..b`ow`rkr/bnl."), h.creditText = ia("B`ow`rKR/bnl")) : (n = h.updateOption("creditText"), E = h.updateOption("creditHref"));
          if (h.creditHref && h.creditText) {
            h._creditLink || (h._creditLink = document.createElement("a"), h._creditLink.setAttribute("class", "canvasjs-chart-credit"), h._creditLink.setAttribute("title", "JavaScript Charts"), V(h._creditLink, { outline: "none", margin: "0px", position: "absolute", right: "2px", top: h.height - 14 + "px", color: "dimgrey", textDecoration: "none", fontSize: "11px", fontFamily: "Calibri, Lucida Grande, Lucida Sans Unicode, Arial, sans-serif" }), h._creditLink.setAttribute("tabIndex", -1), h._creditLink.setAttribute("target", "_blank"));
            if (0 === h.renderCount || n || E)
              h._creditLink.setAttribute("href", h.creditHref), h._creditLink.innerHTML = h.creditText;
            h._creditLink && h.creditHref && h.creditText ? (h._creditLink.parentElement || h._canvasJSContainer.appendChild(h._creditLink), h._creditLink.style.top = h.height - 14 + "px") : h._creditLink.parentElement && h._canvasJSContainer.removeChild(h._creditLink);
          }
        }
      }
      function ua(h, n, E) {
        Ia && (this.canvasCount |= 0, window.console.log(++this.canvasCount));
        var s2 = document.createElement("canvas");
        s2.setAttribute("class", "canvasjs-chart-canvas");
        Na(s2, h, n, E);
        w || "undefined" === typeof G_vmlCanvasManager || G_vmlCanvasManager.initElement(s2);
        return s2;
      }
      function V(h, n) {
        for (var s2 in n)
          h.style[s2] = n[s2];
      }
      function sa(h, n, s2) {
        n.getAttribute("state") || (n.style.backgroundColor = h.toolbar.itemBackgroundColor, n.style.color = h.toolbar.fontColor, n.style.border = "none", V(n, { WebkitUserSelect: "none", MozUserSelect: "none", msUserSelect: "none", userSelect: "none" }));
        n.getAttribute("state") !== s2 && (n.setAttribute("state", s2), n.setAttribute("type", "button"), V(n, { padding: "5px 12px", cursor: "pointer", "float": "left", width: "40px", height: "25px", outline: "0px", verticalAlign: "baseline", lineHeight: "0" }), n.innerHTML = "<img src='" + kb[s2].image + "' alt='" + h._cultureInfo[s2 + "Text"] + "' />", V(n.childNodes[0], { height: "95%", pointerEvents: "none" }));
        n.setAttribute("title", h._cultureInfo[s2 + "Text"]);
      }
      function Ma() {
        for (var h = null, n = 0; n < arguments.length; n++)
          h = arguments[n], h.style && (h.style.display = "inline");
      }
      function wa() {
        for (var h = null, n = 0; n < arguments.length; n++)
          (h = arguments[n]) && h.style && (h.style.display = "none");
      }
      function Ta(h, n, s2, w2, ha) {
        if (null === h || "undefined" === typeof h)
          return "undefined" === typeof s2 ? n : s2;
        h = parseFloat(h.toString()) * (0 <= h.toString().indexOf("%") ? n / 100 : 1);
        "undefined" !== typeof w2 && (h = Math.min(w2, h), "undefined" !== typeof ha && (h = Math.max(ha, h)));
        return !isNaN(h) && h <= n && 0 <= h ? h : "undefined" === typeof s2 ? n : s2;
      }
      function G(h, n, E, w2, ha) {
        this._defaultsKey = h;
        this._themeOptionsKey = n;
        this._index = w2;
        this.parent = ha;
        this._eventListeners = [];
        h = {};
        this.theme && s(this.parent) && s(n) && s(w2) ? h = s(this.predefinedThemes[this.theme]) ? this.predefinedThemes.light1 : this.predefinedThemes[this.theme] : this.parent && (this.parent.themeOptions && this.parent.themeOptions[n]) && (null === w2 ? h = this.parent.themeOptions[n] : 0 < this.parent.themeOptions[n].length && (w2 = Math.min(this.parent.themeOptions[n].length - 1, w2), h = this.parent.themeOptions[n][w2]));
        this.themeOptions = h;
        this.options = E ? E : { _isPlaceholder: true };
        this.setOptions(this.options, h);
      }
      function Fa(h, n, s2, w2, ha) {
        "undefined" === typeof ha && (ha = 0);
        this._padding = ha;
        this._x1 = h;
        this._y1 = n;
        this._x2 = s2;
        this._y2 = w2;
        this._rightOccupied = this._leftOccupied = this._bottomOccupied = this._topOccupied = this._padding;
      }
      function ja(h, n) {
        ja.base.constructor.call(this, "TextBlock", null, n, null, null);
        this.ctx = h;
        this._isDirty = true;
        this._wrappedText = null;
        this._initialize();
      }
      function Ua(h, n) {
        Ua.base.constructor.call(this, "Toolbar", "toolbar", n, null, h);
        this.chart = h;
        this.canvas = h.canvas;
        this.ctx = this.chart.ctx;
        this.optionsName = "toolbar";
      }
      function za(h, n) {
        za.base.constructor.call(this, "Title", "title", n, null, h);
        this.chart = h;
        this.canvas = h.canvas;
        this.ctx = this.chart.ctx;
        this.optionsName = "title";
        if (s(this.options.margin) && h.options.subtitles) {
          for (var E = h.options.subtitles, w2 = 0; w2 < E.length; w2++)
            if ((s(E[w2].horizontalAlign) && "center" === this.horizontalAlign || E[w2].horizontalAlign === this.horizontalAlign) && (s(E[w2].verticalAlign) && "top" === this.verticalAlign || E[w2].verticalAlign === this.verticalAlign) && !E[w2].dockInsidePlotArea === !this.dockInsidePlotArea) {
              this.margin = 0;
              break;
            }
        }
        "undefined" === typeof this.options.fontSize && (this.fontSize = this.chart.getAutoFontSize(this.fontSize));
        this.height = this.width = null;
        this.bounds = { x1: null, y1: null, x2: null, y2: null };
      }
      function Ja(h, n, s2) {
        Ja.base.constructor.call(this, "Subtitle", "subtitles", n, s2, h);
        this.chart = h;
        this.canvas = h.canvas;
        this.ctx = this.chart.ctx;
        this.optionsName = "subtitles";
        this.isOptionsInArray = true;
        "undefined" === typeof this.options.fontSize && (this.fontSize = this.chart.getAutoFontSize(this.fontSize));
        this.height = this.width = null;
        this.bounds = { x1: null, y1: null, x2: null, y2: null };
      }
      function Va() {
        this.pool = [];
      }
      function Ka(h) {
        var n;
        h && La[h] && (n = La[h]);
        Ka.base.constructor.call(this, "CultureInfo", null, n, null, null);
      }
      var Ia = false, va = {}, w = !!document.createElement("canvas").getContext, pa = {
        Chart: {
          width: 500,
          height: 400,
          zoomEnabled: false,
          zoomType: "x",
          backgroundColor: "white",
          theme: "light1",
          animationEnabled: false,
          animationDuration: 1200,
          dataPointWidth: null,
          dataPointMinWidth: null,
          dataPointMaxWidth: null,
          colorSet: "colorSet1",
          culture: "en",
          creditText: "CanvasJS",
          interactivityEnabled: true,
          exportEnabled: false,
          exportFileName: "Chart",
          rangeChanging: null,
          rangeChanged: null,
          publicProperties: {
            title: "readWrite",
            subtitles: "readWrite",
            toolbar: "readWrite",
            toolTip: "readWrite",
            legend: "readWrite",
            axisX: "readWrite",
            axisY: "readWrite",
            axisX2: "readWrite",
            axisY2: "readWrite",
            data: "readWrite",
            options: "readWrite",
            bounds: "readOnly",
            container: "readOnly",
            selectedColorSet: "readOnly"
          }
        },
        Title: { padding: 0, text: null, verticalAlign: "top", horizontalAlign: "center", fontSize: 20, fontFamily: "Calibri", fontWeight: "normal", fontColor: "black", fontStyle: "normal", borderThickness: 0, borderColor: "black", cornerRadius: 0, backgroundColor: w ? "transparent" : null, margin: 5, wrap: true, maxWidth: null, dockInsidePlotArea: false, publicProperties: { options: "readWrite", bounds: "readOnly", chart: "readOnly" } },
        Subtitle: { padding: 0, text: null, verticalAlign: "top", horizontalAlign: "center", fontSize: 14, fontFamily: "Calibri", fontWeight: "normal", fontColor: "black", fontStyle: "normal", borderThickness: 0, borderColor: "black", cornerRadius: 0, backgroundColor: null, margin: 2, wrap: true, maxWidth: null, dockInsidePlotArea: false, publicProperties: { options: "readWrite", bounds: "readOnly", chart: "readOnly" } },
        Toolbar: {
          itemBackgroundColor: "white",
          itemBackgroundColorOnHover: "#2196f3",
          buttonBorderColor: "#2196f3",
          buttonBorderThickness: 1,
          fontColor: "black",
          fontColorOnHover: "white",
          publicProperties: { options: "readWrite", chart: "readOnly" }
        },
        Legend: {
          name: null,
          verticalAlign: "center",
          horizontalAlign: "right",
          fontSize: 14,
          fontFamily: "calibri",
          fontWeight: "normal",
          fontColor: "black",
          fontStyle: "normal",
          cursor: null,
          itemmouseover: null,
          itemmouseout: null,
          itemmousemove: null,
          itemclick: null,
          dockInsidePlotArea: false,
          reversed: false,
          backgroundColor: w ? "transparent" : null,
          borderColor: w ? "transparent" : null,
          borderThickness: 0,
          cornerRadius: 0,
          maxWidth: null,
          maxHeight: null,
          markerMargin: null,
          itemMaxWidth: null,
          itemWidth: null,
          itemWrap: true,
          itemTextFormatter: null,
          publicProperties: { options: "readWrite", bounds: "readOnly", chart: "readOnly" }
        },
        ToolTip: { enabled: true, shared: false, animationEnabled: true, content: null, contentFormatter: null, reversed: false, backgroundColor: w ? "rgba(255,255,255,.9)" : "rgb(255,255,255)", borderColor: null, borderThickness: 2, cornerRadius: 5, fontSize: 14, fontColor: "black", fontFamily: "Calibri, Arial, Georgia, serif;", fontWeight: "normal", fontStyle: "italic", updated: null, hidden: null, publicProperties: {
          options: "readWrite",
          chart: "readOnly"
        } },
        Axis: {
          minimum: null,
          maximum: null,
          viewportMinimum: null,
          viewportMaximum: null,
          interval: null,
          intervalType: null,
          reversed: false,
          logarithmic: false,
          logarithmBase: 10,
          title: null,
          titleFontColor: "black",
          titleFontSize: 20,
          titleFontFamily: "arial",
          titleFontWeight: "normal",
          titleFontStyle: "normal",
          titleWrap: true,
          titleMaxWidth: null,
          titleBackgroundColor: w ? "transparent" : null,
          titleBorderColor: w ? "transparent" : null,
          titleBorderThickness: 0,
          titleCornerRadius: 0,
          labelAngle: 0,
          labelFontFamily: "arial",
          labelFontColor: "black",
          labelFontSize: 12,
          labelFontWeight: "normal",
          labelFontStyle: "normal",
          labelAutoFit: true,
          labelWrap: true,
          labelMaxWidth: null,
          labelFormatter: null,
          labelBackgroundColor: w ? "transparent" : null,
          labelBorderColor: w ? "transparent" : null,
          labelBorderThickness: 0,
          labelCornerRadius: 0,
          labelPlacement: "outside",
          labelTextAlign: "left",
          prefix: "",
          suffix: "",
          includeZero: false,
          tickLength: 5,
          tickColor: "black",
          tickThickness: 1,
          tickPlacement: "outside",
          lineColor: "black",
          lineThickness: 1,
          lineDashType: "solid",
          gridColor: "#A0A0A0",
          gridThickness: 0,
          gridDashType: "solid",
          interlacedColor: w ? "transparent" : null,
          valueFormatString: null,
          margin: 2,
          publicProperties: { options: "readWrite", stripLines: "readWrite", scaleBreaks: "readWrite", crosshair: "readWrite", bounds: "readOnly", chart: "readOnly" }
        },
        StripLine: {
          value: null,
          startValue: null,
          endValue: null,
          color: "orange",
          opacity: null,
          thickness: 2,
          lineDashType: "solid",
          label: "",
          labelPlacement: "inside",
          labelAlign: "far",
          labelWrap: true,
          labelMaxWidth: null,
          labelBackgroundColor: null,
          labelBorderColor: w ? "transparent" : null,
          labelBorderThickness: 0,
          labelCornerRadius: 0,
          labelFontFamily: "arial",
          labelFontColor: "orange",
          labelFontSize: 12,
          labelFontWeight: "normal",
          labelFontStyle: "normal",
          labelFormatter: null,
          showOnTop: false,
          publicProperties: { options: "readWrite", axis: "readOnly", bounds: "readOnly", chart: "readOnly" }
        },
        ScaleBreaks: { autoCalculate: false, collapsibleThreshold: "25%", maxNumberOfAutoBreaks: 2, spacing: 8, type: "straight", color: "#FFFFFF", fillOpacity: 0.9, lineThickness: 2, lineColor: "#E16E6E", lineDashType: "solid", publicProperties: {
          options: "readWrite",
          customBreaks: "readWrite",
          axis: "readOnly",
          autoBreaks: "readOnly",
          bounds: "readOnly",
          chart: "readOnly"
        } },
        Break: { startValue: null, endValue: null, spacing: 8, type: "straight", color: "#FFFFFF", fillOpacity: 0.9, lineThickness: 2, lineColor: "#E16E6E", lineDashType: "solid", publicProperties: { options: "readWrite", scaleBreaks: "readOnly", bounds: "readOnly", chart: "readOnly" } },
        Crosshair: {
          enabled: false,
          snapToDataPoint: false,
          color: "grey",
          opacity: null,
          thickness: 2,
          lineDashType: "solid",
          label: "",
          labelWrap: true,
          labelMaxWidth: null,
          labelBackgroundColor: w ? "grey" : null,
          labelBorderColor: w ? "grey" : null,
          labelBorderThickness: 0,
          labelCornerRadius: 0,
          labelFontFamily: w ? "Calibri, Optima, Candara, Verdana, Geneva, sans-serif" : "calibri",
          labelFontSize: 12,
          labelFontColor: "#fff",
          labelFontWeight: "normal",
          labelFontStyle: "normal",
          labelFormatter: null,
          valueFormatString: null,
          updated: null,
          hidden: null,
          publicProperties: { options: "readWrite", axis: "readOnly", bounds: "readOnly", chart: "readOnly" }
        },
        DataSeries: {
          name: null,
          dataPoints: null,
          label: "",
          bevelEnabled: false,
          highlightEnabled: true,
          cursor: "default",
          indexLabel: "",
          indexLabelPlacement: "auto",
          indexLabelOrientation: "horizontal",
          indexLabelTextAlign: "left",
          indexLabelFontColor: "black",
          indexLabelFontSize: 12,
          indexLabelFontStyle: "normal",
          indexLabelFontFamily: "Arial",
          indexLabelFontWeight: "normal",
          indexLabelBackgroundColor: null,
          indexLabelLineColor: "gray",
          indexLabelLineThickness: 1,
          indexLabelLineDashType: "solid",
          indexLabelMaxWidth: null,
          indexLabelWrap: true,
          indexLabelFormatter: null,
          lineThickness: 2,
          lineDashType: "solid",
          connectNullData: false,
          nullDataLineDashType: "dash",
          color: null,
          lineColor: null,
          risingColor: "white",
          fallingColor: "red",
          fillOpacity: null,
          startAngle: 0,
          radius: null,
          innerRadius: null,
          neckHeight: null,
          neckWidth: null,
          reversed: false,
          valueRepresents: null,
          linkedDataSeriesIndex: null,
          whiskerThickness: 2,
          whiskerDashType: "solid",
          whiskerColor: null,
          whiskerLength: null,
          stemThickness: 2,
          stemColor: null,
          stemDashType: "solid",
          upperBoxColor: "white",
          lowerBoxColor: "white",
          type: "column",
          xValueType: "number",
          axisXType: "primary",
          axisYType: "primary",
          axisXIndex: 0,
          axisYIndex: 0,
          xValueFormatString: null,
          yValueFormatString: null,
          zValueFormatString: null,
          percentFormatString: null,
          showInLegend: null,
          legendMarkerType: null,
          legendMarkerColor: null,
          legendText: null,
          legendMarkerBorderColor: w ? "transparent" : null,
          legendMarkerBorderThickness: 0,
          markerType: "circle",
          markerColor: null,
          markerSize: null,
          markerBorderColor: w ? "transparent" : null,
          markerBorderThickness: 0,
          mouseover: null,
          mouseout: null,
          mousemove: null,
          click: null,
          toolTipContent: null,
          visible: true,
          publicProperties: {
            options: "readWrite",
            axisX: "readWrite",
            axisY: "readWrite",
            chart: "readOnly"
          }
        },
        TextBlock: { x: 0, y: 0, width: null, height: null, maxWidth: null, maxHeight: null, padding: 0, angle: 0, text: "", horizontalAlign: "center", textAlign: "left", fontSize: 12, fontFamily: "calibri", fontWeight: "normal", fontColor: "black", fontStyle: "normal", borderThickness: 0, borderColor: "black", cornerRadius: 0, backgroundColor: null, textBaseline: "top" },
        CultureInfo: {
          decimalSeparator: ".",
          digitGroupSeparator: ",",
          zoomText: "Zoom",
          panText: "Pan",
          resetText: "Reset",
          menuText: "More Options",
          saveJPGText: "Save as JPEG",
          savePNGText: "Save as PNG",
          printText: "Print",
          days: "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),
          shortDays: "Sun Mon Tue Wed Thu Fri Sat".split(" "),
          months: "January February March April May June July August September October November December".split(" "),
          shortMonths: "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" ")
        }
      }, La = { en: {} }, B = w ? "Trebuchet MS, Helvetica, sans-serif" : "Arial", Ga = w ? "Impact, Charcoal, sans-serif" : "Arial", Aa = {
        colorSet1: "#4F81BC #C0504E #9BBB58 #23BFAA #8064A1 #4AACC5 #F79647 #7F6084 #77A033 #33558B #E59566".split(" "),
        colorSet2: "#6D78AD #51CDA0 #DF7970 #4C9CA0 #AE7D99 #C9D45C #5592AD #DF874D #52BCA8 #8E7AA3 #E3CB64 #C77B85 #C39762 #8DD17E #B57952 #FCC26C".split(" "),
        colorSet3: "#8CA1BC #36845C #017E82 #8CB9D0 #708C98 #94838D #F08891 #0366A7 #008276 #EE7757 #E5BA3A #F2990B #03557B #782970".split(" ")
      }, K, aa, Q, U, Z;
      aa = "#333333";
      Q = "#000000";
      K = "#666666";
      Z = U = "#000000";
      var fa = 20, v = 14, Wa = {
        colorSet: "colorSet1",
        backgroundColor: "#FFFFFF",
        title: {
          fontFamily: Ga,
          fontSize: 32,
          fontColor: aa,
          fontWeight: "normal",
          verticalAlign: "top",
          margin: 5
        },
        subtitles: [{ fontFamily: Ga, fontSize: v, fontColor: aa, fontWeight: "normal", verticalAlign: "top", margin: 5 }],
        data: [{ indexLabelFontFamily: B, indexLabelFontSize: v, indexLabelFontColor: aa, indexLabelFontWeight: "normal", indexLabelLineThickness: 1 }],
        axisX: [{ titleFontFamily: B, titleFontSize: fa, titleFontColor: aa, titleFontWeight: "normal", labelFontFamily: B, labelFontSize: v, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: K, tickThickness: 1, tickColor: K, gridThickness: 0, gridColor: K, stripLines: [{
          labelFontFamily: B,
          labelFontSize: v,
          labelFontColor: "#FF7300",
          labelFontWeight: "normal",
          labelBackgroundColor: null,
          color: "#FF7300",
          thickness: 1
        }], crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#EEEEEE", labelFontWeight: "normal", labelBackgroundColor: Z, color: U, thickness: 1, lineDashType: "dash" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" } }],
        axisX2: [{
          titleFontFamily: B,
          titleFontSize: fa,
          titleFontColor: aa,
          titleFontWeight: "normal",
          labelFontFamily: B,
          labelFontSize: v,
          labelFontColor: Q,
          labelFontWeight: "normal",
          lineThickness: 1,
          lineColor: K,
          tickThickness: 1,
          tickColor: K,
          gridThickness: 0,
          gridColor: K,
          stripLines: [{ labelFontFamily: B, labelFontSize: v, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }],
          crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#EEEEEE", labelFontWeight: "normal", labelBackgroundColor: Z, color: U, thickness: 1, lineDashType: "dash" },
          scaleBreaks: {
            type: "zigzag",
            spacing: "2%",
            lineColor: "#BBBBBB",
            lineThickness: 1,
            lineDashType: "solid"
          }
        }],
        axisY: [{ titleFontFamily: B, titleFontSize: fa, titleFontColor: aa, titleFontWeight: "normal", labelFontFamily: B, labelFontSize: v, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: K, tickThickness: 1, tickColor: K, gridThickness: 1, gridColor: K, stripLines: [{ labelFontFamily: B, labelFontSize: v, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }], crosshair: {
          labelFontFamily: B,
          labelFontSize: v,
          labelFontColor: "#EEEEEE",
          labelFontWeight: "normal",
          labelBackgroundColor: Z,
          color: U,
          thickness: 1,
          lineDashType: "dash"
        }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" } }],
        axisY2: [{ titleFontFamily: B, titleFontSize: fa, titleFontColor: aa, titleFontWeight: "normal", labelFontFamily: B, labelFontSize: v, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: K, tickThickness: 1, tickColor: K, gridThickness: 1, gridColor: K, stripLines: [{
          labelFontFamily: B,
          labelFontSize: v,
          labelFontColor: "#FF7300",
          labelFontWeight: "normal",
          labelBackgroundColor: null,
          color: "#FF7300",
          thickness: 1
        }], crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#EEEEEE", labelFontWeight: "normal", labelBackgroundColor: Z, color: U, thickness: 1, lineDashType: "dash" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" } }],
        legend: { fontFamily: B, fontSize: 14, fontColor: aa, fontWeight: "bold", verticalAlign: "bottom", horizontalAlign: "center" },
        toolTip: { fontFamily: B, fontSize: 14, fontStyle: "normal", cornerRadius: 0, borderThickness: 1 },
        toolbar: { itemBackgroundColor: "white", itemBackgroundColorOnHover: "#2196f3", buttonBorderColor: "#2196f3", buttonBorderThickness: 1, fontColor: "black", fontColorOnHover: "white" }
      };
      Q = aa = "#F5F5F5";
      K = "#FFFFFF";
      U = "#40BAF1";
      Z = "#F5F5F5";
      var fa = 20, v = 14, bb = { colorSet: "colorSet2", title: { fontFamily: B, fontSize: 33, fontColor: "#3A3A3A", fontWeight: "bold", verticalAlign: "top", margin: 5 }, subtitles: [{ fontFamily: B, fontSize: v, fontColor: "#3A3A3A", fontWeight: "normal", verticalAlign: "top", margin: 5 }], data: [{
        indexLabelFontFamily: B,
        indexLabelFontSize: v,
        indexLabelFontColor: "#666666",
        indexLabelFontWeight: "normal",
        indexLabelLineThickness: 1
      }], axisX: [{ titleFontFamily: B, titleFontSize: fa, titleFontColor: "#666666", titleFontWeight: "normal", labelFontFamily: B, labelFontSize: v, labelFontColor: "#666666", labelFontWeight: "normal", lineThickness: 1, lineColor: "#BBBBBB", tickThickness: 1, tickColor: "#BBBBBB", gridThickness: 1, gridColor: "#BBBBBB", stripLines: [{
        labelFontFamily: B,
        labelFontSize: v,
        labelFontColor: "#FFA500",
        labelFontWeight: "normal",
        labelBackgroundColor: null,
        color: "#FFA500",
        thickness: 1
      }], crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#EEEEEE", labelFontWeight: "normal", labelBackgroundColor: "black", color: "black", thickness: 1, lineDashType: "dot" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" } }], axisX2: [{
        titleFontFamily: B,
        titleFontSize: fa,
        titleFontColor: "#666666",
        titleFontWeight: "normal",
        labelFontFamily: B,
        labelFontSize: v,
        labelFontColor: "#666666",
        labelFontWeight: "normal",
        lineThickness: 1,
        lineColor: "#BBBBBB",
        tickColor: "#BBBBBB",
        tickThickness: 1,
        gridThickness: 1,
        gridColor: "#BBBBBB",
        stripLines: [{ labelFontFamily: B, labelFontSize: v, labelFontColor: "#FFA500", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FFA500", thickness: 1 }],
        crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#EEEEEE", labelFontWeight: "normal", labelBackgroundColor: "black", color: "black", thickness: 1, lineDashType: "dot" },
        scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" }
      }], axisY: [{
        titleFontFamily: B,
        titleFontSize: fa,
        titleFontColor: "#666666",
        titleFontWeight: "normal",
        labelFontFamily: B,
        labelFontSize: v,
        labelFontColor: "#666666",
        labelFontWeight: "normal",
        lineThickness: 0,
        lineColor: "#BBBBBB",
        tickColor: "#BBBBBB",
        tickThickness: 1,
        gridThickness: 1,
        gridColor: "#BBBBBB",
        stripLines: [{ labelFontFamily: B, labelFontSize: v, labelFontColor: "#FFA500", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FFA500", thickness: 1 }],
        crosshair: {
          labelFontFamily: B,
          labelFontSize: v,
          labelFontColor: "#EEEEEE",
          labelFontWeight: "normal",
          labelBackgroundColor: "black",
          color: "black",
          thickness: 1,
          lineDashType: "dot"
        },
        scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" }
      }], axisY2: [{ titleFontFamily: B, titleFontSize: fa, titleFontColor: "#666666", titleFontWeight: "normal", labelFontFamily: B, labelFontSize: v, labelFontColor: "#666666", labelFontWeight: "normal", lineThickness: 0, lineColor: "#BBBBBB", tickColor: "#BBBBBB", tickThickness: 1, gridThickness: 1, gridColor: "#BBBBBB", stripLines: [{
        labelFontFamily: B,
        labelFontSize: v,
        labelFontColor: "#FFA500",
        labelFontWeight: "normal",
        labelBackgroundColor: null,
        color: "#FFA500",
        thickness: 1
      }], crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#EEEEEE", labelFontWeight: "normal", labelBackgroundColor: "black", color: "black", thickness: 1, lineDashType: "dot" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" } }], legend: { fontFamily: B, fontSize: 14, fontColor: "#3A3A3A", fontWeight: "bold", verticalAlign: "bottom", horizontalAlign: "center" }, toolTip: {
        fontFamily: B,
        fontSize: 14,
        fontStyle: "normal",
        cornerRadius: 0,
        borderThickness: 1
      }, toolbar: { itemBackgroundColor: "white", itemBackgroundColorOnHover: "#2196f3", buttonBorderColor: "#2196f3", buttonBorderThickness: 1, fontColor: "black", fontColorOnHover: "white" } };
      Q = aa = "#F5F5F5";
      K = "#FFFFFF";
      U = "#40BAF1";
      Z = "#F5F5F5";
      fa = 20;
      v = 14;
      Ga = { colorSet: "colorSet12", backgroundColor: "#2A2A2A", title: { fontFamily: Ga, fontSize: 32, fontColor: aa, fontWeight: "normal", verticalAlign: "top", margin: 5 }, subtitles: [{
        fontFamily: Ga,
        fontSize: v,
        fontColor: aa,
        fontWeight: "normal",
        verticalAlign: "top",
        margin: 5
      }], toolbar: { itemBackgroundColor: "#666666", itemBackgroundColorOnHover: "#FF7372", buttonBorderColor: "#FF7372", buttonBorderThickness: 1, fontColor: "#F5F5F5", fontColorOnHover: "#F5F5F5" }, data: [{ indexLabelFontFamily: B, indexLabelFontSize: v, indexLabelFontColor: Q, indexLabelFontWeight: "normal", indexLabelLineThickness: 1 }], axisX: [{
        titleFontFamily: B,
        titleFontSize: fa,
        titleFontColor: Q,
        titleFontWeight: "normal",
        labelFontFamily: B,
        labelFontSize: v,
        labelFontColor: Q,
        labelFontWeight: "normal",
        lineThickness: 1,
        lineColor: K,
        tickThickness: 1,
        tickColor: K,
        gridThickness: 0,
        gridColor: K,
        stripLines: [{ labelFontFamily: B, labelFontSize: v, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }],
        crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: Z, color: U, thickness: 1, lineDashType: "dash" },
        scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" }
      }], axisX2: [{
        titleFontFamily: B,
        titleFontSize: fa,
        titleFontColor: Q,
        titleFontWeight: "normal",
        labelFontFamily: B,
        labelFontSize: v,
        labelFontColor: Q,
        labelFontWeight: "normal",
        lineThickness: 1,
        lineColor: K,
        tickThickness: 1,
        tickColor: K,
        gridThickness: 0,
        gridColor: K,
        stripLines: [{ labelFontFamily: B, labelFontSize: v, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }],
        crosshair: {
          labelFontFamily: B,
          labelFontSize: v,
          labelFontColor: "#000000",
          labelFontWeight: "normal",
          labelBackgroundColor: Z,
          color: U,
          thickness: 1,
          lineDashType: "dash"
        },
        scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" }
      }], axisY: [{ titleFontFamily: B, titleFontSize: fa, titleFontColor: Q, titleFontWeight: "normal", labelFontFamily: B, labelFontSize: v, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: K, tickThickness: 1, tickColor: K, gridThickness: 1, gridColor: K, stripLines: [{
        labelFontFamily: B,
        labelFontSize: v,
        labelFontColor: "#FF7300",
        labelFontWeight: "normal",
        labelBackgroundColor: null,
        color: "#FF7300",
        thickness: 1
      }], crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: Z, color: U, thickness: 1, lineDashType: "dash" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" } }], axisY2: [{
        titleFontFamily: B,
        titleFontSize: fa,
        titleFontColor: Q,
        titleFontWeight: "normal",
        labelFontFamily: B,
        labelFontSize: v,
        labelFontColor: Q,
        labelFontWeight: "normal",
        lineThickness: 1,
        lineColor: K,
        tickThickness: 1,
        tickColor: K,
        gridThickness: 1,
        gridColor: K,
        stripLines: [{ labelFontFamily: B, labelFontSize: v, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }],
        crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: Z, color: U, thickness: 1, lineDashType: "dash" },
        scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" }
      }], legend: {
        fontFamily: B,
        fontSize: 14,
        fontColor: aa,
        fontWeight: "bold",
        verticalAlign: "bottom",
        horizontalAlign: "center"
      }, toolTip: { fontFamily: B, fontSize: 14, fontStyle: "normal", cornerRadius: 0, borderThickness: 1, fontColor: Q, backgroundColor: "rgba(0, 0, 0, .7)" } };
      K = "#FFFFFF";
      Q = aa = "#FAFAFA";
      U = "#40BAF1";
      Z = "#F5F5F5";
      var fa = 20, v = 14, cb = { light1: Wa, light2: bb, dark1: Ga, dark2: {
        colorSet: "colorSet2",
        backgroundColor: "#32373A",
        title: { fontFamily: B, fontSize: 32, fontColor: aa, fontWeight: "normal", verticalAlign: "top", margin: 5 },
        subtitles: [{
          fontFamily: B,
          fontSize: v,
          fontColor: aa,
          fontWeight: "normal",
          verticalAlign: "top",
          margin: 5
        }],
        toolbar: { itemBackgroundColor: "#666666", itemBackgroundColorOnHover: "#FF7372", buttonBorderColor: "#FF7372", buttonBorderThickness: 1, fontColor: "#F5F5F5", fontColorOnHover: "#F5F5F5" },
        data: [{ indexLabelFontFamily: B, indexLabelFontSize: v, indexLabelFontColor: Q, indexLabelFontWeight: "normal", indexLabelLineThickness: 1 }],
        axisX: [{
          titleFontFamily: B,
          titleFontSize: fa,
          titleFontColor: Q,
          titleFontWeight: "normal",
          labelFontFamily: B,
          labelFontSize: v,
          labelFontColor: Q,
          labelFontWeight: "normal",
          lineThickness: 1,
          lineColor: K,
          tickThickness: 1,
          tickColor: K,
          gridThickness: 0,
          gridColor: K,
          stripLines: [{ labelFontFamily: B, labelFontSize: v, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }],
          crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: Z, color: U, thickness: 1, lineDashType: "dash" },
          scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" }
        }],
        axisX2: [{ titleFontFamily: B, titleFontSize: fa, titleFontColor: Q, titleFontWeight: "normal", labelFontFamily: B, labelFontSize: v, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: K, tickThickness: 1, tickColor: K, gridThickness: 0, gridColor: K, stripLines: [{ labelFontFamily: B, labelFontSize: v, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }], crosshair: {
          labelFontFamily: B,
          labelFontSize: v,
          labelFontColor: "#000000",
          labelFontWeight: "normal",
          labelBackgroundColor: Z,
          color: U,
          thickness: 1,
          lineDashType: "dash"
        }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" } }],
        axisY: [{ titleFontFamily: B, titleFontSize: fa, titleFontColor: Q, titleFontWeight: "normal", labelFontFamily: B, labelFontSize: v, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 0, lineColor: K, tickThickness: 1, tickColor: K, gridThickness: 1, gridColor: K, stripLines: [{
          labelFontFamily: B,
          labelFontSize: v,
          labelFontColor: "#FF7300",
          labelFontWeight: "normal",
          labelBackgroundColor: null,
          color: "#FF7300",
          thickness: 1
        }], crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: Z, color: U, thickness: 1, lineDashType: "dash" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" } }],
        axisY2: [{
          titleFontFamily: B,
          titleFontSize: fa,
          titleFontColor: Q,
          titleFontWeight: "normal",
          labelFontFamily: B,
          labelFontSize: v,
          labelFontColor: Q,
          labelFontWeight: "normal",
          lineThickness: 0,
          lineColor: K,
          tickThickness: 1,
          tickColor: K,
          gridThickness: 1,
          gridColor: K,
          stripLines: [{ labelFontFamily: B, labelFontSize: v, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }],
          crosshair: { labelFontFamily: B, labelFontSize: v, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: Z, color: U, thickness: 1, lineDashType: "dash" },
          scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" }
        }],
        legend: {
          fontFamily: B,
          fontSize: 14,
          fontColor: aa,
          fontWeight: "bold",
          verticalAlign: "bottom",
          horizontalAlign: "center"
        },
        toolTip: { fontFamily: B, fontSize: 14, fontStyle: "normal", cornerRadius: 0, borderThickness: 1, fontColor: Q, backgroundColor: "rgba(0, 0, 0, .7)" }
      }, theme1: Wa, theme2: bb, theme3: Wa }, T = { numberDuration: 1, yearDuration: 314496e5, monthDuration: 2592e6, weekDuration: 6048e5, dayDuration: 864e5, hourDuration: 36e5, minuteDuration: 6e4, secondDuration: 1e3, millisecondDuration: 1, dayOfWeekFromInt: "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" ") };
      (function() {
        va.fSDec = function(h) {
          for (var n = "", s2 = 0; s2 < h.length; s2++)
            n += String.fromCharCode(Math.ceil(h.length / 57 / 5) ^ h.charCodeAt(s2));
          return n;
        };
        delete pa[va.fSDec("Bi`su")][va.fSDec("bsdehuIsdg")];
        va.pro = { sCH: pa[va.fSDec("Bi`su")][va.fSDec("bsdehuIsdg")] };
      })();
      var gb = function() {
        var h = false;
        try {
          var n = Object.defineProperty && Object.defineProperty({}, "passive", { get: function() {
            h = true;
            return false;
          } });
          window.addEventListener && (window.addEventListener("test", null, n), window.removeEventListener("test", null, n));
        } catch (s2) {
          h = false;
        }
        return h;
      }(), Za = {}, ra = null, lb = function() {
        this.ctx.clearRect(0, 0, this.width, this.height);
        this.backgroundColor && (this.ctx.fillStyle = this.backgroundColor, this.ctx.fillRect(0, 0, this.width, this.height));
      }, ya = function(h) {
        h.width = 1;
        h.height = 1;
        h.getContext("2d") && h.getContext("2d").clearRect(0, 0, 1, 1);
      }, mb = function(h, n, s2) {
        n = Math.min(this.width, this.height);
        return Math.max("theme4" === this.theme ? 0 : 300 <= n ? 12 : 11, Math.round(n * (h / 400)));
      }, Ba = function() {
        var h = /D{1,4}|M{1,4}|Y{1,4}|h{1,2}|H{1,2}|m{1,2}|s{1,2}|f{1,3}|t{1,2}|T{1,2}|K|z{1,3}|"[^"]*"|'[^']*'/g, n = "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "), s2 = "Sun Mon Tue Wed Thu Fri Sat".split(" "), w2 = "January February March April May June July August September October November December".split(" "), ha = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "), B2 = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g, A = /[^-+\dA-Z]/g;
        return function(v2, J2, N) {
          var K2 = N ? N.days : n, X2 = N ? N.months : w2, P2 = N ? N.shortDays : s2, T2 = N ? N.shortMonths : ha;
          N = "";
          var V2 = false;
          v2 = v2 && v2.getTime ? v2 : v2 ? new Date(v2) : /* @__PURE__ */ new Date();
          if (isNaN(v2))
            throw SyntaxError("invalid date");
          "UTC:" === J2.slice(0, 4) && (J2 = J2.slice(4), V2 = true);
          N = V2 ? "getUTC" : "get";
          var G2 = v2[N + "Date"](), M = v2[N + "Day"](), W = v2[N + "Month"](), a = v2[N + "FullYear"](), d = v2[N + "Hours"](), c = v2[N + "Minutes"](), b = v2[N + "Seconds"](), e = v2[N + "Milliseconds"](), f = V2 ? 0 : v2.getTimezoneOffset();
          return N = J2.replace(h, function(l) {
            switch (l) {
              case "D":
                return G2;
              case "DD":
                return ca(G2, 2);
              case "DDD":
                return P2[M];
              case "DDDD":
                return K2[M];
              case "M":
                return W + 1;
              case "MM":
                return ca(W + 1, 2);
              case "MMM":
                return T2[W];
              case "MMMM":
                return X2[W];
              case "Y":
                return parseInt(String(a).slice(-2));
              case "YY":
                return ca(String(a).slice(-2), 2);
              case "YYY":
                return ca(String(a).slice(-3), 3);
              case "YYYY":
                return ca(a, 4);
              case "h":
                return d % 12 || 12;
              case "hh":
                return ca(d % 12 || 12, 2);
              case "H":
                return d;
              case "HH":
                return ca(d, 2);
              case "m":
                return c;
              case "mm":
                return ca(c, 2);
              case "s":
                return b;
              case "ss":
                return ca(b, 2);
              case "f":
                return ca(String(e), 3).slice(0, 1);
              case "ff":
                return ca(String(e), 3).slice(
                  0,
                  2
                );
              case "fff":
                return ca(String(e), 3).slice(0, 3);
              case "t":
                return 12 > d ? "a" : "p";
              case "tt":
                return 12 > d ? "am" : "pm";
              case "T":
                return 12 > d ? "A" : "P";
              case "TT":
                return 12 > d ? "AM" : "PM";
              case "K":
                return V2 ? "UTC" : (String(v2).match(B2) || [""]).pop().replace(A, "");
              case "z":
                return (0 < f ? "-" : "+") + Math.floor(Math.abs(f) / 60);
              case "zz":
                return (0 < f ? "-" : "+") + ca(Math.floor(Math.abs(f) / 60), 2);
              case "zzz":
                return (0 < f ? "-" : "+") + ca(Math.floor(Math.abs(f) / 60), 2) + ca(Math.abs(f) % 60, 2);
              default:
                return l.slice(1, l.length - 1);
            }
          });
        };
      }(), nb = function(h) {
        var n = 0 > h;
        if (1 > Math.abs(h)) {
          var s2 = parseInt(h.toString().split("e-")[1]);
          s2 && (h = (n ? -1 * h : h) * Math.pow(10, s2 - 1), h = "0." + Array(s2).join("0") + h.toString().substring(2), h = n ? "-" + h : h);
        } else
          s2 = parseInt(h.toString().split("+")[1]), 20 < s2 && (s2 -= 20, h /= Math.pow(10, s2), h = h.toString() + Array(s2 + 1).join("0"));
        return String(h);
      }, da = function(h, n, s2) {
        if (null === h)
          return "";
        if (!isFinite(h))
          return h;
        h = Number(h);
        var w2 = 0 > h ? true : false;
        w2 && (h *= -1);
        var B2 = s2 ? s2.decimalSeparator : ".", v2 = s2 ? s2.digitGroupSeparator : ",", A = "";
        n = String(n);
        var A = 1, J2 = s2 = "", K2 = -1, N = [], X2 = [], P2 = 0, T2 = 0, V2 = 0, G2 = false, Q2 = 0, J2 = n.match(/"[^"]*"|'[^']*'|[eE][+-]*[0]+|[,]+[.]|\u2030|./g);
        n = null;
        for (var M = 0; J2 && M < J2.length; M++)
          if (n = J2[M], "." === n && 0 > K2)
            K2 = M;
          else {
            if ("%" === n)
              A *= 100;
            else if ("‰" === n) {
              A *= 1e3;
              continue;
            } else if ("," === n[0] && "." === n[n.length - 1]) {
              A /= Math.pow(1e3, n.length - 1);
              K2 = M + n.length - 1;
              continue;
            } else
              "E" !== n[0] && "e" !== n[0] || "0" !== n[n.length - 1] || (G2 = true);
            0 > K2 ? (N.push(n), "#" === n || "0" === n ? P2++ : "," === n && V2++) : (X2.push(n), "#" !== n && "0" !== n || T2++);
          }
        G2 && (n = Math.floor(h), J2 = -Math.floor(Math.log(h) / Math.LN10 + 1), Q2 = 0 === h ? 0 : 0 === n ? -(P2 + J2) : nb(n).length - P2, A /= Math.pow(10, Q2));
        0 > K2 && (K2 = M);
        A = (h * A).toFixed(T2);
        n = A.split(".");
        A = (n[0] + "").split("");
        h = (n[1] + "").split("");
        A && "0" === A[0] && A.shift();
        for (G2 = J2 = M = T2 = K2 = 0; 0 < N.length; )
          if (n = N.pop(), "#" === n || "0" === n)
            if (K2++, K2 === P2) {
              var W = A, A = [];
              if ("0" === n)
                for (n = P2 - T2 - (W ? W.length : 0); 0 < n; )
                  W.unshift("0"), n--;
              for (; 0 < W.length; )
                s2 = W.pop() + s2, G2++, 0 === G2 % J2 && (M === V2 && 0 < W.length) && (s2 = v2 + s2);
            } else
              0 < A.length ? (s2 = A.pop() + s2, T2++, G2++) : "0" === n && (s2 = "0" + s2, T2++, G2++), 0 === G2 % J2 && (M === V2 && 0 < A.length) && (s2 = v2 + s2);
          else
            "E" !== n[0] && "e" !== n[0] || "0" !== n[n.length - 1] || !/[eE][+-]*[0]+/.test(n) ? "," === n ? (M++, J2 = G2, G2 = 0, 0 < A.length && (s2 = v2 + s2)) : s2 = 1 < n.length && ('"' === n[0] && '"' === n[n.length - 1] || "'" === n[0] && "'" === n[n.length - 1]) ? n.slice(1, n.length - 1) + s2 : n + s2 : (n = 0 > Q2 ? n.replace("+", "").replace("-", "") : n.replace("-", ""), s2 += n.replace(/[0]+/, function(a) {
              return ca(Q2, a.length);
            }));
        v2 = "";
        for (N = false; 0 < X2.length; )
          n = X2.shift(), "#" === n || "0" === n ? 0 < h.length && 0 !== Number(h.join("")) ? (v2 += h.shift(), N = true) : "0" === n && (v2 += "0", N = true) : 1 < n.length && ('"' === n[0] && '"' === n[n.length - 1] || "'" === n[0] && "'" === n[n.length - 1]) ? v2 += n.slice(1, n.length - 1) : "E" !== n[0] && "e" !== n[0] || "0" !== n[n.length - 1] || !/[eE][+-]*[0]+/.test(n) ? v2 += n : (n = 0 > Q2 ? n.replace("+", "").replace("-", "") : n.replace("-", ""), v2 += n.replace(/[0]+/, function(a) {
            return ca(Q2, a.length);
          }));
        s2 += (N ? B2 : "") + v2;
        return w2 ? "-" + s2 : s2;
      }, Pa = function(h) {
        var n = 0, s2 = 0;
        h = h || window.event;
        h.offsetX || 0 === h.offsetX ? (n = h.offsetX, s2 = h.offsetY) : h.layerX || 0 == h.layerX ? (n = h.layerX, s2 = h.layerY) : (n = h.pageX - h.target.offsetLeft, s2 = h.pageY - h.target.offsetTop);
        return { x: n, y: s2 };
      }, ab = true, Sa = window.devicePixelRatio || 1, Oa = 1, la = ab ? Sa / Oa : 1, Y = function(h, n, s2, w2, v2, B2, A, J2, K2, N, X2, T2, P2) {
        "undefined" === typeof P2 && (P2 = 1);
        A = A || 0;
        J2 = J2 || "black";
        var G2 = 15 < w2 - n && 15 < v2 - s2 ? 8 : 0.35 * Math.min(w2 - n, v2 - s2);
        h.beginPath();
        h.moveTo(n, s2);
        h.save();
        h.fillStyle = B2;
        h.globalAlpha = P2;
        h.fillRect(n, s2, w2 - n, v2 - s2);
        h.globalAlpha = 1;
        0 < A && (P2 = 0 === A % 2 ? 0 : 0.5, h.beginPath(), h.lineWidth = A, h.strokeStyle = J2, h.moveTo(n, s2), h.rect(n - P2, s2 - P2, w2 - n + 2 * P2, v2 - s2 + 2 * P2), h.stroke());
        h.restore();
        true === K2 && (h.save(), h.beginPath(), h.moveTo(n, s2), h.lineTo(n + G2, s2 + G2), h.lineTo(w2 - G2, s2 + G2), h.lineTo(w2, s2), h.closePath(), A = h.createLinearGradient((w2 + n) / 2, s2 + G2, (w2 + n) / 2, s2), A.addColorStop(0, B2), A.addColorStop(1, "rgba(255, 255, 255, .4)"), h.fillStyle = A, h.fill(), h.restore());
        true === N && (h.save(), h.beginPath(), h.moveTo(n, v2), h.lineTo(n + G2, v2 - G2), h.lineTo(w2 - G2, v2 - G2), h.lineTo(w2, v2), h.closePath(), A = h.createLinearGradient((w2 + n) / 2, v2 - G2, (w2 + n) / 2, v2), A.addColorStop(0, B2), A.addColorStop(1, "rgba(255, 255, 255, .4)"), h.fillStyle = A, h.fill(), h.restore());
        true === X2 && (h.save(), h.beginPath(), h.moveTo(n, s2), h.lineTo(n + G2, s2 + G2), h.lineTo(n + G2, v2 - G2), h.lineTo(n, v2), h.closePath(), A = h.createLinearGradient(n + G2, (v2 + s2) / 2, n, (v2 + s2) / 2), A.addColorStop(0, B2), A.addColorStop(1, "rgba(255, 255, 255, 0.1)"), h.fillStyle = A, h.fill(), h.restore());
        true === T2 && (h.save(), h.beginPath(), h.moveTo(w2, s2), h.lineTo(w2 - G2, s2 + G2), h.lineTo(w2 - G2, v2 - G2), h.lineTo(w2, v2), A = h.createLinearGradient(w2 - G2, (v2 + s2) / 2, w2, (v2 + s2) / 2), A.addColorStop(0, B2), A.addColorStop(1, "rgba(255, 255, 255, 0.1)"), h.fillStyle = A, A.addColorStop(0, B2), A.addColorStop(1, "rgba(255, 255, 255, 0.1)"), h.fillStyle = A, h.fill(), h.closePath(), h.restore());
      }, ia = function(h) {
        for (var n = "", s2 = 0; s2 < h.length; s2++)
          n += String.fromCharCode(Math.ceil(h.length / 57 / 5) ^ h.charCodeAt(s2));
        return n;
      }, jb = window && (window[ia("mnb`uhno")] && window[ia("mnb`uhno")].href && window[ia("mnb`uhno")].href.indexOf && (-1 !== window[ia("mnb`uhno")].href.indexOf(ia("b`ow`rkr/bnl")) || -1 !== window[ia("mnb`uhno")].href.indexOf(ia("gdonqhy/bnl")) || -1 !== window[ia("mnb`uhno")].href.indexOf(ia("gheemd")))) && -1 === window[ia("mnb`uhno")].href.indexOf(ia("gheemd")), kb = {
        reset: { image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAeCAYAAABJ/8wUAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAPjSURBVFhHxVdJaFNRFP1J/jwkP5MxsbaC1WJEglSxOFAXIsFpVRE3ggi1K90obioRRBA33XXnQnciirhQcMCdorgQxBkXWlREkFKsWkv5npvckp/XnzRpKh64kLw733fffe9L/wrL0+mVUdO8uTSZ3MBL/we2qg4rkuSpodCELstXE46ziVkLQ6FQcGOmeSSq6wd4aV50d3drWjj8kQKZJTUc9kxFGenv79dZrDksTSTWWJp2QYtEPiErysyzdX0LsxsCQR8keX8gs6RHIk8ysdgKFg2G53mhuOPsshTlBjKaFo1g7SqLNoShKLdFXT8huQ/paLSbxatYnc2mHMM4hr18Vi8TIvCmXF3vYrW6cF23gGTOk0M1wA4RKvOmq6vLZRVJipvmSWT6tZ6CSEYkco5V50VPT4+D7RwOqi6RiSZm0fJ+vggSqkeoypdsNmuyelNwbXsbgvkWYMtzDWNvWaijoyOBqE+hVK8abcssUeXQ/YfKyi0gFYv1Ipgfoj34fYGTJLOYJA0ODirok32GLN8XhUWCwSes1hIwBg6LydJ/tEeRRapAdUp+wSAiZchtZZWWgAZ+JNpD8peYXQVK9UwUxNpzOK8pq97kURZhYTCKBwPD7h2zK+js7Myi7D8Fod+0TkMI8+EMAngLGc/WtBFWawkFHFnoj/t9KLgGmF0B3QfkxC+EarxkdhnFYlFLY06USqUwL7UMjICHfh/wOc2sCqhpxGbCkLvL7EUDbF73+6DkmVWB6zi7xUDQSLeYvWjAILvm9zEnkJhlbRcDQZcv6Kg2AipyT/Axw6wKlqVSqxDdjF8Izfod13qURdrG/nxehY+xGh+h0CSzKygGvSNQIcc097BI24jb9hax6kj2E7OrMFX1il+ICEf2NrPbhiXLl+fYl+U7zK4iYdsDcyLGf+ofFlkwcN+s10KhmpuYhhtm0hCLVIFL0MDsqNlDIqy9x2CLs1jL6OvrI7vPRbtohXG6eFmsFnHDGAp6n9AgyuVySRZrGvROxRgIfLXhzjrNYnNBUxNX/dMgRWT1mt4XLDovaApD53E9W3ilNX5M55LJHpRtIsgAvciR4WWcgK2Dvb1YqgXevmF8z2zEBTcKG39EfSKsT9EbhVUaI2FZO+oZIqImxol6j66/hcAu4sSN4vc1ZPoKeoE6RGhYL2YYA+ymOSSi0Z0wWntbtkGUWCvfSDXIxONraZ/FY90KUfNTpfC5spnNLgxoYNnR9RO4F8ofXEHOgogCQE99w+fF2Xw+b7O59rEOsyRqGEfpVoaDMQQ1CZrG46bcM6AZ0C/wPqNfHliqejyTySxh9TqQpL+xmbIlkB9SlAAAAABJRU5ErkJggg==" },
        pan: { image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAICSURBVEhLxZbPahNRGMUn/5MpuAiBEAIufQGfzr5E40YptBXajYzudCEuGqS+gGlrFwquDGRTutBdYfydzJ3LzeQmJGZue+Dw/Z17Mnfmu5Pof9Hr9Z61Wq0bWZMKj263O6xWq99wU9lOpzPMKgEhEcRucNOcioOK+0RzBhNvt9tPV4nmVF19+OWhVqt9xXgFXZq+8lCv119UKpUJ7iX2FmvFTKz8RH34YdBsNk8wVtjE4fGYwm8wrrDi3WBG5oKXZGRSS9hGuNFojLTe2lFz5xThWZIktayyiE2FdT3rzXBXz7krKiL8c17wAKFDjCus2AvW+YGZ9y2JF0VFRuMPfI//rsCE/C+s26s4gQu9ul7r4NteKx7H8XOC724xNNGbaNu++IrBqbOV7Tj3FgMRvc/YKOr3+3sE47wgEt/Bl/gaK5cHbNU11vYSXylfpK7XOvjuumPp4Wcoipu30Qsez2uMXYz4lfI+mOmwothY+SLiXJy7mKVpWs3Si0CoOMfeI9Od43Wic+jO+ZVv+crsm9QSNhUW9LXSeoPBYLXopthGuFQgdIxxhY+UDwlt1x5CZ1hX+NTUdt/OIvjKaDSmuOJfaIVNPKX+W18j/PLA2/kR44p5Sd8HbHngT/yTfNRWUXX14ZcL3wmX0+TLf8YO7CGT8yFE5zB3/gney25/OETRP9CtPDFe5jShAAAAAElFTkSuQmCC" },
        zoom: { image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAJcEhZcwAADsMAAA7DAcdvqGQAAALWSURBVEhLvZZLaBNRFIabyftBIgEfqCCBoCC6MYqiXYiIj4U76U4X7sUHbhQhUBfixhZEUBDB16YuFERaUaQLK7ooCOJj4UKtYEFU0EptShO/A9Ph3js3k8lo/eHnP7n3nP/M3LlzMz1hkUwmNziOcyKRSFyFt+LxeD/c2Wq1Ym7Kv0M2m11Os1OxWGycn1OwZXCGuXfwIhezkd9/jRgNT2L4ldhs1pbkX5OLJe4euVxuGQaPCa3mnUjtJx7BDuKusJTCV6jVVGHTMuYRjxma7yIOhTgFY6jNaAKew2xPKpVay9ganmkvj+M448/MfJdT5K5Gg4HJacRngPFgqVRaRNwW1B4i7yehWfsEDdz1K+A01AoxPIqGAiuwGfkOTY8+1A6u7AyiFTB2Hu0KPIrdiOnzHLWDybeImvy+Wq2mZa5bUHsD0Zpz+KxHdWQymV6kAb1ElqeORgJLvgnRdj1+R1AfzkIvSUjxVjQSarVakrueIPT8+H1F5jSUy+WXiJrUYBVWyVxU4PEU8TzhfaijUqnMIWrjaY492eWRwdKOIqrnIxnXwLLeRLwk2GQzrEMjg0avEbXxkIxr4OoOImpj2QwyFgms1koa/SZUG8s+0iGnEhNfCNXEhzIXBVz0McTzEvJ+70P9oNFtxEzei3aFYrFYxmuSUPWSv9Yi9IMm2xE1We56Mp1OV4nDwqFmBDV9gk9AEh4gZtFHNt8W4kAUCoXF5MorY9Z/kDni9nDv7hc0i2fhgLvTtX8a99PoMPPagTFPxofRzmDJ9yM+AyEmTfgGysYbQcfhDzPPJDmX0c7gDg4gs9BqFIWhm/Nct5H8gtBq1I7UfIbtvmIuoaGQcp+fdpbbSM43eEH5wrwLbXmhm/fU63VHXjcuok7hEByFY/AeHGC8L5/PL3HT5xGH1uYwfPOICGo+CBcU0vwO1BqzUqILDl/z/9VYIMfpddiAc47jDP8BsUpb13wOLRwAAAAASUVORK5CYII=" },
        menu: { image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAeCAYAAABE4bxTAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADoSURBVFhH7dc9CsJAFATgRxIIBCwCqZKATX5sbawsY2MvWOtF9AB6AU8gguAJbD2AnZ2VXQT/Ko2TYGCL2OYtYQc+BuYA+1hCtnCVwMm27SGaXpDJIAiCvCkVR05hGOZNN3HkFMdx3nQRR06+76/R1IcFLJlNQEWlmWlBTwJtKLKHynehZqnjOGM0PYWRVXk61C37p7xlZ3Hk5HneCk1dmMH811xGoKLSzDiQwIBZB4ocoPJdqNkDt2yKlueWRVGUtzy3rPwo3sWRU3nLjuLI6OO67oZM00wMw3hrmpZx0XU9syxrR0T0BeMpb9dneSR2AAAAAElFTkSuQmCC" }
      };
      G.prototype.setOptions = function(h, n) {
        if (pa[this._defaultsKey]) {
          var s2 = pa[this._defaultsKey], w2;
          for (w2 in s2)
            "publicProperties" !== w2 && s2.hasOwnProperty(w2) && (this[w2] = h && w2 in h ? h[w2] : n && w2 in n ? n[w2] : s2[w2]);
        } else
          Ia && window.console && console.log("defaults not set");
      };
      G.prototype.get = function(h) {
        var n = pa[this._defaultsKey];
        if ("options" === h)
          return this.options && this.options._isPlaceholder ? null : this.options;
        if (n.hasOwnProperty(h) || n.publicProperties && n.publicProperties.hasOwnProperty(h))
          return this[h];
        window.console && window.console.log('Property "' + h + `" doesn't exist. Please check for typo.`);
      };
      G.prototype.set = function(h, n, s2) {
        s2 = "undefined" === typeof s2 ? true : s2;
        var w2 = pa[this._defaultsKey];
        if ("options" === h)
          this.createUserOptions(n);
        else if (w2.hasOwnProperty(h) || w2.publicProperties && w2.publicProperties.hasOwnProperty(h) && "readWrite" === w2.publicProperties[h])
          this.options._isPlaceholder && this.createUserOptions(), this.options[h] = n;
        else {
          window.console && (w2.publicProperties && w2.publicProperties.hasOwnProperty(h) && "readOnly" === w2.publicProperties[h] ? window.console.log('Property "' + h + '" is read-only.') : window.console.log('Property "' + h + `" doesn't exist. Please check for typo.`));
          return;
        }
        s2 && (this.stockChart || this.chart || this).render();
      };
      G.prototype.addTo = function(h, n, s2, w2) {
        w2 = "undefined" === typeof w2 ? true : w2;
        var v2 = pa[this._defaultsKey];
        v2.hasOwnProperty(h) || v2.publicProperties && v2.publicProperties.hasOwnProperty(h) && "readWrite" === v2.publicProperties[h] ? (this.options._isPlaceholder && this.createUserOptions(), "undefined" === typeof this.options[h] && (this.options[h] = []), h = this.options[h], s2 = "undefined" === typeof s2 || null === s2 ? h.length : s2, h.splice(s2, 0, n), w2 && (this.stockChart || this.chart || this).render()) : window.console && (v2.publicProperties && v2.publicProperties.hasOwnProperty(h) && "readOnly" === v2.publicProperties[h] ? window.console.log('Property "' + h + '" is read-only.') : window.console.log('Property "' + h + `" doesn't exist. Please check for typo.`));
      };
      G.prototype.createUserOptions = function(h) {
        if ("undefined" !== typeof h || this.options._isPlaceholder)
          if (this.parent.options._isPlaceholder && this.parent.createUserOptions(), this.isOptionsInArray) {
            this.parent.options[this.optionsName] || (this.parent.options[this.optionsName] = []);
            var n = this.parent.options[this.optionsName], s2 = n.length;
            this.options._isPlaceholder || (Ea(n), s2 = n.indexOf(this.options));
            this.options = "undefined" === typeof h ? {} : h;
            n[s2] = this.options;
          } else
            this.options = "undefined" === typeof h ? {} : h, h = this.parent.options, this.optionsName ? n = this.optionsName : (n = this._defaultsKey) && 0 !== n.length ? (s2 = n.charAt(0).toLowerCase(), 1 < n.length && (s2 = s2.concat(n.slice(1))), n = s2) : n = void 0, h[n] = this.options;
      };
      G.prototype.remove = function(h) {
        h = "undefined" === typeof h ? true : h;
        if (this.isOptionsInArray) {
          var n = this.parent.options[this.optionsName];
          Ea(n);
          var s2 = n.indexOf(this.options);
          0 <= s2 && n.splice(s2, 1);
        } else
          delete this.parent.options[this.optionsName];
        h && (this.stockChart || this.chart || this).render();
      };
      G.prototype.updateOption = function(h) {
        !pa[this._defaultsKey] && (Ia && window.console) && console.log("defaults not set");
        var n = pa[this._defaultsKey], w2 = {}, v2 = this[h], B2 = this._themeOptionsKey, J2 = this._index;
        this.theme && s(this.parent) && s(B2) && s(J2) ? w2 = s(this.predefinedThemes[this.theme]) ? this.predefinedThemes.light1 : this.predefinedThemes[this.theme] : this.parent && (this.parent.themeOptions && this.parent.themeOptions[B2]) && (null === J2 ? w2 = this.parent.themeOptions[B2] : 0 < this.parent.themeOptions[B2].length && (w2 = Math.min(this.parent.themeOptions[B2].length - 1, J2), w2 = this.parent.themeOptions[B2][w2]));
        this.themeOptions = w2;
        h in n && (v2 = h in this.options ? this.options[h] : w2 && h in w2 ? w2[h] : n[h]);
        if (v2 === this[h])
          return false;
        this[h] = v2;
        return true;
      };
      G.prototype.trackChanges = function(h) {
        if (!this.sessionVariables)
          throw "Session Variable Store not set";
        this.sessionVariables[h] = this.options[h];
      };
      G.prototype.isBeingTracked = function(h) {
        this.options._oldOptions || (this.options._oldOptions = {});
        return this.options._oldOptions[h] ? true : false;
      };
      G.prototype.hasOptionChanged = function(h) {
        if (!this.sessionVariables)
          throw "Session Variable Store not set";
        return this.sessionVariables[h] !== this.options[h];
      };
      G.prototype.addEventListener = function(h, n, s2) {
        h && n && (this._eventListeners[h] = this._eventListeners[h] || [], this._eventListeners[h].push({ context: s2 || this, eventHandler: n }));
      };
      G.prototype.removeEventListener = function(h, n) {
        if (h && n && this._eventListeners[h]) {
          for (var s2 = this._eventListeners[h], w2 = 0; w2 < s2.length; w2++)
            if (s2[w2].eventHandler === n) {
              s2[w2].splice(w2, 1);
              break;
            }
        }
      };
      G.prototype.removeAllEventListeners = function() {
        this._eventListeners = [];
      };
      G.prototype.dispatchEvent = function(h, n, s2) {
        if (h && this._eventListeners[h]) {
          n = n || {};
          for (var w2 = this._eventListeners[h], v2 = 0; v2 < w2.length; v2++)
            w2[v2].eventHandler.call(
              w2[v2].context,
              n
            );
        }
        "function" === typeof this[h] && this[h].call(s2 || this.chart, n);
      };
      Fa.prototype.registerSpace = function(h, n) {
        "top" === h ? this._topOccupied += n.height : "bottom" === h ? this._bottomOccupied += n.height : "left" === h ? this._leftOccupied += n.width : "right" === h && (this._rightOccupied += n.width);
      };
      Fa.prototype.unRegisterSpace = function(h, n) {
        "top" === h ? this._topOccupied -= n.height : "bottom" === h ? this._bottomOccupied -= n.height : "left" === h ? this._leftOccupied -= n.width : "right" === h && (this._rightOccupied -= n.width);
      };
      Fa.prototype.getFreeSpace = function() {
        return { x1: this._x1 + this._leftOccupied, y1: this._y1 + this._topOccupied, x2: this._x2 - this._rightOccupied, y2: this._y2 - this._bottomOccupied, width: this._x2 - this._x1 - this._rightOccupied - this._leftOccupied, height: this._y2 - this._y1 - this._bottomOccupied - this._topOccupied };
      };
      Fa.prototype.reset = function() {
        this._rightOccupied = this._leftOccupied = this._bottomOccupied = this._topOccupied = this._padding;
      };
      oa(ja, G);
      ja.prototype._initialize = function() {
        s(this.padding) || "object" !== typeof this.padding ? this.topPadding = this.rightPadding = this.bottomPadding = this.leftPadding = Number(this.padding) | 0 : (this.topPadding = s(this.padding.top) ? 0 : Number(this.padding.top) | 0, this.rightPadding = s(this.padding.right) ? 0 : Number(this.padding.right) | 0, this.bottomPadding = s(this.padding.bottom) ? 0 : Number(this.padding.bottom) | 0, this.leftPadding = s(this.padding.left) ? 0 : Number(this.padding.left) | 0);
      };
      ja.prototype.render = function(h) {
        if (0 !== this.fontSize) {
          h && this.ctx.save();
          var n = this.ctx.font;
          this.ctx.textBaseline = this.textBaseline;
          var s2 = 0;
          this._isDirty && this.measureText(this.ctx);
          this.ctx.translate(this.x, this.y + s2);
          "middle" === this.textBaseline && (s2 = -this._lineHeight / 2);
          this.ctx.font = this._getFontString();
          this.ctx.rotate(Math.PI / 180 * this.angle);
          var w2 = 0, v2 = this.topPadding, B2 = null;
          this.ctx.roundRect || Da(this.ctx);
          (0 < this.borderThickness && this.borderColor || this.backgroundColor) && this.ctx.roundRect(0, s2, this.width, this.height, this.cornerRadius, this.borderThickness, this.backgroundColor, this.borderColor);
          this.ctx.fillStyle = this.fontColor;
          for (s2 = 0; s2 < this._wrappedText.lines.length; s2++) {
            B2 = this._wrappedText.lines[s2];
            if ("right" === this.horizontalAlign || "right" === this.textAlign)
              w2 = this.width - B2.width - this.rightPadding;
            else if ("left" === this.horizontalAlign || "left" === this.textAlign)
              w2 = this.leftPadding;
            else if ("center" === this.horizontalAlign || "center" === this.textAlign)
              w2 = (this.width - (this.leftPadding + this.rightPadding)) / 2 - B2.width / 2 + this.leftPadding;
            this.ctx.fillText(B2.text, w2, v2);
            v2 += B2.height;
          }
          this.ctx.font = n;
          h && this.ctx.restore();
        }
      };
      ja.prototype.setText = function(h) {
        this.text = h;
        this._isDirty = true;
        this._wrappedText = null;
      };
      ja.prototype.measureText = function() {
        this._lineHeight = Ya(this.fontFamily, this.fontSize, this.fontWeight);
        if (null === this.maxWidth)
          throw "Please set maxWidth and height for TextBlock";
        this._wrapText(this.ctx);
        this._isDirty = false;
        return { width: this.width, height: this.height };
      };
      ja.prototype._getLineWithWidth = function(h, n, s2) {
        h = String(h);
        if (!h)
          return { text: "", width: 0 };
        var w2 = s2 = 0, v2 = h.length - 1, B2 = Infinity;
        for (this.ctx.font = this._getFontString(); w2 <= v2; ) {
          var B2 = Math.floor((w2 + v2) / 2), A = h.substr(0, B2 + 1);
          s2 = this.ctx.measureText(A).width;
          if (s2 < n)
            w2 = B2 + 1;
          else if (s2 > n)
            v2 = B2 - 1;
          else
            break;
        }
        s2 > n && 1 < A.length && (A = A.substr(0, A.length - 1), s2 = this.ctx.measureText(A).width);
        n = true;
        if (A.length === h.length || " " === h[A.length])
          n = false;
        n && (h = A.split(" "), 1 < h.length && h.pop(), A = h.join(" "), s2 = this.ctx.measureText(A).width);
        return { text: A, width: s2 };
      };
      ja.prototype._wrapText = function() {
        var h = new String(Ha(String(this.text))), s2 = [], w2 = this.ctx.font, v2 = 0, B2 = 0;
        this.ctx.font = this._getFontString();
        if (0 === this.frontSize)
          B2 = v2 = 0;
        else
          for (; 0 < h.length; ) {
            var J2 = this.maxHeight - (this.topPadding + this.bottomPadding), A = this._getLineWithWidth(h, this.maxWidth - (this.leftPadding + this.rightPadding), false);
            A.height = this._lineHeight;
            s2.push(A);
            var G2 = B2, B2 = Math.max(B2, A.width), v2 = v2 + A.height, h = Ha(h.slice(A.text.length, h.length));
            J2 && v2 > J2 && (A = s2.pop(), v2 -= A.height, B2 = G2);
          }
        this._wrappedText = { lines: s2, width: B2, height: v2 };
        this.width = B2 + (this.leftPadding + this.rightPadding);
        this.height = v2 + (this.topPadding + this.bottomPadding);
        this.ctx.font = w2;
      };
      ja.prototype._getFontString = function() {
        var h;
        h = this.fontStyle ? this.fontStyle + " " : "";
        h += this.fontWeight ? this.fontWeight + " " : "";
        h += this.fontSize ? this.fontSize + "px " : "";
        var s2 = this.fontFamily ? this.fontFamily + "" : "";
        !w && s2 && (s2 = s2.split(",")[0], "'" !== s2[0] && '"' !== s2[0] && (s2 = "'" + s2 + "'"));
        return h += s2;
      };
      oa(Ua, G);
      oa(za, G);
      za.prototype.setLayout = function() {
        if (this.text) {
          var h = this.dockInsidePlotArea ? this.chart.plotArea : this.chart, n = h.layoutManager.getFreeSpace(), w2 = n.x1, v2 = n.y1, B2 = 0, J2 = 0, A = this.chart._menuButton && this.chart.exportEnabled && "top" === this.verticalAlign ? 40 : 0, G2, K2;
          "top" === this.verticalAlign || "bottom" === this.verticalAlign ? (null === this.maxWidth && (this.maxWidth = n.width - 4 - A * ("center" === this.horizontalAlign ? 2 : 1)), J2 = 0.5 * n.height - this.margin - 2, B2 = 0) : "center" === this.verticalAlign && ("left" === this.horizontalAlign || "right" === this.horizontalAlign ? (null === this.maxWidth && (this.maxWidth = n.height - 4), J2 = 0.5 * n.width - this.margin - 2) : "center" === this.horizontalAlign && (null === this.maxWidth && (this.maxWidth = n.width - 4), J2 = 0.5 * n.height - 4));
          var N;
          s(this.padding) || "number" !== typeof this.padding ? s(this.padding) || "object" !== typeof this.padding || (N = this.padding.top ? this.padding.top : this.padding.bottom ? this.padding.bottom : 0, N += this.padding.bottom ? this.padding.bottom : this.padding.top ? this.padding.top : 0) : N = 2 * this.padding;
          this.wrap || (J2 = Math.min(J2, 1.5 * this.fontSize + N));
          J2 = new ja(this.ctx, {
            fontSize: this.fontSize,
            fontFamily: this.fontFamily,
            fontColor: this.fontColor,
            fontStyle: this.fontStyle,
            fontWeight: this.fontWeight,
            horizontalAlign: this.horizontalAlign,
            textAlign: this.horizontalAlign,
            verticalAlign: this.verticalAlign,
            borderColor: this.borderColor,
            borderThickness: this.borderThickness,
            backgroundColor: this.backgroundColor,
            maxWidth: this.maxWidth,
            maxHeight: J2,
            cornerRadius: this.cornerRadius,
            text: this.text,
            padding: this.padding,
            textBaseline: "middle"
          });
          N = J2.measureText();
          "top" === this.verticalAlign || "bottom" === this.verticalAlign ? ("top" === this.verticalAlign ? (v2 = n.y1 + 2 + this.fontSize / 2 + 4, K2 = "top") : "bottom" === this.verticalAlign && (v2 = n.y2 - 2 - N.height + this.fontSize / 2 + 4, K2 = "bottom"), "left" === this.horizontalAlign ? w2 = n.x1 + 2 : "center" === this.horizontalAlign ? w2 = n.x1 + n.width / 2 - N.width / 2 : "right" === this.horizontalAlign && (w2 = n.x2 - 2 - N.width - A), G2 = this.horizontalAlign, this.width = N.width, this.height = N.height) : "center" === this.verticalAlign && ("left" === this.horizontalAlign ? (w2 = n.x1 + 2 + (this.fontSize / 2 + 4), v2 = n.y2 - 2 - (this.maxWidth / 2 - N.width / 2), B2 = -90, K2 = "left", this.width = N.height, this.height = N.width) : "right" === this.horizontalAlign ? (w2 = n.x2 - 2 - (this.fontSize / 2 + 4), v2 = n.y1 + 2 + (this.maxWidth / 2 - N.width / 2), B2 = 90, K2 = "right", this.width = N.height, this.height = N.width) : "center" === this.horizontalAlign && (v2 = h.y1 + (h.height / 2 - N.height / 2) + this.fontSize / 2 + 4, w2 = h.x1 + (h.width / 2 - N.width / 2), K2 = "center", this.width = N.width, this.height = N.height), G2 = "center");
          J2.x = w2;
          J2.y = v2;
          J2.angle = B2;
          J2.horizontalAlign = G2;
          this._textBlock = J2;
          h.layoutManager.registerSpace(K2, { width: this.width + ("left" === K2 || "right" === K2 ? this.margin + 2 : 0), height: this.height + ("top" === K2 || "bottom" === K2 ? this.margin + 2 : 0) });
          this.bounds = { x1: w2, y1: v2, x2: w2 + this.width, y2: v2 + this.height };
          this.ctx.textBaseline = "top";
        }
      };
      za.prototype.render = function() {
        this._textBlock && this._textBlock.render(true);
      };
      oa(Ja, G);
      Ja.prototype.setLayout = za.prototype.setLayout;
      Ja.prototype.render = za.prototype.render;
      Va.prototype.get = function(h, s2) {
        var w2 = null;
        0 < this.pool.length ? (w2 = this.pool.pop(), Na(w2, h, s2)) : w2 = ua(h, s2);
        return w2;
      };
      Va.prototype.release = function(h) {
        this.pool.push(h);
      };
      oa(Ka, G);
      var Qa = { addTheme: function(h, s2) {
        cb[h] = s2;
      }, addColorSet: function(h, s2) {
        Aa[h] = s2;
      }, addCultureInfo: function(h, s2) {
        La[h] = s2;
      }, formatNumber: function(h, s2, w2) {
        w2 = w2 || "en";
        if (La[w2])
          return da(h, s2 || "#,##0.##", new Ka(w2));
        throw "Unknown Culture Name";
      }, formatDate: function(h, s2, w2) {
        w2 = w2 || "en";
        if (La[w2])
          return Ba(h, s2 || "DD MMM YYYY", new Ka(w2));
        throw "Unknown Culture Name";
      } };
      "undefined" !== typeof module && "undefined" !== typeof module.exports ? module.exports = Qa : "function" === typeof define && define.amd ? define([], function() {
        return Qa;
      }) : (window.CanvasJS && window.console && window.console.log("CanvasJS namespace already exists. If you are loading both chart and stockchart scripts, just load stockchart alone as it includes all chart features."), window.CanvasJS = window.CanvasJS ? window.CanvasJS : Qa);
      B = Qa.Chart = function() {
        function h(a, d) {
          return a.x - d.x;
        }
        function n(a, d, c) {
          d = d || {};
          s(c) ? (this.predefinedThemes = cb, this.optionsName = this.parent = this.index = null) : (this.parent = c.parent, this.index = c.index, this.predefinedThemes = c.predefinedThemes, this.optionsName = c.optionsName, this.stockChart = c.stockChart, this.panel = a, this.isOptionsInArray = c.isOptionsInArray);
          this.theme = s(d.theme) || s(this.predefinedThemes[d.theme]) ? "light1" : d.theme;
          n.base.constructor.call(this, "Chart", this.optionsName, d, this.index, this.parent);
          var b = this;
          this._containerId = a;
          this._objectsInitialized = false;
          this.overlaidCanvasCtx = this.ctx = null;
          this._indexLabels = [];
          this._panTimerId = 0;
          this._lastTouchEventType = "";
          this._lastTouchData = null;
          this.isAnimating = false;
          this.renderCount = 0;
          this.disableToolTip = this.animatedRender = false;
          this.canvasPool = new Va();
          this.allDOMEventHandlers = [];
          this.panEnabled = false;
          this._defaultCursor = "default";
          this.plotArea = { canvas: null, ctx: null, x1: 0, y1: 0, x2: 0, y2: 0, width: 0, height: 0 };
          this._dataInRenderedOrder = [];
          (this.container = "string" === typeof this._containerId ? document.getElementById(this._containerId) : this._containerId) ? (this.container.innerHTML = "", d = a = 0, a = this.options.width ? this.width : 0 < this.container.clientWidth ? this.container.clientWidth : this.width, d = this.options.height ? this.height : 0 < this.container.clientHeight ? this.container.clientHeight : this.height, this.width = a, this.height = d, this.x1 = this.y1 = 0, this.x2 = this.width, this.y2 = this.height, this.selectedColorSet = "undefined" !== typeof Aa[this.colorSet] ? Aa[this.colorSet] : Aa.colorSet1, this._canvasJSContainer = document.createElement("div"), this._canvasJSContainer.setAttribute("class", "canvasjs-chart-container"), this._canvasJSContainer.style.position = "relative", this._canvasJSContainer.style.textAlign = "left", this._canvasJSContainer.style.cursor = "auto", this._canvasJSContainer.style.direction = "ltr", w || (this._canvasJSContainer.style.height = "0px"), this.container.appendChild(this._canvasJSContainer), this.canvas = ua(a, d), this._preRenderCanvas = ua(a, d), this.canvas.style.position = "absolute", this.canvas.style.WebkitUserSelect = "none", this.canvas.style.MozUserSelect = "none", this.canvas.style.msUserSelect = "none", this.canvas.style.userSelect = "none", this.canvas.getContext && (this._canvasJSContainer.appendChild(this.canvas), this.ctx = this.canvas.getContext("2d"), this.ctx.textBaseline = "top", Da(this.ctx), this._preRenderCtx = this._preRenderCanvas.getContext("2d"), this._preRenderCtx.textBaseline = "top", Da(this._preRenderCtx), w ? this.plotArea.ctx = this.ctx : (this.plotArea.canvas = ua(a, d), this.plotArea.canvas.style.position = "absolute", this.plotArea.canvas.setAttribute("class", "plotAreaCanvas"), this._canvasJSContainer.appendChild(this.plotArea.canvas), this.plotArea.ctx = this.plotArea.canvas.getContext("2d")), this.overlaidCanvas = ua(a, d), this.overlaidCanvas.style.position = "absolute", this.overlaidCanvas.style.webkitTapHighlightColor = "transparent", this.overlaidCanvas.style.WebkitUserSelect = "none", this.overlaidCanvas.style.MozUserSelect = "none", this.overlaidCanvas.style.msUserSelect = "none", this.overlaidCanvas.style.userSelect = "none", this.overlaidCanvas.getContext && (this._canvasJSContainer.appendChild(this.overlaidCanvas), this.overlaidCanvasCtx = this.overlaidCanvas.getContext("2d"), this.overlaidCanvasCtx.textBaseline = "top", Da(this.overlaidCanvasCtx)), this._eventManager = new Z2(this), this.windowResizeHandler = P(window, "resize", function() {
            b._updateSize() && b.render();
          }, this.allDOMEventHandlers), this._toolBar = document.createElement("div"), this._toolBar.setAttribute("class", "canvasjs-chart-toolbar"), V(this._toolBar, {
            position: "absolute",
            right: "1px",
            top: "1px"
          }), this._canvasJSContainer.appendChild(this._toolBar), this.bounds = { x1: 0, y1: 0, x2: this.width, y2: this.height }, P(this.overlaidCanvas, "click", function(a2) {
            b._mouseEventHandler(a2);
          }, this.allDOMEventHandlers), P(this.overlaidCanvas, "mousemove", function(a2) {
            b._mouseEventHandler(a2);
          }, this.allDOMEventHandlers), P(this.overlaidCanvas, "mouseup", function(a2) {
            b._mouseEventHandler(a2);
          }, this.allDOMEventHandlers), P(
            this.overlaidCanvas,
            "mousedown",
            function(a2) {
              b._mouseEventHandler(a2);
              wa(b._dropdownMenu);
            },
            this.allDOMEventHandlers
          ), P(this.overlaidCanvas, "mouseout", function(a2) {
            b._mouseEventHandler(a2);
          }, this.allDOMEventHandlers), P(this.overlaidCanvas, window.navigator.msPointerEnabled ? "MSPointerDown" : "touchstart", function(a2) {
            b._touchEventHandler(a2);
          }, this.allDOMEventHandlers), P(this.overlaidCanvas, window.navigator.msPointerEnabled ? "MSPointerMove" : "touchmove", function(a2) {
            b._touchEventHandler(a2);
          }, this.allDOMEventHandlers), P(
            this.overlaidCanvas,
            window.navigator.msPointerEnabled ? "MSPointerUp" : "touchend",
            function(a2) {
              b._touchEventHandler(a2);
            },
            this.allDOMEventHandlers
          ), P(this.overlaidCanvas, window.navigator.msPointerEnabled ? "MSPointerCancel" : "touchcancel", function(a2) {
            b._touchEventHandler(a2);
          }, this.allDOMEventHandlers), this.toolTip = new U2(this, this.options.toolTip), this.data = null, this.axisX = [], this.axisX2 = [], this.axisY = [], this.axisY2 = [], this.sessionVariables = { axisX: [], axisX2: [], axisY: [], axisY2: [] })) : window.console && window.console.log('CanvasJS Error: Chart Container with id "' + this._containerId + '" was not found');
        }
        function v2(a, d) {
          for (var c = [], b, e = 0; e < a.length; e++)
            if (0 == e)
              c.push(a[0]);
            else {
              var f, l, t;
              t = e - 1;
              f = 0 === t ? 0 : t - 1;
              l = t === a.length - 1 ? t : t + 1;
              b = Math.abs((a[l].x - a[f].x) / (0 === a[l].x - a[t].x ? 0.01 : a[l].x - a[t].x)) * (d - 1) / 2 + 1;
              var C = (a[l].x - a[f].x) / b;
              b = (a[l].y - a[f].y) / b;
              c[c.length] = a[t].x > a[f].x && 0 < C || a[t].x < a[f].x && 0 > C ? { x: a[t].x + C / 3, y: a[t].y + b / 3 } : { x: a[t].x, y: a[t].y + (1 === c.length ? 0 : b / 9) };
              t = e;
              f = 0 === t ? 0 : t - 1;
              l = t === a.length - 1 ? t : t + 1;
              b = Math.abs((a[l].x - a[f].x) / (0 === a[t].x - a[f].x ? 0.01 : a[t].x - a[f].x)) * (d - 1) / 2 + 1;
              C = (a[l].x - a[f].x) / b;
              b = (a[l].y - a[f].y) / b;
              c[c.length] = a[t].x > a[f].x && 0 < C || a[t].x < a[f].x && 0 > C ? { x: a[t].x - C / 3, y: a[t].y - b / 3 } : { x: a[t].x, y: a[t].y - b / 9 };
              c[c.length] = a[e];
            }
          return c;
        }
        function B2(a, d, c, b, e, f, l, t, C, k) {
          var m = 0;
          k ? (l.color = f, t.color = f) : k = 1;
          m = C ? Math.abs(e - c) : Math.abs(b - d);
          m = 0 < l.trimLength ? Math.abs(m * l.trimLength / 100) : Math.abs(m - l.length);
          C ? (c += m / 2, e -= m / 2) : (d += m / 2, b -= m / 2);
          var m = 1 === Math.round(l.thickness) % 2 ? 0.5 : 0, p = 1 === Math.round(t.thickness) % 2 ? 0.5 : 0;
          a.save();
          a.globalAlpha = k;
          a.strokeStyle = t.color || f;
          a.lineWidth = t.thickness || 2;
          a.setLineDash && a.setLineDash(J(t.dashType, t.thickness));
          a.beginPath();
          C && 0 < t.thickness ? (a.moveTo(b - l.thickness / 2, Math.round((c + e) / 2) - p), a.lineTo(d + l.thickness / 2, Math.round((c + e) / 2) - p)) : 0 < t.thickness && (a.moveTo(Math.round((d + b) / 2) - p, c + l.thickness / 2), a.lineTo(Math.round((d + b) / 2) - p, e - l.thickness / 2));
          a.stroke();
          a.strokeStyle = l.color || f;
          a.lineWidth = l.thickness || 2;
          a.setLineDash && a.setLineDash(J(l.dashType, l.thickness));
          a.beginPath();
          C && 0 < l.thickness ? (a.moveTo(b - m, c), a.lineTo(b - m, e), a.moveTo(d + m, c), a.lineTo(d + m, e)) : 0 < l.thickness && (a.moveTo(d, c + m), a.lineTo(b, c + m), a.moveTo(d, e - m), a.lineTo(b, e - m));
          a.stroke();
          a.restore();
        }
        function K2(a, d) {
          K2.base.constructor.call(this, "Legend", "legend", d, null, a);
          this.chart = a;
          this.canvas = a.canvas;
          this.ctx = this.chart.ctx;
          this.ghostCtx = this.chart._eventManager.ghostCtx;
          this.items = [];
          this.optionsName = "legend";
          this.height = this.width = 0;
          this.orientation = null;
          this.dataSeries = [];
          this.bounds = { x1: null, y1: null, x2: null, y2: null };
          "undefined" === typeof this.options.fontSize && (this.fontSize = this.chart.getAutoFontSize(this.fontSize));
          this.lineHeight = Ya(this.fontFamily, this.fontSize, this.fontWeight);
          this.horizontalSpacing = this.fontSize;
        }
        function Q2(a, d, c, b) {
          Q2.base.constructor.call(this, "DataSeries", "data", d, c, a);
          this.chart = a;
          this.canvas = a.canvas;
          this._ctx = a.canvas.ctx;
          this.index = c;
          this.noDataPointsInPlotArea = 0;
          this.id = b;
          this.chart._eventManager.objectMap[b] = { id: b, objectType: "dataSeries", dataSeriesIndex: c };
          a = d.dataPoints ? d.dataPoints.length : 0;
          this.dataPointEOs = [];
          for (d = 0; d < a; d++)
            this.dataPointEOs[d] = {};
          this.dataPointIds = [];
          this.plotUnit = [];
          this.axisY = this.axisX = null;
          this.optionsName = "data";
          this.isOptionsInArray = true;
          null === this.fillOpacity && (this.type.match(/area/i) ? this.fillOpacity = 0.7 : this.fillOpacity = 1);
          this.axisPlacement = this.getDefaultAxisPlacement();
          "undefined" === typeof this.options.indexLabelFontSize && (this.indexLabelFontSize = this.chart.getAutoFontSize(this.indexLabelFontSize));
        }
        function A(a, d, c, b, e, f) {
          A.base.constructor.call(this, "Axis", d, c, b, a);
          this.chart = a;
          this.canvas = a.canvas;
          this.ctx = a.ctx;
          this.intervalStartPosition = this.maxHeight = this.maxWidth = 0;
          this.labels = [];
          this.dataSeries = [];
          this._stripLineLabels = this._ticks = this._labels = null;
          this.dataInfo = { min: Infinity, max: -Infinity, viewPortMin: Infinity, viewPortMax: -Infinity, minDiff: Infinity };
          this.isOptionsInArray = true;
          "axisX" === e ? ("left" === f || "bottom" === f ? (this.optionsName = "axisX", s(this.chart.sessionVariables.axisX[b]) && (this.chart.sessionVariables.axisX[b] = {}), this.sessionVariables = this.chart.sessionVariables.axisX[b]) : (this.optionsName = "axisX2", s(this.chart.sessionVariables.axisX2[b]) && (this.chart.sessionVariables.axisX2[b] = {}), this.sessionVariables = this.chart.sessionVariables.axisX2[b]), this.options.interval || (this.intervalType = null)) : "left" === f || "bottom" === f ? (this.optionsName = "axisY", s(this.chart.sessionVariables.axisY[b]) && (this.chart.sessionVariables.axisY[b] = {}), this.sessionVariables = this.chart.sessionVariables.axisY[b]) : (this.optionsName = "axisY2", s(this.chart.sessionVariables.axisY2[b]) && (this.chart.sessionVariables.axisY2[b] = {}), this.sessionVariables = this.chart.sessionVariables.axisY2[b]);
          "undefined" === typeof this.options.titleFontSize && (this.titleFontSize = this.chart.getAutoFontSize(this.titleFontSize));
          "undefined" === typeof this.options.labelFontSize && (this.labelFontSize = this.chart.getAutoFontSize(this.labelFontSize));
          this.type = e;
          "axisX" !== e || c && "undefined" !== typeof c.gridThickness || (this.gridThickness = 0);
          this._position = f;
          this.lineCoordinates = { x1: null, y1: null, x2: null, y2: null, width: null };
          this.labelAngle = (this.labelAngle % 360 + 360) % 360;
          90 < this.labelAngle && 270 > this.labelAngle ? this.labelAngle -= 180 : 270 <= this.labelAngle && 360 >= this.labelAngle && (this.labelAngle -= 360);
          this.options.scaleBreaks && (this.scaleBreaks = new fa2(this.chart, this.options.scaleBreaks, ++this.chart._eventManager.lastObjectId, this));
          this.stripLines = [];
          if (this.options.stripLines && 0 < this.options.stripLines.length)
            for (a = 0; a < this.options.stripLines.length; a++)
              this.stripLines.push(new N(this.chart, this.options.stripLines[a], a, ++this.chart._eventManager.lastObjectId, this));
          this.options.crosshair && (this.crosshair = new ca2(
            this.chart,
            this.options.crosshair,
            this
          ));
          this._titleTextBlock = null;
          this.hasOptionChanged("viewportMinimum") && null === this.viewportMinimum && (this.options.viewportMinimum = void 0, this.sessionVariables.viewportMinimum = null);
          this.hasOptionChanged("viewportMinimum") || isNaN(this.sessionVariables.newViewportMinimum) || null === this.sessionVariables.newViewportMinimum ? this.sessionVariables.newViewportMinimum = null : this.viewportMinimum = this.sessionVariables.newViewportMinimum;
          this.hasOptionChanged("viewportMaximum") && null === this.viewportMaximum && (this.options.viewportMaximum = void 0, this.sessionVariables.viewportMaximum = null);
          this.hasOptionChanged("viewportMaximum") || isNaN(this.sessionVariables.newViewportMaximum) || null === this.sessionVariables.newViewportMaximum ? this.sessionVariables.newViewportMaximum = null : this.viewportMaximum = this.sessionVariables.newViewportMaximum;
          null !== this.minimum && null !== this.viewportMinimum && (this.viewportMinimum = Math.max(this.viewportMinimum, this.minimum));
          null !== this.maximum && null !== this.viewportMaximum && (this.viewportMaximum = Math.min(this.viewportMaximum, this.maximum));
          this.trackChanges("viewportMinimum");
          this.trackChanges("viewportMaximum");
        }
        function fa2(a, d, c, b) {
          fa2.base.constructor.call(this, "ScaleBreaks", "scaleBreaks", d, null, b);
          this.id = c;
          this.chart = a;
          this.ctx = this.chart.ctx;
          this.axis = b;
          this.optionsName = "scaleBreaks";
          this.isOptionsInArray = false;
          this._appliedBreaks = [];
          this.customBreaks = [];
          this.autoBreaks = [];
          "string" === typeof this.spacing ? (this.spacing = parseFloat(this.spacing), this.spacing = isNaN(this.spacing) ? 8 : (10 < this.spacing ? 10 : this.spacing) + "%") : "number" !== typeof this.spacing && (this.spacing = 8);
          this.autoCalculate && (this.maxNumberOfAutoBreaks = Math.min(this.maxNumberOfAutoBreaks, 5));
          if (this.options.customBreaks && 0 < this.options.customBreaks.length) {
            for (a = 0; a < this.options.customBreaks.length; a++)
              this.customBreaks.push(new aa2(this.chart, "customBreaks", this.options.customBreaks[a], a, ++this.chart._eventManager.lastObjectId, this)), "number" === typeof this.customBreaks[a].startValue && ("number" === typeof this.customBreaks[a].endValue && this.customBreaks[a].endValue !== this.customBreaks[a].startValue) && this._appliedBreaks.push(this.customBreaks[a]);
            this._appliedBreaks.sort(function(a2, b2) {
              return a2.startValue - b2.startValue;
            });
            for (a = 0; a < this._appliedBreaks.length - 1; a++)
              this._appliedBreaks[a].endValue >= this._appliedBreaks[a + 1].startValue && (this._appliedBreaks[a].endValue = Math.max(this._appliedBreaks[a].endValue, this._appliedBreaks[a + 1].endValue), window.console && window.console.log("CanvasJS Error: Breaks " + a + " and " + (a + 1) + " are overlapping."), this._appliedBreaks.splice(a, 2), a--);
          }
        }
        function aa2(a, d, c, b, e, f) {
          aa2.base.constructor.call(this, "Break", d, c, b, f);
          this.id = e;
          this.chart = a;
          this.ctx = this.chart.ctx;
          this.scaleBreaks = f;
          this.optionsName = d;
          this.isOptionsInArray = true;
          this.type = c.type ? this.type : f.type;
          this.fillOpacity = s(c.fillOpacity) ? f.fillOpacity : this.fillOpacity;
          this.lineThickness = s(c.lineThickness) ? f.lineThickness : this.lineThickness;
          this.color = c.color ? this.color : f.color;
          this.lineColor = c.lineColor ? this.lineColor : f.lineColor;
          this.lineDashType = c.lineDashType ? this.lineDashType : f.lineDashType;
          !s(this.startValue) && this.startValue.getTime && (this.startValue = this.startValue.getTime());
          !s(this.endValue) && this.endValue.getTime && (this.endValue = this.endValue.getTime());
          "number" === typeof this.startValue && ("number" === typeof this.endValue && this.endValue < this.startValue) && (a = this.startValue, this.startValue = this.endValue, this.endValue = a);
          this.spacing = "undefined" === typeof c.spacing ? f.spacing : c.spacing;
          "string" === typeof this.options.spacing ? (this.spacing = parseFloat(this.spacing), this.spacing = isNaN(this.spacing) ? 0 : (10 < this.spacing ? 10 : this.spacing) + "%") : "number" !== typeof this.options.spacing && (this.spacing = f.spacing);
          this.size = f.parent.logarithmic ? 1 : 0;
        }
        function N(a, d, c, b, e) {
          N.base.constructor.call(this, "StripLine", "stripLines", d, c, e);
          this.id = b;
          this.chart = a;
          this.ctx = this.chart.ctx;
          this.label = this.label;
          this.axis = e;
          this.optionsName = "stripLines";
          this.isOptionsInArray = true;
          this._thicknessType = "pixel";
          null !== this.startValue && null !== this.endValue && (this.value = e.logarithmic ? Math.sqrt((this.startValue.getTime ? this.startValue.getTime() : this.startValue) * (this.endValue.getTime ? this.endValue.getTime() : this.endValue)) : ((this.startValue.getTime ? this.startValue.getTime() : this.startValue) + (this.endValue.getTime ? this.endValue.getTime() : this.endValue)) / 2, this._thicknessType = null);
        }
        function ca2(a, d, c) {
          ca2.base.constructor.call(this, "Crosshair", "crosshair", d, null, c);
          this.chart = a;
          this.ctx = this.chart.ctx;
          this.axis = c;
          this.optionsName = "crosshair";
          this._thicknessType = "pixel";
        }
        function U2(a, d) {
          U2.base.constructor.call(this, "ToolTip", "toolTip", d, null, a);
          this.chart = a;
          this.canvas = a.canvas;
          this.ctx = this.chart.ctx;
          this.currentDataPointIndex = this.currentSeriesIndex = -1;
          this._prevY = this._prevX = NaN;
          this.containerTransitionDuration = 0.1;
          this.mozContainerTransition = this.getContainerTransition(this.containerTransitionDuration);
          this.optionsName = "toolTip";
          this._initialize();
        }
        function Z2(a) {
          this.chart = a;
          this.lastObjectId = 0;
          this.objectMap = [];
          this.rectangularRegionEventSubscriptions = [];
          this.previousDataPointEventObject = null;
          this.ghostCanvas = ua(this.chart.width, this.chart.height, true);
          this.ghostCtx = this.ghostCanvas.getContext("2d");
          this.mouseoveredObjectMaps = [];
        }
        function ia2(a) {
          this.chart = a;
          this.ctx = this.chart.plotArea.ctx;
          this.animations = [];
          this.animationRequestId = null;
        }
        oa(n, G);
        n.prototype.destroy = function() {
          var a = this.allDOMEventHandlers;
          this._animator && this._animator.cancelAllAnimations();
          this._panTimerId && clearTimeout(this._panTimerId);
          for (var d = 0; d < a.length; d++) {
            var c = a[d][0], b = a[d][1], e = a[d][2], f = a[d][3], f = f || false;
            c.removeEventListener ? c.removeEventListener(b, e, f) : c.detachEvent && c.detachEvent("on" + b, e);
          }
          this.allDOMEventHandlers = [];
          for (this.removeAllEventListeners(); this._canvasJSContainer && this._canvasJSContainer.hasChildNodes(); )
            this._canvasJSContainer.removeChild(this._canvasJSContainer.lastChild);
          for (; this.container && this.container.hasChildNodes(); )
            this.container.removeChild(this.container.lastChild);
          for (; this._dropdownMenu && this._dropdownMenu.hasChildNodes(); )
            this._dropdownMenu.removeChild(this._dropdownMenu.lastChild);
          this.container = this._canvasJSContainer = null;
          this.toolTip.container = null;
          this.canvas && ya(this.canvas);
          this.overlaidCanvas && ya(this.overlaidCanvas);
          this._preRenderCanvas && ya(this._preRenderCanvas);
          this._breaksCanvas && ya(this._breaksCanvas);
          this._eventManager && this._eventManager.ghostCanvas && ya(this._eventManager.ghostCanvas);
          this._toolBar = this._dropdownMenu = this._menuButton = this._resetButton = this._zoomButton = null;
        };
        n.prototype._updateOptions = function() {
          var a = this;
          this.updateOption("width");
          this.updateOption("height");
          this.updateOption("dataPointWidth");
          this.updateOption("dataPointMinWidth");
          this.updateOption("dataPointMaxWidth");
          this.updateOption("interactivityEnabled");
          this.updateOption("theme");
          this.updateOption("colorSet") && (this.selectedColorSet = "undefined" !== typeof Aa[this.colorSet] ? Aa[this.colorSet] : Aa.colorSet1);
          this.updateOption("backgroundColor");
          this.backgroundColor || (this.backgroundColor = "rgba(0,0,0,0)");
          this.updateOption("culture");
          this._cultureInfo = new Ka(this.options.culture);
          this.updateOption("animationEnabled");
          this.animationEnabled = this.animationEnabled && w;
          this.updateOption("animationDuration");
          this.updateOption("rangeChanging");
          this.updateOption("rangeChanged");
          this.updateOption("exportEnabled");
          this.updateOption("exportFileName");
          this.updateOption("zoomType");
          this.toolbar = new Ua(this, this.options.toolbar);
          if (this.options.zoomEnabled || this.panEnabled) {
            if (this._zoomButton)
              V(this._zoomButton, {
                borderRight: this.toolbar.buttonBorderThickness + "px solid " + this.toolbar.buttonBorderColor,
                backgroundColor: a.toolbar.itemBackgroundColor,
                color: a.toolbar.fontColor
              }), sa(this, this._zoomButton, "zoom");
            else {
              var d = false;
              wa(this._zoomButton = document.createElement("button"));
              sa(this, this._zoomButton, "pan");
              this._toolBar.appendChild(this._zoomButton);
              this._zoomButton.style.borderRight = this.toolbar.buttonBorderThickness + "px solid " + this.toolbar.buttonBorderColor;
              P(this._zoomButton, "touchstart", function(a2) {
                d = true;
              }, this.allDOMEventHandlers);
              P(this._zoomButton, "click", function() {
                a.zoomEnabled ? (a.zoomEnabled = false, a.panEnabled = true, sa(a, a._zoomButton, "zoom")) : (a.zoomEnabled = true, a.panEnabled = false, sa(a, a._zoomButton, "pan"));
                a.render();
              }, this.allDOMEventHandlers);
              P(this._zoomButton, "mousemove", function() {
                d ? d = false : (V(a._zoomButton, { backgroundColor: a.toolbar.itemBackgroundColorOnHover, color: a.toolbar.fontColorOnHover, transition: "0.4s", WebkitTransition: "0.4s" }), 0 >= navigator.userAgent.search("MSIE") && V(a._zoomButton.childNodes[0], { WebkitFilter: "invert(100%)", filter: "invert(100%)" }));
              }, this.allDOMEventHandlers);
              P(this._zoomButton, "mouseout", function() {
                d || (V(
                  a._zoomButton,
                  { backgroundColor: a.toolbar.itemBackgroundColor, color: a.toolbar.fontColor, transition: "0.4s", WebkitTransition: "0.4s" }
                ), 0 >= navigator.userAgent.search("MSIE") && V(a._zoomButton.childNodes[0], { WebkitFilter: "invert(0%)", filter: "invert(0%)" }));
              }, this.allDOMEventHandlers);
            }
            this._resetButton ? (V(this._resetButton, { borderRight: this.toolbar.buttonBorderThickness + "px solid " + this.toolbar.buttonBorderColor, backgroundColor: a.toolbar.itemBackgroundColor, color: a.toolbar.fontColor }), this._resetButton.title = this._cultureInfo.resetText) : (d = false, wa(this._resetButton = document.createElement("button")), sa(this, this._resetButton, "reset"), this._resetButton.style.borderRight = (this.exportEnabled ? this.toolbar.buttonBorderThickness : 0) + "px solid " + this.toolbar.buttonBorderColor, this._toolBar.appendChild(this._resetButton), P(this._resetButton, "touchstart", function(a2) {
              d = true;
            }, this.allDOMEventHandlers), P(this._resetButton, "click", function() {
              a.toolTip.hide();
              a.toolTip && a.toolTip.enabled && a.toolTip.dispatchEvent(
                "hidden",
                { chart: a, toolTip: a.toolTip },
                a.toolTip
              );
              a.zoomEnabled || a.panEnabled ? (a.zoomEnabled = true, a.panEnabled = false, sa(a, a._zoomButton, "pan"), a._defaultCursor = "default", a.overlaidCanvas.style.cursor = a._defaultCursor) : (a.zoomEnabled = false, a.panEnabled = false);
              if (a.sessionVariables.axisX)
                for (var b = 0; b < a.sessionVariables.axisX.length; b++)
                  a.sessionVariables.axisX[b].newViewportMinimum = null, a.sessionVariables.axisX[b].newViewportMaximum = null;
              if (a.sessionVariables.axisX2)
                for (b = 0; b < a.sessionVariables.axisX2.length; b++)
                  a.sessionVariables.axisX2[b].newViewportMinimum = null, a.sessionVariables.axisX2[b].newViewportMaximum = null;
              if (a.sessionVariables.axisY)
                for (b = 0; b < a.sessionVariables.axisY.length; b++)
                  a.sessionVariables.axisY[b].newViewportMinimum = null, a.sessionVariables.axisY[b].newViewportMaximum = null;
              if (a.sessionVariables.axisY2)
                for (b = 0; b < a.sessionVariables.axisY2.length; b++)
                  a.sessionVariables.axisY2[b].newViewportMinimum = null, a.sessionVariables.axisY2[b].newViewportMaximum = null;
              a.resetOverlayedCanvas();
              0 >= navigator.userAgent.search("MSIE") && V(
                a._resetButton.childNodes[0],
                { WebkitFilter: "invert(0%)", filter: "invert(0%)" }
              );
              wa(a._zoomButton, a._resetButton);
              a.stockChart && (a.stockChart._rangeEventParameter = { stockChart: a.stockChart, source: "chart", index: a.stockChart.charts.indexOf(a), minimum: null, maximum: null });
              a._dispatchRangeEvent("rangeChanging", "reset");
              a.stockChart && (a.stockChart._rangeEventParameter.type = "rangeChanging", a.stockChart.dispatchEvent("rangeChanging", a.stockChart._rangeEventParameter, a.stockChart));
              a.render();
              a.syncCharts && a.syncCharts(null, null);
              a._dispatchRangeEvent(
                "rangeChanged",
                "reset"
              );
              a.stockChart && (a.stockChart._rangeEventParameter.type = "rangeChanged", a.stockChart.dispatchEvent("rangeChanged", a.stockChart._rangeEventParameter, a.stockChart));
            }, this.allDOMEventHandlers), P(
              this._resetButton,
              "mousemove",
              function() {
                d || (V(a._resetButton, { backgroundColor: a.toolbar.itemBackgroundColorOnHover, color: a.toolbar.fontColorOnHover, transition: "0.4s", WebkitTransition: "0.4s" }), 0 >= navigator.userAgent.search("MSIE") && V(a._resetButton.childNodes[0], { WebkitFilter: "invert(100%)", filter: "invert(100%)" }));
              },
              this.allDOMEventHandlers
            ), P(this._resetButton, "mouseout", function() {
              d || (V(a._resetButton, { backgroundColor: a.toolbar.itemBackgroundColor, color: a.toolbar.fontColor, transition: "0.4s", WebkitTransition: "0.4s" }), 0 >= navigator.userAgent.search("MSIE") && V(a._resetButton.childNodes[0], { WebkitFilter: "invert(0%)", filter: "invert(0%)" }));
            }, this.allDOMEventHandlers), this.overlaidCanvas.style.cursor = a._defaultCursor);
            this.zoomEnabled || this.panEnabled || (this._zoomButton ? (a._zoomButton.getAttribute("state") === a._cultureInfo.zoomText ? (this.panEnabled = true, this.zoomEnabled = false) : (this.zoomEnabled = true, this.panEnabled = false), Ma(a._zoomButton, a._resetButton)) : (this.zoomEnabled = true, this.panEnabled = false));
          } else
            this.panEnabled = this.zoomEnabled = false;
          hb(this);
          "none" !== this._toolBar.style.display && this._zoomButton && (this.panEnabled ? sa(a, a._zoomButton, "zoom") : sa(a, a._zoomButton, "pan"), a._resetButton.getAttribute("state") !== a._cultureInfo.resetText && sa(a, a._resetButton, "reset"));
          this.options.toolTip && this.toolTip.options !== this.options.toolTip && (this.toolTip.options = this.options.toolTip);
          for (var c in this.toolTip.options)
            this.toolTip.options.hasOwnProperty(c) && this.toolTip.updateOption(c);
        };
        n.prototype._updateSize = function() {
          var a;
          a = [this.canvas, this.overlaidCanvas, this._eventManager.ghostCanvas];
          var d = 0, c = 0;
          this.options.width ? d = this.width : this.width = d = 0 < this.container.clientWidth ? this.container.clientWidth : this.width;
          this.options.height ? c = this.height : this.height = c = 0 < this.container.clientHeight ? this.container.clientHeight : this.height;
          if (this.canvas.width !== d * la || this.canvas.height !== c * la) {
            for (var b = 0; b < a.length; b++)
              Na(a[b], d, c);
            this.bounds = { x1: 0, y1: 0, x2: this.width, y2: this.height, width: this.width, height: this.height };
            a = true;
          } else
            a = false;
          return a;
        };
        n.prototype._initialize = function() {
          this.isNavigator = s(this.parent) || s(this.parent._defaultsKey) || "Navigator" !== this.parent._defaultsKey ? false : true;
          this._animator ? this._animator.cancelAllAnimations() : this._animator = new ia2(this);
          this.removeAllEventListeners();
          this.disableToolTip = false;
          this._axes = [];
          this.funnelPyramidClickHandler = this.pieDoughnutClickHandler = null;
          this._updateOptions();
          this.animatedRender = w && this.animationEnabled && 0 === this.renderCount;
          this._updateSize();
          this.clearCanvas();
          this.ctx.beginPath();
          this.axisX = [];
          this.axisX2 = [];
          this.axisY = [];
          this.axisY2 = [];
          this._indexLabels = [];
          this._dataInRenderedOrder = [];
          this._events = [];
          this._eventManager && this._eventManager.reset();
          this.plotInfo = { axisPlacement: null, plotTypes: [] };
          this.layoutManager = new Fa(0, 0, this.width, this.height, this.isNavigator ? 0 : 2);
          this.plotArea.layoutManager && this.plotArea.layoutManager.reset();
          this.data = [];
          this.title = null;
          this.subtitles = [];
          var a = 0, d = null;
          if (this.options.data) {
            for (var c = 0; c < this.options.data.length; c++)
              if (a++, !this.options.data[c].type || 0 <= n._supportedChartTypes.indexOf(this.options.data[c].type)) {
                var b = new Q2(this, this.options.data[c], a - 1, ++this._eventManager.lastObjectId);
                "error" === b.type && (b.linkedDataSeriesIndex = s(this.options.data[c].linkedDataSeriesIndex) ? c - 1 : this.options.data[c].linkedDataSeriesIndex, 0 > b.linkedDataSeriesIndex || b.linkedDataSeriesIndex >= this.options.data.length || "number" !== typeof b.linkedDataSeriesIndex || "error" === this.options.data[b.linkedDataSeriesIndex].type) && (b.linkedDataSeriesIndex = null);
                null === b.name && (b.name = "DataSeries " + a);
                null === b.color ? 1 < this.options.data.length ? (b._colorSet = [this.selectedColorSet[b.index % this.selectedColorSet.length]], b.color = this.selectedColorSet[b.index % this.selectedColorSet.length]) : b._colorSet = "line" === b.type || "stepLine" === b.type || "spline" === b.type || "area" === b.type || "stepArea" === b.type || "splineArea" === b.type || "stackedArea" === b.type || "stackedArea100" === b.type || "rangeArea" === b.type || "rangeSplineArea" === b.type || "candlestick" === b.type || "ohlc" === b.type || "waterfall" === b.type || "boxAndWhisker" === b.type ? [this.selectedColorSet[0]] : this.selectedColorSet : b._colorSet = [b.color];
                null === b.markerSize && (("line" === b.type || "stepLine" === b.type || "spline" === b.type || 0 <= b.type.toLowerCase().indexOf("area")) && b.dataPoints && b.dataPoints.length < this.width / 16 || "scatter" === b.type) && (b.markerSize = 8);
                "bubble" !== b.type && "scatter" !== b.type || !b.dataPoints || (b.dataPoints.some ? b.dataPoints.some(function(a2) {
                  return a2.x;
                }) && b.dataPoints.sort(h) : b.dataPoints.sort(h));
                this.data.push(b);
                var e = b.axisPlacement, d = d || e, f;
                "normal" === e ? "xySwapped" === this.plotInfo.axisPlacement ? f = 'You cannot combine "' + b.type + '" with bar chart' : "none" === this.plotInfo.axisPlacement ? f = 'You cannot combine "' + b.type + '" with pie chart' : null === this.plotInfo.axisPlacement && (this.plotInfo.axisPlacement = "normal") : "xySwapped" === e ? "normal" === this.plotInfo.axisPlacement ? f = 'You cannot combine "' + b.type + '" with line, area, column or pie chart' : "none" === this.plotInfo.axisPlacement ? f = 'You cannot combine "' + b.type + '" with pie chart' : null === this.plotInfo.axisPlacement && (this.plotInfo.axisPlacement = "xySwapped") : "none" === e ? "normal" === this.plotInfo.axisPlacement ? f = 'You cannot combine "' + b.type + '" with line, area, column or bar chart' : "xySwapped" === this.plotInfo.axisPlacement ? f = 'You cannot combine "' + b.type + '" with bar chart' : null === this.plotInfo.axisPlacement && (this.plotInfo.axisPlacement = "none") : null === e && "none" === this.plotInfo.axisPlacement && (f = 'You cannot combine "' + b.type + '" with pie chart');
                if (f && window.console) {
                  window.console.log(f);
                  return;
                }
              }
            for (c = 0; c < this.data.length; c++) {
              if ("none" == d && "error" === this.data[c].type && window.console) {
                window.console.log('You cannot combine "' + b.type + '" with error chart');
                return;
              }
              "error" === this.data[c].type && (this.data[c].axisPlacement = this.plotInfo.axisPlacement = d || "normal", this.data[c]._linkedSeries = null === this.data[c].linkedDataSeriesIndex ? null : this.data[this.data[c].linkedDataSeriesIndex]);
            }
          }
          this._objectsInitialized = true;
          this._plotAreaElements = [];
        };
        n._supportedChartTypes = Ea("line stepLine spline column area stepArea splineArea bar bubble scatter stackedColumn stackedColumn100 stackedBar stackedBar100 stackedArea stackedArea100 candlestick ohlc boxAndWhisker rangeColumn error rangeBar rangeArea rangeSplineArea pie doughnut funnel pyramid waterfall".split(" "));
        n.prototype.setLayout = function() {
          for (var a = this._plotAreaElements, d = 0; d < this.data.length; d++)
            if ("normal" === this.plotInfo.axisPlacement || "xySwapped" === this.plotInfo.axisPlacement) {
              if (!this.data[d].axisYType || "primary" === this.data[d].axisYType)
                if (this.options.axisY && 0 < this.options.axisY.length) {
                  if (!this.axisY.length)
                    for (var c = 0; c < this.options.axisY.length; c++)
                      "normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisY[c] = new A(this, "axisY", this.options.axisY[c], c, "axisY", "left")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisY[c] = new A(
                        this,
                        "axisY",
                        this.options.axisY[c],
                        c,
                        "axisY",
                        "bottom"
                      ));
                  this.data[d].axisY = this.axisY[0 <= this.data[d].axisYIndex && this.data[d].axisYIndex < this.axisY.length ? this.data[d].axisYIndex : 0];
                  this.axisY[0 <= this.data[d].axisYIndex && this.data[d].axisYIndex < this.axisY.length ? this.data[d].axisYIndex : 0].dataSeries.push(this.data[d]);
                } else
                  this.axisY.length || ("normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisY[0] = new A(this, "axisY", this.options.axisY, 0, "axisY", "left")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisY[0] = new A(
                    this,
                    "axisY",
                    this.options.axisY,
                    0,
                    "axisY",
                    "bottom"
                  ))), this.data[d].axisY = this.axisY[0], this.axisY[0].dataSeries.push(this.data[d]);
              if ("secondary" === this.data[d].axisYType)
                if (this.options.axisY2 && 0 < this.options.axisY2.length) {
                  if (!this.axisY2.length)
                    for (c = 0; c < this.options.axisY2.length; c++)
                      "normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisY2[c] = new A(this, "axisY2", this.options.axisY2[c], c, "axisY", "right")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisY2[c] = new A(
                        this,
                        "axisY2",
                        this.options.axisY2[c],
                        c,
                        "axisY",
                        "top"
                      ));
                  this.data[d].axisY = this.axisY2[0 <= this.data[d].axisYIndex && this.data[d].axisYIndex < this.axisY2.length ? this.data[d].axisYIndex : 0];
                  this.axisY2[0 <= this.data[d].axisYIndex && this.data[d].axisYIndex < this.axisY2.length ? this.data[d].axisYIndex : 0].dataSeries.push(this.data[d]);
                } else
                  this.axisY2.length || ("normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisY2[0] = new A(this, "axisY2", this.options.axisY2, 0, "axisY", "right")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisY2[0] = new A(this, "axisY2", this.options.axisY2, 0, "axisY", "top"))), this.data[d].axisY = this.axisY2[0], this.axisY2[0].dataSeries.push(this.data[d]);
              if (!this.data[d].axisXType || "primary" === this.data[d].axisXType)
                if (this.options.axisX && 0 < this.options.axisX.length) {
                  if (!this.axisX.length)
                    for (c = 0; c < this.options.axisX.length; c++)
                      "normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisX[c] = new A(this, "axisX", this.options.axisX[c], c, "axisX", "bottom")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisX[c] = new A(this, "axisX", this.options.axisX[c], c, "axisX", "left"));
                  this.data[d].axisX = this.axisX[0 <= this.data[d].axisXIndex && this.data[d].axisXIndex < this.axisX.length ? this.data[d].axisXIndex : 0];
                  this.axisX[0 <= this.data[d].axisXIndex && this.data[d].axisXIndex < this.axisX.length ? this.data[d].axisXIndex : 0].dataSeries.push(this.data[d]);
                } else
                  this.axisX.length || ("normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisX[0] = new A(this, "axisX", this.options.axisX, 0, "axisX", "bottom")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisX[0] = new A(this, "axisX", this.options.axisX, 0, "axisX", "left"))), this.data[d].axisX = this.axisX[0], this.axisX[0].dataSeries.push(this.data[d]);
              if ("secondary" === this.data[d].axisXType)
                if (this.options.axisX2 && 0 < this.options.axisX2.length) {
                  if (!this.axisX2.length)
                    for (c = 0; c < this.options.axisX2.length; c++)
                      "normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisX2[c] = new A(this, "axisX2", this.options.axisX2[c], c, "axisX", "top")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisX2[c] = new A(this, "axisX2", this.options.axisX2[c], c, "axisX", "right"));
                  this.data[d].axisX = this.axisX2[0 <= this.data[d].axisXIndex && this.data[d].axisXIndex < this.axisX2.length ? this.data[d].axisXIndex : 0];
                  this.axisX2[0 <= this.data[d].axisXIndex && this.data[d].axisXIndex < this.axisX2.length ? this.data[d].axisXIndex : 0].dataSeries.push(this.data[d]);
                } else
                  this.axisX2.length || ("normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisX2[0] = new A(
                    this,
                    "axisX2",
                    this.options.axisX2,
                    0,
                    "axisX",
                    "top"
                  )) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisX2[0] = new A(this, "axisX2", this.options.axisX2, 0, "axisX", "right"))), this.data[d].axisX = this.axisX2[0], this.axisX2[0].dataSeries.push(this.data[d]);
            }
          if (this.axisY) {
            for (c = 1; c < this.axisY.length; c++)
              "undefined" === typeof this.axisY[c].options.gridThickness && (this.axisY[c].gridThickness = 0);
            for (c = 0; c < this.axisY.length - 1; c++)
              "undefined" === typeof this.axisY[c].options.margin && (this.axisY[c].margin = 10);
          }
          if (this.axisY2) {
            for (c = 1; c < this.axisY2.length; c++)
              "undefined" === typeof this.axisY2[c].options.gridThickness && (this.axisY2[c].gridThickness = 0);
            for (c = 0; c < this.axisY2.length - 1; c++)
              "undefined" === typeof this.axisY2[c].options.margin && (this.axisY2[c].margin = 10);
          }
          this.axisY && 0 < this.axisY.length && (this.axisY2 && 0 < this.axisY2.length) && (0 < this.axisY[0].gridThickness && "undefined" === typeof this.axisY2[0].options.gridThickness ? this.axisY2[0].gridThickness = 0 : 0 < this.axisY2[0].gridThickness && "undefined" === typeof this.axisY[0].options.gridThickness && (this.axisY[0].gridThickness = 0));
          if (this.axisX)
            for (c = 0; c < this.axisX.length; c++)
              "undefined" === typeof this.axisX[c].options.gridThickness && (this.axisX[c].gridThickness = 0);
          if (this.axisX2)
            for (c = 0; c < this.axisX2.length; c++)
              "undefined" === typeof this.axisX2[c].options.gridThickness && (this.axisX2[c].gridThickness = 0);
          this.axisX && 0 < this.axisX.length && (this.axisX2 && 0 < this.axisX2.length) && (0 < this.axisX[0].gridThickness && "undefined" === typeof this.axisX2[0].options.gridThickness ? this.axisX2[0].gridThickness = 0 : 0 < this.axisX2[0].gridThickness && "undefined" === typeof this.axisX[0].options.gridThickness && (this.axisX[0].gridThickness = 0));
          c = false;
          if (0 < this._axes.length && this.options.zoomEnabled && (this.zoomEnabled || this.panEnabled)) {
            for (d = 0; d < this._axes.length; d++)
              if (!s(this._axes[d].viewportMinimum) || !s(this._axes[d].viewportMaximum)) {
                c = true;
                break;
              }
          }
          c ? (Ma(this._zoomButton, this._resetButton), this._toolBar.style.border = this.toolbar.buttonBorderThickness + "px solid " + this.toolbar.buttonBorderColor, this._zoomButton.style.borderRight = this.toolbar.buttonBorderThickness + "px solid " + this.toolbar.buttonBorderColor, this._resetButton.style.borderRight = (this.exportEnabled ? this.toolbar.buttonBorderThickness : 0) + "px solid " + this.toolbar.buttonBorderColor) : (wa(this._zoomButton, this._resetButton), this._toolBar.style.border = this.toolbar.buttonBorderThickness + "px solid transparent", this.options.zoomEnabled && (this.zoomEnabled = true, this.panEnabled = false));
          fb(this);
          this._processData();
          this.options.title && (this.title = new za(this, this.options.title), this.title.dockInsidePlotArea ? a.push(this.title) : this.title.setLayout());
          if (this.options.subtitles)
            for (d = 0; d < this.options.subtitles.length; d++)
              c = new Ja(this, this.options.subtitles[d], d), this.subtitles.push(c), c.dockInsidePlotArea ? a.push(c) : c.setLayout();
          this.legend = new K2(this, this.options.legend);
          for (d = 0; d < this.data.length; d++)
            (this.data[d].showInLegend || "pie" === this.data[d].type || "doughnut" === this.data[d].type || "funnel" === this.data[d].type || "pyramid" === this.data[d].type) && this.legend.dataSeries.push(this.data[d]);
          this.legend.dockInsidePlotArea ? a.push(this.legend) : this.legend.setLayout();
          for (d = 0; d < this._axes.length; d++)
            if (this._axes[d].scaleBreaks && this._axes[d].scaleBreaks._appliedBreaks.length) {
              w ? (this._breaksCanvas = ua(this.width, this.height, true), this._breaksCanvasCtx = this._breaksCanvas.getContext("2d")) : (this._breaksCanvas = this.canvas, this._breaksCanvasCtx = this.ctx);
              break;
            }
          this._preRenderCanvas = ua(this.width, this.height);
          this._preRenderCtx = this._preRenderCanvas.getContext("2d");
          "normal" !== this.plotInfo.axisPlacement && "xySwapped" !== this.plotInfo.axisPlacement || A.setLayout(this.axisX, this.axisX2, this.axisY, this.axisY2, this.plotInfo.axisPlacement, this.layoutManager.getFreeSpace());
        };
        n.prototype.renderElements = function() {
          if (this.height) {
            var a = this._plotAreaElements;
            this.title && !this.title.dockInsidePlotArea && this.title.render();
            for (var d = 0; d < this.subtitles.length; d++)
              this.subtitles[d].dockInsidePlotArea || this.subtitles[d].render();
            this.legend.dockInsidePlotArea || this.legend.render();
            if ("normal" === this.plotInfo.axisPlacement || "xySwapped" === this.plotInfo.axisPlacement)
              A.render(this.axisX, this.axisX2, this.axisY, this.axisY2, this.plotInfo.axisPlacement);
            else if ("none" === this.plotInfo.axisPlacement)
              this.preparePlotArea();
            else
              return;
            for (d = 0; d < a.length; d++)
              a[d].setLayout(), a[d].render();
            var c = [];
            if (this.animatedRender) {
              var b = ua(this.width, this.height);
              b.getContext("2d").drawImage(this.canvas, 0, 0, this.width, this.height);
            }
            ib(this);
            var a = this.ctx.miterLimit, e;
            this.ctx.miterLimit = 3;
            w && this._breaksCanvas && (this._preRenderCtx.drawImage(
              this.canvas,
              0,
              0,
              this.width,
              this.height
            ), this._preRenderCtx.drawImage(this._breaksCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx.globalCompositeOperation = "source-atop", this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), this._preRenderCtx.clearRect(0, 0, this.width, this.height));
            for (d = 0; d < this.plotInfo.plotTypes.length; d++)
              for (var f = this.plotInfo.plotTypes[d], l = 0; l < f.plotUnits.length; l++) {
                var t = f.plotUnits[l], C = null;
                t.targetCanvas && ya(t.targetCanvas);
                t.targetCanvas = null;
                this.animatedRender && (t.targetCanvas = ua(this.width, this.height), t.targetCanvasCtx = t.targetCanvas.getContext("2d"), e = t.targetCanvasCtx.miterLimit, t.targetCanvasCtx.miterLimit = 3);
                "line" === t.type ? C = this.renderLine(t) : "stepLine" === t.type ? C = this.renderStepLine(t) : "spline" === t.type ? C = this.renderSpline(t) : "column" === t.type ? C = this.renderColumn(t) : "bar" === t.type ? C = this.renderBar(t) : "area" === t.type ? C = this.renderArea(t) : "stepArea" === t.type ? C = this.renderStepArea(t) : "splineArea" === t.type ? C = this.renderSplineArea(t) : "stackedColumn" === t.type ? C = this.renderStackedColumn(t) : "stackedColumn100" === t.type ? C = this.renderStackedColumn100(t) : "stackedBar" === t.type ? C = this.renderStackedBar(t) : "stackedBar100" === t.type ? C = this.renderStackedBar100(t) : "stackedArea" === t.type ? C = this.renderStackedArea(t) : "stackedArea100" === t.type ? C = this.renderStackedArea100(t) : "bubble" === t.type ? C = C = this.renderBubble(t) : "scatter" === t.type ? C = this.renderScatter(t) : "pie" === t.type ? this.renderPie(t) : "doughnut" === t.type ? this.renderPie(t) : "funnel" === t.type ? C = this.renderFunnel(t) : "pyramid" === t.type ? C = this.renderFunnel(t) : "candlestick" === t.type ? C = this.renderCandlestick(t) : "ohlc" === t.type ? C = this.renderCandlestick(t) : "rangeColumn" === t.type ? C = this.renderRangeColumn(t) : "error" === t.type ? C = this.renderError(t) : "rangeBar" === t.type ? C = this.renderRangeBar(t) : "rangeArea" === t.type ? C = this.renderRangeArea(t) : "rangeSplineArea" === t.type ? C = this.renderRangeSplineArea(t) : "waterfall" === t.type ? C = this.renderWaterfall(t) : "boxAndWhisker" === t.type && (C = this.renderBoxAndWhisker(t));
                for (var k = 0; k < t.dataSeriesIndexes.length; k++)
                  this._dataInRenderedOrder.push(this.data[t.dataSeriesIndexes[k]]);
                this.animatedRender && (t.targetCanvasCtx.miterLimit = e, C && c.push(C));
              }
            this.ctx.miterLimit = a;
            this.animatedRender && this._breaksCanvasCtx && c.push({ source: this._breaksCanvasCtx, dest: this.plotArea.ctx, animationCallback: M.fadeInAnimation, easingFunction: M.easing.easeInQuad, animationBase: 0, startTimePercent: 0.7 });
            this.animatedRender && 0 < this._indexLabels.length && (e = ua(this.width, this.height).getContext("2d"), c.push(this.renderIndexLabels(e)));
            var m = this;
            if (0 < c.length)
              m.disableToolTip = true, m._animator.animate(
                200,
                m.animationDuration,
                function(a2) {
                  m.ctx.clearRect(0, 0, m.width, m.height);
                  m.ctx.drawImage(b, 0, 0, Math.floor(m.width * la), Math.floor(m.height * la), 0, 0, m.width, m.height);
                  for (var e2 = 0; e2 < c.length; e2++)
                    C = c[e2], 1 > a2 && "undefined" !== typeof C.startTimePercent ? a2 >= C.startTimePercent && C.animationCallback(C.easingFunction(a2 - C.startTimePercent, 0, 1, 1 - C.startTimePercent), C) : C.animationCallback(C.easingFunction(a2, 0, 1, 1), C);
                  m.dispatchEvent("dataAnimationIterationEnd", { chart: m });
                },
                function() {
                  c = [];
                  for (var a2 = 0; a2 < m.plotInfo.plotTypes.length; a2++)
                    for (var e2 = m.plotInfo.plotTypes[a2], d2 = 0; d2 < e2.plotUnits.length; d2++) {
                      var f2 = e2.plotUnits[d2];
                      f2.targetCanvas && ya(f2.targetCanvas);
                      f2.targetCanvas = null;
                    }
                  b = null;
                  m.disableToolTip = false;
                  m.dispatchEvent("dataAnimationEnd", { chart: m });
                }
              );
            else {
              if (m._breaksCanvas)
                if (w)
                  m.plotArea.ctx.drawImage(m._breaksCanvas, 0, 0, this.width, this.height);
                else
                  for (k = 0; k < m._axes.length; k++)
                    m._axes[k].createMask();
              0 < m._indexLabels.length && m.renderIndexLabels();
              m.dispatchEvent("dataAnimationIterationEnd", { chart: m });
              m.dispatchEvent("dataAnimationEnd", { chart: m });
            }
            this.attachPlotAreaEventHandlers();
            this.zoomEnabled || (this.panEnabled || !this._zoomButton || "none" === this._zoomButton.style.display) || wa(this._zoomButton, this._resetButton);
            this.toolTip._updateToolTip();
            this.renderCount++;
            Ia && (m = this, setTimeout(function() {
              var a2 = document.getElementById("ghostCanvasCopy");
              a2 && (Na(a2, m.width, m.height), a2.getContext("2d").drawImage(m._eventManager.ghostCanvas, 0, 0));
            }, 2e3));
            this._breaksCanvas && (delete this._breaksCanvas, delete this._breaksCanvasCtx);
            for (k = 0; k < this._axes.length; k++)
              this._axes[k].maskCanvas && (delete this._axes[k].maskCanvas, delete this._axes[k].maskCtx);
          }
        };
        n.prototype.render = function(a) {
          a && (this.options = a);
          this._initialize();
          this.setLayout();
          this.renderElements();
          this._preRenderCanvas && ya(this._preRenderCanvas);
        };
        n.prototype.attachPlotAreaEventHandlers = function() {
          this.attachEvent({ context: this, chart: this, mousedown: this._plotAreaMouseDown, mouseup: this._plotAreaMouseUp, mousemove: this._plotAreaMouseMove, cursor: this.panEnabled ? "move" : "default", capture: true, bounds: this.plotArea });
        };
        n.prototype.categoriseDataSeries = function() {
          for (var a = "", d = 0; d < this.data.length; d++)
            if (a = this.data[d], a.dataPoints && (0 !== a.dataPoints.length && a.visible) && 0 <= n._supportedChartTypes.indexOf(a.type)) {
              for (var c = null, b = false, e = null, f = false, l = 0; l < this.plotInfo.plotTypes.length; l++)
                if (this.plotInfo.plotTypes[l].type === a.type) {
                  b = true;
                  c = this.plotInfo.plotTypes[l];
                  break;
                }
              b || (c = { type: a.type, totalDataSeries: 0, plotUnits: [] }, this.plotInfo.plotTypes.push(c));
              for (l = 0; l < c.plotUnits.length; l++)
                if (c.plotUnits[l].axisYType === a.axisYType && c.plotUnits[l].axisXType === a.axisXType && c.plotUnits[l].axisYIndex === a.axisYIndex && c.plotUnits[l].axisXIndex === a.axisXIndex) {
                  f = true;
                  e = c.plotUnits[l];
                  break;
                }
              f || (e = { type: a.type, previousDataSeriesCount: 0, index: c.plotUnits.length, plotType: c, axisXType: a.axisXType, axisYType: a.axisYType, axisYIndex: a.axisYIndex, axisXIndex: a.axisXIndex, axisY: "primary" === a.axisYType ? this.axisY[0 <= a.axisYIndex && a.axisYIndex < this.axisY.length ? a.axisYIndex : 0] : this.axisY2[0 <= a.axisYIndex && a.axisYIndex < this.axisY2.length ? a.axisYIndex : 0], axisX: "primary" === a.axisXType ? this.axisX[0 <= a.axisXIndex && a.axisXIndex < this.axisX.length ? a.axisXIndex : 0] : this.axisX2[0 <= a.axisXIndex && a.axisXIndex < this.axisX2.length ? a.axisXIndex : 0], dataSeriesIndexes: [], yTotals: [], yAbsTotals: [] }, c.plotUnits.push(e));
              c.totalDataSeries++;
              e.dataSeriesIndexes.push(d);
              a.plotUnit = e;
            }
          for (d = 0; d < this.plotInfo.plotTypes.length; d++)
            for (c = this.plotInfo.plotTypes[d], l = a = 0; l < c.plotUnits.length; l++)
              c.plotUnits[l].previousDataSeriesCount = a, a += c.plotUnits[l].dataSeriesIndexes.length;
        };
        n.prototype.assignIdToDataPoints = function() {
          for (var a = 0; a < this.data.length; a++) {
            var d = this.data[a];
            if (d.dataPoints)
              for (var c = d.dataPoints.length, b = 0; b < c; b++)
                d.dataPointIds[b] = ++this._eventManager.lastObjectId;
          }
        };
        n.prototype._processData = function() {
          this.assignIdToDataPoints();
          this.categoriseDataSeries();
          for (var a = 0; a < this.plotInfo.plotTypes.length; a++)
            for (var d = this.plotInfo.plotTypes[a], c = 0; c < d.plotUnits.length; c++) {
              var b = d.plotUnits[c];
              "line" === b.type || "stepLine" === b.type || "spline" === b.type || "column" === b.type || "area" === b.type || "stepArea" === b.type || "splineArea" === b.type || "bar" === b.type || "bubble" === b.type || "scatter" === b.type ? this._processMultiseriesPlotUnit(b) : "stackedColumn" === b.type || "stackedBar" === b.type || "stackedArea" === b.type ? this._processStackedPlotUnit(b) : "stackedColumn100" === b.type || "stackedBar100" === b.type || "stackedArea100" === b.type ? this._processStacked100PlotUnit(b) : "candlestick" === b.type || "ohlc" === b.type || "rangeColumn" === b.type || "rangeBar" === b.type || "rangeArea" === b.type || "rangeSplineArea" === b.type || "error" === b.type || "boxAndWhisker" === b.type ? this._processMultiYPlotUnit(b) : "waterfall" === b.type && this._processSpecificPlotUnit(b);
            }
          this.calculateAutoBreaks();
        };
        n.prototype._processMultiseriesPlotUnit = function(a) {
          if (a.dataSeriesIndexes && !(1 > a.dataSeriesIndexes.length))
            for (var d = a.axisY.dataInfo, c = a.axisX.dataInfo, b, e, f = false, l = 0; l < a.dataSeriesIndexes.length; l++) {
              var t = this.data[a.dataSeriesIndexes[l]], C = 0, k = false, m = false, p;
              if ("normal" === t.axisPlacement || "xySwapped" === t.axisPlacement)
                var q = a.axisX.sessionVariables.newViewportMinimum ? a.axisX.sessionVariables.newViewportMinimum : a.axisX.options && a.axisX.options.viewportMinimum ? a.axisX.options.viewportMinimum : a.axisX.options && a.axisX.options.minimum ? a.axisX.options.minimum : a.axisX.logarithmic ? 0 : -Infinity, g = a.axisX.sessionVariables.newViewportMaximum ? a.axisX.sessionVariables.newViewportMaximum : a.axisX.options && a.axisX.options.viewportMaximum ? a.axisX.options.viewportMaximum : a.axisX.options && a.axisX.options.maximum ? a.axisX.options.maximum : Infinity;
              if (t.dataPoints[C].x && t.dataPoints[C].x.getTime || "dateTime" === t.xValueType)
                f = true;
              for (C = 0; C < t.dataPoints.length; C++) {
                "undefined" === typeof t.dataPoints[C].x && (t.dataPoints[C].x = C + (a.axisX.logarithmic ? 1 : 0));
                t.dataPoints[C].x.getTime ? (f = true, b = t.dataPoints[C].x.getTime()) : b = t.dataPoints[C].x;
                e = t.dataPoints[C].y;
                b < c.min && (c.min = b);
                b > c.max && (c.max = b);
                e < d.min && "number" === typeof e && (d.min = e);
                e > d.max && "number" === typeof e && (d.max = e);
                if (0 < C) {
                  if (a.axisX.logarithmic) {
                    var r = b / t.dataPoints[C - 1].x;
                    1 > r && (r = 1 / r);
                    c.minDiff > r && 1 !== r && (c.minDiff = r);
                  } else
                    r = b - t.dataPoints[C - 1].x, 0 > r && (r *= -1), c.minDiff > r && 0 !== r && (c.minDiff = r);
                  null !== e && null !== t.dataPoints[C - 1].y && (a.axisY.logarithmic ? (r = e / t.dataPoints[C - 1].y, 1 > r && (r = 1 / r), d.minDiff > r && 1 !== r && (d.minDiff = r)) : (r = e - t.dataPoints[C - 1].y, 0 > r && (r *= -1), d.minDiff > r && 0 !== r && (d.minDiff = r)));
                }
                if (b < q && !k)
                  null !== e && (p = b);
                else {
                  if (!k && (k = true, 0 < C)) {
                    C -= 2;
                    continue;
                  }
                  if (b > g && !m)
                    m = true;
                  else if (b > g && m)
                    continue;
                  t.dataPoints[C].label && (a.axisX.labels[b] = t.dataPoints[C].label);
                  b < c.viewPortMin && (c.viewPortMin = b);
                  b > c.viewPortMax && (c.viewPortMax = b);
                  null === e ? c.viewPortMin === b && p < b && (c.viewPortMin = p) : (e < d.viewPortMin && "number" === typeof e && (d.viewPortMin = e), e > d.viewPortMax && "number" === typeof e && (d.viewPortMax = e));
                }
              }
              t.axisX.valueType = t.xValueType = f ? "dateTime" : "number";
            }
        };
        n.prototype._processStackedPlotUnit = function(a) {
          if (a.dataSeriesIndexes && !(1 > a.dataSeriesIndexes.length)) {
            for (var d = a.axisY.dataInfo, c = a.axisX.dataInfo, b, e, f = false, l = [], t = [], C = Infinity, k = -Infinity, m = 0; m < a.dataSeriesIndexes.length; m++) {
              var p = this.data[a.dataSeriesIndexes[m]], q = 0, g = false, r = false, h2;
              if ("normal" === p.axisPlacement || "xySwapped" === p.axisPlacement)
                var ba = a.axisX.sessionVariables.newViewportMinimum ? a.axisX.sessionVariables.newViewportMinimum : a.axisX.options && a.axisX.options.viewportMinimum ? a.axisX.options.viewportMinimum : a.axisX.options && a.axisX.options.minimum ? a.axisX.options.minimum : -Infinity, u = a.axisX.sessionVariables.newViewportMaximum ? a.axisX.sessionVariables.newViewportMaximum : a.axisX.options && a.axisX.options.viewportMaximum ? a.axisX.options.viewportMaximum : a.axisX.options && a.axisX.options.maximum ? a.axisX.options.maximum : Infinity;
              if (p.dataPoints[q].x && p.dataPoints[q].x.getTime || "dateTime" === p.xValueType)
                f = true;
              for (q = 0; q < p.dataPoints.length; q++) {
                "undefined" === typeof p.dataPoints[q].x && (p.dataPoints[q].x = q + (a.axisX.logarithmic ? 1 : 0));
                p.dataPoints[q].x.getTime ? (f = true, b = p.dataPoints[q].x.getTime()) : b = p.dataPoints[q].x;
                e = s(p.dataPoints[q].y) ? 0 : p.dataPoints[q].y;
                b < c.min && (c.min = b);
                b > c.max && (c.max = b);
                if (0 < q) {
                  if (a.axisX.logarithmic) {
                    var y = b / p.dataPoints[q - 1].x;
                    1 > y && (y = 1 / y);
                    c.minDiff > y && 1 !== y && (c.minDiff = y);
                  } else
                    y = b - p.dataPoints[q - 1].x, 0 > y && (y *= -1), c.minDiff > y && 0 !== y && (c.minDiff = y);
                  null !== e && null !== p.dataPoints[q - 1].y && (a.axisY.logarithmic ? 0 < e && (y = e / p.dataPoints[q - 1].y, 1 > y && (y = 1 / y), d.minDiff > y && 1 !== y && (d.minDiff = y)) : (y = e - p.dataPoints[q - 1].y, 0 > y && (y *= -1), d.minDiff > y && 0 !== y && (d.minDiff = y)));
                }
                if (b < ba && !g)
                  null !== p.dataPoints[q].y && (h2 = b);
                else {
                  if (!g && (g = true, 0 < q)) {
                    q -= 2;
                    continue;
                  }
                  if (b > u && !r)
                    r = true;
                  else if (b > u && r)
                    continue;
                  p.dataPoints[q].label && (a.axisX.labels[b] = p.dataPoints[q].label);
                  b < c.viewPortMin && (c.viewPortMin = b);
                  b > c.viewPortMax && (c.viewPortMax = b);
                  null === p.dataPoints[q].y ? c.viewPortMin === b && h2 < b && (c.viewPortMin = h2) : (a.yTotals[b] = (a.yTotals[b] ? a.yTotals[b] : 0) + e, a.yAbsTotals[b] = (a.yAbsTotals[b] ? a.yAbsTotals[b] : 0) + Math.abs(e), 0 <= e ? l[b] ? l[b] += e : (l[b] = e, C = Math.min(e, C)) : t[b] ? t[b] += e : (t[b] = e, k = Math.max(e, k)));
                }
              }
              a.axisY.scaleBreaks && (a.axisY.scaleBreaks.autoCalculate && 1 <= a.axisY.scaleBreaks.maxNumberOfAutoBreaks) && (d.dataPointYPositiveSums ? (d.dataPointYPositiveSums.push.apply(d.dataPointYPositiveSums, l), d.dataPointYNegativeSums.push.apply(d.dataPointYPositiveSums, t)) : (d.dataPointYPositiveSums = l, d.dataPointYNegativeSums = t));
              p.axisX.valueType = p.xValueType = f ? "dateTime" : "number";
            }
            for (q in l)
              l.hasOwnProperty(q) && !isNaN(q) && (a = l[q], a < d.min && (d.min = Math.min(a, C)), a > d.max && (d.max = a), q < c.viewPortMin || q > c.viewPortMax || (a < d.viewPortMin && (d.viewPortMin = Math.min(a, C)), a > d.viewPortMax && (d.viewPortMax = a)));
            for (q in t)
              t.hasOwnProperty(q) && !isNaN(q) && (a = t[q], a < d.min && (d.min = a), a > d.max && (d.max = Math.max(a, k)), q < c.viewPortMin || q > c.viewPortMax || (a < d.viewPortMin && (d.viewPortMin = a), a > d.viewPortMax && (d.viewPortMax = Math.max(a, k))));
          }
        };
        n.prototype._processStacked100PlotUnit = function(a) {
          if (a.dataSeriesIndexes && !(1 > a.dataSeriesIndexes.length)) {
            for (var d = a.axisY.dataInfo, c = a.axisX.dataInfo, b, e, f = false, l = false, t = false, C = [], k = 0; k < a.dataSeriesIndexes.length; k++) {
              var m = this.data[a.dataSeriesIndexes[k]], p = 0, q = false, g = false, r;
              if ("normal" === m.axisPlacement || "xySwapped" === m.axisPlacement)
                var h2 = a.axisX.sessionVariables.newViewportMinimum ? a.axisX.sessionVariables.newViewportMinimum : a.axisX.options && a.axisX.options.viewportMinimum ? a.axisX.options.viewportMinimum : a.axisX.options && a.axisX.options.minimum ? a.axisX.options.minimum : -Infinity, ba = a.axisX.sessionVariables.newViewportMaximum ? a.axisX.sessionVariables.newViewportMaximum : a.axisX.options && a.axisX.options.viewportMaximum ? a.axisX.options.viewportMaximum : a.axisX.options && a.axisX.options.maximum ? a.axisX.options.maximum : Infinity;
              if (m.dataPoints[p].x && m.dataPoints[p].x.getTime || "dateTime" === m.xValueType)
                f = true;
              for (p = 0; p < m.dataPoints.length; p++) {
                "undefined" === typeof m.dataPoints[p].x && (m.dataPoints[p].x = p + (a.axisX.logarithmic ? 1 : 0));
                m.dataPoints[p].x.getTime ? (f = true, b = m.dataPoints[p].x.getTime()) : b = m.dataPoints[p].x;
                e = s(m.dataPoints[p].y) ? null : m.dataPoints[p].y;
                b < c.min && (c.min = b);
                b > c.max && (c.max = b);
                if (0 < p) {
                  if (a.axisX.logarithmic) {
                    var u = b / m.dataPoints[p - 1].x;
                    1 > u && (u = 1 / u);
                    c.minDiff > u && 1 !== u && (c.minDiff = u);
                  } else
                    u = b - m.dataPoints[p - 1].x, 0 > u && (u *= -1), c.minDiff > u && 0 !== u && (c.minDiff = u);
                  s(e) || null === m.dataPoints[p - 1].y || (a.axisY.logarithmic ? 0 < e && (u = e / m.dataPoints[p - 1].y, 1 > u && (u = 1 / u), d.minDiff > u && 1 !== u && (d.minDiff = u)) : (u = e - m.dataPoints[p - 1].y, 0 > u && (u *= -1), d.minDiff > u && 0 !== u && (d.minDiff = u)));
                }
                if (b < h2 && !q)
                  null !== e && (r = b);
                else {
                  if (!q && (q = true, 0 < p)) {
                    p -= 2;
                    continue;
                  }
                  if (b > ba && !g)
                    g = true;
                  else if (b > ba && g)
                    continue;
                  m.dataPoints[p].label && (a.axisX.labels[b] = m.dataPoints[p].label);
                  b < c.viewPortMin && (c.viewPortMin = b);
                  b > c.viewPortMax && (c.viewPortMax = b);
                  null === e ? c.viewPortMin === b && r < b && (c.viewPortMin = r) : (a.yTotals[b] = (a.yTotals[b] ? a.yTotals[b] : 0) + e, a.yAbsTotals[b] = (a.yAbsTotals[b] ? a.yAbsTotals[b] : 0) + Math.abs(e), 0 <= e ? l = true : 0 > e && (t = true), C[b] = C[b] ? C[b] + Math.abs(e) : Math.abs(e));
                }
              }
              m.axisX.valueType = m.xValueType = f ? "dateTime" : "number";
            }
            a.axisY.logarithmic ? (d.max = s(d.viewPortMax) ? 99 * Math.pow(a.axisY.logarithmBase, -0.05) : Math.max(d.viewPortMax, 99 * Math.pow(a.axisY.logarithmBase, -0.05)), d.min = s(d.viewPortMin) ? 1 : Math.min(d.viewPortMin, 1)) : l && !t ? (d.max = s(d.viewPortMax) ? 99 : Math.max(d.viewPortMax, 99), d.min = s(d.viewPortMin) ? 1 : Math.min(d.viewPortMin, 1)) : l && t ? (d.max = s(d.viewPortMax) ? 99 : Math.max(d.viewPortMax, 99), d.min = s(d.viewPortMin) ? -99 : Math.min(d.viewPortMin, -99)) : !l && t && (d.max = s(d.viewPortMax) ? -1 : Math.max(
              d.viewPortMax,
              -1
            ), d.min = s(d.viewPortMin) ? -99 : Math.min(d.viewPortMin, -99));
            d.viewPortMin = d.min;
            d.viewPortMax = d.max;
            a.dataPointYSums = C;
          }
        };
        n.prototype._processMultiYPlotUnit = function(a) {
          if (a.dataSeriesIndexes && !(1 > a.dataSeriesIndexes.length))
            for (var d = a.axisY.dataInfo, c = a.axisX.dataInfo, b, e, f, l, t = false, C = 0; C < a.dataSeriesIndexes.length; C++) {
              var k = this.data[a.dataSeriesIndexes[C]], m = 0, p = false, q = false, g, r, h2;
              if ("normal" === k.axisPlacement || "xySwapped" === k.axisPlacement)
                var s2 = a.axisX.sessionVariables.newViewportMinimum ? a.axisX.sessionVariables.newViewportMinimum : a.axisX.options && a.axisX.options.viewportMinimum ? a.axisX.options.viewportMinimum : a.axisX.options && a.axisX.options.minimum ? a.axisX.options.minimum : a.axisX.logarithmic ? 0 : -Infinity, u = a.axisX.sessionVariables.newViewportMaximum ? a.axisX.sessionVariables.newViewportMaximum : a.axisX.options && a.axisX.options.viewportMaximum ? a.axisX.options.viewportMaximum : a.axisX.options && a.axisX.options.maximum ? a.axisX.options.maximum : Infinity;
              if (k.dataPoints[m].x && k.dataPoints[m].x.getTime || "dateTime" === k.xValueType)
                t = true;
              for (m = 0; m < k.dataPoints.length; m++) {
                "undefined" === typeof k.dataPoints[m].x && (k.dataPoints[m].x = m + (a.axisX.logarithmic ? 1 : 0));
                k.dataPoints[m].x.getTime ? (t = true, b = k.dataPoints[m].x.getTime()) : b = k.dataPoints[m].x;
                if ((e = k.dataPoints[m].y) && e.length) {
                  f = Math.min.apply(null, e);
                  l = Math.max.apply(null, e);
                  r = true;
                  for (var y = 0; y < e.length; y++)
                    null === e.k && (r = false);
                  r && (p || (h2 = g), g = b);
                }
                b < c.min && (c.min = b);
                b > c.max && (c.max = b);
                f < d.min && (d.min = f);
                l > d.max && (d.max = l);
                0 < m && (a.axisX.logarithmic ? (r = b / k.dataPoints[m - 1].x, 1 > r && (r = 1 / r), c.minDiff > r && 1 !== r && (c.minDiff = r)) : (r = b - k.dataPoints[m - 1].x, 0 > r && (r *= -1), c.minDiff > r && 0 !== r && (c.minDiff = r)), e && (null !== e[0] && k.dataPoints[m - 1].y && null !== k.dataPoints[m - 1].y[0]) && (a.axisY.logarithmic ? (r = e[0] / k.dataPoints[m - 1].y[0], 1 > r && (r = 1 / r), d.minDiff > r && 1 !== r && (d.minDiff = r)) : (r = e[0] - k.dataPoints[m - 1].y[0], 0 > r && (r *= -1), d.minDiff > r && 0 !== r && (d.minDiff = r))));
                if (!(b < s2) || p) {
                  if (!p && (p = true, 0 < m)) {
                    m -= 2;
                    g = h2;
                    continue;
                  }
                  if (b > u && !q)
                    q = true;
                  else if (b > u && q)
                    continue;
                  k.dataPoints[m].label && (a.axisX.labels[b] = k.dataPoints[m].label);
                  b < c.viewPortMin && (c.viewPortMin = b);
                  b > c.viewPortMax && (c.viewPortMax = b);
                  if (c.viewPortMin === b && e) {
                    for (y = 0; y < e.length; y++)
                      if (null === e[y] && g < b) {
                        c.viewPortMin = g;
                        break;
                      }
                  }
                  null === e ? c.viewPortMin === b && g < b && (c.viewPortMin = g) : (f < d.viewPortMin && (d.viewPortMin = f), l > d.viewPortMax && (d.viewPortMax = l));
                }
              }
              k.axisX.valueType = k.xValueType = t ? "dateTime" : "number";
            }
        };
        n.prototype._processSpecificPlotUnit = function(a) {
          if ("waterfall" === a.type && a.dataSeriesIndexes && !(1 > a.dataSeriesIndexes.length))
            for (var d = a.axisY.dataInfo, c = a.axisX.dataInfo, b, e, f = false, l = 0; l < a.dataSeriesIndexes.length; l++) {
              var t = this.data[a.dataSeriesIndexes[l]], C = 0, k = false, m = false, p = b = 0;
              if ("normal" === t.axisPlacement || "xySwapped" === t.axisPlacement)
                var q = a.axisX.sessionVariables.newViewportMinimum ? a.axisX.sessionVariables.newViewportMinimum : a.axisX.options && a.axisX.options.viewportMinimum ? a.axisX.options.viewportMinimum : a.axisX.options && a.axisX.options.minimum ? a.axisX.options.minimum : a.axisX.logarithmic ? 0 : -Infinity, g = a.axisX.sessionVariables.newViewportMaximum ? a.axisX.sessionVariables.newViewportMaximum : a.axisX.options && a.axisX.options.viewportMaximum ? a.axisX.options.viewportMaximum : a.axisX.options && a.axisX.options.maximum ? a.axisX.options.maximum : Infinity;
              if (t.dataPoints[C].x && t.dataPoints[C].x.getTime || "dateTime" === t.xValueType)
                f = true;
              for (C = 0; C < t.dataPoints.length; C++)
                "undefined" !== typeof t.dataPoints[C].isCumulativeSum && true === t.dataPoints[C].isCumulativeSum ? (t.dataPointEOs[C].cumulativeSumYStartValue = 0, t.dataPointEOs[C].cumulativeSum = 0 === C ? 0 : t.dataPointEOs[C - 1].cumulativeSum, t.dataPoints[C].y = 0 === C ? 0 : t.dataPointEOs[C - 1].cumulativeSum) : "undefined" !== typeof t.dataPoints[C].isIntermediateSum && true === t.dataPoints[C].isIntermediateSum ? (t.dataPointEOs[C].cumulativeSumYStartValue = p, t.dataPointEOs[C].cumulativeSum = 0 === C ? 0 : t.dataPointEOs[C - 1].cumulativeSum, t.dataPoints[C].y = 0 === C ? 0 : b, p = 0 === C ? 0 : t.dataPointEOs[C - 1].cumulativeSum, b = 0) : (e = "number" !== typeof t.dataPoints[C].y ? 0 : t.dataPoints[C].y, t.dataPointEOs[C].cumulativeSumYStartValue = 0 === C ? 0 : t.dataPointEOs[C - 1].cumulativeSum, t.dataPointEOs[C].cumulativeSum = 0 === C ? e : t.dataPointEOs[C - 1].cumulativeSum + e, b += e);
              for (C = 0; C < t.dataPoints.length; C++)
                if ("undefined" === typeof t.dataPoints[C].x && (t.dataPoints[C].x = C + (a.axisX.logarithmic ? 1 : 0)), t.dataPoints[C].x.getTime ? (f = true, b = t.dataPoints[C].x.getTime()) : b = t.dataPoints[C].x, e = t.dataPoints[C].y, b < c.min && (c.min = b), b > c.max && (c.max = b), t.dataPointEOs[C].cumulativeSum < d.min && (d.min = t.dataPointEOs[C].cumulativeSum), t.dataPointEOs[C].cumulativeSum > d.max && (d.max = t.dataPointEOs[C].cumulativeSum), 0 < C && (a.axisX.logarithmic ? (p = b / t.dataPoints[C - 1].x, 1 > p && (p = 1 / p), c.minDiff > p && 1 !== p && (c.minDiff = p)) : (p = b - t.dataPoints[C - 1].x, 0 > p && (p *= -1), c.minDiff > p && 0 !== p && (c.minDiff = p)), null !== e && null !== t.dataPoints[C - 1].y && (a.axisY.logarithmic ? (e = t.dataPointEOs[C].cumulativeSum / t.dataPointEOs[C - 1].cumulativeSum, 1 > e && (e = 1 / e), d.minDiff > e && 1 !== e && (d.minDiff = e)) : (e = t.dataPointEOs[C].cumulativeSum - t.dataPointEOs[C - 1].cumulativeSum, 0 > e && (e *= -1), d.minDiff > e && 0 !== e && (d.minDiff = e)))), !(b < q) || k) {
                  if (!k && (k = true, 0 < C)) {
                    C -= 2;
                    continue;
                  }
                  if (b > g && !m)
                    m = true;
                  else if (b > g && m)
                    continue;
                  t.dataPoints[C].label && (a.axisX.labels[b] = t.dataPoints[C].label);
                  b < c.viewPortMin && (c.viewPortMin = b);
                  b > c.viewPortMax && (c.viewPortMax = b);
                  0 < C && (t.dataPointEOs[C - 1].cumulativeSum < d.viewPortMin && (d.viewPortMin = t.dataPointEOs[C - 1].cumulativeSum), t.dataPointEOs[C - 1].cumulativeSum > d.viewPortMax && (d.viewPortMax = t.dataPointEOs[C - 1].cumulativeSum));
                  t.dataPointEOs[C].cumulativeSum < d.viewPortMin && (d.viewPortMin = t.dataPointEOs[C].cumulativeSum);
                  t.dataPointEOs[C].cumulativeSum > d.viewPortMax && (d.viewPortMax = t.dataPointEOs[C].cumulativeSum);
                }
              t.axisX.valueType = t.xValueType = f ? "dateTime" : "number";
            }
        };
        n.prototype.calculateAutoBreaks = function() {
          function a(a2, b2, c2, e2) {
            if (e2)
              return c2 = Math.pow(Math.min(c2 * a2 / b2, b2 / a2), 0.2), 1 >= c2 && (c2 = Math.pow(1 > a2 ? 1 / a2 : Math.min(b2 / a2, a2), 0.25)), { startValue: a2 * c2, endValue: b2 / c2 };
            c2 = 0.2 * Math.min(c2 - b2 + a2, b2 - a2);
            0 >= c2 && (c2 = 0.25 * Math.min(b2 - a2, Math.abs(a2)));
            return { startValue: a2 + c2, endValue: b2 - c2 };
          }
          function d(a2) {
            if (a2.dataSeriesIndexes && !(1 > a2.dataSeriesIndexes.length)) {
              var b2 = a2.axisX.scaleBreaks && a2.axisX.scaleBreaks.autoCalculate && 1 <= a2.axisX.scaleBreaks.maxNumberOfAutoBreaks, c2 = a2.axisY.scaleBreaks && a2.axisY.scaleBreaks.autoCalculate && 1 <= a2.axisY.scaleBreaks.maxNumberOfAutoBreaks;
              if (b2 || c2)
                for (var d2 = a2.axisY.dataInfo, g2 = a2.axisX.dataInfo, f2, k2 = g2.min, l2 = g2.max, m2 = d2.min, p2 = d2.max, g2 = g2._dataRanges, d2 = d2._dataRanges, q2, t2 = 0, C2 = 0; C2 < a2.dataSeriesIndexes.length; C2++) {
                  var h2 = e.data[a2.dataSeriesIndexes[C2]];
                  if (!(4 > h2.dataPoints.length)) {
                    for (t2 = 0; t2 < h2.dataPoints.length; t2++)
                      if (b2 && (q2 = (l2 + 1 - k2) * Math.max(parseFloat(a2.axisX.scaleBreaks.collapsibleThreshold) || 10, 10) / 100, f2 = h2.dataPoints[t2].x.getTime ? h2.dataPoints[t2].x.getTime() : h2.dataPoints[t2].x, q2 = Math.floor((f2 - k2) / q2), f2 < g2[q2].min && (g2[q2].min = f2), f2 > g2[q2].max && (g2[q2].max = f2)), c2) {
                        var n2 = (p2 + 1 - m2) * Math.max(parseFloat(a2.axisY.scaleBreaks.collapsibleThreshold) || 10, 10) / 100;
                        if ((f2 = "waterfall" === a2.type ? h2.dataPointEOs[t2].cumulativeSum : h2.dataPoints[t2].y) && f2.length)
                          for (var w2 = 0; w2 < f2.length; w2++)
                            q2 = Math.floor((f2[w2] - m2) / n2), f2[w2] < d2[q2].min && (d2[q2].min = f2[w2]), f2[w2] > d2[q2].max && (d2[q2].max = f2[w2]);
                        else
                          s(f2) || (q2 = Math.floor((f2 - m2) / n2), f2 < d2[q2].min && (d2[q2].min = f2), f2 > d2[q2].max && (d2[q2].max = f2));
                      }
                  }
                }
            }
          }
          function c(a2) {
            if (a2.dataSeriesIndexes && !(1 > a2.dataSeriesIndexes.length) && a2.axisX.scaleBreaks && a2.axisX.scaleBreaks.autoCalculate && 1 <= a2.axisX.scaleBreaks.maxNumberOfAutoBreaks)
              for (var b2 = a2.axisX.dataInfo, c2 = b2.min, d2 = b2.max, g2 = b2._dataRanges, f2, k2 = 0, l2 = 0; l2 < a2.dataSeriesIndexes.length; l2++) {
                var m2 = e.data[a2.dataSeriesIndexes[l2]];
                if (!(4 > m2.dataPoints.length))
                  for (k2 = 0; k2 < m2.dataPoints.length; k2++)
                    f2 = (d2 + 1 - c2) * Math.max(parseFloat(a2.axisX.scaleBreaks.collapsibleThreshold) || 10, 10) / 100, b2 = m2.dataPoints[k2].x.getTime ? m2.dataPoints[k2].x.getTime() : m2.dataPoints[k2].x, f2 = Math.floor((b2 - c2) / f2), b2 < g2[f2].min && (g2[f2].min = b2), b2 > g2[f2].max && (g2[f2].max = b2);
              }
          }
          for (var b, e = this, f = false, l = 0; l < this._axes.length; l++)
            if (this._axes[l].scaleBreaks && this._axes[l].scaleBreaks.autoCalculate && 1 <= this._axes[l].scaleBreaks.maxNumberOfAutoBreaks) {
              f = true;
              this._axes[l].dataInfo._dataRanges = [];
              for (var t = 0; t < 100 / Math.max(parseFloat(this._axes[l].scaleBreaks.collapsibleThreshold) || 10, 10); t++)
                this._axes[l].dataInfo._dataRanges.push({ min: Infinity, max: -Infinity });
            }
          if (f) {
            for (l = 0; l < this.plotInfo.plotTypes.length; l++)
              for (f = this.plotInfo.plotTypes[l], t = 0; t < f.plotUnits.length; t++)
                b = f.plotUnits[t], "line" === b.type || "stepLine" === b.type || "spline" === b.type || "column" === b.type || "area" === b.type || "stepArea" === b.type || "splineArea" === b.type || "bar" === b.type || "bubble" === b.type || "scatter" === b.type || "candlestick" === b.type || "ohlc" === b.type || "rangeColumn" === b.type || "rangeBar" === b.type || "rangeArea" === b.type || "rangeSplineArea" === b.type || "waterfall" === b.type || "error" === b.type || "boxAndWhisker" === b.type ? d(b) : 0 <= b.type.indexOf("stacked") && c(b);
            for (l = 0; l < this._axes.length; l++)
              if (this._axes[l].dataInfo._dataRanges) {
                var C = this._axes[l].dataInfo.min;
                b = (this._axes[l].dataInfo.max + 1 - C) * Math.max(parseFloat(this._axes[l].scaleBreaks.collapsibleThreshold) || 10, 10) / 100;
                var k = this._axes[l].dataInfo._dataRanges, m, p, f = [];
                if (this._axes[l].dataInfo.dataPointYPositiveSums) {
                  var q = this._axes[l].dataInfo.dataPointYPositiveSums;
                  m = k;
                  for (t in q)
                    if (q.hasOwnProperty(t) && !isNaN(t) && (p = q[t], !s(p))) {
                      var g = Math.floor((p - C) / b);
                      p < m[g].min && (m[g].min = p);
                      p > m[g].max && (m[g].max = p);
                    }
                  delete this._axes[l].dataInfo.dataPointYPositiveSums;
                }
                if (this._axes[l].dataInfo.dataPointYNegativeSums) {
                  q = this._axes[l].dataInfo.dataPointYNegativeSums;
                  m = k;
                  for (t in q)
                    q.hasOwnProperty(t) && !isNaN(t) && (p = -1 * q[t], s(p) || (g = Math.floor((p - C) / b), p < m[g].min && (m[g].min = p), p > m[g].max && (m[g].max = p)));
                  delete this._axes[l].dataInfo.dataPointYNegativeSums;
                }
                for (t = 0; t < k.length - 1; t++)
                  if (m = k[t].max, isFinite(m))
                    for (; t < k.length - 1; )
                      if (C = k[t + 1].min, isFinite(C)) {
                        p = C - m;
                        p > b && f.push({ diff: p, start: m, end: C });
                        break;
                      } else
                        t++;
                if (this._axes[l].scaleBreaks.customBreaks) {
                  for (t = 0; t < this._axes[l].scaleBreaks.customBreaks.length; t++)
                    for (b = 0; b < f.length; b++)
                      if (this._axes[l].scaleBreaks.customBreaks[t].startValue <= f[b].start && f[b].start <= this._axes[l].scaleBreaks.customBreaks[t].endValue || this._axes[l].scaleBreaks.customBreaks[t].startValue <= f[b].start && f[b].start <= this._axes[l].scaleBreaks.customBreaks[t].endValue || f[b].start <= this._axes[l].scaleBreaks.customBreaks[t].startValue && this._axes[l].scaleBreaks.customBreaks[t].startValue <= f[b].end || f[b].start <= this._axes[l].scaleBreaks.customBreaks[t].endValue && this._axes[l].scaleBreaks.customBreaks[t].endValue <= f[b].end)
                        f.splice(b, 1), b--;
                }
                f.sort(function(a2, b2) {
                  return b2.diff - a2.diff;
                });
                for (t = 0; t < Math.min(f.length, this._axes[l].scaleBreaks.maxNumberOfAutoBreaks); t++)
                  b = a(f[t].start, f[t].end, this._axes[l].logarithmic ? this._axes[l].dataInfo.max / this._axes[l].dataInfo.min : this._axes[l].dataInfo.max - this._axes[l].dataInfo.min, this._axes[l].logarithmic), this._axes[l].scaleBreaks.autoBreaks.push(new aa2(this, "autoBreaks", b, t, ++this._eventManager.lastObjectId, this._axes[l].scaleBreaks)), this._axes[l].scaleBreaks._appliedBreaks.push(this._axes[l].scaleBreaks.autoBreaks[this._axes[l].scaleBreaks.autoBreaks.length - 1]);
                this._axes[l].scaleBreaks._appliedBreaks.sort(function(a2, b2) {
                  return a2.startValue - b2.startValue;
                });
              }
          }
        };
        n.prototype.renderCrosshairs = function(a) {
          for (var d = 0; d < this.axisX.length; d++)
            this.axisX[d] != a && (this.axisX[d].crosshair && this.axisX[d].crosshair.enabled && !this.axisX[d].crosshair._hidden) && this.axisX[d].showCrosshair(this.axisX[d].crosshair._updatedValue);
          for (d = 0; d < this.axisX2.length; d++)
            this.axisX2[d] != a && (this.axisX2[d].crosshair && this.axisX2[d].crosshair.enabled && !this.axisX2[d].crosshair._hidden) && this.axisX2[d].showCrosshair(this.axisX2[d].crosshair._updatedValue);
          for (d = 0; d < this.axisY.length; d++)
            this.axisY[d] != a && (this.axisY[d].crosshair && this.axisY[d].crosshair.enabled && !this.axisY[d].crosshair._hidden) && this.axisY[d].showCrosshair(this.axisY[d].crosshair._updatedValue);
          for (d = 0; d < this.axisY2.length; d++)
            this.axisY2[d] != a && (this.axisY2[d].crosshair && this.axisY2[d].crosshair.enabled && !this.axisY2[d].crosshair._hidden) && this.axisY2[d].showCrosshair(this.axisY2[d].crosshair._updatedValue);
        };
        n.prototype.getDataPointAtXY = function(a, d, c) {
          c = c || false;
          for (var b = [], e = this._dataInRenderedOrder.length - 1; 0 <= e; e--) {
            var f = null;
            (f = this._dataInRenderedOrder[e].getDataPointAtXY(a, d, c)) && b.push(f);
          }
          a = null;
          d = false;
          for (c = 0; c < b.length; c++)
            if ("line" === b[c].dataSeries.type || "stepLine" === b[c].dataSeries.type || "area" === b[c].dataSeries.type || "stepArea" === b[c].dataSeries.type) {
              if (e = ma("markerSize", b[c].dataPoint, b[c].dataSeries) || 8, b[c].distance <= e / 2) {
                d = true;
                break;
              }
            }
          for (c = 0; c < b.length; c++)
            d && "line" !== b[c].dataSeries.type && "stepLine" !== b[c].dataSeries.type && "area" !== b[c].dataSeries.type && "stepArea" !== b[c].dataSeries.type || (a ? b[c].distance <= a.distance && (a = b[c]) : a = b[c]);
          return a;
        };
        n.prototype.getObjectAtXY = function(a, d, c) {
          var b = null;
          if (c = this.getDataPointAtXY(a, d, c || false))
            b = c.dataSeries.dataPointIds[c.dataPointIndex];
          else if (w)
            b = $a(a, d, this._eventManager.ghostCtx);
          else
            for (c = 0; c < this.legend.items.length; c++) {
              var e = this.legend.items[c];
              a >= e.x1 && (a <= e.x2 && d >= e.y1 && d <= e.y2) && (b = e.id);
            }
          return b;
        };
        n.prototype.getAutoFontSize = mb;
        n.prototype.resetOverlayedCanvas = function() {
          this.overlaidCanvasCtx.clearRect(0, 0, this.width, this.height);
        };
        n.prototype.clearCanvas = lb;
        n.prototype.attachEvent = function(a) {
          this._events.push(a);
        };
        n.prototype._touchEventHandler = function(a) {
          if (a.changedTouches && this.interactivityEnabled) {
            var d = [], c = a.changedTouches, b = c ? c[0] : a, e = null;
            switch (a.type) {
              case "touchstart":
              case "MSPointerDown":
                d = ["mousemove", "mousedown"];
                this._lastTouchData = Pa(b);
                this._lastTouchData.time = /* @__PURE__ */ new Date();
                break;
              case "touchmove":
              case "MSPointerMove":
                d = ["mousemove"];
                break;
              case "touchend":
              case "MSPointerUp":
                var f = this._lastTouchData && this._lastTouchData.time ? /* @__PURE__ */ new Date() - this._lastTouchData.time : 0, d = "touchstart" === this._lastTouchEventType || "MSPointerDown" === this._lastTouchEventType || 300 > f ? ["mouseup", "click"] : ["mouseup"];
                break;
              default:
                return;
            }
            if (!(c && 1 < c.length)) {
              e = Pa(b);
              e.time = /* @__PURE__ */ new Date();
              try {
                var l = e.y - this._lastTouchData.y, f = e.time - this._lastTouchData.time;
                if (1 < Math.abs(l) && this._lastTouchData.scroll || 5 < Math.abs(l) && 250 > f)
                  this._lastTouchData.scroll = true;
              } catch (t) {
              }
              this._lastTouchEventType = a.type;
              if (this._lastTouchData.scroll && this.zoomEnabled)
                this.isDrag && this.resetOverlayedCanvas(), this.isDrag = false;
              else
                for (c = 0; c < d.length; c++)
                  if (e = d[c], l = document.createEvent("MouseEvent"), l.initMouseEvent(
                    e,
                    true,
                    true,
                    window,
                    1,
                    b.screenX,
                    b.screenY,
                    b.clientX,
                    b.clientY,
                    false,
                    false,
                    false,
                    false,
                    0,
                    null
                  ), b.target.dispatchEvent(l), !s(this._lastTouchData.scroll) && !this._lastTouchData.scroll || !this._lastTouchData.scroll && 250 < f || "click" === e)
                    a.preventManipulation && a.preventManipulation(), a.preventDefault && a.cancelable && a.preventDefault();
            }
          }
        };
        n.prototype._dispatchRangeEvent = function(a, d) {
          var c = { chart: this };
          c.type = a;
          c.trigger = d;
          var b = [];
          this.axisX && 0 < this.axisX.length && b.push("axisX");
          this.axisX2 && 0 < this.axisX2.length && b.push("axisX2");
          this.axisY && 0 < this.axisY.length && b.push("axisY");
          this.axisY2 && 0 < this.axisY2.length && b.push("axisY2");
          for (var e = 0; e < b.length; e++)
            if (s(c[b[e]]) && (c[b[e]] = []), "axisY" === b[e])
              for (var f = 0; f < this.axisY.length; f++)
                c[b[e]].push({ viewportMinimum: this[b[e]][f].sessionVariables.newViewportMinimum, viewportMaximum: this[b[e]][f].sessionVariables.newViewportMaximum });
            else if ("axisY2" === b[e])
              for (f = 0; f < this.axisY2.length; f++)
                c[b[e]].push({ viewportMinimum: this[b[e]][f].sessionVariables.newViewportMinimum, viewportMaximum: this[b[e]][f].sessionVariables.newViewportMaximum });
            else if ("axisX" === b[e])
              for (f = 0; f < this.axisX.length; f++)
                c[b[e]].push({ viewportMinimum: this[b[e]][f].sessionVariables.newViewportMinimum, viewportMaximum: this[b[e]][f].sessionVariables.newViewportMaximum });
            else if ("axisX2" === b[e])
              for (f = 0; f < this.axisX2.length; f++)
                c[b[e]].push({ viewportMinimum: this[b[e]][f].sessionVariables.newViewportMinimum, viewportMaximum: this[b[e]][f].sessionVariables.newViewportMaximum });
          this.dispatchEvent(a, c, this);
        };
        n.prototype._mouseEventHandler = function(a) {
          "undefined" === typeof a.target && a.srcElement && (a.target = a.srcElement);
          var d = Pa(a), c = a.type, b, e;
          a.which ? e = 3 == a.which : a.button && (e = 2 == a.button);
          n.capturedEventParam && (b = n.capturedEventParam, "mouseup" === c && (n.capturedEventParam = null, b.chart.overlaidCanvas.releaseCapture ? b.chart.overlaidCanvas.releaseCapture() : document.documentElement.removeEventListener("mouseup", b.chart._mouseEventHandler, false)), b.hasOwnProperty(c) && ("mouseup" !== c || b.chart.overlaidCanvas.releaseCapture ? a.target !== b.chart.overlaidCanvas && w || b[c].call(b.context, d.x, d.y) : a.target !== b.chart.overlaidCanvas && (b.chart.isDrag = false)));
          if (this.interactivityEnabled) {
            if (this._ignoreNextEvent)
              this._ignoreNextEvent = false;
            else if (a.preventManipulation && a.preventManipulation(), a.preventDefault && a.preventDefault(), Ia && window.console && (window.console.log(c + " --> x: " + d.x + "; y:" + d.y), e && window.console.log(a.which), "mouseup" === c && window.console.log("mouseup")), !e) {
              if (!n.capturedEventParam && this._events) {
                for (var f = 0; f < this._events.length; f++)
                  if (this._events[f].hasOwnProperty(c))
                    if (b = this._events[f], e = b.bounds, d.x >= e.x1 && d.x <= e.x2 && d.y >= e.y1 && d.y <= e.y2) {
                      b[c].call(b.context, d.x, d.y);
                      "mousedown" === c && true === b.capture ? (n.capturedEventParam = b, this.overlaidCanvas.setCapture ? this.overlaidCanvas.setCapture() : document.documentElement.addEventListener("mouseup", this._mouseEventHandler, false)) : "mouseup" === c && (b.chart.overlaidCanvas.releaseCapture ? b.chart.overlaidCanvas.releaseCapture() : document.documentElement.removeEventListener("mouseup", this._mouseEventHandler, false));
                      break;
                    } else
                      b = null;
                a.target.style.cursor = b && b.cursor ? b.cursor : this._defaultCursor;
              }
              c = this.plotArea;
              if (d.x < c.x1 || d.x > c.x2 || d.y < c.y1 || d.y > c.y2) {
                this.toolTip && this.toolTip.enabled ? (this.toolTip.hide(), this.toolTip.dispatchEvent("hidden", { chart: this, toolTip: this.toolTip }, this.toolTip)) : this.resetOverlayedCanvas();
                for (f = 0; f < this.axisX.length; f++)
                  this.axisX[f].crosshair && this.axisX[f].crosshair.enabled && (this.axisX[f].crosshair.hide(), this.axisX[f].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisX[f].options }, this.axisX[f].crosshair));
                for (f = 0; f < this.axisX2.length; f++)
                  this.axisX2[f].crosshair && this.axisX2[f].crosshair.enabled && (this.axisX2[f].crosshair.hide(), this.axisX2[f].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisX2[f].options }, this.axisX2[f].crosshair));
                for (f = 0; f < this.axisY.length; f++)
                  this.axisY[f].crosshair && this.axisY[f].crosshair.enabled && (this.axisY[f].crosshair.hide(), this.axisY[f].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisY[f].options }, this.axisY[f].crosshair));
                for (f = 0; f < this.axisY2.length; f++)
                  this.axisY2[f].crosshair && this.axisY2[f].crosshair.enabled && (this.axisY2[f].crosshair.hide(), this.axisY2[f].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisY2[f].options }, this.axisY2[f].crosshair));
              }
              this.isDrag && this.zoomEnabled || !this._eventManager || this._eventManager.mouseEventHandler(a);
            }
          }
        };
        n.prototype._plotAreaMouseDown = function(a, d) {
          this.isDrag = true;
          this.dragStartPoint = { x: a, y: d };
        };
        n.prototype._plotAreaMouseUp = function(a, d) {
          if (("normal" === this.plotInfo.axisPlacement || "xySwapped" === this.plotInfo.axisPlacement) && this.isDrag) {
            var c = d - this.dragStartPoint.y, b = a - this.dragStartPoint.x, e = 0 <= this.zoomType.indexOf("x"), f = 0 <= this.zoomType.indexOf("y"), l = false;
            this.resetOverlayedCanvas();
            if ("xySwapped" === this.plotInfo.axisPlacement)
              var t = f, f = e, e = t;
            if (this.panEnabled || this.zoomEnabled) {
              if (this.panEnabled)
                for (e = f = 0; e < this._axes.length; e++)
                  c = this._axes[e], c.logarithmic ? c.viewportMinimum < c.minimum ? (f = c.minimum / c.viewportMinimum, c.sessionVariables.newViewportMinimum = c.viewportMinimum * f, c.sessionVariables.newViewportMaximum = c.viewportMaximum * f, l = true) : c.viewportMaximum > c.maximum && (f = c.viewportMaximum / c.maximum, c.sessionVariables.newViewportMinimum = c.viewportMinimum / f, c.sessionVariables.newViewportMaximum = c.viewportMaximum / f, l = true) : c.viewportMinimum < c.minimum ? (f = c.minimum - c.viewportMinimum, c.sessionVariables.newViewportMinimum = c.viewportMinimum + f, c.sessionVariables.newViewportMaximum = c.viewportMaximum + f, l = true) : c.viewportMaximum > c.maximum && (f = c.viewportMaximum - c.maximum, c.sessionVariables.newViewportMinimum = c.viewportMinimum - f, c.sessionVariables.newViewportMaximum = c.viewportMaximum - f, l = true);
              else if ((!e || 2 < Math.abs(b)) && (!f || 2 < Math.abs(c)) && this.zoomEnabled) {
                if (!this.dragStartPoint)
                  return;
                c = e ? this.dragStartPoint.x : this.plotArea.x1;
                b = f ? this.dragStartPoint.y : this.plotArea.y1;
                e = e ? a : this.plotArea.x2;
                f = f ? d : this.plotArea.y2;
                2 < Math.abs(c - e) && 2 < Math.abs(b - f) && this._zoomPanToSelectedRegion(c, b, e, f) && (l = true);
              }
              l && (this._ignoreNextEvent = true, this._dispatchRangeEvent("rangeChanging", "zoom"), this.stockChart && (this.stockChart.navigator && this.stockChart.navigator.enabled) && (this.stockChart._rangeEventParameter || (this.stockChart._rangeEventParameter = { stockChart: this.stockChart, source: "chart", index: this.stockChart.charts.indexOf(this), minimum: this.stockChart.sessionVariables._axisXMin, maximum: this.stockChart.sessionVariables._axisXMax }), this.stockChart._rangeEventParameter.type = "rangeChanging", this.stockChart.dispatchEvent("rangeChanging", this.stockChart._rangeEventParameter, this.stockChart)), this.render(), this._dispatchRangeEvent("rangeChanged", "zoom"), this.stockChart && (this.stockChart.navigator && this.stockChart.navigator.enabled) && (this.stockChart._rangeEventParameter.type = "rangeChanged", this.stockChart.dispatchEvent("rangeChanged", this.stockChart._rangeEventParameter, this.stockChart)), l && (this.zoomEnabled && "none" === this._zoomButton.style.display) && (Ma(this._zoomButton, this._resetButton), sa(this, this._zoomButton, "pan"), sa(this, this._resetButton, "reset")));
            }
          }
          this.isDrag = false;
          if ("none" !== this.plotInfo.axisPlacement) {
            this.resetOverlayedCanvas();
            if (this.axisX && 0 < this.axisX.length)
              for (l = 0; l < this.axisX.length; l++)
                this.axisX[l].crosshair && this.axisX[l].crosshair.enabled && this.axisX[l].renderCrosshair(a, d);
            if (this.axisX2 && 0 < this.axisX2.length)
              for (l = 0; l < this.axisX2.length; l++)
                this.axisX2[l].crosshair && this.axisX2[l].crosshair.enabled && this.axisX2[l].renderCrosshair(a, d);
            if (this.axisY && 0 < this.axisY.length)
              for (l = 0; l < this.axisY.length; l++)
                this.axisY[l].crosshair && this.axisY[l].crosshair.enabled && this.axisY[l].renderCrosshair(a, d);
            if (this.axisY2 && 0 < this.axisY2.length)
              for (l = 0; l < this.axisY2.length; l++)
                this.axisY2[l].crosshair && this.axisY2[l].crosshair.enabled && this.axisY2[l].renderCrosshair(a, d);
            if (this.axisX && 0 < this.axisX.length)
              for (l = 0; l < this.axisX.length; l++)
                this.axisX[l].crosshair && this.axisX[l].crosshair.enabled && this.axisX[l].crosshair.renderLabel();
            if (this.axisX2 && 0 < this.axisX2.length)
              for (l = 0; l < this.axisX2.length; l++)
                this.axisX2[l].crosshair && this.axisX2[l].crosshair.enabled && this.axisX2[l].crosshair.renderLabel();
            if (this.axisY && 0 < this.axisY.length)
              for (l = 0; l < this.axisY.length; l++)
                this.axisY[l].crosshair && this.axisY[l].crosshair.enabled && this.axisY[l].crosshair.renderLabel();
            if (this.axisY2 && 0 < this.axisY2.length)
              for (l = 0; l < this.axisY2.length; l++)
                this.axisY2[l].crosshair && this.axisY2[l].crosshair.enabled && this.axisY2[l].crosshair.renderLabel();
          }
        };
        n.prototype._plotAreaMouseMove = function(a, d) {
          if (this.isDrag && "none" !== this.plotInfo.axisPlacement) {
            var c = 0, b = 0, e = c = null, e = 0 <= this.zoomType.indexOf("x"), f = 0 <= this.zoomType.indexOf("y"), l = this;
            "xySwapped" === this.plotInfo.axisPlacement && (c = f, f = e, e = c);
            c = this.dragStartPoint.x - a;
            b = this.dragStartPoint.y - d;
            if (2 < Math.abs(c) && 8 > Math.abs(c) && (this.panEnabled || this.zoomEnabled)) {
              this.toolTip.hide();
              this.toolTip && this.toolTip.enabled && this.toolTip.dispatchEvent("hidden", { chart: this, toolTip: this.toolTip }, this.toolTip);
              for (var t = 0; t < this.axisX.length; t++)
                this.axisX[t].crosshair && this.axisX[t].crosshair.enabled && (this.axisX[t].crosshair.hide(), this.axisX[t].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisX[t].options }, this.axisX[t].crosshair));
              for (t = 0; t < this.axisX2.length; t++)
                this.axisX2[t].crosshair && this.axisX2[t].crosshair.enabled && (this.axisX2[t].crosshair.hide(), this.axisX2[t].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisX2[t].options }, this.axisX2[t].crosshair));
              for (t = 0; t < this.axisY.length; t++)
                this.axisY[t].crosshair && this.axisY[t].crosshair.enabled && (this.axisY[t].crosshair.hide(), this.axisY[t].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisY[t].options }, this.axisY[t].crosshair));
              for (t = 0; t < this.axisY2.length; t++)
                this.axisY2[t].crosshair && this.axisY2[t].crosshair.enabled && (this.axisY2[t].crosshair.hide(), this.axisY2[t].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisY2[t].options }, this.axisY2[t].crosshair));
            } else
              this.panEnabled || this.zoomEnabled || this.toolTip.mouseMoveHandler(a, d);
            if ((!e || 2 < Math.abs(c) || !f || 2 < Math.abs(b)) && (this.panEnabled || this.zoomEnabled)) {
              if (this.panEnabled)
                e = { x1: e ? this.plotArea.x1 + c : this.plotArea.x1, y1: f ? this.plotArea.y1 + b : this.plotArea.y1, x2: e ? this.plotArea.x2 + c : this.plotArea.x2, y2: f ? this.plotArea.y2 + b : this.plotArea.y2 }, clearTimeout(l._panTimerId), l._panTimerId = setTimeout(function(b2, c2, e2, f2) {
                  return function() {
                    l._zoomPanToSelectedRegion(b2, c2, e2, f2, true) && (l._dispatchRangeEvent("rangeChanging", "pan"), l.stockChart && (l.stockChart.navigator && l.stockChart.navigator.enabled) && (l.stockChart._rangeEventParameter.type = "rangeChanging", l.stockChart.dispatchEvent("rangeChanging", l.stockChart._rangeEventParameter, l.stockChart)), l.render(), l._dispatchRangeEvent("rangeChanged", "pan"), l.stockChart && (l.stockChart.navigator && l.stockChart.navigator.enabled) && (l.stockChart._rangeEventParameter.type = "rangeChanged", l.stockChart.dispatchEvent("rangeChanged", l.stockChart._rangeEventParameter, l.stockChart)), l.dragStartPoint.x = a, l.dragStartPoint.y = d);
                  };
                }(e.x1, e.y1, e.x2, e.y2), 0);
              else if (this.zoomEnabled) {
                this.resetOverlayedCanvas();
                c = this.overlaidCanvasCtx.globalAlpha;
                this.overlaidCanvasCtx.fillStyle = "#A89896";
                var b = e ? this.dragStartPoint.x : this.plotArea.x1, t = f ? this.dragStartPoint.y : this.plotArea.y1, C = e ? a - this.dragStartPoint.x : this.plotArea.x2 - this.plotArea.x1, k = f ? d - this.dragStartPoint.y : this.plotArea.y2 - this.plotArea.y1;
                this.validateRegion(b, t, e ? a : this.plotArea.x2 - this.plotArea.x1, f ? d : this.plotArea.y2 - this.plotArea.y1, "xy" !== this.zoomType).isValid && (this.resetOverlayedCanvas(), this.overlaidCanvasCtx.fillStyle = "#99B2B5");
                this.overlaidCanvasCtx.globalAlpha = 0.7;
                this.overlaidCanvasCtx.fillRect(b, t, C, k);
                this.overlaidCanvasCtx.globalAlpha = c;
              }
            }
          } else if (this.toolTip.mouseMoveHandler(a, d), "none" !== this.plotInfo.axisPlacement) {
            if (this.axisX && 0 < this.axisX.length)
              for (e = 0; e < this.axisX.length; e++)
                this.axisX[e].crosshair && this.axisX[e].crosshair.enabled && this.axisX[e].renderCrosshair(a, d);
            if (this.axisX2 && 0 < this.axisX2.length)
              for (e = 0; e < this.axisX2.length; e++)
                this.axisX2[e].crosshair && this.axisX2[e].crosshair.enabled && this.axisX2[e].renderCrosshair(a, d);
            if (this.axisY && 0 < this.axisY.length)
              for (e = 0; e < this.axisY.length; e++)
                this.axisY[e].crosshair && this.axisY[e].crosshair.enabled && this.axisY[e].renderCrosshair(a, d);
            if (this.axisY2 && 0 < this.axisY2.length)
              for (e = 0; e < this.axisY2.length; e++)
                this.axisY2[e].crosshair && this.axisY2[e].crosshair.enabled && this.axisY2[e].renderCrosshair(
                  a,
                  d
                );
            if (this.axisX && 0 < this.axisX.length)
              for (e = 0; e < this.axisX.length; e++)
                this.axisX[e].crosshair && this.axisX[e].crosshair.enabled && this.axisX[e].crosshair.renderLabel();
            if (this.axisX2 && 0 < this.axisX2.length)
              for (e = 0; e < this.axisX2.length; e++)
                this.axisX2[e].crosshair && this.axisX2[e].crosshair.enabled && this.axisX2[e].crosshair.renderLabel();
            if (this.axisY && 0 < this.axisY.length)
              for (e = 0; e < this.axisY.length; e++)
                this.axisY[e].crosshair && this.axisY[e].crosshair.enabled && this.axisY[e].crosshair.renderLabel();
            if (this.axisY2 && 0 < this.axisY2.length)
              for (e = 0; e < this.axisY2.length; e++)
                this.axisY2[e].crosshair && this.axisY2[e].crosshair.enabled && this.axisY2[e].crosshair.renderLabel();
          }
        };
        n.prototype._zoomPanToSelectedRegion = function(a, d, c, b, e) {
          a = this.validateRegion(a, d, c, b, e);
          d = a.axesWithValidRange;
          c = a.axesRanges;
          if (a.isValid)
            for (b = 0; b < d.length; b++)
              e = c[b], d[b].setViewPortRange(e.val1, e.val2), this.syncCharts && "y" != this.zoomType && this.syncCharts(e.val1, e.val2), this.stockChart && (this.stockChart._rangeEventParameter = {
                stockChart: this.stockChart,
                source: "chart",
                index: this.stockChart.charts.indexOf(this),
                minimum: e.val1,
                maximum: e.val2
              });
          return a.isValid;
        };
        n.prototype.validateRegion = function(a, d, c, b, e) {
          e = e || false;
          for (var f = 0 <= this.zoomType.indexOf("x"), l = 0 <= this.zoomType.indexOf("y"), t = false, C = [], k = [], m = [], p = 0; p < this._axes.length; p++)
            ("axisX" === this._axes[p].type && f || "axisY" === this._axes[p].type && l) && k.push(this._axes[p]);
          for (l = 0; l < k.length; l++) {
            var p = k[l], f = false, q = p.convertPixelToValue({ x: a, y: d }), g = p.convertPixelToValue({ x: c, y: b });
            if (q > g)
              var r = g, g = q, q = r;
            if (p.scaleBreaks)
              for (r = 0; !f && r < p.scaleBreaks._appliedBreaks.length; r++)
                f = p.scaleBreaks._appliedBreaks[r].startValue <= q && p.scaleBreaks._appliedBreaks[r].endValue >= g;
            if (isFinite(p.dataInfo.minDiff)) {
              if (r = p.getApparentDifference(q, g, null, true), !(f || !(this.panEnabled && p.scaleBreaks && p.scaleBreaks._appliedBreaks.length) && (p.logarithmic && r < Math.pow(p.dataInfo.minDiff, 3) || !p.logarithmic && r < 3 * Math.abs(p.dataInfo.minDiff)) || q < p.minimum || g > p.maximum))
                C.push(p), m.push({ val1: q, val2: g }), t = true;
              else if (!e) {
                t = false;
                break;
              }
            }
          }
          return { isValid: t, axesWithValidRange: C, axesRanges: m };
        };
        n.prototype.preparePlotArea = function() {
          var a = this.plotArea;
          !w && (0 < a.x1 || 0 < a.y1) && a.ctx.translate(a.x1, a.y1);
          if ((this.axisX[0] || this.axisX2[0]) && (this.axisY[0] || this.axisY2[0])) {
            var d = this.axisX[0] ? this.axisX[0].lineCoordinates : this.axisX2[0].lineCoordinates;
            if (this.axisY && 0 < this.axisY.length && this.axisY[0]) {
              var c = this.axisY[0];
              a.x1 = d.x1 < d.x2 ? d.x1 : c.lineCoordinates.x1;
              a.y1 = d.y1 < c.lineCoordinates.y1 ? d.y1 : c.lineCoordinates.y1;
              a.x2 = d.x2 > c.lineCoordinates.x2 ? d.x2 : c.lineCoordinates.x2;
              a.y2 = d.y2 > d.y1 ? d.y2 : c.lineCoordinates.y2;
              a.width = a.x2 - a.x1;
              a.height = a.y2 - a.y1;
            }
            this.axisY2 && 0 < this.axisY2.length && this.axisY2[0] && (c = this.axisY2[0], a.x1 = d.x1 < d.x2 ? d.x1 : c.lineCoordinates.x1, a.y1 = d.y1 < c.lineCoordinates.y1 ? d.y1 : c.lineCoordinates.y1, a.x2 = d.x2 > c.lineCoordinates.x2 ? d.x2 : c.lineCoordinates.x2, a.y2 = d.y2 > d.y1 ? d.y2 : c.lineCoordinates.y2, a.width = a.x2 - a.x1, a.height = a.y2 - a.y1);
          } else
            d = this.layoutManager.getFreeSpace(), a.x1 = d.x1, a.x2 = d.x2, a.y1 = d.y1, a.y2 = d.y2, a.width = d.width, a.height = d.height;
          w || (a.canvas.width = a.width, a.canvas.height = a.height, a.canvas.style.left = a.x1 + "px", a.canvas.style.top = a.y1 + "px", (0 < a.x1 || 0 < a.y1) && a.ctx.translate(-a.x1, -a.y1));
          a.layoutManager = new Fa(a.x1, a.y1, a.x2, a.y2, 2);
        };
        n.prototype.renderIndexLabels = function(a) {
          var d = a || this.plotArea.ctx, c = this.plotArea, b = 0, e = 0, f = 0, l = f = e = 0, t = 0, C = b = 0, k = 0;
          for (a = 0; a < this._indexLabels.length; a++) {
            var m = this._indexLabels[a], p = m.chartType.toLowerCase(), q, g, l = ma("indexLabelFontColor", m.dataPoint, m.dataSeries), r = ma(
              "indexLabelFontSize",
              m.dataPoint,
              m.dataSeries
            ), t = ma("indexLabelFontFamily", m.dataPoint, m.dataSeries), C = ma("indexLabelFontStyle", m.dataPoint, m.dataSeries), k = ma("indexLabelFontWeight", m.dataPoint, m.dataSeries), h2 = ma("indexLabelBackgroundColor", m.dataPoint, m.dataSeries);
            q = ma("indexLabelMaxWidth", m.dataPoint, m.dataSeries);
            g = ma("indexLabelWrap", m.dataPoint, m.dataSeries);
            var ba = ma("indexLabelLineDashType", m.dataPoint, m.dataSeries), u = ma("indexLabelLineColor", m.dataPoint, m.dataSeries), n2 = s(m.dataPoint.indexLabelLineThickness) ? s(m.dataSeries.options.indexLabelLineThickness) ? 0 : m.dataSeries.options.indexLabelLineThickness : m.dataPoint.indexLabelLineThickness, b = 0 < n2 ? Math.min(10, ("normal" === this.plotInfo.axisPlacement ? this.plotArea.height : this.plotArea.width) << 0) : 0, x = { percent: null, total: null }, z = null;
            if (0 <= m.dataSeries.type.indexOf("stacked") || "pie" === m.dataSeries.type || "doughnut" === m.dataSeries.type)
              x = this.getPercentAndTotal(m.dataSeries, m.dataPoint);
            if (m.dataSeries.indexLabelFormatter || m.dataPoint.indexLabelFormatter)
              z = {
                chart: this,
                dataSeries: m.dataSeries,
                dataPoint: m.dataPoint,
                index: m.indexKeyword,
                total: x.total,
                percent: x.percent
              };
            var H = m.dataPoint.indexLabelFormatter ? m.dataPoint.indexLabelFormatter(z) : m.dataPoint.indexLabel ? this.replaceKeywordsWithValue(m.dataPoint.indexLabel, m.dataPoint, m.dataSeries, null, m.indexKeyword) : m.dataSeries.indexLabelFormatter ? m.dataSeries.indexLabelFormatter(z) : m.dataSeries.indexLabel ? this.replaceKeywordsWithValue(m.dataSeries.indexLabel, m.dataPoint, m.dataSeries, null, m.indexKeyword) : null;
            if (null !== H && "" !== H) {
              var x = ma("indexLabelPlacement", m.dataPoint, m.dataSeries), z = ma("indexLabelOrientation", m.dataPoint, m.dataSeries), D = ma("indexLabelTextAlign", m.dataPoint, m.dataSeries), v3 = m.direction, e = m.dataSeries.axisX, f = m.dataSeries.axisY, A2 = false, h2 = new ja(d, { x: 0, y: 0, maxWidth: q ? q : 0.5 * this.width, maxHeight: g ? 5 * r : 1.5 * r, angle: "horizontal" === z ? 0 : -90, text: H, padding: 0, backgroundColor: h2, textAlign: D, fontSize: r, fontFamily: t, fontWeight: k, fontColor: l, fontStyle: C, textBaseline: "middle" });
              h2.measureText();
              m.dataSeries.indexLabelMaxWidth = h2.maxWidth;
              if ("stackedarea100" === p) {
                if (m.point.x < c.x1 || m.point.x > c.x2 || m.point.y < c.y1 - 1 || m.point.y > c.y2 + 1)
                  continue;
              } else if ("rangearea" === p || "rangesplinearea" === p) {
                if (m.dataPoint.x < e.viewportMinimum || m.dataPoint.x > e.viewportMaximum || Math.max.apply(null, m.dataPoint.y) < f.viewportMinimum || Math.min.apply(null, m.dataPoint.y) > f.viewportMaximum)
                  continue;
              } else if (0 <= p.indexOf("line") || 0 <= p.indexOf("area") || 0 <= p.indexOf("bubble") || 0 <= p.indexOf("scatter")) {
                if (m.dataPoint.x < e.viewportMinimum || m.dataPoint.x > e.viewportMaximum || m.dataPoint.y < f.viewportMinimum || m.dataPoint.y > f.viewportMaximum)
                  continue;
              } else if (0 <= p.indexOf("column") || "waterfall" === p || "error" === p && !m.axisSwapped) {
                if (m.dataPoint.x < e.viewportMinimum || m.dataPoint.x > e.viewportMaximum || m.bounds.y1 > c.y2 || m.bounds.y2 < c.y1)
                  continue;
              } else if (0 <= p.indexOf("bar") || "error" === p) {
                if (m.dataPoint.x < e.viewportMinimum || m.dataPoint.x > e.viewportMaximum || m.bounds.x1 > c.x2 || m.bounds.x2 < c.x1)
                  continue;
              } else if ("candlestick" === p || "ohlc" === p) {
                if (m.dataPoint.x < e.viewportMinimum || m.dataPoint.x > e.viewportMaximum || Math.max.apply(null, m.dataPoint.y) < f.viewportMinimum || Math.min.apply(null, m.dataPoint.y) > f.viewportMaximum)
                  continue;
              } else if (m.dataPoint.x < e.viewportMinimum || m.dataPoint.x > e.viewportMaximum)
                continue;
              l = t = 2;
              "horizontal" === z ? (C = h2.width, k = h2.height) : (k = h2.width, C = h2.height);
              if ("normal" === this.plotInfo.axisPlacement) {
                if (0 <= p.indexOf("line") || 0 <= p.indexOf("area"))
                  x = "auto", t = 4;
                else if (0 <= p.indexOf("stacked"))
                  "auto" === x && (x = "inside");
                else if ("bubble" === p || "scatter" === p)
                  x = "inside";
                q = m.point.x - ("horizontal" === z ? C / 2 : C / 2 - r / 2);
                "inside" !== x ? (e = c.y1, f = c.y2, 0 < v3 ? (g = m.point.y + ("horizontal" === z ? r / 2 : 0) - k - t - b, g < e && (g = "auto" === x ? Math.max(m.point.y, e) + r / 2 + t : e + r / 2 + t, A2 = g + k > m.point.y)) : (g = m.point.y + r / 2 + t + b, g > f - k && (g = "auto" === x ? Math.min(m.point.y, f) + r / 2 - k - t : f + r / 2 - k, A2 = g < m.point.y))) : (e = Math.max(m.bounds.y1, c.y1), f = Math.min(m.bounds.y2, c.y2 - k + r / 2), b = 0 <= p.indexOf("range") || "error" === p ? 0 < v3 ? Math.max(m.bounds.y1, c.y1) + r / 2 + t : Math.min(m.bounds.y2, c.y2) + r / 2 - k + t : (Math.max(m.bounds.y1, c.y1) + Math.min(m.bounds.y2, c.y2)) / 2 - k / 2 + r / 2 + ("horizontal" === z ? t : 0), 0 < v3 ? (g = Math.max(m.point.y, b), g < e && ("bubble" === p || "scatter" === p) && (g = Math.max(m.point.y - k - t, c.y1 + t))) : (g = Math.min(m.point.y, b), g > f - k - t && ("bubble" === p || "scatter" === p) && (g = Math.min(m.point.y + t, c.y2 - k - t))), g = Math.min(g, f));
              } else
                0 <= p.indexOf("line") || 0 <= p.indexOf("area") || 0 <= p.indexOf("scatter") ? (x = "auto", l = 4) : 0 <= p.indexOf("stacked") ? "auto" === x && (x = "inside") : "bubble" === p && (x = "inside"), g = m.point.y + r / 2 - k / 2 + t, "inside" !== x ? (e = c.x1, f = c.x2, 0 > v3 ? (q = m.point.x - ("horizontal" === z ? C : C - r / 2) - l - b, q < e && (q = "auto" === x ? Math.max(m.point.x, e) + l : e + l, A2 = q + C > m.point.x)) : (q = m.point.x + ("horizontal" === z ? 0 : r / 2) + l + b, q > f - C - l - b && (q = "auto" === x ? Math.min(m.point.x, f) - ("horizontal" === z ? C : C / 2) - l : f - C - l, A2 = q < m.point.x))) : (e = Math.max(m.bounds.x1, c.x1), Math.min(m.bounds.x2, c.x2), b = 0 <= p.indexOf("range") || "error" === p ? 0 > v3 ? Math.max(m.bounds.x1, c.x1) + r / 2 + l : Math.min(m.bounds.x2, c.x2) - C / 2 - l + ("horizontal" === z ? 0 : r / 2) : (Math.max(m.bounds.x1, c.x1) + Math.min(m.bounds.x2, c.x2)) / 2 + ("horizontal" === z ? 0 : r / 2), q = 0 > v3 ? Math.max(
                  m.point.x,
                  b
                ) - ("horizontal" === z ? C / 2 : 0) : Math.min(m.point.x, b) - C / 2, q = Math.max(q, e));
              "vertical" === z && (g += k - r / 2);
              h2.x = q;
              h2.y = g;
              h2.render(true);
              n2 && ("inside" !== x && (0 > p.indexOf("bar") && ("error" !== p || !m.axisSwapped) && m.point.x > c.x1 && m.point.x < c.x2 || !A2) && (0 > p.indexOf("column") && ("error" !== p || m.axisSwapped) && m.point.y > c.y1 && m.point.y < c.y2 || !A2)) && (d.lineWidth = n2, d.strokeStyle = u ? u : "gray", d.setLineDash && d.setLineDash(J(ba, n2)), d.beginPath(), d.moveTo(m.point.x, m.point.y), 0 <= p.indexOf("bar") || "error" === p && m.axisSwapped ? d.lineTo(q + (0 < m.direction ? -l : C + l) + ("vertical" === z ? -r / 2 : 0), g + ("vertical" === z ? -k / 2 : k / 2 - r / 2) - t) : 0 <= p.indexOf("column") || "error" === p && !m.axisSwapped ? d.lineTo(q + C / 2 - ("horizontal" === z ? 0 : r / 2), g + ("vertical" === z ? (g - k < m.point.y ? 0 : -k) + t : (g - r / 2 < m.point.y ? k : 0) - r / 2)) : 0 <= p.indexOf("waterfall") ? d.lineTo(q + C / 2 - ("horizontal" === z ? 0 : r / 2), "vertical" === z ? 0 < v3 && g < m.point.y ? g : 0 > v3 && g - k > m.point.y ? g - k : m.point.y : 0 < v3 && g + k - r / 2 < m.point.y ? g + k - r / 2 : 0 > v3 && g - r / 2 > m.point.y ? g - r / 2 - 2 : m.point.y) : d.lineTo(q + C / 2 - ("horizontal" === z ? 0 : r / 2), g + ("vertical" === z ? g - k < m.point.y ? 0 : -k : (g + k < m.point.y ? k : 0) - r / 2)), d.stroke());
            }
          }
          d = { source: d, dest: this.plotArea.ctx, animationCallback: M.fadeInAnimation, easingFunction: M.easing.easeInQuad, animationBase: 0, startTimePercent: 0.7 };
          for (a = 0; a < this._indexLabels.length; a++)
            m = this._indexLabels[a], h2 = ma("indexLabelBackgroundColor", m.dataPoint, m.dataSeries), m.dataSeries.indexLabelBackgroundColor = s(h2) ? w ? "transparent" : null : h2;
          return d;
        };
        n.prototype.renderLine = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = this._eventManager.ghostCtx;
            c.save();
            var e = this.plotArea;
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            for (var f = [], l, t = 0; t < a.dataSeriesIndexes.length; t++) {
              var C = a.dataSeriesIndexes[t], k = this.data[C];
              c.lineWidth = k.lineThickness;
              var m = k.dataPoints, p = "solid";
              if (c.setLineDash) {
                var q = J(k.nullDataLineDashType, k.lineThickness), p = k.lineDashType, g = J(p, k.lineThickness);
                c.setLineDash(g);
              }
              var r = k.id;
              this._eventManager.objectMap[r] = {
                objectType: "dataSeries",
                dataSeriesIndex: C
              };
              r = X(r);
              b.strokeStyle = r;
              b.lineWidth = 0 < k.lineThickness ? Math.max(k.lineThickness, 4) : 0;
              var r = k._colorSet, h2 = r = k.lineColor = k.options.lineColor ? k.options.lineColor : r[0];
              c.strokeStyle = r;
              var s2 = true, u = 0, n2, x;
              c.beginPath();
              if (0 < m.length) {
                for (var z = false, u = 0; u < m.length; u++)
                  if (n2 = m[u].x.getTime ? m[u].x.getTime() : m[u].x, !(n2 < a.axisX.dataInfo.viewPortMin || n2 > a.axisX.dataInfo.viewPortMax && (!k.connectNullData || !z)))
                    if ("number" !== typeof m[u].y)
                      0 < u && !(k.connectNullData || z || s2) && (c.stroke(), w && b.stroke()), z = true;
                    else {
                      n2 = a.axisX.convertValueToPixel(n2);
                      x = a.axisY.convertValueToPixel(m[u].y);
                      var H = k.dataPointIds[u];
                      this._eventManager.objectMap[H] = { id: H, objectType: "dataPoint", dataSeriesIndex: C, dataPointIndex: u, x1: n2, y1: x };
                      s2 || z ? (!s2 && k.connectNullData ? (c.setLineDash && (k.options.nullDataLineDashType || p === k.lineDashType && k.lineDashType !== k.nullDataLineDashType) && (c.stroke(), c.beginPath(), c.moveTo(l.x, l.y), p = k.nullDataLineDashType, c.setLineDash(q)), c.lineTo(n2, x), w && b.lineTo(n2, x)) : (c.beginPath(), c.moveTo(n2, x), w && (b.beginPath(), b.moveTo(n2, x))), z = s2 = false) : (c.lineTo(n2, x), w && b.lineTo(n2, x), 0 == u % 500 && (c.stroke(), c.beginPath(), c.moveTo(n2, x), w && (b.stroke(), b.beginPath(), b.moveTo(n2, x))));
                      l = { x: n2, y: x };
                      u < m.length - 1 && (h2 !== (m[u].lineColor || r) || p !== (m[u].lineDashType || k.lineDashType)) && (c.stroke(), c.beginPath(), c.moveTo(n2, x), h2 = m[u].lineColor || r, c.strokeStyle = h2, c.setLineDash && (m[u].lineDashType ? (p = m[u].lineDashType, c.setLineDash(J(p, k.lineThickness))) : (p = k.lineDashType, c.setLineDash(g))));
                      if (0 !== m[u].markerSize && (0 < m[u].markerSize || 0 < k.markerSize)) {
                        var D = k.getMarkerProperties(u, n2, x, c);
                        f.push(D);
                        H = X(H);
                        w && f.push({ x: n2, y: x, ctx: b, type: D.type, size: D.size, color: H, borderColor: H, borderThickness: D.borderThickness });
                      }
                      (m[u].indexLabel || k.indexLabel || m[u].indexLabelFormatter || k.indexLabelFormatter) && this._indexLabels.push({ chartType: "line", dataPoint: m[u], dataSeries: k, point: { x: n2, y: x }, direction: 0 > m[u].y === a.axisY.reversed ? 1 : -1, color: r });
                    }
                c.stroke();
                w && b.stroke();
              }
            }
            W.drawMarkers(f);
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), b.beginPath());
            c.restore();
            c.beginPath();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.xClipAnimation, easingFunction: M.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderStepLine = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = this._eventManager.ghostCtx;
            c.save();
            var e = this.plotArea;
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            for (var f = [], l, t = 0; t < a.dataSeriesIndexes.length; t++) {
              var C = a.dataSeriesIndexes[t], k = this.data[C];
              c.lineWidth = k.lineThickness;
              var m = k.dataPoints, p = "solid";
              if (c.setLineDash) {
                var q = J(k.nullDataLineDashType, k.lineThickness), p = k.lineDashType, g = J(p, k.lineThickness);
                c.setLineDash(g);
              }
              var r = k.id;
              this._eventManager.objectMap[r] = { objectType: "dataSeries", dataSeriesIndex: C };
              r = X(r);
              b.strokeStyle = r;
              b.lineWidth = 0 < k.lineThickness ? Math.max(k.lineThickness, 4) : 0;
              var r = k._colorSet, h2 = r = k.lineColor = k.options.lineColor ? k.options.lineColor : r[0];
              c.strokeStyle = r;
              var s2 = true, u = 0, n2, x;
              c.beginPath();
              if (0 < m.length) {
                for (var z = false, u = 0; u < m.length; u++)
                  if (n2 = m[u].getTime ? m[u].x.getTime() : m[u].x, !(n2 < a.axisX.dataInfo.viewPortMin || n2 > a.axisX.dataInfo.viewPortMax && (!k.connectNullData || !z)))
                    if ("number" !== typeof m[u].y)
                      0 < u && !(k.connectNullData || z || s2) && (c.stroke(), w && b.stroke()), z = true;
                    else {
                      var H = x;
                      n2 = a.axisX.convertValueToPixel(n2);
                      x = a.axisY.convertValueToPixel(m[u].y);
                      var D = k.dataPointIds[u];
                      this._eventManager.objectMap[D] = { id: D, objectType: "dataPoint", dataSeriesIndex: C, dataPointIndex: u, x1: n2, y1: x };
                      s2 || z ? (!s2 && k.connectNullData ? (c.setLineDash && (k.options.nullDataLineDashType || p === k.lineDashType && k.lineDashType !== k.nullDataLineDashType) && (c.stroke(), c.beginPath(), c.moveTo(l.x, l.y), p = k.nullDataLineDashType, c.setLineDash(q)), c.lineTo(n2, H), c.lineTo(n2, x), w && (b.lineTo(n2, H), b.lineTo(n2, x))) : (c.beginPath(), c.moveTo(n2, x), w && (b.beginPath(), b.moveTo(n2, x))), z = s2 = false) : (c.lineTo(n2, H), w && b.lineTo(n2, H), c.lineTo(n2, x), w && b.lineTo(n2, x), 0 == u % 500 && (c.stroke(), c.beginPath(), c.moveTo(n2, x), w && (b.stroke(), b.beginPath(), b.moveTo(n2, x))));
                      l = { x: n2, y: x };
                      u < m.length - 1 && (h2 !== (m[u].lineColor || r) || p !== (m[u].lineDashType || k.lineDashType)) && (c.stroke(), c.beginPath(), c.moveTo(n2, x), h2 = m[u].lineColor || r, c.strokeStyle = h2, c.setLineDash && (m[u].lineDashType ? (p = m[u].lineDashType, c.setLineDash(J(p, k.lineThickness))) : (p = k.lineDashType, c.setLineDash(g))));
                      0 !== m[u].markerSize && (0 < m[u].markerSize || 0 < k.markerSize) && (H = k.getMarkerProperties(u, n2, x, c), f.push(H), D = X(D), w && f.push({ x: n2, y: x, ctx: b, type: H.type, size: H.size, color: D, borderColor: D, borderThickness: H.borderThickness }));
                      (m[u].indexLabel || k.indexLabel || m[u].indexLabelFormatter || k.indexLabelFormatter) && this._indexLabels.push({ chartType: "stepLine", dataPoint: m[u], dataSeries: k, point: { x: n2, y: x }, direction: 0 > m[u].y === a.axisY.reversed ? 1 : -1, color: r });
                    }
                c.stroke();
                w && b.stroke();
              }
            }
            W.drawMarkers(f);
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), b.beginPath());
            c.restore();
            c.beginPath();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.xClipAnimation, easingFunction: M.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderSpline = function(a) {
          function d(a2) {
            a2 = v2(a2, 2);
            if (0 < a2.length) {
              b.beginPath();
              w && e.beginPath();
              b.moveTo(a2[0].x, a2[0].y);
              a2[0].newStrokeStyle && (b.strokeStyle = a2[0].newStrokeStyle);
              a2[0].newLineDashArray && b.setLineDash(a2[0].newLineDashArray);
              w && e.moveTo(a2[0].x, a2[0].y);
              for (var c2 = 0; c2 < a2.length - 3; c2 += 3)
                if (b.bezierCurveTo(a2[c2 + 1].x, a2[c2 + 1].y, a2[c2 + 2].x, a2[c2 + 2].y, a2[c2 + 3].x, a2[c2 + 3].y), w && e.bezierCurveTo(a2[c2 + 1].x, a2[c2 + 1].y, a2[c2 + 2].x, a2[c2 + 2].y, a2[c2 + 3].x, a2[c2 + 3].y), 0 < c2 && 0 === c2 % 3e3 || a2[c2 + 3].newStrokeStyle || a2[c2 + 3].newLineDashArray)
                  b.stroke(), b.beginPath(), b.moveTo(a2[c2 + 3].x, a2[c2 + 3].y), a2[c2 + 3].newStrokeStyle && (b.strokeStyle = a2[c2 + 3].newStrokeStyle), a2[c2 + 3].newLineDashArray && b.setLineDash(a2[c2 + 3].newLineDashArray), w && (e.stroke(), e.beginPath(), e.moveTo(a2[c2 + 3].x, a2[c2 + 3].y));
              b.stroke();
              w && e.stroke();
            }
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = w ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = this._eventManager.ghostCtx;
            b.save();
            var f = this.plotArea;
            b.beginPath();
            b.rect(f.x1, f.y1, f.width, f.height);
            b.clip();
            for (var l = [], t = 0; t < a.dataSeriesIndexes.length; t++) {
              var C = a.dataSeriesIndexes[t], k = this.data[C];
              b.lineWidth = k.lineThickness;
              var m = k.dataPoints, p = "solid";
              if (b.setLineDash) {
                var q = J(k.nullDataLineDashType, k.lineThickness), p = k.lineDashType, g = J(p, k.lineThickness);
                b.setLineDash(g);
              }
              var r = k.id;
              this._eventManager.objectMap[r] = { objectType: "dataSeries", dataSeriesIndex: C };
              r = X(r);
              e.strokeStyle = r;
              e.lineWidth = 0 < k.lineThickness ? Math.max(k.lineThickness, 4) : 0;
              var r = k._colorSet, h2 = r = k.lineColor = k.options.lineColor ? k.options.lineColor : r[0];
              b.strokeStyle = r;
              var s2 = 0, u, n2, x = [];
              b.beginPath();
              if (0 < m.length) {
                for (n2 = false, s2 = 0; s2 < m.length; s2++)
                  if (u = m[s2].getTime ? m[s2].x.getTime() : m[s2].x, !(u < a.axisX.dataInfo.viewPortMin || u > a.axisX.dataInfo.viewPortMax && (!k.connectNullData || !n2)))
                    if ("number" !== typeof m[s2].y)
                      0 < s2 && !n2 && (k.connectNullData ? b.setLineDash && (0 < x.length && (k.options.nullDataLineDashType || !m[s2 - 1].lineDashType)) && (x[x.length - 1].newLineDashArray = q, p = k.nullDataLineDashType) : (d(x), x = [])), n2 = true;
                    else {
                      u = a.axisX.convertValueToPixel(u);
                      n2 = a.axisY.convertValueToPixel(m[s2].y);
                      var z = k.dataPointIds[s2];
                      this._eventManager.objectMap[z] = { id: z, objectType: "dataPoint", dataSeriesIndex: C, dataPointIndex: s2, x1: u, y1: n2 };
                      x[x.length] = { x: u, y: n2 };
                      s2 < m.length - 1 && (h2 !== (m[s2].lineColor || r) || p !== (m[s2].lineDashType || k.lineDashType)) && (h2 = m[s2].lineColor || r, x[x.length - 1].newStrokeStyle = h2, b.setLineDash && (m[s2].lineDashType ? (p = m[s2].lineDashType, x[x.length - 1].newLineDashArray = J(p, k.lineThickness)) : (p = k.lineDashType, x[x.length - 1].newLineDashArray = g)));
                      if (0 !== m[s2].markerSize && (0 < m[s2].markerSize || 0 < k.markerSize)) {
                        var H = k.getMarkerProperties(s2, u, n2, b);
                        l.push(H);
                        z = X(z);
                        w && l.push({ x: u, y: n2, ctx: e, type: H.type, size: H.size, color: z, borderColor: z, borderThickness: H.borderThickness });
                      }
                      (m[s2].indexLabel || k.indexLabel || m[s2].indexLabelFormatter || k.indexLabelFormatter) && this._indexLabels.push({ chartType: "spline", dataPoint: m[s2], dataSeries: k, point: { x: u, y: n2 }, direction: 0 > m[s2].y === a.axisY.reversed ? 1 : -1, color: r });
                      n2 = false;
                    }
              }
              d(x);
            }
            W.drawMarkers(l);
            w && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(f.x1, f.y1, f.width, f.height), e.beginPath());
            b.restore();
            b.beginPath();
            return {
              source: c,
              dest: this.plotArea.ctx,
              animationCallback: M.xClipAnimation,
              easingFunction: M.easing.linear,
              animationBase: 0
            };
          }
        };
        n.prototype.renderColumn = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, f = 0, l, t, C, k = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), f = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, m = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : Math.min(0.15 * this.width, 0.9 * (this.plotArea.width / a.plotType.totalDataSeries)) << 0, p = a.axisX.dataInfo.minDiff;
            isFinite(p) || (p = 0.3 * Math.abs(a.axisX.range));
            p = this.dataPointWidth = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.width * (a.axisX.logarithmic ? Math.log(p) / Math.log(a.axisX.range) : Math.abs(p) / Math.abs(a.axisX.range)) / a.plotType.totalDataSeries) << 0;
            this.dataPointMaxWidth && f > m && (f = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, m));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && m < f) && (m = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, f));
            p < f && (p = f);
            p > m && (p = m);
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (m = 0; m < a.dataSeriesIndexes.length; m++) {
              var q = a.dataSeriesIndexes[m], g = this.data[q], r = g.dataPoints;
              if (0 < r.length) {
                for (var h2 = 5 < p && g.bevelEnabled ? true : false, f = 0; f < r.length; f++)
                  if (r[f].getTime ? C = r[f].x.getTime() : C = r[f].x, !(C < a.axisX.dataInfo.viewPortMin || C > a.axisX.dataInfo.viewPortMax) && "number" === typeof r[f].y) {
                    l = a.axisX.convertValueToPixel(C);
                    t = a.axisY.convertValueToPixel(r[f].y);
                    l = a.axisX.reversed ? l + a.plotType.totalDataSeries * p / 2 - (a.previousDataSeriesCount + m) * p << 0 : l - a.plotType.totalDataSeries * p / 2 + (a.previousDataSeriesCount + m) * p << 0;
                    var s2 = a.axisX.reversed ? l - p << 0 : l + p << 0, u;
                    0 <= r[f].y ? u = k : (u = t, t = k);
                    t > u && (b = t, t = u, u = b);
                    b = r[f].color ? r[f].color : g._colorSet[f % g._colorSet.length];
                    Y(c, a.axisX.reversed ? s2 : l, t, a.axisX.reversed ? l : s2, u, b, 0, null, h2 && (a.axisY.reversed ? 0 > r[f].y : 0 <= r[f].y), (a.axisY.reversed ? 0 <= r[f].y : 0 > r[f].y) && h2, false, false, g.fillOpacity);
                    b = g.dataPointIds[f];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: q, dataPointIndex: f, x1: l, y1: t, x2: s2, y2: u };
                    b = X(b);
                    w && Y(
                      this._eventManager.ghostCtx,
                      a.axisX.reversed ? s2 : l,
                      t,
                      a.axisX.reversed ? l : s2,
                      u,
                      b,
                      0,
                      null,
                      false,
                      false,
                      false,
                      false
                    );
                    (r[f].indexLabel || g.indexLabel || r[f].indexLabelFormatter || g.indexLabelFormatter) && this._indexLabels.push({ chartType: "column", dataPoint: r[f], dataSeries: g, point: { x: l + (s2 - l) / 2, y: 0 > r[f].y === a.axisY.reversed ? t : u }, direction: 0 > r[f].y === a.axisY.reversed ? 1 : -1, bounds: { x1: l, y1: Math.min(t, u), x2: s2, y2: Math.max(t, u) }, color: b });
                  }
              }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.yScaleAnimation, easingFunction: M.easing.easeOutQuart, animationBase: k < a.axisY.bounds.y1 ? a.axisY.bounds.y1 : k > a.axisY.bounds.y2 ? a.axisY.bounds.y2 : k };
          }
        };
        n.prototype.renderStackedColumn = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, f = [], l = [], t = [], C = [], k = 0, m, p, q = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), k = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, g = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.15 * this.width << 0, r = a.axisX.dataInfo.minDiff;
            isFinite(r) || (r = 0.3 * Math.abs(a.axisX.range));
            r = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.width * (a.axisX.logarithmic ? Math.log(r) / Math.log(a.axisX.range) : Math.abs(r) / Math.abs(a.axisX.range)) / a.plotType.plotUnits.length) << 0;
            this.dataPointMaxWidth && k > g && (k = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, g));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && g < k) && (g = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, k));
            r < k && (r = k);
            r > g && (r = g);
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (g = 0; g < a.dataSeriesIndexes.length; g++) {
              var h2 = a.dataSeriesIndexes[g], s2 = this.data[h2], u = s2.dataPoints;
              if (0 < u.length) {
                var n2 = 5 < r && s2.bevelEnabled ? true : false;
                c.strokeStyle = "#4572A7 ";
                for (k = 0; k < u.length; k++)
                  if (b = u[k].x.getTime ? u[k].x.getTime() : u[k].x, !(b < a.axisX.dataInfo.viewPortMin || b > a.axisX.dataInfo.viewPortMax) && "number" === typeof u[k].y) {
                    m = a.axisX.convertValueToPixel(b);
                    m = m - a.plotType.plotUnits.length * r / 2 + a.index * r << 0;
                    var x = m + r << 0, z;
                    if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 < u[k].y)
                      t[b] = u[k].y + (t[b] ? t[b] : 0), 0 < t[b] && (p = a.axisY.convertValueToPixel(t[b]), z = "undefined" !== typeof f[b] ? f[b] : q, f[b] = p);
                    else if (a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 >= u[k].y)
                      C[b] = u[k].y + (C[b] ? C[b] : 0), z = a.axisY.convertValueToPixel(C[b]), p = "undefined" !== typeof l[b] ? l[b] : q, l[b] = z;
                    else if (p = a.axisY.convertValueToPixel(u[k].y), 0 <= u[k].y) {
                      var H = "undefined" !== typeof f[b] ? f[b] : 0;
                      p -= H;
                      z = q - H;
                      f[b] = H + (z - p);
                    } else
                      H = l[b] ? l[b] : 0, z = p + H, p = q + H, l[b] = H + (z - p);
                    b = u[k].color ? u[k].color : s2._colorSet[k % s2._colorSet.length];
                    Y(c, m, a.axisY.reversed ? z : p, x, a.axisY.reversed ? p : z, b, 0, null, n2 && (a.axisY.reversed ? 0 > u[k].y : 0 <= u[k].y), (a.axisY.reversed ? 0 <= u[k].y : 0 > u[k].y) && n2, false, false, s2.fillOpacity);
                    b = s2.dataPointIds[k];
                    this._eventManager.objectMap[b] = {
                      id: b,
                      objectType: "dataPoint",
                      dataSeriesIndex: h2,
                      dataPointIndex: k,
                      x1: m,
                      y1: p,
                      x2: x,
                      y2: z
                    };
                    b = X(b);
                    w && Y(this._eventManager.ghostCtx, m, p, x, z, b, 0, null, false, false, false, false);
                    (u[k].indexLabel || s2.indexLabel || u[k].indexLabelFormatter || s2.indexLabelFormatter) && this._indexLabels.push({ chartType: "stackedColumn", dataPoint: u[k], dataSeries: s2, point: { x: m + (x - m) / 2, y: 0 <= u[k].y ? p : z }, direction: 0 > u[k].y === a.axisY.reversed ? 1 : -1, bounds: { x1: m, y1: Math.min(p, z), x2: x, y2: Math.max(p, z) }, color: b });
                  }
              }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.yScaleAnimation, easingFunction: M.easing.easeOutQuart, animationBase: q < a.axisY.bounds.y1 ? a.axisY.bounds.y1 : q > a.axisY.bounds.y2 ? a.axisY.bounds.y2 : q };
          }
        };
        n.prototype.renderStackedColumn100 = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, f = [], l = [], t = [], C = [], k = 0, m, p, q = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), k = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, g = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.15 * this.width << 0, r = a.axisX.dataInfo.minDiff;
            isFinite(r) || (r = 0.3 * Math.abs(a.axisX.range));
            r = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.width * (a.axisX.logarithmic ? Math.log(r) / Math.log(a.axisX.range) : Math.abs(r) / Math.abs(a.axisX.range)) / a.plotType.plotUnits.length) << 0;
            this.dataPointMaxWidth && k > g && (k = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, g));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && g < k) && (g = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, k));
            r < k && (r = k);
            r > g && (r = g);
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (g = 0; g < a.dataSeriesIndexes.length; g++) {
              var h2 = a.dataSeriesIndexes[g], s2 = this.data[h2], u = s2.dataPoints;
              if (0 < u.length) {
                for (var n2 = 5 < r && s2.bevelEnabled ? true : false, k = 0; k < u.length; k++)
                  if (b = u[k].x.getTime ? u[k].x.getTime() : u[k].x, !(b < a.axisX.dataInfo.viewPortMin || b > a.axisX.dataInfo.viewPortMax) && "number" === typeof u[k].y) {
                    m = a.axisX.convertValueToPixel(b);
                    p = 0 !== a.dataPointYSums[b] ? 100 * (u[k].y / a.dataPointYSums[b]) : 0;
                    m = m - a.plotType.plotUnits.length * r / 2 + a.index * r << 0;
                    var x = m + r << 0, z;
                    if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 < u[k].y) {
                      t[b] = p + ("undefined" !== typeof t[b] ? t[b] : 0);
                      if (0 >= t[b])
                        continue;
                      p = a.axisY.convertValueToPixel(t[b]);
                      z = f[b] ? f[b] : q;
                      f[b] = p;
                    } else if (a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 >= u[k].y)
                      C[b] = p + ("undefined" !== typeof C[b] ? C[b] : 0), z = a.axisY.convertValueToPixel(C[b]), p = l[b] ? l[b] : q, l[b] = z;
                    else if (p = a.axisY.convertValueToPixel(p), 0 <= u[k].y) {
                      var H = "undefined" !== typeof f[b] ? f[b] : 0;
                      p -= H;
                      z = q - H;
                      a.dataSeriesIndexes.length - 1 === g && 1 >= Math.abs(e.y1 - p) && (p = e.y1);
                      f[b] = H + (z - p);
                    } else
                      H = "undefined" !== typeof l[b] ? l[b] : 0, z = p + H, p = q + H, a.dataSeriesIndexes.length - 1 === g && 1 >= Math.abs(e.y2 - z) && (z = e.y2), l[b] = H + (z - p);
                    b = u[k].color ? u[k].color : s2._colorSet[k % s2._colorSet.length];
                    Y(
                      c,
                      m,
                      a.axisY.reversed ? z : p,
                      x,
                      a.axisY.reversed ? p : z,
                      b,
                      0,
                      null,
                      n2 && (a.axisY.reversed ? 0 > u[k].y : 0 <= u[k].y),
                      (a.axisY.reversed ? 0 <= u[k].y : 0 > u[k].y) && n2,
                      false,
                      false,
                      s2.fillOpacity
                    );
                    b = s2.dataPointIds[k];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: h2, dataPointIndex: k, x1: m, y1: p, x2: x, y2: z };
                    b = X(b);
                    w && Y(this._eventManager.ghostCtx, m, p, x, z, b, 0, null, false, false, false, false);
                    (u[k].indexLabel || s2.indexLabel || u[k].indexLabelFormatter || s2.indexLabelFormatter) && this._indexLabels.push({
                      chartType: "stackedColumn100",
                      dataPoint: u[k],
                      dataSeries: s2,
                      point: { x: m + (x - m) / 2, y: 0 <= u[k].y ? p : z },
                      direction: 0 > u[k].y === a.axisY.reversed ? 1 : -1,
                      bounds: { x1: m, y1: Math.min(p, z), x2: x, y2: Math.max(p, z) },
                      color: b
                    });
                  }
              }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.yScaleAnimation, easingFunction: M.easing.easeOutQuart, animationBase: q < a.axisY.bounds.y1 ? a.axisY.bounds.y1 : q > a.axisY.bounds.y2 ? a.axisY.bounds.y2 : q };
          }
        };
        n.prototype.renderBar = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, f = 0, l, t, C, k = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), f = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, m = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : Math.min(0.15 * this.height, 0.9 * (this.plotArea.height / a.plotType.totalDataSeries)) << 0, p = a.axisX.dataInfo.minDiff;
            isFinite(p) || (p = 0.3 * Math.abs(a.axisX.range));
            p = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.height * (a.axisX.logarithmic ? Math.log(p) / Math.log(a.axisX.range) : Math.abs(p) / Math.abs(a.axisX.range)) / a.plotType.totalDataSeries) << 0;
            this.dataPointMaxWidth && f > m && (f = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, m));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && m < f) && (m = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, f));
            p < f && (p = f);
            p > m && (p = m);
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(
              e.x1,
              e.y1,
              e.width,
              e.height
            ), this._eventManager.ghostCtx.clip());
            for (m = 0; m < a.dataSeriesIndexes.length; m++) {
              var q = a.dataSeriesIndexes[m], g = this.data[q], r = g.dataPoints;
              if (0 < r.length) {
                var h2 = 5 < p && g.bevelEnabled ? true : false;
                c.strokeStyle = "#4572A7 ";
                for (f = 0; f < r.length; f++)
                  if (r[f].getTime ? C = r[f].x.getTime() : C = r[f].x, !(C < a.axisX.dataInfo.viewPortMin || C > a.axisX.dataInfo.viewPortMax) && "number" === typeof r[f].y) {
                    t = a.axisX.convertValueToPixel(C);
                    l = a.axisY.convertValueToPixel(r[f].y);
                    t = a.axisX.reversed ? t + a.plotType.totalDataSeries * p / 2 - (a.previousDataSeriesCount + m) * p << 0 : t - a.plotType.totalDataSeries * p / 2 + (a.previousDataSeriesCount + m) * p << 0;
                    var s2 = a.axisX.reversed ? t - p << 0 : t + p << 0, u;
                    0 <= r[f].y ? u = k : (u = l, l = k);
                    b = r[f].color ? r[f].color : g._colorSet[f % g._colorSet.length];
                    Y(c, a.axisY.reversed ? l : u, a.axisX.reversed ? s2 : t, a.axisY.reversed ? u : l, a.axisX.reversed ? t : s2, b, 0, null, h2, false, false, false, g.fillOpacity);
                    b = g.dataPointIds[f];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: q, dataPointIndex: f, x1: u, y1: t, x2: l, y2: s2 };
                    b = X(b);
                    w && Y(
                      this._eventManager.ghostCtx,
                      u,
                      a.axisX.reversed ? s2 : t,
                      l,
                      a.axisX.reversed ? t : s2,
                      b,
                      0,
                      null,
                      false,
                      false,
                      false,
                      false
                    );
                    (r[f].indexLabel || g.indexLabel || r[f].indexLabelFormatter || g.indexLabelFormatter) && this._indexLabels.push({ chartType: "bar", dataPoint: r[f], dataSeries: g, point: { x: 0 <= r[f].y ? l : u, y: t + (s2 - t) / 2 }, direction: 0 > r[f].y === a.axisY.reversed ? 1 : -1, bounds: { x1: Math.min(u, l), y1: t, x2: Math.max(u, l), y2: s2 }, color: b });
                  }
              }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(
              a.axisX.maskCanvas,
              0,
              0,
              this.width,
              this.height
            ), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.xScaleAnimation, easingFunction: M.easing.easeOutQuart, animationBase: k < a.axisY.bounds.x1 ? a.axisY.bounds.x1 : k > a.axisY.bounds.x2 ? a.axisY.bounds.x2 : k };
          }
        };
        n.prototype.renderStackedBar = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, f = [], l = [], t = [], C = [], k = 0, m, p, q = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), k = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, g = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.15 * this.height << 0, r = a.axisX.dataInfo.minDiff;
            isFinite(r) || (r = 0.3 * Math.abs(a.axisX.range));
            r = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.height * (a.axisX.logarithmic ? Math.log(r) / Math.log(a.axisX.range) : Math.abs(r) / Math.abs(a.axisX.range)) / a.plotType.plotUnits.length) << 0;
            this.dataPointMaxWidth && k > g && (k = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, g));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && g < k) && (g = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, k));
            r < k && (r = k);
            r > g && (r = g);
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (g = 0; g < a.dataSeriesIndexes.length; g++) {
              var h2 = a.dataSeriesIndexes[g], s2 = this.data[h2], u = s2.dataPoints;
              if (0 < u.length) {
                var n2 = 5 < r && s2.bevelEnabled ? true : false;
                c.strokeStyle = "#4572A7 ";
                for (k = 0; k < u.length; k++)
                  if (b = u[k].x.getTime ? u[k].x.getTime() : u[k].x, !(b < a.axisX.dataInfo.viewPortMin || b > a.axisX.dataInfo.viewPortMax) && "number" === typeof u[k].y) {
                    p = a.axisX.convertValueToPixel(b);
                    p = p - a.plotType.plotUnits.length * r / 2 + a.index * r << 0;
                    var x = p + r << 0, z;
                    if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 < u[k].y)
                      t[b] = u[k].y + (t[b] ? t[b] : 0), 0 < t[b] && (z = f[b] ? f[b] : q, f[b] = m = a.axisY.convertValueToPixel(t[b]));
                    else if (a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 >= u[k].y)
                      C[b] = u[k].y + (C[b] ? C[b] : 0), m = l[b] ? l[b] : q, l[b] = z = a.axisY.convertValueToPixel(C[b]);
                    else if (m = a.axisY.convertValueToPixel(u[k].y), 0 <= u[k].y) {
                      var H = f[b] ? f[b] : 0;
                      z = q + H;
                      m += H;
                      f[b] = H + (m - z);
                    } else
                      H = l[b] ? l[b] : 0, z = m - H, m = q - H, l[b] = H + (m - z);
                    b = u[k].color ? u[k].color : s2._colorSet[k % s2._colorSet.length];
                    Y(c, a.axisY.reversed ? m : z, p, a.axisY.reversed ? z : m, x, b, 0, null, n2, false, false, false, s2.fillOpacity);
                    b = s2.dataPointIds[k];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: h2, dataPointIndex: k, x1: z, y1: p, x2: m, y2: x };
                    b = X(b);
                    w && Y(
                      this._eventManager.ghostCtx,
                      z,
                      p,
                      m,
                      x,
                      b,
                      0,
                      null,
                      false,
                      false,
                      false,
                      false
                    );
                    (u[k].indexLabel || s2.indexLabel || u[k].indexLabelFormatter || s2.indexLabelFormatter) && this._indexLabels.push({ chartType: "stackedBar", dataPoint: u[k], dataSeries: s2, point: { x: 0 <= u[k].y ? m : z, y: p + (x - p) / 2 }, direction: 0 > u[k].y === a.axisY.reversed ? 1 : -1, bounds: { x1: Math.min(z, m), y1: p, x2: Math.max(z, m), y2: x }, color: b });
                  }
              }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(
              a.axisX.maskCanvas,
              0,
              0,
              this.width,
              this.height
            ), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.xScaleAnimation, easingFunction: M.easing.easeOutQuart, animationBase: q < a.axisY.bounds.x1 ? a.axisY.bounds.x1 : q > a.axisY.bounds.x2 ? a.axisY.bounds.x2 : q };
          }
        };
        n.prototype.renderStackedBar100 = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, f = [], l = [], t = [], C = [], k = 0, m, p, q = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), k = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, g = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.15 * this.height << 0, r = a.axisX.dataInfo.minDiff;
            isFinite(r) || (r = 0.3 * Math.abs(a.axisX.range));
            r = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.height * (a.axisX.logarithmic ? Math.log(r) / Math.log(a.axisX.range) : Math.abs(r) / Math.abs(a.axisX.range)) / a.plotType.plotUnits.length) << 0;
            this.dataPointMaxWidth && k > g && (k = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, g));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && g < k) && (g = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, k));
            r < k && (r = k);
            r > g && (r = g);
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (g = 0; g < a.dataSeriesIndexes.length; g++) {
              var h2 = a.dataSeriesIndexes[g], s2 = this.data[h2], u = s2.dataPoints;
              if (0 < u.length) {
                var n2 = 5 < r && s2.bevelEnabled ? true : false;
                c.strokeStyle = "#4572A7 ";
                for (k = 0; k < u.length; k++)
                  if (b = u[k].x.getTime ? u[k].x.getTime() : u[k].x, !(b < a.axisX.dataInfo.viewPortMin || b > a.axisX.dataInfo.viewPortMax) && "number" === typeof u[k].y) {
                    p = a.axisX.convertValueToPixel(b);
                    var x;
                    x = 0 !== a.dataPointYSums[b] ? 100 * (u[k].y / a.dataPointYSums[b]) : 0;
                    p = p - a.plotType.plotUnits.length * r / 2 + a.index * r << 0;
                    var z = p + r << 0;
                    if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 < u[k].y) {
                      t[b] = x + (t[b] ? t[b] : 0);
                      if (0 >= t[b])
                        continue;
                      x = f[b] ? f[b] : q;
                      f[b] = m = a.axisY.convertValueToPixel(t[b]);
                    } else if (a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 >= u[k].y)
                      C[b] = x + (C[b] ? C[b] : 0), m = l[b] ? l[b] : q, l[b] = x = a.axisY.convertValueToPixel(C[b]);
                    else if (m = a.axisY.convertValueToPixel(x), 0 <= u[k].y) {
                      var H = f[b] ? f[b] : 0;
                      x = q + H;
                      m += H;
                      a.dataSeriesIndexes.length - 1 === g && 1 >= Math.abs(e.x2 - m) && (m = e.x2);
                      f[b] = H + (m - x);
                    } else
                      H = l[b] ? l[b] : 0, x = m - H, m = q - H, a.dataSeriesIndexes.length - 1 === g && 1 >= Math.abs(e.x1 - x) && (x = e.x1), l[b] = H + (m - x);
                    b = u[k].color ? u[k].color : s2._colorSet[k % s2._colorSet.length];
                    Y(c, a.axisY.reversed ? m : x, p, a.axisY.reversed ? x : m, z, b, 0, null, n2, false, false, false, s2.fillOpacity);
                    b = s2.dataPointIds[k];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: h2, dataPointIndex: k, x1: x, y1: p, x2: m, y2: z };
                    b = X(b);
                    w && Y(this._eventManager.ghostCtx, x, p, m, z, b, 0, null, false, false, false, false);
                    (u[k].indexLabel || s2.indexLabel || u[k].indexLabelFormatter || s2.indexLabelFormatter) && this._indexLabels.push({ chartType: "stackedBar100", dataPoint: u[k], dataSeries: s2, point: { x: 0 <= u[k].y ? m : x, y: p + (z - p) / 2 }, direction: 0 > u[k].y === a.axisY.reversed ? 1 : -1, bounds: { x1: Math.min(x, m), y1: p, x2: Math.max(x, m), y2: z }, color: b });
                  }
              }
            }
            w && (d.drawImage(
              this._preRenderCanvas,
              0,
              0,
              this.width,
              this.height
            ), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return {
              source: d,
              dest: this.plotArea.ctx,
              animationCallback: M.xScaleAnimation,
              easingFunction: M.easing.easeOutQuart,
              animationBase: q < a.axisY.bounds.x1 ? a.axisY.bounds.x1 : q > a.axisY.bounds.x2 ? a.axisY.bounds.x2 : q
            };
          }
        };
        n.prototype.renderArea = function(a) {
          var d, c;
          function b() {
            H && (0 < g.lineThickness && f.stroke(), a.axisY.logarithmic || 0 >= a.axisY.viewportMinimum && 0 <= a.axisY.viewportMaximum ? z = x : 0 > a.axisY.viewportMaximum ? z = t.y1 : 0 < a.axisY.viewportMinimum && (z = x), f.lineTo(s2, z), f.lineTo(H.x, z), f.closePath(), f.globalAlpha = g.fillOpacity, f.fill(), f.globalAlpha = 1, w && (l.lineTo(s2, z), l.lineTo(H.x, z), l.closePath(), l.fill()), f.beginPath(), f.moveTo(
              s2,
              u
            ), l.beginPath(), l.moveTo(s2, u), H = { x: s2, y: u });
          }
          var e = a.targetCanvasCtx || this.plotArea.ctx, f = w ? this._preRenderCtx : e;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var l = this._eventManager.ghostCtx, t = a.axisY.lineCoordinates, C = [], k = this.plotArea, m;
            f.save();
            w && l.save();
            f.beginPath();
            f.rect(k.x1, k.y1, k.width, k.height);
            f.clip();
            w && (l.beginPath(), l.rect(k.x1, k.y1, k.width, k.height), l.clip());
            for (var p = 0; p < a.dataSeriesIndexes.length; p++) {
              var q = a.dataSeriesIndexes[p], g = this.data[q], r = g.dataPoints, C = g.id;
              this._eventManager.objectMap[C] = { objectType: "dataSeries", dataSeriesIndex: q };
              C = X(C);
              l.fillStyle = C;
              C = [];
              d = true;
              var h2 = 0, s2, u, n2, x = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), z, H = null;
              if (0 < r.length) {
                var D = g._colorSet[h2 % g._colorSet.length], v3 = g.lineColor = g.options.lineColor || D, A2 = v3;
                f.fillStyle = D;
                f.strokeStyle = v3;
                f.lineWidth = g.lineThickness;
                c = "solid";
                if (f.setLineDash) {
                  var L = J(g.nullDataLineDashType, g.lineThickness);
                  c = g.lineDashType;
                  var S = J(c, g.lineThickness);
                  f.setLineDash(S);
                }
                for (var ea = true; h2 < r.length; h2++)
                  if (n2 = r[h2].x.getTime ? r[h2].x.getTime() : r[h2].x, !(n2 < a.axisX.dataInfo.viewPortMin || n2 > a.axisX.dataInfo.viewPortMax && (!g.connectNullData || !ea)))
                    if ("number" !== typeof r[h2].y)
                      g.connectNullData || (ea || d) || b(), ea = true;
                    else {
                      s2 = a.axisX.convertValueToPixel(n2);
                      u = a.axisY.convertValueToPixel(r[h2].y);
                      d || ea ? (!d && g.connectNullData ? (f.setLineDash && (g.options.nullDataLineDashType || c === g.lineDashType && g.lineDashType !== g.nullDataLineDashType) && (d = s2, c = u, s2 = m.x, u = m.y, b(), f.moveTo(m.x, m.y), s2 = d, u = c, H = m, c = g.nullDataLineDashType, f.setLineDash(L)), f.lineTo(
                        s2,
                        u
                      ), w && l.lineTo(s2, u)) : (f.beginPath(), f.moveTo(s2, u), w && (l.beginPath(), l.moveTo(s2, u)), H = { x: s2, y: u }), ea = d = false) : (f.lineTo(s2, u), w && l.lineTo(s2, u), 0 == h2 % 250 && b());
                      m = { x: s2, y: u };
                      h2 < r.length - 1 && (A2 !== (r[h2].lineColor || v3) || c !== (r[h2].lineDashType || g.lineDashType)) && (b(), A2 = r[h2].lineColor || v3, f.strokeStyle = A2, f.setLineDash && (r[h2].lineDashType ? (c = r[h2].lineDashType, f.setLineDash(J(c, g.lineThickness))) : (c = g.lineDashType, f.setLineDash(S))));
                      var $ = g.dataPointIds[h2];
                      this._eventManager.objectMap[$] = {
                        id: $,
                        objectType: "dataPoint",
                        dataSeriesIndex: q,
                        dataPointIndex: h2,
                        x1: s2,
                        y1: u
                      };
                      0 !== r[h2].markerSize && (0 < r[h2].markerSize || 0 < g.markerSize) && (n2 = g.getMarkerProperties(h2, s2, u, f), C.push(n2), $ = X($), w && C.push({ x: s2, y: u, ctx: l, type: n2.type, size: n2.size, color: $, borderColor: $, borderThickness: n2.borderThickness }));
                      (r[h2].indexLabel || g.indexLabel || r[h2].indexLabelFormatter || g.indexLabelFormatter) && this._indexLabels.push({ chartType: "area", dataPoint: r[h2], dataSeries: g, point: { x: s2, y: u }, direction: 0 > r[h2].y === a.axisY.reversed ? 1 : -1, color: D });
                    }
                b();
                W.drawMarkers(C);
              }
            }
            w && (e.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), f.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && f.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && f.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), f.clearRect(k.x1, k.y1, k.width, k.height), this._eventManager.ghostCtx.restore());
            f.restore();
            return {
              source: e,
              dest: this.plotArea.ctx,
              animationCallback: M.xClipAnimation,
              easingFunction: M.easing.linear,
              animationBase: 0
            };
          }
        };
        n.prototype.renderSplineArea = function(a) {
          function d() {
            var c2 = v2(y, 2);
            if (0 < c2.length) {
              if (0 < m.lineThickness) {
                b.beginPath();
                b.moveTo(c2[0].x, c2[0].y);
                c2[0].newStrokeStyle && (b.strokeStyle = c2[0].newStrokeStyle);
                c2[0].newLineDashArray && b.setLineDash(c2[0].newLineDashArray);
                for (var d2 = 0; d2 < c2.length - 3; d2 += 3)
                  if (b.bezierCurveTo(c2[d2 + 1].x, c2[d2 + 1].y, c2[d2 + 2].x, c2[d2 + 2].y, c2[d2 + 3].x, c2[d2 + 3].y), w && e.bezierCurveTo(c2[d2 + 1].x, c2[d2 + 1].y, c2[d2 + 2].x, c2[d2 + 2].y, c2[d2 + 3].x, c2[d2 + 3].y), c2[d2 + 3].newStrokeStyle || c2[d2 + 3].newLineDashArray)
                    b.stroke(), b.beginPath(), b.moveTo(c2[d2 + 3].x, c2[d2 + 3].y), c2[d2 + 3].newStrokeStyle && (b.strokeStyle = c2[d2 + 3].newStrokeStyle), c2[d2 + 3].newLineDashArray && b.setLineDash(c2[d2 + 3].newLineDashArray);
                b.stroke();
              }
              b.beginPath();
              b.moveTo(c2[0].x, c2[0].y);
              w && (e.beginPath(), e.moveTo(c2[0].x, c2[0].y));
              for (d2 = 0; d2 < c2.length - 3; d2 += 3)
                b.bezierCurveTo(c2[d2 + 1].x, c2[d2 + 1].y, c2[d2 + 2].x, c2[d2 + 2].y, c2[d2 + 3].x, c2[d2 + 3].y), w && e.bezierCurveTo(c2[d2 + 1].x, c2[d2 + 1].y, c2[d2 + 2].x, c2[d2 + 2].y, c2[d2 + 3].x, c2[d2 + 3].y);
              a.axisY.logarithmic || 0 >= a.axisY.viewportMinimum && 0 <= a.axisY.viewportMaximum ? n2 = s2 : 0 > a.axisY.viewportMaximum ? n2 = f.y1 : 0 < a.axisY.viewportMinimum && (n2 = s2);
              u = { x: c2[0].x, y: c2[0].y };
              b.lineTo(c2[c2.length - 1].x, n2);
              b.lineTo(u.x, n2);
              b.closePath();
              b.globalAlpha = m.fillOpacity;
              b.fill();
              b.globalAlpha = 1;
              w && (e.lineTo(c2[c2.length - 1].x, n2), e.lineTo(u.x, n2), e.closePath(), e.fill());
            }
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = w ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = this._eventManager.ghostCtx, f = a.axisY.lineCoordinates, l = [], t = this.plotArea;
            b.save();
            w && e.save();
            b.beginPath();
            b.rect(t.x1, t.y1, t.width, t.height);
            b.clip();
            w && (e.beginPath(), e.rect(t.x1, t.y1, t.width, t.height), e.clip());
            for (var h2 = 0; h2 < a.dataSeriesIndexes.length; h2++) {
              var k = a.dataSeriesIndexes[h2], m = this.data[k], p = m.dataPoints, l = m.id;
              this._eventManager.objectMap[l] = { objectType: "dataSeries", dataSeriesIndex: k };
              l = X(l);
              e.fillStyle = l;
              var l = [], q = 0, g, r, s2 = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), n2, u = null, y = [];
              if (0 < p.length) {
                var x = m._colorSet[q % m._colorSet.length], z = m.lineColor = m.options.lineColor || x, H = z;
                b.fillStyle = x;
                b.strokeStyle = z;
                b.lineWidth = m.lineThickness;
                var D = "solid";
                if (b.setLineDash) {
                  var A2 = J(m.nullDataLineDashType, m.lineThickness), D = m.lineDashType, B3 = J(D, m.lineThickness);
                  b.setLineDash(B3);
                }
                for (r = false; q < p.length; q++)
                  if (g = p[q].x.getTime ? p[q].x.getTime() : p[q].x, !(g < a.axisX.dataInfo.viewPortMin || g > a.axisX.dataInfo.viewPortMax && (!m.connectNullData || !r)))
                    if ("number" !== typeof p[q].y)
                      0 < q && !r && (m.connectNullData ? b.setLineDash && (0 < y.length && (m.options.nullDataLineDashType || !p[q - 1].lineDashType)) && (y[y.length - 1].newLineDashArray = A2, D = m.nullDataLineDashType) : (d(), y = [])), r = true;
                    else {
                      g = a.axisX.convertValueToPixel(g);
                      r = a.axisY.convertValueToPixel(p[q].y);
                      var L = m.dataPointIds[q];
                      this._eventManager.objectMap[L] = { id: L, objectType: "dataPoint", dataSeriesIndex: k, dataPointIndex: q, x1: g, y1: r };
                      y[y.length] = { x: g, y: r };
                      q < p.length - 1 && (H !== (p[q].lineColor || z) || D !== (p[q].lineDashType || m.lineDashType)) && (H = p[q].lineColor || z, y[y.length - 1].newStrokeStyle = H, b.setLineDash && (p[q].lineDashType ? (D = p[q].lineDashType, y[y.length - 1].newLineDashArray = J(D, m.lineThickness)) : (D = m.lineDashType, y[y.length - 1].newLineDashArray = B3)));
                      if (0 !== p[q].markerSize && (0 < p[q].markerSize || 0 < m.markerSize)) {
                        var S = m.getMarkerProperties(q, g, r, b);
                        l.push(S);
                        L = X(L);
                        w && l.push({ x: g, y: r, ctx: e, type: S.type, size: S.size, color: L, borderColor: L, borderThickness: S.borderThickness });
                      }
                      (p[q].indexLabel || m.indexLabel || p[q].indexLabelFormatter || m.indexLabelFormatter) && this._indexLabels.push({
                        chartType: "splineArea",
                        dataPoint: p[q],
                        dataSeries: m,
                        point: { x: g, y: r },
                        direction: 0 > p[q].y === a.axisY.reversed ? 1 : -1,
                        color: x
                      });
                      r = false;
                    }
                d();
                W.drawMarkers(l);
              }
            }
            w && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(t.x1, t.y1, t.width, t.height), this._eventManager.ghostCtx.restore());
            b.restore();
            return { source: c, dest: this.plotArea.ctx, animationCallback: M.xClipAnimation, easingFunction: M.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderStepArea = function(a) {
          var d, c;
          function b() {
            H && (0 < g.lineThickness && f.stroke(), a.axisY.logarithmic || 0 >= a.axisY.viewportMinimum && 0 <= a.axisY.viewportMaximum ? z = x : 0 > a.axisY.viewportMaximum ? z = t.y1 : 0 < a.axisY.viewportMinimum && (z = x), f.lineTo(n2, z), f.lineTo(H.x, z), f.closePath(), f.globalAlpha = g.fillOpacity, f.fill(), f.globalAlpha = 1, w && (l.lineTo(n2, z), l.lineTo(H.x, z), l.closePath(), l.fill()), f.beginPath(), f.moveTo(n2, u), l.beginPath(), l.moveTo(n2, u), H = { x: n2, y: u });
          }
          var e = a.targetCanvasCtx || this.plotArea.ctx, f = w ? this._preRenderCtx : e;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var l = this._eventManager.ghostCtx, t = a.axisY.lineCoordinates, h2 = [], k = this.plotArea, m;
            f.save();
            w && l.save();
            f.beginPath();
            f.rect(k.x1, k.y1, k.width, k.height);
            f.clip();
            w && (l.beginPath(), l.rect(k.x1, k.y1, k.width, k.height), l.clip());
            for (var p = 0; p < a.dataSeriesIndexes.length; p++) {
              var q = a.dataSeriesIndexes[p], g = this.data[q], r = g.dataPoints, h2 = g.id;
              this._eventManager.objectMap[h2] = { objectType: "dataSeries", dataSeriesIndex: q };
              h2 = X(h2);
              l.fillStyle = h2;
              h2 = [];
              d = true;
              var s2 = 0, n2, u, y, x = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), z, H = null;
              c = false;
              if (0 < r.length) {
                var D = g._colorSet[s2 % g._colorSet.length], v3 = g.lineColor = g.options.lineColor || D, A2 = v3;
                f.fillStyle = D;
                f.strokeStyle = v3;
                f.lineWidth = g.lineThickness;
                var L = "solid";
                if (f.setLineDash) {
                  var S = J(g.nullDataLineDashType, g.lineThickness), L = g.lineDashType, B3 = J(L, g.lineThickness);
                  f.setLineDash(B3);
                }
                for (; s2 < r.length; s2++)
                  if (y = r[s2].x.getTime ? r[s2].x.getTime() : r[s2].x, !(y < a.axisX.dataInfo.viewPortMin || y > a.axisX.dataInfo.viewPortMax && (!g.connectNullData || !c))) {
                    var $ = u;
                    "number" !== typeof r[s2].y ? (g.connectNullData || (c || d) || b(), c = true) : (n2 = a.axisX.convertValueToPixel(y), u = a.axisY.convertValueToPixel(r[s2].y), d || c ? (!d && g.connectNullData ? (f.setLineDash && (g.options.nullDataLineDashType || L === g.lineDashType && g.lineDashType !== g.nullDataLineDashType) && (d = n2, c = u, n2 = m.x, u = m.y, b(), f.moveTo(m.x, m.y), n2 = d, u = c, H = m, L = g.nullDataLineDashType, f.setLineDash(S)), f.lineTo(n2, $), f.lineTo(n2, u), w && (l.lineTo(n2, $), l.lineTo(n2, u))) : (f.beginPath(), f.moveTo(n2, u), w && (l.beginPath(), l.moveTo(n2, u)), H = { x: n2, y: u }), c = d = false) : (f.lineTo(n2, $), w && l.lineTo(n2, $), f.lineTo(n2, u), w && l.lineTo(n2, u), 0 == s2 % 250 && b()), m = { x: n2, y: u }, s2 < r.length - 1 && (A2 !== (r[s2].lineColor || v3) || L !== (r[s2].lineDashType || g.lineDashType)) && (b(), A2 = r[s2].lineColor || v3, f.strokeStyle = A2, f.setLineDash && (r[s2].lineDashType ? (L = r[s2].lineDashType, f.setLineDash(J(L, g.lineThickness))) : (L = g.lineDashType, f.setLineDash(B3)))), y = g.dataPointIds[s2], this._eventManager.objectMap[y] = { id: y, objectType: "dataPoint", dataSeriesIndex: q, dataPointIndex: s2, x1: n2, y1: u }, 0 !== r[s2].markerSize && (0 < r[s2].markerSize || 0 < g.markerSize) && ($ = g.getMarkerProperties(s2, n2, u, f), h2.push($), y = X(y), w && h2.push({ x: n2, y: u, ctx: l, type: $.type, size: $.size, color: y, borderColor: y, borderThickness: $.borderThickness })), (r[s2].indexLabel || g.indexLabel || r[s2].indexLabelFormatter || g.indexLabelFormatter) && this._indexLabels.push({ chartType: "stepArea", dataPoint: r[s2], dataSeries: g, point: { x: n2, y: u }, direction: 0 > r[s2].y === a.axisY.reversed ? 1 : -1, color: D }));
                  }
                b();
                W.drawMarkers(h2);
              }
            }
            w && (e.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), f.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && f.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && f.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(
              this._preRenderCanvas,
              0,
              0,
              this.width,
              this.height
            ), f.clearRect(k.x1, k.y1, k.width, k.height), this._eventManager.ghostCtx.restore());
            f.restore();
            return { source: e, dest: this.plotArea.ctx, animationCallback: M.xClipAnimation, easingFunction: M.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderStackedArea = function(a) {
          function d() {
            if (!(1 > k.length)) {
              for (0 < D.lineThickness && b.stroke(); 0 < k.length; ) {
                var a2 = k.pop();
                b.lineTo(a2.x, a2.y);
                w && n2.lineTo(a2.x, a2.y);
              }
              b.closePath();
              b.globalAlpha = D.fillOpacity;
              b.fill();
              b.globalAlpha = 1;
              b.beginPath();
              w && (n2.closePath(), n2.fill(), n2.beginPath());
              k = [];
            }
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = w ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = null, f = null, l = [], t = this.plotArea, h2 = [], k = [], m = [], p = [], q = 0, g, r, s2 = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), n2 = this._eventManager.ghostCtx, u, y, x;
            w && n2.beginPath();
            b.save();
            w && n2.save();
            b.beginPath();
            b.rect(t.x1, t.y1, t.width, t.height);
            b.clip();
            w && (n2.beginPath(), n2.rect(t.x1, t.y1, t.width, t.height), n2.clip());
            for (var e = [], z = 0; z < a.dataSeriesIndexes.length; z++) {
              var H = a.dataSeriesIndexes[z], D = this.data[H], v3 = D.dataPoints;
              D.dataPointIndexes = [];
              for (q = 0; q < v3.length; q++)
                H = v3[q].x.getTime ? v3[q].x.getTime() : v3[q].x, D.dataPointIndexes[H] = q, e[H] || (m.push(H), e[H] = true);
              m.sort(Ra);
            }
            for (z = 0; z < a.dataSeriesIndexes.length; z++) {
              H = a.dataSeriesIndexes[z];
              D = this.data[H];
              v3 = D.dataPoints;
              y = true;
              k = [];
              q = D.id;
              this._eventManager.objectMap[q] = { objectType: "dataSeries", dataSeriesIndex: H };
              q = X(q);
              n2.fillStyle = q;
              if (0 < m.length) {
                var e = D._colorSet[0], A2 = D.lineColor = D.options.lineColor || e, L = A2;
                b.fillStyle = e;
                b.strokeStyle = A2;
                b.lineWidth = D.lineThickness;
                x = "solid";
                if (b.setLineDash) {
                  var S = J(D.nullDataLineDashType, D.lineThickness);
                  x = D.lineDashType;
                  var B3 = J(x, D.lineThickness);
                  b.setLineDash(B3);
                }
                for (var $ = true, q = 0; q < m.length; q++) {
                  var f = m[q], ga = null, ga = 0 <= D.dataPointIndexes[f] ? v3[D.dataPointIndexes[f]] : { x: f, y: null };
                  if (!(f < a.axisX.dataInfo.viewPortMin || f > a.axisX.dataInfo.viewPortMax && (!D.connectNullData || !$)))
                    if ("number" !== typeof ga.y)
                      D.connectNullData || ($ || y) || d(), $ = true;
                    else {
                      g = a.axisX.convertValueToPixel(f);
                      var na = h2[f] ? h2[f] : 0;
                      if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length) {
                        p[f] = ga.y + (p[f] ? p[f] : 0);
                        if (0 >= p[f] && a.axisY.logarithmic)
                          continue;
                        r = a.axisY.convertValueToPixel(p[f]);
                      } else
                        r = a.axisY.convertValueToPixel(ga.y), r -= na;
                      k.push({ x: g, y: s2 - na });
                      h2[f] = s2 - r;
                      y || $ ? (!y && D.connectNullData ? (b.setLineDash && (D.options.nullDataLineDashType || x === D.lineDashType && D.lineDashType !== D.nullDataLineDashType) && (y = k.pop(), x = k[k.length - 1], d(), b.moveTo(u.x, u.y), k.push(x), k.push(y), x = D.nullDataLineDashType, b.setLineDash(S)), b.lineTo(g, r), w && n2.lineTo(g, r)) : (b.beginPath(), b.moveTo(g, r), w && (n2.beginPath(), n2.moveTo(g, r))), $ = y = false) : (b.lineTo(g, r), w && n2.lineTo(g, r), 0 == q % 250 && (d(), b.moveTo(g, r), w && n2.moveTo(g, r), k.push({ x: g, y: s2 - na })));
                      u = { x: g, y: r };
                      q < v3.length - 1 && (L !== (v3[q].lineColor || A2) || x !== (v3[q].lineDashType || D.lineDashType)) && (d(), b.beginPath(), b.moveTo(g, r), k.push({ x: g, y: s2 - na }), L = v3[q].lineColor || A2, b.strokeStyle = L, b.setLineDash && (v3[q].lineDashType ? (x = v3[q].lineDashType, b.setLineDash(J(x, D.lineThickness))) : (x = D.lineDashType, b.setLineDash(B3))));
                      if (0 <= D.dataPointIndexes[f]) {
                        var ka = D.dataPointIds[D.dataPointIndexes[f]];
                        this._eventManager.objectMap[ka] = { id: ka, objectType: "dataPoint", dataSeriesIndex: H, dataPointIndex: D.dataPointIndexes[f], x1: g, y1: r };
                      }
                      0 <= D.dataPointIndexes[f] && 0 !== ga.markerSize && (0 < ga.markerSize || 0 < D.markerSize) && (na = D.getMarkerProperties(D.dataPointIndexes[f], g, r, b), l.push(na), f = X(ka), w && l.push({ x: g, y: r, ctx: n2, type: na.type, size: na.size, color: f, borderColor: f, borderThickness: na.borderThickness }));
                      (ga.indexLabel || D.indexLabel || ga.indexLabelFormatter || D.indexLabelFormatter) && this._indexLabels.push({ chartType: "stackedArea", dataPoint: ga, dataSeries: D, point: { x: g, y: r }, direction: 0 > v3[q].y === a.axisY.reversed ? 1 : -1, color: e });
                    }
                }
                d();
                b.moveTo(g, r);
                w && n2.moveTo(g, r);
              }
              delete D.dataPointIndexes;
            }
            W.drawMarkers(l);
            w && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(t.x1, t.y1, t.width, t.height), n2.restore());
            b.restore();
            return { source: c, dest: this.plotArea.ctx, animationCallback: M.xClipAnimation, easingFunction: M.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderStackedArea100 = function(a) {
          function d() {
            for (0 < D.lineThickness && b.stroke(); 0 < k.length; ) {
              var a2 = k.pop();
              b.lineTo(a2.x, a2.y);
              w && x.lineTo(
                a2.x,
                a2.y
              );
            }
            b.closePath();
            b.globalAlpha = D.fillOpacity;
            b.fill();
            b.globalAlpha = 1;
            b.beginPath();
            w && (x.closePath(), x.fill(), x.beginPath());
            k = [];
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = w ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = null, f = null, l = this.plotArea, t = [], h2 = [], k = [], m = [], p = [], q = 0, g, r, s2, n2, u, y = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), x = this._eventManager.ghostCtx;
            b.save();
            w && x.save();
            b.beginPath();
            b.rect(l.x1, l.y1, l.width, l.height);
            b.clip();
            w && (x.beginPath(), x.rect(l.x1, l.y1, l.width, l.height), x.clip());
            for (var e = [], z = 0; z < a.dataSeriesIndexes.length; z++) {
              var H = a.dataSeriesIndexes[z], D = this.data[H], v3 = D.dataPoints;
              D.dataPointIndexes = [];
              for (q = 0; q < v3.length; q++)
                H = v3[q].x.getTime ? v3[q].x.getTime() : v3[q].x, D.dataPointIndexes[H] = q, e[H] || (m.push(H), e[H] = true);
              m.sort(Ra);
            }
            for (z = 0; z < a.dataSeriesIndexes.length; z++) {
              H = a.dataSeriesIndexes[z];
              D = this.data[H];
              v3 = D.dataPoints;
              n2 = true;
              e = D.id;
              this._eventManager.objectMap[e] = { objectType: "dataSeries", dataSeriesIndex: H };
              e = X(e);
              x.fillStyle = e;
              k = [];
              if (0 < m.length) {
                var e = D._colorSet[q % D._colorSet.length], A2 = D.lineColor = D.options.lineColor || e, L = A2;
                b.fillStyle = e;
                b.strokeStyle = A2;
                b.lineWidth = D.lineThickness;
                u = "solid";
                if (b.setLineDash) {
                  var S = J(D.nullDataLineDashType, D.lineThickness);
                  u = D.lineDashType;
                  var B3 = J(u, D.lineThickness);
                  b.setLineDash(B3);
                }
                for (var $ = true, q = 0; q < m.length; q++) {
                  var f = m[q], ga = null, ga = 0 <= D.dataPointIndexes[f] ? v3[D.dataPointIndexes[f]] : { x: f, y: null };
                  if (!(f < a.axisX.dataInfo.viewPortMin || f > a.axisX.dataInfo.viewPortMax && (!D.connectNullData || !$)))
                    if ("number" !== typeof ga.y)
                      D.connectNullData || ($ || n2) || d(), $ = true;
                    else {
                      var na;
                      na = 0 !== a.dataPointYSums[f] ? 100 * (ga.y / a.dataPointYSums[f]) : 0;
                      g = a.axisX.convertValueToPixel(f);
                      var ka = h2[f] ? h2[f] : 0;
                      if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length) {
                        p[f] = na + (p[f] ? p[f] : 0);
                        if (0 >= p[f] && a.axisY.logarithmic)
                          continue;
                        r = a.axisY.convertValueToPixel(p[f]);
                      } else
                        r = a.axisY.convertValueToPixel(na), r -= ka;
                      k.push({ x: g, y: y - ka });
                      h2[f] = y - r;
                      n2 || $ ? (!n2 && D.connectNullData ? (b.setLineDash && (D.options.nullDataLineDashType || u === D.lineDashType && D.lineDashType !== D.nullDataLineDashType) && (n2 = k.pop(), u = k[k.length - 1], d(), b.moveTo(s2.x, s2.y), k.push(u), k.push(n2), u = D.nullDataLineDashType, b.setLineDash(S)), b.lineTo(g, r), w && x.lineTo(g, r)) : (b.beginPath(), b.moveTo(g, r), w && (x.beginPath(), x.moveTo(g, r))), $ = n2 = false) : (b.lineTo(g, r), w && x.lineTo(g, r), 0 == q % 250 && (d(), b.moveTo(g, r), w && x.moveTo(g, r), k.push({ x: g, y: y - ka })));
                      s2 = { x: g, y: r };
                      q < v3.length - 1 && (L !== (v3[q].lineColor || A2) || u !== (v3[q].lineDashType || D.lineDashType)) && (d(), b.beginPath(), b.moveTo(
                        g,
                        r
                      ), k.push({ x: g, y: y - ka }), L = v3[q].lineColor || A2, b.strokeStyle = L, b.setLineDash && (v3[q].lineDashType ? (u = v3[q].lineDashType, b.setLineDash(J(u, D.lineThickness))) : (u = D.lineDashType, b.setLineDash(B3))));
                      if (0 <= D.dataPointIndexes[f]) {
                        var F = D.dataPointIds[D.dataPointIndexes[f]];
                        this._eventManager.objectMap[F] = { id: F, objectType: "dataPoint", dataSeriesIndex: H, dataPointIndex: D.dataPointIndexes[f], x1: g, y1: r };
                      }
                      0 <= D.dataPointIndexes[f] && 0 !== ga.markerSize && (0 < ga.markerSize || 0 < D.markerSize) && (ka = D.getMarkerProperties(
                        q,
                        g,
                        r,
                        b
                      ), t.push(ka), f = X(F), w && t.push({ x: g, y: r, ctx: x, type: ka.type, size: ka.size, color: f, borderColor: f, borderThickness: ka.borderThickness }));
                      (ga.indexLabel || D.indexLabel || ga.indexLabelFormatter || D.indexLabelFormatter) && this._indexLabels.push({ chartType: "stackedArea100", dataPoint: ga, dataSeries: D, point: { x: g, y: r }, direction: 0 > v3[q].y === a.axisY.reversed ? 1 : -1, color: e });
                    }
                }
                d();
                b.moveTo(g, r);
                w && x.moveTo(g, r);
              }
              delete D.dataPointIndexes;
            }
            W.drawMarkers(t);
            w && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(l.x1, l.y1, l.width, l.height), x.restore());
            b.restore();
            return { source: c, dest: this.plotArea.ctx, animationCallback: M.xClipAnimation, easingFunction: M.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderBubble = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = this.plotArea, e = 0, f, l;
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(b.x1, b.y1, b.width, b.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(b.x1, b.y1, b.width, b.height), this._eventManager.ghostCtx.clip());
            for (var t = -Infinity, h2 = Infinity, k = 0; k < a.dataSeriesIndexes.length; k++)
              for (var m = a.dataSeriesIndexes[k], p = this.data[m], q = p.dataPoints, g = 0, e = 0; e < q.length; e++)
                f = q[e].getTime ? f = q[e].x.getTime() : f = q[e].x, f < a.axisX.dataInfo.viewPortMin || f > a.axisX.dataInfo.viewPortMax || "undefined" === typeof q[e].z || (g = q[e].z, g > t && (t = g), g < h2 && (h2 = g));
            for (var r = 25 * Math.PI, s2 = Math.max(Math.pow(0.25 * Math.min(b.height, b.width) / 2, 2) * Math.PI, r), k = 0; k < a.dataSeriesIndexes.length; k++)
              if (m = a.dataSeriesIndexes[k], p = this.data[m], q = p.dataPoints, 0 < q.length) {
                for (c.strokeStyle = "#4572A7 ", e = 0; e < q.length; e++)
                  if (f = q[e].getTime ? f = q[e].x.getTime() : f = q[e].x, !(f < a.axisX.dataInfo.viewPortMin || f > a.axisX.dataInfo.viewPortMax) && "number" === typeof q[e].y) {
                    f = a.axisX.convertValueToPixel(f);
                    l = a.axisY.convertValueToPixel(q[e].y);
                    var g = q[e].z, n2 = 2 * Math.max(Math.sqrt((t === h2 ? s2 / 2 : r + (s2 - r) / (t - h2) * (g - h2)) / Math.PI) << 0, 1), g = p.getMarkerProperties(e, c);
                    g.size = n2;
                    c.globalAlpha = p.fillOpacity;
                    W.drawMarker(f, l, c, g.type, g.size, g.color, g.borderColor, g.borderThickness);
                    c.globalAlpha = 1;
                    var u = p.dataPointIds[e];
                    this._eventManager.objectMap[u] = { id: u, objectType: "dataPoint", dataSeriesIndex: m, dataPointIndex: e, x1: f, y1: l, size: n2 };
                    n2 = X(u);
                    w && W.drawMarker(f, l, this._eventManager.ghostCtx, g.type, g.size, n2, n2, g.borderThickness);
                    (q[e].indexLabel || p.indexLabel || q[e].indexLabelFormatter || p.indexLabelFormatter) && this._indexLabels.push({ chartType: "bubble", dataPoint: q[e], dataSeries: p, point: { x: f, y: l }, direction: 1, bounds: { x1: f - g.size / 2, y1: l - g.size / 2, x2: f + g.size / 2, y2: l + g.size / 2 }, color: null });
                  }
              }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(
              a.axisX.maskCanvas,
              0,
              0,
              this.width,
              this.height
            ), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(b.x1, b.y1, b.width, b.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.fadeInAnimation, easingFunction: M.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderScatter = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = this.plotArea, e = 0, f, l;
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(b.x1, b.y1, b.width, b.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(b.x1, b.y1, b.width, b.height), this._eventManager.ghostCtx.clip());
            for (var t = 0; t < a.dataSeriesIndexes.length; t++) {
              var h2 = a.dataSeriesIndexes[t], k = this.data[h2], m = k.dataPoints;
              if (0 < m.length) {
                c.strokeStyle = "#4572A7 ";
                Math.pow(0.3 * Math.min(
                  b.height,
                  b.width
                ) / 2, 2);
                for (var p = 0, q = 0, e = 0; e < m.length; e++)
                  if (f = m[e].getTime ? f = m[e].x.getTime() : f = m[e].x, !(f < a.axisX.dataInfo.viewPortMin || f > a.axisX.dataInfo.viewPortMax) && "number" === typeof m[e].y) {
                    f = a.axisX.convertValueToPixel(f);
                    l = a.axisY.convertValueToPixel(m[e].y);
                    var g = k.getMarkerProperties(e, f, l, c);
                    c.globalAlpha = k.fillOpacity;
                    W.drawMarker(g.x, g.y, g.ctx, g.type, g.size, g.color, g.borderColor, g.borderThickness);
                    c.globalAlpha = 1;
                    Math.sqrt((p - f) * (p - f) + (q - l) * (q - l)) < Math.min(g.size, 5) && m.length > Math.min(
                      this.plotArea.width,
                      this.plotArea.height
                    ) || (p = k.dataPointIds[e], this._eventManager.objectMap[p] = { id: p, objectType: "dataPoint", dataSeriesIndex: h2, dataPointIndex: e, x1: f, y1: l }, p = X(p), w && W.drawMarker(g.x, g.y, this._eventManager.ghostCtx, g.type, g.size, p, p, g.borderThickness), (m[e].indexLabel || k.indexLabel || m[e].indexLabelFormatter || k.indexLabelFormatter) && this._indexLabels.push({ chartType: "scatter", dataPoint: m[e], dataSeries: k, point: { x: f, y: l }, direction: 1, bounds: { x1: f - g.size / 2, y1: l - g.size / 2, x2: f + g.size / 2, y2: l + g.size / 2 }, color: null }), p = f, q = l);
                  }
              }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(b.x1, b.y1, b.width, b.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return {
              source: d,
              dest: this.plotArea.ctx,
              animationCallback: M.fadeInAnimation,
              easingFunction: M.easing.easeInQuad,
              animationBase: 0
            };
          }
        };
        n.prototype.renderCandlestick = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d, b = this._eventManager.ghostCtx;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = null, f = null, l = this.plotArea, t = 0, h2, k, m, p, q, g, e = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, f = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.015 * this.width, r = a.axisX.dataInfo.minDiff;
            isFinite(r) || (r = 0.3 * Math.abs(a.axisX.range));
            r = this.options.dataPointWidth ? this.dataPointWidth : 0.7 * l.width * (a.axisX.logarithmic ? Math.log(r) / Math.log(a.axisX.range) : Math.abs(r) / Math.abs(a.axisX.range)) << 0;
            this.dataPointMaxWidth && e > f && (e = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, f));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && f < e) && (f = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, e));
            r < e && (r = e);
            r > f && (r = f);
            c.save();
            w && b.save();
            c.beginPath();
            c.rect(l.x1, l.y1, l.width, l.height);
            c.clip();
            w && (b.beginPath(), b.rect(l.x1, l.y1, l.width, l.height), b.clip());
            for (var n2 = 0; n2 < a.dataSeriesIndexes.length; n2++) {
              var ba = a.dataSeriesIndexes[n2], u = this.data[ba], y = u.dataPoints;
              if (0 < y.length) {
                for (var x = 5 < r && u.bevelEnabled ? true : false, t = 0; t < y.length; t++)
                  if (y[t].getTime ? g = y[t].x.getTime() : g = y[t].x, !(g < a.axisX.dataInfo.viewPortMin || g > a.axisX.dataInfo.viewPortMax) && !s(y[t].y) && y[t].y.length && "number" === typeof y[t].y[0] && "number" === typeof y[t].y[1] && "number" === typeof y[t].y[2] && "number" === typeof y[t].y[3]) {
                    h2 = a.axisX.convertValueToPixel(g);
                    k = a.axisY.convertValueToPixel(y[t].y[0]);
                    m = a.axisY.convertValueToPixel(y[t].y[1]);
                    p = a.axisY.convertValueToPixel(y[t].y[2]);
                    q = a.axisY.convertValueToPixel(y[t].y[3]);
                    var z = h2 - r / 2 << 0, H = z + r << 0, f = u.options.fallingColor ? u.fallingColor : u._colorSet[0], e = y[t].color ? y[t].color : u._colorSet[0], D = Math.round(Math.max(1, 0.15 * r)), v3 = 0 === D % 2 ? 0 : 0.5, A2 = u.dataPointIds[t];
                    this._eventManager.objectMap[A2] = { id: A2, objectType: "dataPoint", dataSeriesIndex: ba, dataPointIndex: t, x1: z, y1: k, x2: H, y2: m, x3: h2, y3: p, x4: h2, y4: q, borderThickness: D, color: e };
                    c.strokeStyle = e;
                    c.beginPath();
                    c.lineWidth = D;
                    b.lineWidth = Math.max(D, 4);
                    "candlestick" === u.type ? (c.moveTo(h2 - v3, m), c.lineTo(h2 - v3, Math.min(k, q)), c.stroke(), c.moveTo(h2 - v3, Math.max(k, q)), c.lineTo(h2 - v3, p), c.stroke(), Y(c, z, Math.min(k, q), H, Math.max(k, q), y[t].y[0] <= y[t].y[3] ? u.risingColor : f, D, e, x, x, false, false, u.fillOpacity), w && (e = X(A2), b.strokeStyle = e, b.moveTo(h2 - v3, m), b.lineTo(h2 - v3, Math.min(
                      k,
                      q
                    )), b.stroke(), b.moveTo(h2 - v3, Math.max(k, q)), b.lineTo(h2 - v3, p), b.stroke(), Y(b, z, Math.min(k, q), H, Math.max(k, q), e, 0, null, false, false, false, false))) : "ohlc" === u.type && (c.moveTo(h2 - v3, m), c.lineTo(h2 - v3, p), c.stroke(), c.beginPath(), c.moveTo(h2, k), c.lineTo(z, k), c.stroke(), c.beginPath(), c.moveTo(h2, q), c.lineTo(H, q), c.stroke(), w && (e = X(A2), b.strokeStyle = e, b.moveTo(h2 - v3, m), b.lineTo(h2 - v3, p), b.stroke(), b.beginPath(), b.moveTo(h2, k), b.lineTo(z, k), b.stroke(), b.beginPath(), b.moveTo(h2, q), b.lineTo(H, q), b.stroke()));
                    (y[t].indexLabel || u.indexLabel || y[t].indexLabelFormatter || u.indexLabelFormatter) && this._indexLabels.push({ chartType: u.type, dataPoint: y[t], dataSeries: u, point: { x: z + (H - z) / 2, y: a.axisY.reversed ? p : m }, direction: 1, bounds: { x1: z, y1: Math.min(m, p), x2: H, y2: Math.max(m, p) }, color: e });
                  }
              }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(l.x1, l.y1, l.width, l.height), b.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.fadeInAnimation, easingFunction: M.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderBoxAndWhisker = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d, b = this._eventManager.ghostCtx;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = null, f = this.plotArea, l = 0, t, h2, k, m, p, q, g, e = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, l = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.015 * this.width, r = a.axisX.dataInfo.minDiff;
            isFinite(r) || (r = 0.3 * Math.abs(a.axisX.range));
            r = this.options.dataPointWidth ? this.dataPointWidth : 0.7 * f.width * (a.axisX.logarithmic ? Math.log(r) / Math.log(a.axisX.range) : Math.abs(r) / Math.abs(a.axisX.range)) << 0;
            this.dataPointMaxWidth && e > l && (e = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, l));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && l < e) && (l = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, e));
            r < e && (r = e);
            r > l && (r = l);
            c.save();
            w && b.save();
            c.beginPath();
            c.rect(f.x1, f.y1, f.width, f.height);
            c.clip();
            w && (b.beginPath(), b.rect(f.x1, f.y1, f.width, f.height), b.clip());
            for (var n2 = false, n2 = !!a.axisY.reversed, ba = 0; ba < a.dataSeriesIndexes.length; ba++) {
              var u = a.dataSeriesIndexes[ba], y = this.data[u], x = y.dataPoints;
              if (0 < x.length) {
                for (var z = 5 < r && y.bevelEnabled ? true : false, l = 0; l < x.length; l++)
                  if (x[l].getTime ? g = x[l].x.getTime() : g = x[l].x, !(g < a.axisX.dataInfo.viewPortMin || g > a.axisX.dataInfo.viewPortMax) && !s(x[l].y) && x[l].y.length && "number" === typeof x[l].y[0] && "number" === typeof x[l].y[1] && "number" === typeof x[l].y[2] && "number" === typeof x[l].y[3] && "number" === typeof x[l].y[4] && 5 === x[l].y.length) {
                    t = a.axisX.convertValueToPixel(g);
                    h2 = a.axisY.convertValueToPixel(x[l].y[0]);
                    k = a.axisY.convertValueToPixel(x[l].y[1]);
                    m = a.axisY.convertValueToPixel(x[l].y[2]);
                    p = a.axisY.convertValueToPixel(x[l].y[3]);
                    q = a.axisY.convertValueToPixel(x[l].y[4]);
                    var v3 = t - r / 2 << 0, D = t + r / 2 << 0, e = x[l].color ? x[l].color : y._colorSet[0], A2 = Math.round(Math.max(1, 0.15 * r)), B3 = 0 === A2 % 2 ? 0 : 0.5, L = x[l].whiskerColor ? x[l].whiskerColor : x[l].color ? y.whiskerColor ? y.whiskerColor : x[l].color : y.whiskerColor ? y.whiskerColor : e, S = "number" === typeof x[l].whiskerThickness ? x[l].whiskerThickness : "number" === typeof y.options.whiskerThickness ? y.whiskerThickness : A2, ea = x[l].whiskerDashType ? x[l].whiskerDashType : y.whiskerDashType, $ = s(x[l].whiskerLength) ? s(y.options.whiskerLength) ? r : y.whiskerLength : x[l].whiskerLength, $ = "number" === typeof $ ? 0 >= $ ? 0 : $ >= r ? r : $ : "string" === typeof $ ? parseInt($) * r / 100 > r ? r : parseInt($) * r / 100 : r, ga = 1 === Math.round(S) % 2 ? 0.5 : 0, na = x[l].stemColor ? x[l].stemColor : x[l].color ? y.stemColor ? y.stemColor : x[l].color : y.stemColor ? y.stemColor : e, ka = "number" === typeof x[l].stemThickness ? x[l].stemThickness : "number" === typeof y.options.stemThickness ? y.stemThickness : A2, F = 1 === Math.round(ka) % 2 ? 0.5 : 0, E = x[l].stemDashType ? x[l].stemDashType : y.stemDashType, K3 = x[l].lineColor ? x[l].lineColor : x[l].color ? y.lineColor ? y.lineColor : x[l].color : y.lineColor ? y.lineColor : e, G2 = "number" === typeof x[l].lineThickness ? x[l].lineThickness : "number" === typeof y.options.lineThickness ? y.lineThickness : A2, N2 = x[l].lineDashType ? x[l].lineDashType : y.lineDashType, O = 1 === Math.round(G2) % 2 ? 0.5 : 0, P2 = y.upperBoxColor, Q3 = y.lowerBoxColor, ta = s(y.options.fillOpacity) ? 1 : y.fillOpacity, R = y.dataPointIds[l];
                    this._eventManager.objectMap[R] = {
                      id: R,
                      objectType: "dataPoint",
                      dataSeriesIndex: u,
                      dataPointIndex: l,
                      x1: v3,
                      y1: h2,
                      x2: D,
                      y2: k,
                      x3: t,
                      y3: m,
                      x4: t,
                      y4: p,
                      y5: q,
                      borderThickness: A2,
                      color: e,
                      stemThickness: ka,
                      stemColor: na,
                      whiskerThickness: S,
                      whiskerLength: $,
                      whiskerColor: L,
                      lineThickness: G2,
                      lineColor: K3
                    };
                    c.save();
                    0 < ka && (c.beginPath(), c.strokeStyle = na, c.lineWidth = ka, c.setLineDash && c.setLineDash(J(E, ka)), c.moveTo(t - F, k), c.lineTo(t - F, h2), c.stroke(), c.moveTo(t - F, p), c.lineTo(t - F, m), c.stroke());
                    c.restore();
                    b.lineWidth = Math.max(A2, 4);
                    c.beginPath();
                    Y(c, v3, Math.min(q, k), D, Math.max(k, q), Q3, 0, e, n2 ? z : false, n2 ? false : z, false, false, ta);
                    c.beginPath();
                    Y(
                      c,
                      v3,
                      Math.min(m, q),
                      D,
                      Math.max(q, m),
                      P2,
                      0,
                      e,
                      n2 ? false : z,
                      n2 ? z : false,
                      false,
                      false,
                      ta
                    );
                    c.beginPath();
                    c.lineWidth = A2;
                    c.strokeStyle = e;
                    c.rect(v3 - B3, Math.min(k, m) - B3, D - v3 + 2 * B3, Math.max(k, m) - Math.min(k, m) + 2 * B3);
                    c.stroke();
                    c.save();
                    0 < G2 && (c.beginPath(), c.globalAlpha = 1, c.setLineDash && c.setLineDash(J(N2, G2)), c.strokeStyle = K3, c.lineWidth = G2, c.moveTo(v3, q - O), c.lineTo(D, q - O), c.stroke());
                    c.restore();
                    c.save();
                    0 < S && (c.beginPath(), c.setLineDash && c.setLineDash(J(ea, S)), c.strokeStyle = L, c.lineWidth = S, c.moveTo(t - $ / 2 << 0, p - ga), c.lineTo(t + $ / 2 << 0, p - ga), c.stroke(), c.moveTo(t - $ / 2 << 0, h2 + ga), c.lineTo(t + $ / 2 << 0, h2 + ga), c.stroke());
                    c.restore();
                    w && (e = X(R), b.strokeStyle = e, b.lineWidth = ka, 0 < ka && (b.moveTo(t - B3 - F, k), b.lineTo(t - B3 - F, Math.max(h2, p)), b.stroke(), b.moveTo(t - B3 - F, Math.min(h2, p)), b.lineTo(t - B3 - F, m), b.stroke()), Y(b, v3, Math.max(k, m), D, Math.min(k, m), e, 0, null, false, false, false, false), 0 < S && (b.beginPath(), b.lineWidth = S, b.moveTo(t + $ / 2, p - ga), b.lineTo(t - $ / 2, p - ga), b.stroke(), b.moveTo(t + $ / 2, h2 + ga), b.lineTo(t - $ / 2, h2 + ga), b.stroke()));
                    (x[l].indexLabel || y.indexLabel || x[l].indexLabelFormatter || y.indexLabelFormatter) && this._indexLabels.push({ chartType: y.type, dataPoint: x[l], dataSeries: y, point: { x: v3 + (D - v3) / 2, y: a.axisY.reversed ? h2 : p }, direction: 1, bounds: { x1: v3, y1: Math.min(h2, p), x2: D, y2: Math.max(h2, p) }, color: e });
                  }
              }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(
              this._preRenderCanvas,
              0,
              0,
              this.width,
              this.height
            ), c.clearRect(f.x1, f.y1, f.width, f.height), b.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.fadeInAnimation, easingFunction: M.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderRangeColumn = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, f = 0, l, t, h2, f = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1;
            l = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.03 * this.width;
            var k = a.axisX.dataInfo.minDiff;
            isFinite(k) || (k = 0.3 * Math.abs(a.axisX.range));
            k = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.width * (a.axisX.logarithmic ? Math.log(k) / Math.log(a.axisX.range) : Math.abs(k) / Math.abs(a.axisX.range)) / a.plotType.totalDataSeries) << 0;
            this.dataPointMaxWidth && f > l && (f = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, l));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && l < f) && (l = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, f));
            k < f && (k = f);
            k > l && (k = l);
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (var m = 0; m < a.dataSeriesIndexes.length; m++) {
              var p = a.dataSeriesIndexes[m], q = this.data[p], g = q.dataPoints;
              if (0 < g.length) {
                for (var r = 5 < k && q.bevelEnabled ? true : false, f = 0; f < g.length; f++)
                  if (g[f].getTime ? h2 = g[f].x.getTime() : h2 = g[f].x, !(h2 < a.axisX.dataInfo.viewPortMin || h2 > a.axisX.dataInfo.viewPortMax) && !s(g[f].y) && g[f].y.length && "number" === typeof g[f].y[0] && "number" === typeof g[f].y[1]) {
                    b = a.axisX.convertValueToPixel(h2);
                    l = a.axisY.convertValueToPixel(g[f].y[0]);
                    t = a.axisY.convertValueToPixel(g[f].y[1]);
                    var n2 = a.axisX.reversed ? b + a.plotType.totalDataSeries * k / 2 - (a.previousDataSeriesCount + m) * k << 0 : b - a.plotType.totalDataSeries * k / 2 + (a.previousDataSeriesCount + m) * k << 0, ba = a.axisX.reversed ? n2 - k << 0 : n2 + k << 0, b = g[f].color ? g[f].color : q._colorSet[f % q._colorSet.length];
                    if (l > t) {
                      var u = l;
                      l = t;
                      t = u;
                    }
                    u = q.dataPointIds[f];
                    this._eventManager.objectMap[u] = { id: u, objectType: "dataPoint", dataSeriesIndex: p, dataPointIndex: f, x1: n2, y1: l, x2: ba, y2: t };
                    Y(c, a.axisX.reversed ? ba : n2, l, a.axisX.reversed ? n2 : ba, t, b, 0, b, r, r, false, false, q.fillOpacity);
                    b = X(u);
                    w && Y(this._eventManager.ghostCtx, a.axisX.reversed ? ba : n2, l, a.axisX.reversed ? n2 : ba, t, b, 0, null, false, false, false, false);
                    if (g[f].indexLabel || q.indexLabel || g[f].indexLabelFormatter || q.indexLabelFormatter)
                      this._indexLabels.push({ chartType: "rangeColumn", dataPoint: g[f], dataSeries: q, indexKeyword: 0, point: { x: n2 + (ba - n2) / 2, y: g[f].y[1] >= g[f].y[0] ? t : l }, direction: g[f].y[1] >= g[f].y[0] ? -1 : 1, bounds: { x1: n2, y1: Math.min(l, t), x2: ba, y2: Math.max(l, t) }, color: b }), this._indexLabels.push({ chartType: "rangeColumn", dataPoint: g[f], dataSeries: q, indexKeyword: 1, point: { x: n2 + (ba - n2) / 2, y: g[f].y[1] >= g[f].y[0] ? l : t }, direction: g[f].y[1] >= g[f].y[0] ? 1 : -1, bounds: { x1: n2, y1: Math.min(l, t), x2: ba, y2: Math.max(l, t) }, color: b });
                  }
              }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return {
              source: d,
              dest: this.plotArea.ctx,
              animationCallback: M.fadeInAnimation,
              easingFunction: M.easing.easeInQuad,
              animationBase: 0
            };
          }
        };
        n.prototype.renderError = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d, b = a.axisY._position ? "left" === a.axisY._position || "right" === a.axisY._position ? false : true : false;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = null, f = false, l = this.plotArea, t = 0, h2, k, m, p, q, g, r, n2 = a.axisX.dataInfo.minDiff;
            isFinite(n2) || (n2 = 0.3 * Math.abs(a.axisX.range));
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(l.x1, l.y1, l.width, l.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(l.x1, l.y1, l.width, l.height), this._eventManager.ghostCtx.clip());
            for (var ba = 0, u = 0; u < this.data.length; u++)
              !this.data[u].type.match(/(bar|column)/ig) || !this.data[u].visible || this.data[u].type.match(/(stacked)/ig) && ba || ba++;
            for (var y = 0; y < a.dataSeriesIndexes.length; y++) {
              var x = a.dataSeriesIndexes[y], z = this.data[x], v3 = z.dataPoints, D = s(z._linkedSeries) ? false : z._linkedSeries.type.match(/(bar|column)/ig) && z._linkedSeries.visible ? true : false, A2 = 0;
              if (D)
                for (e = z._linkedSeries.id, u = 0; u < e; u++)
                  !this.data[u].type.match(/(bar|column)/ig) || !this.data[u].visible || this.data[u].type.match(/(stacked)/ig) && A2 || (this.data[u].type.match(/(range)/ig) && (f = true), A2++);
              e = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1;
              t = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : b ? Math.min(0.15 * this.height, 0.9 * (this.plotArea.height / (D ? ba : 1))) << 0 : 0.3 * this.width;
              f && (t = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : b ? Math.min(0.15 * this.height, 0.9 * (this.plotArea.height / (D ? ba : 1))) << 0 : 0.03 * this.width);
              u = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * ((b ? l.height : l.width) * (a.axisX.logarithmic ? Math.log(n2) / Math.log(a.axisX.range) : Math.abs(n2) / Math.abs(a.axisX.range)) / (D ? ba : 1)) << 0;
              this.dataPointMaxWidth && e > t && (e = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, t));
              !this.dataPointMaxWidth && (this.dataPointMinWidth && t < e) && (t = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, e));
              u < e && (u = e);
              u > t && (u = t);
              if (0 < v3.length)
                for (var E = z._colorSet, t = 0; t < v3.length; t++) {
                  var e = z.lineColor = z.options.color ? z.options.color : E[0], L = { color: v3[t].whiskerColor ? v3[t].whiskerColor : v3[t].color ? z.whiskerColor ? z.whiskerColor : v3[t].color : z.whiskerColor ? z.whiskerColor : e, thickness: s(v3[t].whiskerThickness) ? z.whiskerThickness : v3[t].whiskerThickness, dashType: v3[t].whiskerDashType ? v3[t].whiskerDashType : z.whiskerDashType, length: s(v3[t].whiskerLength) ? s(z.options.whiskerLength) ? u : z.options.whiskerLength : v3[t].whiskerLength, trimLength: s(v3[t].whiskerLength) ? s(z.options.whiskerLength) ? 50 : 0 : 0 };
                  L.length = "number" === typeof L.length ? 0 >= L.length ? 0 : L.length >= u ? u : L.length : "string" === typeof L.length ? parseInt(L.length) * u / 100 > u ? u : parseInt(L.length) * u / 100 > u : u;
                  L.thickness = "number" === typeof L.thickness ? 0 > L.thickness ? 0 : Math.round(L.thickness) : 2;
                  var S = { color: v3[t].stemColor ? v3[t].stemColor : v3[t].color ? z.stemColor ? z.stemColor : v3[t].color : z.stemColor ? z.stemColor : e, thickness: v3[t].stemThickness ? v3[t].stemThickness : z.stemThickness, dashType: v3[t].stemDashType ? v3[t].stemDashType : z.stemDashType };
                  S.thickness = "number" === typeof S.thickness ? 0 > S.thickness ? 0 : Math.round(S.thickness) : 2;
                  v3[t].getTime ? r = v3[t].x.getTime() : r = v3[t].x;
                  if (!(r < a.axisX.dataInfo.viewPortMin || r > a.axisX.dataInfo.viewPortMax) && !s(v3[t].y) && v3[t].y.length && "number" === typeof v3[t].y[0] && "number" === typeof v3[t].y[1]) {
                    var ea = a.axisX.convertValueToPixel(r);
                    b ? k = ea : h2 = ea;
                    ea = a.axisY.convertValueToPixel(v3[t].y[0]);
                    b ? m = ea : q = ea;
                    ea = a.axisY.convertValueToPixel(v3[t].y[1]);
                    b ? p = ea : g = ea;
                    b ? (q = a.axisX.reversed ? k + (D ? ba : 1) * u / 2 - (D ? A2 - 1 : 0) * u << 0 : k - (D ? ba : 1) * u / 2 + (D ? A2 - 1 : 0) * u << 0, g = a.axisX.reversed ? q - u << 0 : q + u << 0) : (m = a.axisX.reversed ? h2 + (D ? ba : 1) * u / 2 - (D ? A2 - 1 : 0) * u << 0 : h2 - (D ? ba : 1) * u / 2 + (D ? A2 - 1 : 0) * u << 0, p = a.axisX.reversed ? m - u << 0 : m + u << 0);
                    !b && q > g && (ea = q, q = g, g = ea);
                    b && m > p && (ea = m, m = p, p = ea);
                    ea = z.dataPointIds[t];
                    this._eventManager.objectMap[ea] = {
                      id: ea,
                      objectType: "dataPoint",
                      dataSeriesIndex: x,
                      dataPointIndex: t,
                      x1: Math.min(m, p),
                      y1: Math.min(q, g),
                      x2: Math.max(p, m),
                      y2: Math.max(g, q),
                      isXYSwapped: b,
                      stemProperties: S,
                      whiskerProperties: L
                    };
                    B2(c, Math.min(m, p), Math.min(q, g), Math.max(p, m), Math.max(g, q), e, L, S, b);
                    w && B2(this._eventManager.ghostCtx, m, q, p, g, e, L, S, b);
                    if (v3[t].indexLabel || z.indexLabel || v3[t].indexLabelFormatter || z.indexLabelFormatter)
                      this._indexLabels.push({ chartType: "error", dataPoint: v3[t], dataSeries: z, indexKeyword: 0, point: { x: b ? v3[t].y[1] >= v3[t].y[0] ? m : p : m + (p - m) / 2, y: b ? q + (g - q) / 2 : v3[t].y[1] >= v3[t].y[0] ? g : q }, direction: v3[t].y[1] >= v3[t].y[0] ? -1 : 1, bounds: { x1: b ? Math.min(m, p) : m, y1: b ? q : Math.min(q, g), x2: b ? Math.max(m, p) : p, y2: b ? g : Math.max(q, g) }, color: e, axisSwapped: b }), this._indexLabels.push({ chartType: "error", dataPoint: v3[t], dataSeries: z, indexKeyword: 1, point: { x: b ? v3[t].y[1] >= v3[t].y[0] ? p : m : m + (p - m) / 2, y: b ? q + (g - q) / 2 : v3[t].y[1] >= v3[t].y[0] ? q : g }, direction: v3[t].y[1] >= v3[t].y[0] ? 1 : -1, bounds: { x1: b ? Math.min(m, p) : m, y1: b ? q : Math.min(q, g), x2: b ? Math.max(m, p) : p, y2: b ? g : Math.max(q, g) }, color: e, axisSwapped: b });
                  }
                }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(
              a.axisX.maskCanvas,
              0,
              0,
              this.width,
              this.height
            ), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(l.x1, l.y1, l.width, l.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.fadeInAnimation, easingFunction: M.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderRangeBar = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, f = 0, l, t, h2, k, f = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1;
            l = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : Math.min(0.15 * this.height, 0.9 * (this.plotArea.height / a.plotType.totalDataSeries)) << 0;
            var m = a.axisX.dataInfo.minDiff;
            isFinite(m) || (m = 0.3 * Math.abs(a.axisX.range));
            m = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.height * (a.axisX.logarithmic ? Math.log(m) / Math.log(a.axisX.range) : Math.abs(m) / Math.abs(a.axisX.range)) / a.plotType.totalDataSeries) << 0;
            this.dataPointMaxWidth && f > l && (f = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, l));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && l < f) && (l = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, f));
            m < f && (m = f);
            m > l && (m = l);
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (var p = 0; p < a.dataSeriesIndexes.length; p++) {
              var q = a.dataSeriesIndexes[p], g = this.data[q], r = g.dataPoints;
              if (0 < r.length) {
                var n2 = 5 < m && g.bevelEnabled ? true : false;
                c.strokeStyle = "#4572A7 ";
                for (f = 0; f < r.length; f++)
                  if (r[f].getTime ? k = r[f].x.getTime() : k = r[f].x, !(k < a.axisX.dataInfo.viewPortMin || k > a.axisX.dataInfo.viewPortMax) && !s(r[f].y) && r[f].y.length && "number" === typeof r[f].y[0] && "number" === typeof r[f].y[1]) {
                    l = a.axisY.convertValueToPixel(r[f].y[0]);
                    t = a.axisY.convertValueToPixel(r[f].y[1]);
                    h2 = a.axisX.convertValueToPixel(k);
                    h2 = a.axisX.reversed ? h2 + a.plotType.totalDataSeries * m / 2 - (a.previousDataSeriesCount + p) * m << 0 : h2 - a.plotType.totalDataSeries * m / 2 + (a.previousDataSeriesCount + p) * m << 0;
                    var v3 = a.axisX.reversed ? h2 - m << 0 : h2 + m << 0;
                    l > t && (b = l, l = t, t = b);
                    b = r[f].color ? r[f].color : g._colorSet[f % g._colorSet.length];
                    Y(c, l, a.axisX.reversed ? v3 : h2, t, a.axisX.reversed ? h2 : v3, b, 0, null, n2, false, false, false, g.fillOpacity);
                    b = g.dataPointIds[f];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: q, dataPointIndex: f, x1: l, y1: h2, x2: t, y2: v3 };
                    b = X(b);
                    w && Y(this._eventManager.ghostCtx, l, a.axisX.reversed ? v3 : h2, t, a.axisX.reversed ? h2 : v3, b, 0, null, false, false, false, false);
                    if (r[f].indexLabel || g.indexLabel || r[f].indexLabelFormatter || g.indexLabelFormatter)
                      this._indexLabels.push({ chartType: "rangeBar", dataPoint: r[f], dataSeries: g, indexKeyword: 0, point: { x: r[f].y[1] >= r[f].y[0] ? l : t, y: h2 + (v3 - h2) / 2 }, direction: r[f].y[1] >= r[f].y[0] ? -1 : 1, bounds: {
                        x1: Math.min(l, t),
                        y1: h2,
                        x2: Math.max(l, t),
                        y2: v3
                      }, color: b }), this._indexLabels.push({ chartType: "rangeBar", dataPoint: r[f], dataSeries: g, indexKeyword: 1, point: { x: r[f].y[1] >= r[f].y[0] ? t : l, y: h2 + (v3 - h2) / 2 }, direction: r[f].y[1] >= r[f].y[0] ? 1 : -1, bounds: { x1: Math.min(l, t), y1: h2, x2: Math.max(l, t), y2: v3 }, color: b });
                  }
              }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(
              a.axisY.maskCanvas,
              0,
              0,
              this.width,
              this.height
            ), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.fadeInAnimation, easingFunction: M.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderRangeArea = function(a) {
          function d() {
            if (y) {
              for (var a2 = null, c2 = h2.length - 1; 0 <= c2; c2--)
                a2 = h2[c2], b.lineTo(a2.x, a2.y2), e.lineTo(a2.x, a2.y2);
              b.closePath();
              b.globalAlpha = m.fillOpacity;
              b.fill();
              b.globalAlpha = 1;
              e.fill();
              if (0 < m.lineThickness) {
                b.beginPath();
                b.moveTo(a2.x, a2.y2);
                for (c2 = 0; c2 < h2.length; c2++)
                  a2 = h2[c2], b.lineTo(a2.x, a2.y2);
                b.moveTo(h2[0].x, h2[0].y1);
                for (c2 = 0; c2 < h2.length; c2++)
                  a2 = h2[c2], b.lineTo(a2.x, a2.y1);
                b.stroke();
              }
              b.beginPath();
              b.moveTo(r, s2);
              e.beginPath();
              e.moveTo(r, s2);
              y = { x: r, y: s2 };
              h2 = [];
              h2.push({ x: r, y1: s2, y2: n2 });
            }
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = w ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = this._eventManager.ghostCtx, f = [], l = this.plotArea;
            b.save();
            w && e.save();
            b.beginPath();
            b.rect(l.x1, l.y1, l.width, l.height);
            b.clip();
            w && (e.beginPath(), e.rect(l.x1, l.y1, l.width, l.height), e.clip());
            for (var t = 0; t < a.dataSeriesIndexes.length; t++) {
              var h2 = [], k = a.dataSeriesIndexes[t], m = this.data[k], p = m.dataPoints, f = m.id;
              this._eventManager.objectMap[f] = { objectType: "dataSeries", dataSeriesIndex: k };
              f = X(f);
              e.fillStyle = f;
              var f = [], q = true, g = 0, r, s2, n2, u, y = null;
              if (0 < p.length) {
                var x = m._colorSet[g % m._colorSet.length], v3 = m.lineColor = m.options.lineColor || x, A2 = v3;
                b.fillStyle = x;
                b.strokeStyle = v3;
                b.lineWidth = m.lineThickness;
                var D = "solid";
                if (b.setLineDash) {
                  var B3 = J(m.nullDataLineDashType, m.lineThickness), D = m.lineDashType, E = J(D, m.lineThickness);
                  b.setLineDash(E);
                }
                for (var L = true; g < p.length; g++)
                  if (u = p[g].x.getTime ? p[g].x.getTime() : p[g].x, !(u < a.axisX.dataInfo.viewPortMin || u > a.axisX.dataInfo.viewPortMax && (!m.connectNullData || !L)))
                    if (null !== p[g].y && p[g].y.length && "number" === typeof p[g].y[0] && "number" === typeof p[g].y[1]) {
                      r = a.axisX.convertValueToPixel(u);
                      s2 = a.axisY.convertValueToPixel(p[g].y[0]);
                      n2 = a.axisY.convertValueToPixel(p[g].y[1]);
                      q || L ? (m.connectNullData && !q ? (b.setLineDash && (m.options.nullDataLineDashType || D === m.lineDashType && m.lineDashType !== m.nullDataLineDashType) && (h2[h2.length - 1].newLineDashArray = E, D = m.nullDataLineDashType, b.setLineDash(B3)), b.lineTo(r, s2), w && e.lineTo(r, s2), h2.push({ x: r, y1: s2, y2: n2 })) : (b.beginPath(), b.moveTo(r, s2), y = { x: r, y: s2 }, h2 = [], h2.push({ x: r, y1: s2, y2: n2 }), w && (e.beginPath(), e.moveTo(r, s2))), L = q = false) : (b.lineTo(r, s2), h2.push({ x: r, y1: s2, y2: n2 }), w && e.lineTo(r, s2), 0 == g % 250 && d());
                      u = m.dataPointIds[g];
                      this._eventManager.objectMap[u] = { id: u, objectType: "dataPoint", dataSeriesIndex: k, dataPointIndex: g, x1: r, y1: s2, y2: n2 };
                      g < p.length - 1 && (A2 !== (p[g].lineColor || v3) || D !== (p[g].lineDashType || m.lineDashType)) && (d(), A2 = p[g].lineColor || v3, h2[h2.length - 1].newStrokeStyle = A2, b.strokeStyle = A2, b.setLineDash && (p[g].lineDashType ? (D = p[g].lineDashType, h2[h2.length - 1].newLineDashArray = J(D, m.lineThickness), b.setLineDash(h2[h2.length - 1].newLineDashArray)) : (D = m.lineDashType, h2[h2.length - 1].newLineDashArray = E, b.setLineDash(E))));
                      if (0 !== p[g].markerSize && (0 < p[g].markerSize || 0 < m.markerSize)) {
                        var S = m.getMarkerProperties(g, r, n2, b);
                        f.push(S);
                        var ea = X(u);
                        w && f.push({ x: r, y: n2, ctx: e, type: S.type, size: S.size, color: ea, borderColor: ea, borderThickness: S.borderThickness });
                        S = m.getMarkerProperties(g, r, s2, b);
                        f.push(S);
                        ea = X(u);
                        w && f.push({ x: r, y: s2, ctx: e, type: S.type, size: S.size, color: ea, borderColor: ea, borderThickness: S.borderThickness });
                      }
                      if (p[g].indexLabel || m.indexLabel || p[g].indexLabelFormatter || m.indexLabelFormatter)
                        this._indexLabels.push({
                          chartType: "rangeArea",
                          dataPoint: p[g],
                          dataSeries: m,
                          indexKeyword: 0,
                          point: { x: r, y: s2 },
                          direction: p[g].y[0] > p[g].y[1] === a.axisY.reversed ? -1 : 1,
                          color: x
                        }), this._indexLabels.push({ chartType: "rangeArea", dataPoint: p[g], dataSeries: m, indexKeyword: 1, point: { x: r, y: n2 }, direction: p[g].y[0] > p[g].y[1] === a.axisY.reversed ? 1 : -1, color: x });
                    } else
                      L || q || d(), L = true;
                d();
                W.drawMarkers(f);
              }
            }
            w && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(l.x1, l.y1, l.width, l.height), this._eventManager.ghostCtx.restore());
            b.restore();
            return { source: c, dest: this.plotArea.ctx, animationCallback: M.xClipAnimation, easingFunction: M.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderRangeSplineArea = function(a) {
          function d(a2, c2) {
            var d2 = v2(n2, 2);
            if (0 < d2.length) {
              if (0 < k.lineThickness) {
                b.strokeStyle = c2;
                b.setLineDash && b.setLineDash(a2);
                b.beginPath();
                b.moveTo(d2[0].x, d2[0].y);
                for (var f2 = 0; f2 < d2.length - 3; f2 += 3) {
                  if (d2[f2].newStrokeStyle || d2[f2].newLineDashArray)
                    b.stroke(), b.beginPath(), b.moveTo(d2[f2].x, d2[f2].y), d2[f2].newStrokeStyle && (b.strokeStyle = d2[f2].newStrokeStyle), d2[f2].newLineDashArray && b.setLineDash(d2[f2].newLineDashArray);
                  b.bezierCurveTo(d2[f2 + 1].x, d2[f2 + 1].y, d2[f2 + 2].x, d2[f2 + 2].y, d2[f2 + 3].x, d2[f2 + 3].y);
                }
              }
              b.beginPath();
              b.moveTo(d2[0].x, d2[0].y);
              w && (e.beginPath(), e.moveTo(d2[0].x, d2[0].y));
              for (f2 = 0; f2 < d2.length - 3; f2 += 3)
                b.bezierCurveTo(d2[f2 + 1].x, d2[f2 + 1].y, d2[f2 + 2].x, d2[f2 + 2].y, d2[f2 + 3].x, d2[f2 + 3].y), w && e.bezierCurveTo(d2[f2 + 1].x, d2[f2 + 1].y, d2[f2 + 2].x, d2[f2 + 2].y, d2[f2 + 3].x, d2[f2 + 3].y);
              d2 = v2(ba, 2);
              b.lineTo(ba[ba.length - 1].x, ba[ba.length - 1].y);
              for (f2 = d2.length - 1; 2 < f2; f2 -= 3)
                b.bezierCurveTo(d2[f2 - 1].x, d2[f2 - 1].y, d2[f2 - 2].x, d2[f2 - 2].y, d2[f2 - 3].x, d2[f2 - 3].y), w && e.bezierCurveTo(d2[f2 - 1].x, d2[f2 - 1].y, d2[f2 - 2].x, d2[f2 - 2].y, d2[f2 - 3].x, d2[f2 - 3].y);
              b.closePath();
              b.globalAlpha = k.fillOpacity;
              b.fill();
              w && (e.closePath(), e.fill());
              b.globalAlpha = 1;
              if (0 < k.lineThickness) {
                b.strokeStyle = c2;
                b.setLineDash && b.setLineDash(a2);
                b.beginPath();
                b.moveTo(d2[0].x, d2[0].y);
                for (var g2 = f2 = 0; f2 < d2.length - 3; f2 += 3, g2++) {
                  if (n2[g2].newStrokeStyle || n2[g2].newLineDashArray)
                    b.stroke(), b.beginPath(), b.moveTo(d2[f2].x, d2[f2].y), n2[g2].newStrokeStyle && (b.strokeStyle = n2[g2].newStrokeStyle), n2[g2].newLineDashArray && b.setLineDash(n2[g2].newLineDashArray);
                  b.bezierCurveTo(d2[f2 + 1].x, d2[f2 + 1].y, d2[f2 + 2].x, d2[f2 + 2].y, d2[f2 + 3].x, d2[f2 + 3].y);
                }
                d2 = v2(n2, 2);
                b.moveTo(d2[0].x, d2[0].y);
                for (g2 = f2 = 0; f2 < d2.length - 3; f2 += 3, g2++) {
                  if (n2[g2].newStrokeStyle || n2[g2].newLineDashArray)
                    b.stroke(), b.beginPath(), b.moveTo(
                      d2[f2].x,
                      d2[f2].y
                    ), n2[g2].newStrokeStyle && (b.strokeStyle = n2[g2].newStrokeStyle), n2[g2].newLineDashArray && b.setLineDash(n2[g2].newLineDashArray);
                  b.bezierCurveTo(d2[f2 + 1].x, d2[f2 + 1].y, d2[f2 + 2].x, d2[f2 + 2].y, d2[f2 + 3].x, d2[f2 + 3].y);
                }
                b.stroke();
              }
              b.beginPath();
            }
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = w ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = this._eventManager.ghostCtx, f = [], l = this.plotArea;
            b.save();
            w && e.save();
            b.beginPath();
            b.rect(l.x1, l.y1, l.width, l.height);
            b.clip();
            w && (e.beginPath(), e.rect(
              l.x1,
              l.y1,
              l.width,
              l.height
            ), e.clip());
            for (var h2 = 0; h2 < a.dataSeriesIndexes.length; h2++) {
              var s2 = a.dataSeriesIndexes[h2], k = this.data[s2], m = k.dataPoints, f = k.id;
              this._eventManager.objectMap[f] = { objectType: "dataSeries", dataSeriesIndex: s2 };
              f = X(f);
              e.fillStyle = f;
              var f = [], p = 0, q, g, r, n2 = [], ba = [];
              if (0 < m.length) {
                var u = k._colorSet[p % k._colorSet.length], y = k.lineColor = k.options.lineColor || u, x = y;
                b.fillStyle = u;
                b.lineWidth = k.lineThickness;
                var z = "solid", A2;
                if (b.setLineDash) {
                  var D = J(k.nullDataLineDashType, k.lineThickness), z = k.lineDashType;
                  A2 = J(
                    z,
                    k.lineThickness
                  );
                }
                for (g = false; p < m.length; p++)
                  if (q = m[p].x.getTime ? m[p].x.getTime() : m[p].x, !(q < a.axisX.dataInfo.viewPortMin || q > a.axisX.dataInfo.viewPortMax && (!k.connectNullData || !g)))
                    if (null !== m[p].y && m[p].y.length && "number" === typeof m[p].y[0] && "number" === typeof m[p].y[1]) {
                      q = a.axisX.convertValueToPixel(q);
                      g = a.axisY.convertValueToPixel(m[p].y[0]);
                      r = a.axisY.convertValueToPixel(m[p].y[1]);
                      var B3 = k.dataPointIds[p];
                      this._eventManager.objectMap[B3] = {
                        id: B3,
                        objectType: "dataPoint",
                        dataSeriesIndex: s2,
                        dataPointIndex: p,
                        x1: q,
                        y1: g,
                        y2: r
                      };
                      n2[n2.length] = { x: q, y: g };
                      ba[ba.length] = { x: q, y: r };
                      p < m.length - 1 && (x !== (m[p].lineColor || y) || z !== (m[p].lineDashType || k.lineDashType)) && (x = m[p].lineColor || y, n2[n2.length - 1].newStrokeStyle = x, b.setLineDash && (m[p].lineDashType ? (z = m[p].lineDashType, n2[n2.length - 1].newLineDashArray = J(z, k.lineThickness)) : (z = k.lineDashType, n2[n2.length - 1].newLineDashArray = A2)));
                      if (0 !== m[p].markerSize && (0 < m[p].markerSize || 0 < k.markerSize)) {
                        var G2 = k.getMarkerProperties(p, q, g, b);
                        f.push(G2);
                        var L = X(B3);
                        w && f.push({
                          x: q,
                          y: g,
                          ctx: e,
                          type: G2.type,
                          size: G2.size,
                          color: L,
                          borderColor: L,
                          borderThickness: G2.borderThickness
                        });
                        G2 = k.getMarkerProperties(p, q, r, b);
                        f.push(G2);
                        L = X(B3);
                        w && f.push({ x: q, y: r, ctx: e, type: G2.type, size: G2.size, color: L, borderColor: L, borderThickness: G2.borderThickness });
                      }
                      if (m[p].indexLabel || k.indexLabel || m[p].indexLabelFormatter || k.indexLabelFormatter)
                        this._indexLabels.push({ chartType: "rangeSplineArea", dataPoint: m[p], dataSeries: k, indexKeyword: 0, point: { x: q, y: g }, direction: m[p].y[0] <= m[p].y[1] ? -1 : 1, color: u }), this._indexLabels.push({
                          chartType: "rangeSplineArea",
                          dataPoint: m[p],
                          dataSeries: k,
                          indexKeyword: 1,
                          point: { x: q, y: r },
                          direction: m[p].y[0] <= m[p].y[1] ? 1 : -1,
                          color: u
                        });
                      g = false;
                    } else
                      0 < p && !g && (k.connectNullData ? b.setLineDash && (0 < n2.length && (k.options.nullDataLineDashType || !m[p - 1].lineDashType)) && (n2[n2.length - 1].newLineDashArray = D, z = k.nullDataLineDashType) : (d(A2, y), n2 = [], ba = [])), g = true;
                d(A2, y);
                W.drawMarkers(f);
              }
            }
            w && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(
              a.axisX.maskCanvas,
              0,
              0,
              this.width,
              this.height
            ), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(l.x1, l.y1, l.width, l.height), this._eventManager.ghostCtx.restore());
            b.restore();
            return { source: c, dest: this.plotArea.ctx, animationCallback: M.xClipAnimation, easingFunction: M.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderWaterfall = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = w ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = this._eventManager.ghostCtx, e = null, f = this.plotArea, l = 0, h2, s2, k, m, p = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), l = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1;
            s2 = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : Math.min(0.15 * this.width, 0.9 * (this.plotArea.width / a.plotType.totalDataSeries)) << 0;
            var q = a.axisX.dataInfo.minDiff;
            isFinite(q) || (q = 0.3 * Math.abs(a.axisX.range));
            q = this.options.dataPointWidth ? this.dataPointWidth : 0.6 * (f.width * (a.axisX.logarithmic ? Math.log(q) / Math.log(a.axisX.range) : Math.abs(q) / Math.abs(a.axisX.range)) / a.plotType.totalDataSeries) << 0;
            this.dataPointMaxWidth && l > s2 && (l = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, s2));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && s2 < l) && (s2 = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, l));
            q < l && (q = l);
            q > s2 && (q = s2);
            c.save();
            w && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(f.x1, f.y1, f.width, f.height);
            c.clip();
            w && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(f.x1, f.y1, f.width, f.height), this._eventManager.ghostCtx.clip());
            for (var g = 0; g < a.dataSeriesIndexes.length; g++) {
              var r = a.dataSeriesIndexes[g], n2 = this.data[r], v3 = n2.dataPoints, e = n2._colorSet[0];
              n2.risingColor = n2.options.risingColor ? n2.options.risingColor : e;
              n2.fallingColor = n2.options.fallingColor ? n2.options.fallingColor : "#e40a0a";
              var u = "number" === typeof n2.options.lineThickness ? Math.round(n2.lineThickness) : 1, y = 1 === Math.round(u) % 2 ? -0.5 : 0;
              if (0 < v3.length)
                for (var x = 5 < q && n2.bevelEnabled ? true : false, z = false, A2 = null, D = null, l = 0; l < v3.length; l++)
                  if (v3[l].getTime ? m = v3[l].x.getTime() : m = v3[l].x, "number" !== typeof v3[l].y) {
                    if (0 < l && !z && n2.connectNullData)
                      var B3 = n2.options.nullDataLineDashType || !v3[l - 1].lineDashType ? n2.nullDataLineDashType : v3[l - 1].lineDashType;
                    z = true;
                  } else {
                    h2 = a.axisX.convertValueToPixel(m);
                    s2 = 0 === n2.dataPointEOs[l].cumulativeSum ? p : a.axisY.convertValueToPixel(n2.dataPointEOs[l].cumulativeSum);
                    k = 0 === n2.dataPointEOs[l].cumulativeSumYStartValue ? p : a.axisY.convertValueToPixel(n2.dataPointEOs[l].cumulativeSumYStartValue);
                    h2 = a.axisX.reversed ? h2 + a.plotType.totalDataSeries * q / 2 - (a.previousDataSeriesCount + g) * q << 0 : h2 - a.plotType.totalDataSeries * q / 2 + (a.previousDataSeriesCount + g) * q << 0;
                    var E = a.axisX.reversed ? h2 - q << 0 : h2 + q << 0;
                    s2 > k && (e = s2, s2 = k, k = e);
                    a.axisY.reversed && (e = s2, s2 = k, k = e);
                    e = n2.dataPointIds[l];
                    this._eventManager.objectMap[e] = { id: e, objectType: "dataPoint", dataSeriesIndex: r, dataPointIndex: l, x1: h2, y1: s2, x2: E, y2: k };
                    var L = v3[l].color ? v3[l].color : 0 < v3[l].y ? n2.risingColor : n2.fallingColor;
                    Y(c, a.axisX.reversed ? E : h2, a.axisY.reversed ? k : s2, a.axisX.reversed ? h2 : E, a.axisY.reversed ? s2 : k, L, 0, L, x, x, false, false, n2.fillOpacity);
                    e = X(e);
                    w && Y(this._eventManager.ghostCtx, a.axisX.reversed ? E : h2, s2, a.axisX.reversed ? h2 : E, k, e, 0, null, false, false, false, false);
                    var S, L = h2;
                    S = "undefined" !== typeof v3[l].isIntermediateSum && true === v3[l].isIntermediateSum || "undefined" !== typeof v3[l].isCumulativeSum && true === v3[l].isCumulativeSum ? 0 < v3[l].y ? s2 : k : 0 < v3[l].y ? k : s2;
                    0 < l && A2 && (!z || n2.connectNullData) && (z && c.setLineDash && c.setLineDash(J(B3, u)), c.beginPath(), c.moveTo(A2, D - y), c.lineTo(L, S - y), 0 < u && c.stroke(), w && (b.beginPath(), b.moveTo(A2, D - y), b.lineTo(L, S - y), 0 < u && b.stroke()));
                    z = false;
                    A2 = E;
                    D = 0 < v3[l].y ? s2 : k;
                    L = v3[l].lineDashType ? v3[l].lineDashType : n2.options.lineDashType ? n2.options.lineDashType : "shortDash";
                    c.strokeStyle = v3[l].lineColor ? v3[l].lineColor : n2.options.lineColor ? n2.options.lineColor : "#9e9e9e";
                    c.lineWidth = u;
                    c.setLineDash && (L = J(L, u), c.setLineDash(L));
                    (v3[l].indexLabel || n2.indexLabel || v3[l].indexLabelFormatter || n2.indexLabelFormatter) && this._indexLabels.push({ chartType: "waterfall", dataPoint: v3[l], dataSeries: n2, point: { x: h2 + (E - h2) / 2, y: 0 <= v3[l].y ? s2 : k }, direction: 0 > v3[l].y === a.axisY.reversed ? 1 : -1, bounds: { x1: h2, y1: Math.min(s2, k), x2: E, y2: Math.max(s2, k) }, color: e });
                  }
            }
            w && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(f.x1, f.y1, f.width, f.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: M.fadeInAnimation, easingFunction: M.easing.easeInQuad, animationBase: 0 };
          }
        };
        var pa2 = function(a, d, c, b, e, f, l, h2, s2) {
          if (!(0 > c)) {
            "undefined" === typeof h2 && (h2 = 1);
            if (!w) {
              var k = Number((l % (2 * Math.PI)).toFixed(8));
              Number((f % (2 * Math.PI)).toFixed(8)) === k && (l -= 1e-4);
            }
            a.save();
            a.globalAlpha = h2;
            "pie" === e ? (a.beginPath(), a.moveTo(d.x, d.y), a.arc(d.x, d.y, c, f, l, false), a.fillStyle = b, a.strokeStyle = "white", a.lineWidth = 2, a.closePath(), a.fill()) : "doughnut" === e && (a.beginPath(), a.arc(d.x, d.y, c, f, l, false), 0 <= s2 && a.arc(d.x, d.y, s2 * c, l, f, true), a.closePath(), a.fillStyle = b, a.strokeStyle = "white", a.lineWidth = 2, a.fill());
            a.globalAlpha = 1;
            a.restore();
          }
        };
        n.prototype.renderPie = function(a) {
          function d() {
            if (k && m) {
              for (var a2 = 0, b2 = 0, c2 = 0, d2 = 0, e2 = 0; e2 < m.length; e2++) {
                var f2 = m[e2], l2 = k.dataPointIds[e2];
                g[e2].id = l2;
                g[e2].objectType = "dataPoint";
                g[e2].dataPointIndex = e2;
                g[e2].dataSeriesIndex = 0;
                var h3 = g[e2], p2 = { percent: null, total: null }, t = null, p2 = n2.getPercentAndTotal(k, f2);
                if (k.indexLabelFormatter || f2.indexLabelFormatter)
                  t = { chart: n2.options, dataSeries: k, dataPoint: f2, total: p2.total, percent: p2.percent };
                p2 = f2.indexLabelFormatter ? f2.indexLabelFormatter(t) : f2.indexLabel ? n2.replaceKeywordsWithValue(f2.indexLabel, f2, k, e2) : k.indexLabelFormatter ? k.indexLabelFormatter(t) : k.indexLabel ? n2.replaceKeywordsWithValue(k.indexLabel, f2, k, e2) : f2.label ? f2.label : "";
                n2._eventManager.objectMap[l2] = h3;
                h3.center = { x: x.x, y: x.y };
                h3.y = f2.y;
                h3.radius = D;
                h3.percentInnerRadius = E;
                h3.indexLabelText = p2;
                h3.indexLabelPlacement = k.indexLabelPlacement;
                h3.indexLabelLineColor = f2.indexLabelLineColor ? f2.indexLabelLineColor : k.options.indexLabelLineColor ? k.options.indexLabelLineColor : f2.color ? f2.color : k._colorSet[e2 % k._colorSet.length];
                h3.indexLabelLineThickness = s(f2.indexLabelLineThickness) ? k.indexLabelLineThickness : f2.indexLabelLineThickness;
                h3.indexLabelLineDashType = f2.indexLabelLineDashType ? f2.indexLabelLineDashType : k.indexLabelLineDashType;
                h3.indexLabelFontColor = f2.indexLabelFontColor ? f2.indexLabelFontColor : k.indexLabelFontColor;
                h3.indexLabelFontStyle = f2.indexLabelFontStyle ? f2.indexLabelFontStyle : k.indexLabelFontStyle;
                h3.indexLabelFontWeight = f2.indexLabelFontWeight ? f2.indexLabelFontWeight : k.indexLabelFontWeight;
                h3.indexLabelFontSize = s(f2.indexLabelFontSize) ? k.indexLabelFontSize : f2.indexLabelFontSize;
                h3.indexLabelFontFamily = f2.indexLabelFontFamily ? f2.indexLabelFontFamily : k.indexLabelFontFamily;
                h3.indexLabelBackgroundColor = f2.indexLabelBackgroundColor ? f2.indexLabelBackgroundColor : k.options.indexLabelBackgroundColor ? k.options.indexLabelBackgroundColor : k.indexLabelBackgroundColor;
                h3.indexLabelMaxWidth = f2.indexLabelMaxWidth ? f2.indexLabelMaxWidth : k.indexLabelMaxWidth ? k.indexLabelMaxWidth : 0.33 * q.width;
                h3.indexLabelWrap = "undefined" !== typeof f2.indexLabelWrap ? f2.indexLabelWrap : k.indexLabelWrap;
                h3.indexLabelTextAlign = f2.indexLabelTextAlign ? f2.indexLabelTextAlign : k.indexLabelTextAlign ? k.indexLabelTextAlign : "left";
                h3.startAngle = 0 === e2 ? k.startAngle ? k.startAngle / 180 * Math.PI : 0 : g[e2 - 1].endAngle;
                h3.startAngle = (h3.startAngle + 2 * Math.PI) % (2 * Math.PI);
                h3.endAngle = h3.startAngle + 2 * Math.PI / z * Math.abs(f2.y);
                f2 = (h3.endAngle + h3.startAngle) / 2;
                f2 = (f2 + 2 * Math.PI) % (2 * Math.PI);
                h3.midAngle = f2;
                if (h3.midAngle > Math.PI / 2 - u && h3.midAngle < Math.PI / 2 + u) {
                  if (0 === a2 || g[c2].midAngle > h3.midAngle)
                    c2 = e2;
                  a2++;
                } else if (h3.midAngle > 3 * Math.PI / 2 - u && h3.midAngle < 3 * Math.PI / 2 + u) {
                  if (0 === b2 || g[d2].midAngle > h3.midAngle)
                    d2 = e2;
                  b2++;
                }
                h3.hemisphere = f2 > Math.PI / 2 && f2 <= 3 * Math.PI / 2 ? "left" : "right";
                h3.indexLabelTextBlock = new ja(n2.plotArea.ctx, {
                  fontSize: h3.indexLabelFontSize,
                  fontFamily: h3.indexLabelFontFamily,
                  fontColor: h3.indexLabelFontColor,
                  fontStyle: h3.indexLabelFontStyle,
                  fontWeight: h3.indexLabelFontWeight,
                  textAlign: h3.indexLabelTextAlign,
                  backgroundColor: h3.indexLabelBackgroundColor,
                  maxWidth: h3.indexLabelMaxWidth,
                  maxHeight: h3.indexLabelWrap ? 5 * h3.indexLabelFontSize : 1.5 * h3.indexLabelFontSize,
                  text: h3.indexLabelText,
                  padding: 0,
                  textBaseline: "top"
                });
                h3.indexLabelTextBlock.measureText();
              }
              l2 = f2 = 0;
              p2 = false;
              for (e2 = 0; e2 < m.length; e2++)
                h3 = g[(c2 + e2) % m.length], 1 < a2 && (h3.midAngle > Math.PI / 2 - u && h3.midAngle < Math.PI / 2 + u) && (f2 <= a2 / 2 && !p2 ? (h3.hemisphere = "right", f2++) : (h3.hemisphere = "left", p2 = true));
              p2 = false;
              for (e2 = 0; e2 < m.length; e2++)
                h3 = g[(d2 + e2) % m.length], 1 < b2 && (h3.midAngle > 3 * Math.PI / 2 - u && h3.midAngle < 3 * Math.PI / 2 + u) && (l2 <= b2 / 2 && !p2 ? (h3.hemisphere = "left", l2++) : (h3.hemisphere = "right", p2 = true));
            }
          }
          function c(a2) {
            var b2 = n2.plotArea.ctx;
            b2.clearRect(q.x1, q.y1, q.width, q.height);
            b2.fillStyle = n2.backgroundColor;
            b2.fillRect(q.x1, q.y1, q.width, q.height);
            for (b2 = 0; b2 < m.length; b2++) {
              var c2 = g[b2].startAngle, d2 = g[b2].endAngle;
              if (d2 > c2) {
                var e2 = 0.07 * D * Math.cos(g[b2].midAngle), f2 = 0.07 * D * Math.sin(g[b2].midAngle), l2 = false;
                if (m[b2].exploded) {
                  if (1e-9 < Math.abs(g[b2].center.x - (x.x + e2)) || 1e-9 < Math.abs(g[b2].center.y - (x.y + f2)))
                    g[b2].center.x = x.x + e2 * a2, g[b2].center.y = x.y + f2 * a2, l2 = true;
                } else if (0 < Math.abs(g[b2].center.x - x.x) || 0 < Math.abs(g[b2].center.y - x.y))
                  g[b2].center.x = x.x + e2 * (1 - a2), g[b2].center.y = x.y + f2 * (1 - a2), l2 = true;
                l2 && (e2 = {}, e2.dataSeries = k, e2.dataPoint = k.dataPoints[b2], e2.index = b2, n2.toolTip.highlightObjects([e2]));
                pa2(
                  n2.plotArea.ctx,
                  g[b2].center,
                  g[b2].radius,
                  m[b2].color ? m[b2].color : k._colorSet[b2 % k._colorSet.length],
                  k.type,
                  c2,
                  d2,
                  k.fillOpacity,
                  g[b2].percentInnerRadius
                );
              }
            }
            a2 = n2.plotArea.ctx;
            a2.save();
            a2.fillStyle = "black";
            a2.strokeStyle = "grey";
            a2.textBaseline = "middle";
            a2.lineJoin = "round";
            for (b2 = b2 = 0; b2 < m.length; b2++)
              c2 = g[b2], c2.indexLabelText && (c2.indexLabelTextBlock.y -= c2.indexLabelTextBlock.height / 2, d2 = 0, d2 = "left" === c2.hemisphere ? "inside" !== k.indexLabelPlacement ? -(c2.indexLabelTextBlock.width + p) : -c2.indexLabelTextBlock.width / 2 : "inside" !== k.indexLabelPlacement ? p : -c2.indexLabelTextBlock.width / 2, c2.indexLabelTextBlock.x += d2, c2.indexLabelTextBlock.render(true), c2.indexLabelTextBlock.x -= d2, c2.indexLabelTextBlock.y += c2.indexLabelTextBlock.height / 2, "inside" !== c2.indexLabelPlacement && 0 < c2.indexLabelLineThickness && (d2 = c2.center.x + D * Math.cos(c2.midAngle), e2 = c2.center.y + D * Math.sin(c2.midAngle), a2.strokeStyle = c2.indexLabelLineColor, a2.lineWidth = c2.indexLabelLineThickness, a2.setLineDash && a2.setLineDash(J(c2.indexLabelLineDashType, c2.indexLabelLineThickness)), a2.beginPath(), a2.moveTo(d2, e2), a2.lineTo(c2.indexLabelTextBlock.x, c2.indexLabelTextBlock.y), a2.lineTo(c2.indexLabelTextBlock.x + ("left" === c2.hemisphere ? -p : p), c2.indexLabelTextBlock.y), a2.stroke()), a2.lineJoin = "miter");
            a2.save();
          }
          function b(a2, b2) {
            var c2 = 0, c2 = a2.indexLabelTextBlock.y - a2.indexLabelTextBlock.height / 2, d2 = a2.indexLabelTextBlock.y + a2.indexLabelTextBlock.height / 2, e2 = b2.indexLabelTextBlock.y - b2.indexLabelTextBlock.height / 2, f2 = b2.indexLabelTextBlock.y + b2.indexLabelTextBlock.height / 2;
            return c2 = b2.indexLabelTextBlock.y > a2.indexLabelTextBlock.y ? e2 - d2 : c2 - f2;
          }
          function e(a2) {
            for (var c2 = null, d2 = 1; d2 < m.length; d2++)
              if (c2 = (a2 + d2 + g.length) % g.length, g[c2].hemisphere !== g[a2].hemisphere) {
                c2 = null;
                break;
              } else if (g[c2].indexLabelText && c2 !== a2 && (0 > b(g[c2], g[a2]) || ("right" === g[a2].hemisphere ? g[c2].indexLabelTextBlock.y >= g[a2].indexLabelTextBlock.y : g[c2].indexLabelTextBlock.y <= g[a2].indexLabelTextBlock.y)))
                break;
              else
                c2 = null;
            return c2;
          }
          function f(a2, c2, d2) {
            d2 = (d2 || 0) + 1;
            if (1e3 < d2)
              return 0;
            c2 = c2 || 0;
            var k2 = 0, l2 = x.y - 1 * w2, h3 = x.y + 1 * w2;
            if (0 <= a2 && a2 < m.length) {
              var p2 = g[a2];
              if (0 > c2 && p2.indexLabelTextBlock.y < l2 || 0 < c2 && p2.indexLabelTextBlock.y > h3)
                return 0;
              var q2 = 0, t = 0, t = q2 = q2 = 0;
              0 > c2 ? p2.indexLabelTextBlock.y - p2.indexLabelTextBlock.height / 2 > l2 && p2.indexLabelTextBlock.y - p2.indexLabelTextBlock.height / 2 + c2 < l2 && (c2 = -(l2 - (p2.indexLabelTextBlock.y - p2.indexLabelTextBlock.height / 2 + c2))) : p2.indexLabelTextBlock.y + p2.indexLabelTextBlock.height / 2 < l2 && p2.indexLabelTextBlock.y + p2.indexLabelTextBlock.height / 2 + c2 > h3 && (c2 = p2.indexLabelTextBlock.y + p2.indexLabelTextBlock.height / 2 + c2 - h3);
              c2 = p2.indexLabelTextBlock.y + c2;
              l2 = 0;
              l2 = "right" === p2.hemisphere ? x.x + Math.sqrt(Math.pow(w2, 2) - Math.pow(c2 - x.y, 2)) : x.x - Math.sqrt(Math.pow(w2, 2) - Math.pow(c2 - x.y, 2));
              t = x.x + D * Math.cos(p2.midAngle);
              q2 = x.y + D * Math.sin(p2.midAngle);
              q2 = Math.sqrt(Math.pow(l2 - t, 2) + Math.pow(c2 - q2, 2));
              t = Math.acos(D / w2);
              q2 = Math.acos((w2 * w2 + D * D - q2 * q2) / (2 * D * w2));
              c2 = q2 < t ? c2 - p2.indexLabelTextBlock.y : 0;
              l2 = null;
              for (h3 = 1; h3 < m.length; h3++)
                if (l2 = (a2 - h3 + g.length) % g.length, g[l2].hemisphere !== g[a2].hemisphere) {
                  l2 = null;
                  break;
                } else if (g[l2].indexLabelText && g[l2].hemisphere === g[a2].hemisphere && l2 !== a2 && (0 > b(g[l2], g[a2]) || ("right" === g[a2].hemisphere ? g[l2].indexLabelTextBlock.y <= g[a2].indexLabelTextBlock.y : g[l2].indexLabelTextBlock.y >= g[a2].indexLabelTextBlock.y)))
                  break;
                else
                  l2 = null;
              t = l2;
              q2 = e(a2);
              h3 = l2 = 0;
              0 > c2 ? (h3 = "right" === p2.hemisphere ? t : q2, k2 = c2, null !== h3 && (t = -c2, c2 = p2.indexLabelTextBlock.y - p2.indexLabelTextBlock.height / 2 - (g[h3].indexLabelTextBlock.y + g[h3].indexLabelTextBlock.height / 2), c2 - t < r && (l2 = -t, h3 = f(h3, l2, d2 + 1), +h3.toFixed(y) > +l2.toFixed(y) && (k2 = c2 > r ? -(c2 - r) : -(t - (h3 - l2)))))) : 0 < c2 && (h3 = "right" === p2.hemisphere ? q2 : t, k2 = c2, null !== h3 && (t = c2, c2 = g[h3].indexLabelTextBlock.y - g[h3].indexLabelTextBlock.height / 2 - (p2.indexLabelTextBlock.y + p2.indexLabelTextBlock.height / 2), c2 - t < r && (l2 = t, h3 = f(h3, l2, d2 + 1), +h3.toFixed(y) < +l2.toFixed(y) && (k2 = c2 > r ? c2 - r : t - (l2 - h3)))));
              k2 && (d2 = p2.indexLabelTextBlock.y + k2, c2 = 0, c2 = "right" === p2.hemisphere ? x.x + Math.sqrt(Math.pow(w2, 2) - Math.pow(d2 - x.y, 2)) : x.x - Math.sqrt(Math.pow(w2, 2) - Math.pow(d2 - x.y, 2)), p2.midAngle > Math.PI / 2 - u && p2.midAngle < Math.PI / 2 + u ? (l2 = (a2 - 1 + g.length) % g.length, l2 = g[l2], a2 = g[(a2 + 1 + g.length) % g.length], "left" === p2.hemisphere && "right" === l2.hemisphere && c2 > l2.indexLabelTextBlock.x ? c2 = l2.indexLabelTextBlock.x - 15 : "right" === p2.hemisphere && ("left" === a2.hemisphere && c2 < a2.indexLabelTextBlock.x) && (c2 = a2.indexLabelTextBlock.x + 15)) : p2.midAngle > 3 * Math.PI / 2 - u && p2.midAngle < 3 * Math.PI / 2 + u && (l2 = (a2 - 1 + g.length) % g.length, l2 = g[l2], a2 = g[(a2 + 1 + g.length) % g.length], "right" === p2.hemisphere && "left" === l2.hemisphere && c2 < l2.indexLabelTextBlock.x ? c2 = l2.indexLabelTextBlock.x + 15 : "left" === p2.hemisphere && ("right" === a2.hemisphere && c2 > a2.indexLabelTextBlock.x) && (c2 = a2.indexLabelTextBlock.x - 15)), p2.indexLabelTextBlock.y = d2, p2.indexLabelTextBlock.x = c2, p2.indexLabelAngle = Math.atan2(p2.indexLabelTextBlock.y - x.y, p2.indexLabelTextBlock.x - x.x));
            }
            return k2;
          }
          function l() {
            var a2 = n2.plotArea.ctx;
            a2.fillStyle = "grey";
            a2.strokeStyle = "grey";
            a2.font = "16px Arial";
            a2.textBaseline = "middle";
            for (var c2 = a2 = 0, d2 = 0, l2 = true, c2 = 0; 10 > c2 && (1 > c2 || 0 < d2); c2++) {
              if (k.radius || !k.radius && "undefined" !== typeof k.innerRadius && null !== k.innerRadius && D - d2 <= B3)
                l2 = false;
              l2 && (D -= d2);
              d2 = 0;
              if ("inside" !== k.indexLabelPlacement) {
                w2 = D * v3;
                for (a2 = 0; a2 < m.length; a2++) {
                  var h3 = g[a2];
                  h3.indexLabelTextBlock.x = x.x + w2 * Math.cos(h3.midAngle);
                  h3.indexLabelTextBlock.y = x.y + w2 * Math.sin(h3.midAngle);
                  h3.indexLabelAngle = h3.midAngle;
                  h3.radius = D;
                  h3.percentInnerRadius = E;
                }
                for (var t, s2, a2 = 0; a2 < m.length; a2++) {
                  var h3 = g[a2], u2 = e(a2);
                  if (null !== u2) {
                    t = g[a2];
                    s2 = g[u2];
                    var z2 = 0, z2 = b(t, s2) - r;
                    if (0 > z2) {
                      for (var A3 = s2 = 0, H = 0; H < m.length; H++)
                        H !== a2 && g[H].hemisphere === h3.hemisphere && (g[H].indexLabelTextBlock.y < h3.indexLabelTextBlock.y ? s2++ : A3++);
                      s2 = z2 / (s2 + A3 || 1) * A3;
                      var A3 = -1 * (z2 - s2), J2 = H = 0;
                      "right" === h3.hemisphere ? (H = f(a2, s2), A3 = -1 * (z2 - H), J2 = f(u2, A3), +J2.toFixed(y) < +A3.toFixed(y) && +H.toFixed(y) <= +s2.toFixed(y) && f(a2, -(A3 - J2))) : (H = f(u2, s2), A3 = -1 * (z2 - H), J2 = f(a2, A3), +J2.toFixed(y) < +A3.toFixed(y) && +H.toFixed(y) <= +s2.toFixed(y) && f(u2, -(A3 - J2)));
                    }
                  }
                }
              } else
                for (a2 = 0; a2 < m.length; a2++)
                  h3 = g[a2], w2 = "pie" === k.type ? 0.7 * D : 0.85 * D, u2 = x.x + w2 * Math.cos(h3.midAngle), s2 = x.y + w2 * Math.sin(h3.midAngle), h3.indexLabelTextBlock.x = u2, h3.indexLabelTextBlock.y = s2;
              for (a2 = 0; a2 < m.length; a2++)
                if (h3 = g[a2], u2 = h3.indexLabelTextBlock.measureText(), 0 !== u2.height && 0 !== u2.width)
                  u2 = u2 = 0, "right" === h3.hemisphere ? (u2 = q.x2 - (h3.indexLabelTextBlock.x + h3.indexLabelTextBlock.width + p), u2 *= -1) : u2 = q.x1 - (h3.indexLabelTextBlock.x - h3.indexLabelTextBlock.width - p), 0 < u2 && (!l2 && h3.indexLabelText && (s2 = "right" === h3.hemisphere ? q.x2 - h3.indexLabelTextBlock.x : h3.indexLabelTextBlock.x - q.x1, 0.3 * h3.indexLabelTextBlock.maxWidth > s2 ? h3.indexLabelText = "" : h3.indexLabelTextBlock.maxWidth = 0.85 * s2, 0.3 * h3.indexLabelTextBlock.maxWidth < s2 && (h3.indexLabelTextBlock.x -= "right" === h3.hemisphere ? 2 : -2)), Math.abs(h3.indexLabelTextBlock.y - h3.indexLabelTextBlock.height / 2 - x.y) < D || Math.abs(h3.indexLabelTextBlock.y + h3.indexLabelTextBlock.height / 2 - x.y) < D) && (u2 /= Math.abs(Math.cos(h3.indexLabelAngle)), 9 < u2 && (u2 *= 0.3), u2 > d2 && (d2 = u2)), u2 = u2 = 0, 0 < h3.indexLabelAngle && h3.indexLabelAngle < Math.PI ? (u2 = q.y2 - (h3.indexLabelTextBlock.y + h3.indexLabelTextBlock.height / 2 + 5), u2 *= -1) : u2 = q.y1 - (h3.indexLabelTextBlock.y - h3.indexLabelTextBlock.height / 2 - 5), 0 < u2 && (!l2 && h3.indexLabelText && (s2 = 0 < h3.indexLabelAngle && h3.indexLabelAngle < Math.PI ? -1 : 1, 0 === f(a2, u2 * s2) && f(a2, 2 * s2)), Math.abs(h3.indexLabelTextBlock.x - x.x) < D && (u2 /= Math.abs(Math.sin(h3.indexLabelAngle)), 9 < u2 && (u2 *= 0.3), u2 > d2 && (d2 = u2)));
              var G2 = function(a3, b2, c3) {
                for (var d3 = [], e2 = 0; d3.push(g[b2]), b2 !== c3; b2 = (b2 + 1 + m.length) % m.length)
                  ;
                d3.sort(function(a4, b3) {
                  return a4.y - b3.y;
                });
                for (b2 = 0; b2 < d3.length; b2++)
                  if (c3 = d3[b2], e2 < 0.7 * a3)
                    e2 += c3.indexLabelTextBlock.height, c3.indexLabelTextBlock.text = "", c3.indexLabelText = "", c3.indexLabelTextBlock.measureText();
                  else
                    break;
              };
              (function() {
                for (var a3 = -1, c3 = -1, d3 = 0, f2 = false, l3 = 0; l3 < m.length; l3++)
                  if (f2 = false, t = g[l3], t.indexLabelText) {
                    var k2 = e(l3);
                    if (null !== k2) {
                      var h4 = g[k2];
                      z2 = 0;
                      z2 = b(t, h4);
                      var q2;
                      if (q2 = 0 > z2) {
                        q2 = t.indexLabelTextBlock.x;
                        var r2 = t.indexLabelTextBlock.y - t.indexLabelTextBlock.height / 2, n3 = t.indexLabelTextBlock.y + t.indexLabelTextBlock.height / 2, s3 = h4.indexLabelTextBlock.y - h4.indexLabelTextBlock.height / 2, u3 = h4.indexLabelTextBlock.x + h4.indexLabelTextBlock.width, C = h4.indexLabelTextBlock.y + h4.indexLabelTextBlock.height / 2;
                        q2 = t.indexLabelTextBlock.x + t.indexLabelTextBlock.width < h4.indexLabelTextBlock.x - p || q2 > u3 + p || r2 > C + p || n3 < s3 - p ? false : true;
                      }
                      q2 ? (0 > a3 && (a3 = l3), k2 !== a3 && (c3 = k2, d3 += -z2), 0 === l3 % Math.max(m.length / 10, 3) && (f2 = true)) : f2 = true;
                      f2 && (0 < d3 && 0 <= a3 && 0 <= c3) && (G2(d3, a3, c3), c3 = a3 = -1, d3 = 0);
                    }
                  }
                0 < d3 && G2(d3, a3, c3);
              })();
            }
          }
          function h2() {
            n2.plotArea.layoutManager.reset();
            n2.title && (n2.title.dockInsidePlotArea || "center" === n2.title.horizontalAlign && "center" === n2.title.verticalAlign) && n2.title.render();
            if (n2.subtitles)
              for (var a2 = 0; a2 < n2.subtitles.length; a2++) {
                var b2 = n2.subtitles[a2];
                (b2.dockInsidePlotArea || "center" === b2.horizontalAlign && "center" === b2.verticalAlign) && b2.render();
              }
            n2.legend && (n2.legend.dockInsidePlotArea || "center" === n2.legend.horizontalAlign && "center" === n2.legend.verticalAlign) && (n2.legend.setLayout(), n2.legend.render());
          }
          var n2 = this;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var k = this.data[a.dataSeriesIndexes[0]], m = k.dataPoints, p = 10, q = this.plotArea, g = k.dataPointEOs, r = 2, w2, v3 = 1.3, u = 20 / 180 * Math.PI, y = 6, x = { x: (q.x2 + q.x1) / 2, y: (q.y2 + q.y1) / 2 }, z = 0;
            a = false;
            for (var A2 = 0; A2 < m.length; A2++)
              z += Math.abs(m[A2].y), !a && ("undefined" !== typeof m[A2].indexLabel && null !== m[A2].indexLabel && 0 < m[A2].indexLabel.toString().length) && (a = true), !a && ("undefined" !== typeof m[A2].label && null !== m[A2].label && 0 < m[A2].label.toString().length) && (a = true);
            if (0 !== z) {
              a = a || "undefined" !== typeof k.indexLabel && null !== k.indexLabel && 0 < k.indexLabel.toString().length;
              var D = "inside" !== k.indexLabelPlacement && a ? 0.75 * Math.min(q.width, q.height) / 2 : 0.92 * Math.min(q.width, q.height) / 2;
              k.radius && (D = Ta(k.radius, D));
              var B3 = "undefined" !== typeof k.innerRadius && null !== k.innerRadius ? Ta(k.innerRadius, D) : 0.7 * D;
              k.radius = D;
              "doughnut" === k.type && (k.innerRadius = B3);
              var E = Math.min(B3 / D, (D - 1) / D);
              this.pieDoughnutClickHandler = function(a2) {
                n2.isAnimating || !s(a2.dataSeries.explodeOnClick) && !a2.dataSeries.explodeOnClick || (a2 = a2.dataPoint, a2.exploded = a2.exploded ? false : true, 1 < this.dataPoints.length && n2._animator.animate(0, 500, function(a3) {
                  c(a3);
                  h2();
                  n2.dispatchEvent("dataAnimationIterationEnd", { chart: n2 });
                  n2.dispatchEvent("dataAnimationEnd", { chart: n2 });
                }));
              };
              d();
              l();
              l();
              l();
              l();
              this.disableToolTip = true;
              this._animator.animate(0, this.animatedRender ? this.animationDuration : 0, function(a2) {
                var b2 = n2.plotArea.ctx;
                b2.clearRect(q.x1, q.y1, q.width, q.height);
                b2.fillStyle = n2.backgroundColor;
                b2.fillRect(q.x1, q.y1, q.width, q.height);
                for (var b2 = g[0].startAngle + 2 * Math.PI * a2, c2 = 0; c2 < m.length; c2++) {
                  var d2 = 0 === c2 ? g[c2].startAngle : e2, e2 = d2 + (g[c2].endAngle - g[c2].startAngle), f2 = false;
                  e2 > b2 && (e2 = b2, f2 = true);
                  var l2 = m[c2].color ? m[c2].color : k._colorSet[c2 % k._colorSet.length];
                  e2 > d2 && pa2(n2.plotArea.ctx, g[c2].center, g[c2].radius, l2, k.type, d2, e2, k.fillOpacity, g[c2].percentInnerRadius);
                  if (f2)
                    break;
                }
                h2();
                n2.dispatchEvent("dataAnimationIterationEnd", { chart: n2 });
                1 <= a2 && n2.dispatchEvent("dataAnimationEnd", { chart: n2 });
              }, function() {
                n2.disableToolTip = false;
                n2._animator.animate(0, n2.animatedRender ? 500 : 0, function(a2) {
                  c(a2);
                  h2();
                  n2.dispatchEvent("dataAnimationIterationEnd", { chart: n2 });
                });
                n2.dispatchEvent("dataAnimationEnd", { chart: n2 });
              });
            }
          }
        };
        var ra2 = function(a, d, c, b) {
          "undefined" === typeof c && (c = 1);
          0 >= Math.round(d.y4 - d.y1) || (a.save(), a.globalAlpha = c, a.beginPath(), a.moveTo(Math.round(d.x1), Math.round(d.y1)), a.lineTo(
            Math.round(d.x2),
            Math.round(d.y2)
          ), a.lineTo(Math.round(d.x3), Math.round(d.y3)), a.lineTo(Math.round(d.x4), Math.round(d.y4)), "undefined" !== d.x5 && (a.lineTo(Math.round(d.x5), Math.round(d.y5)), a.lineTo(Math.round(d.x6), Math.round(d.y6))), a.closePath(), a.fillStyle = b ? b : d.color, a.fill(), a.globalAplha = 1, a.restore());
        };
        n.prototype.renderFunnel = function(a) {
          function d() {
            for (var a2 = 0, b2 = [], c2 = 0; c2 < y.length; c2++) {
              if ("undefined" === typeof y[c2].y)
                return -1;
              y[c2].y = "number" === typeof y[c2].y ? y[c2].y : 0;
              a2 += Math.abs(y[c2].y);
            }
            if (0 === a2)
              return -1;
            for (c2 = b2[0] = 0; c2 < y.length; c2++)
              b2.push(Math.abs(y[c2].y) * E / a2);
            return b2;
          }
          function c() {
            var a2 = T2, b2 = V2, c2 = O, d2 = W2, e2, f2;
            e2 = $;
            f2 = N2 - Q3;
            d2 = Math.abs((f2 - e2) * (b2 - a2 + (d2 - c2)) / 2);
            c2 = W2 - O;
            e2 = f2 - e2;
            f2 = c2 * (f2 - N2);
            f2 = Math.abs(f2);
            f2 = d2 + f2;
            for (var d2 = [], g2 = 0, l2 = 0; l2 < y.length; l2++) {
              if ("undefined" === typeof y[l2].y)
                return -1;
              y[l2].y = "number" === typeof y[l2].y ? y[l2].y : 0;
              g2 += Math.abs(y[l2].y);
            }
            if (0 === g2)
              return -1;
            for (var k2 = d2[0] = 0, h3 = 0, m2, p2, b2 = b2 - a2, k2 = false, l2 = 0; l2 < y.length; l2++)
              a2 = Math.abs(y[l2].y) * f2 / g2, k2 ? m2 = 0 == Number(c2.toFixed(3)) ? 0 : a2 / c2 : (p2 = aa3 * aa3 * b2 * b2 - 4 * Math.abs(aa3) * a2, 0 > p2 ? (p2 = c2, k2 = (b2 + p2) * (e2 - h3) / 2, a2 -= k2, m2 = e2 - h3, h3 += e2 - h3, m2 += 0 == p2 ? 0 : a2 / p2, h3 += a2 / p2, k2 = true) : (m2 = (Math.abs(aa3) * b2 - Math.sqrt(p2)) / 2, p2 = b2 - 2 * m2 / Math.abs(aa3), h3 += m2, h3 > e2 && (h3 -= m2, p2 = c2, k2 = (b2 + p2) * (e2 - h3) / 2, a2 -= k2, m2 = e2 - h3, h3 += e2 - h3, m2 += a2 / p2, h3 += a2 / p2, k2 = true), b2 = p2)), d2.push(m2);
            return d2;
          }
          function b() {
            if (u && y) {
              for (var a2, b2, c2, d2, e2, f2, l2, k2, h3, m2, p2, q2, t, n3, r2, C = [], x2 = [], v4 = { percent: null, total: null }, z2 = null, D2 = 0; D2 < y.length; D2++)
                r2 = R[D2], r2 = "undefined" !== typeof r2.x5 ? (r2.y2 + r2.y4) / 2 : (r2.y2 + r2.y3) / 2, r2 = g(r2).x2 + 1, C[D2] = K3 - r2 - X2;
              r2 = 0.5 * X2;
              for (var D2 = 0, B4 = y.length - 1; D2 < y.length || 0 <= B4; D2++, B4--) {
                b2 = u.reversed ? y[B4] : y[D2];
                a2 = b2.color ? b2.color : u.reversed ? u._colorSet[(y.length - 1 - D2) % u._colorSet.length] : u._colorSet[D2 % u._colorSet.length];
                c2 = b2.indexLabelPlacement || u.indexLabelPlacement || "outside";
                n3 = b2.indexLabelTextAlign || u.indexLabelTextAlign || "left";
                d2 = b2.indexLabelBackgroundColor || u.indexLabelBackgroundColor || (w ? "transparent" : null);
                e2 = b2.indexLabelFontColor || u.indexLabelFontColor || "#979797";
                f2 = s(b2.indexLabelFontSize) ? u.indexLabelFontSize : b2.indexLabelFontSize;
                l2 = b2.indexLabelFontStyle || u.indexLabelFontStyle || "normal";
                k2 = b2.indexLabelFontFamily || u.indexLabelFontFamily || "arial";
                h3 = b2.indexLabelFontWeight || u.indexLabelFontWeight || "normal";
                a2 = b2.indexLabelLineColor || u.options.indexLabelLineColor || a2;
                m2 = "number" === typeof b2.indexLabelLineThickness ? b2.indexLabelLineThickness : "number" === typeof u.indexLabelLineThickness ? u.indexLabelLineThickness : 2;
                p2 = b2.indexLabelLineDashType || u.indexLabelLineDashType || "solid";
                q2 = "undefined" !== typeof b2.indexLabelWrap ? b2.indexLabelWrap : "undefined" !== typeof u.indexLabelWrap ? u.indexLabelWrap : true;
                t = u.dataPointIds[D2];
                A2._eventManager.objectMap[t] = { id: t, objectType: "dataPoint", dataPointIndex: D2, dataSeriesIndex: 0, funnelSection: R[u.reversed ? y.length - 1 - D2 : D2] };
                "inside" === u.indexLabelPlacement && (C[D2] = D2 !== ca3 ? u.reversed ? R[D2].x2 - R[D2].x1 : R[D2].x3 - R[D2].x4 : R[D2].x3 - R[D2].x6, 20 > C[D2] && (C[D2] = D2 !== ca3 ? u.reversed ? R[D2].x3 - R[D2].x4 : R[D2].x2 - R[D2].x1 : R[D2].x2 - R[D2].x1, C[D2] /= 2));
                t = b2.indexLabelMaxWidth ? b2.indexLabelMaxWidth : u.options.indexLabelMaxWidth ? u.indexLabelMaxWidth : C[D2];
                if (t > C[D2] || 0 > t)
                  t = C[D2];
                x2[D2] = "inside" === u.indexLabelPlacement ? q2 ? Math.max(R[D2].height, f2) : 1.5 * f2 : false;
                v4 = A2.getPercentAndTotal(u, b2);
                if (u.indexLabelFormatter || b2.indexLabelFormatter)
                  z2 = { chart: A2.options, dataSeries: u, dataPoint: b2, total: v4.total, percent: v4.percent };
                b2 = b2.indexLabelFormatter ? b2.indexLabelFormatter(z2) : b2.indexLabel ? A2.replaceKeywordsWithValue(b2.indexLabel, b2, u, D2) : u.indexLabelFormatter ? u.indexLabelFormatter(z2) : u.indexLabel ? A2.replaceKeywordsWithValue(u.indexLabel, b2, u, D2) : b2.label ? b2.label : "";
                0 >= m2 && (m2 = 0);
                1e3 > t && 1e3 - t < r2 && (t += 1e3 - t);
                P2.roundRect || Da(P2);
                c2 = new ja(P2, {
                  fontSize: f2,
                  fontFamily: k2,
                  fontColor: e2,
                  fontStyle: l2,
                  fontWeight: h3,
                  horizontalAlign: c2,
                  textAlign: n3,
                  backgroundColor: d2,
                  maxWidth: t,
                  maxHeight: false === x2[D2] ? q2 ? 4.28571429 * f2 : 1.5 * f2 : x2[D2],
                  text: b2,
                  padding: da2
                });
                c2.measureText();
                I.push({ textBlock: c2, id: u.reversed ? B4 : D2, isDirty: false, lineColor: a2, lineThickness: m2, lineDashType: p2, height: c2.height < c2.maxHeight ? c2.height : c2.maxHeight, width: c2.width < c2.maxWidth ? c2.width : c2.maxWidth });
              }
            }
          }
          function e() {
            var a2, b2, c2, d2, e2, f2 = [];
            e2 = false;
            c2 = 0;
            for (var g2, l2 = K3 - V2 - X2 / 2, l2 = u.options.indexLabelMaxWidth ? u.indexLabelMaxWidth > l2 ? l2 : u.indexLabelMaxWidth : l2, k2 = I.length - 1; 0 <= k2; k2--) {
              g2 = y[I[k2].id];
              c2 = I[k2];
              d2 = c2.textBlock;
              b2 = (a2 = q(k2) < R.length ? I[q(k2)] : null) ? a2.textBlock : null;
              c2 = c2.height;
              a2 && d2.y + c2 + da2 > b2.y && (e2 = true);
              c2 = g2.indexLabelMaxWidth || l2;
              if (c2 > l2 || 0 > c2)
                c2 = l2;
              f2.push(c2);
            }
            if (e2)
              for (k2 = I.length - 1; 0 <= k2; k2--)
                a2 = R[k2], I[k2].textBlock.maxWidth = f2[f2.length - (k2 + 1)], I[k2].textBlock.measureText(), I[k2].textBlock.x = K3 - l2, c2 = I[k2].textBlock.height < I[k2].textBlock.maxHeight ? I[k2].textBlock.height : I[k2].textBlock.maxHeight, e2 = I[k2].textBlock.width < I[k2].textBlock.maxWidth ? I[k2].textBlock.width : I[k2].textBlock.maxWidth, I[k2].height = c2, I[k2].width = e2, c2 = "undefined" !== typeof a2.x5 ? (a2.y2 + a2.y4) / 2 : (a2.y2 + a2.y3) / 2, I[k2].textBlock.y = c2 - I[k2].height / 2, u.reversed ? (I[k2].textBlock.y + I[k2].height > U3 + z && (I[k2].textBlock.y = U3 + z - I[k2].height), I[k2].textBlock.y < ta - z && (I[k2].textBlock.y = ta - z)) : (I[k2].textBlock.y < U3 - z && (I[k2].textBlock.y = U3 - z), I[k2].textBlock.y + I[k2].height > ta + z && (I[k2].textBlock.y = ta + z - I[k2].height));
          }
          function f() {
            var a2, b2, c2, d2;
            if ("inside" !== u.indexLabelPlacement)
              for (var e2 = 0; e2 < R.length; e2++)
                0 == I[e2].textBlock.text.length ? I[e2].isDirty = true : (a2 = R[e2], c2 = "undefined" !== typeof a2.x5 ? (a2.y2 + a2.y4) / 2 : (a2.y2 + a2.y3) / 2, b2 = u.reversed ? "undefined" !== typeof a2.x5 ? c2 > Ca ? g(c2).x2 + 1 : (a2.x2 + a2.x3) / 2 + 1 : (a2.x2 + a2.x3) / 2 + 1 : "undefined" !== typeof a2.x5 ? c2 < Ca ? g(c2).x2 + 1 : (a2.x4 + a2.x3) / 2 + 1 : (a2.x2 + a2.x3) / 2 + 1, I[e2].textBlock.x = b2 + X2, I[e2].textBlock.y = c2 - I[e2].height / 2, u.reversed ? (I[e2].textBlock.y + I[e2].height > U3 + z && (I[e2].textBlock.y = U3 + z - I[e2].height), I[e2].textBlock.y < ta - z && (I[e2].textBlock.y = ta - z)) : (I[e2].textBlock.y < U3 - z && (I[e2].textBlock.y = U3 - z), I[e2].textBlock.y + I[e2].height > ta + z && (I[e2].textBlock.y = ta + z - I[e2].height)));
            else
              for (e2 = 0; e2 < R.length; e2++)
                0 == I[e2].textBlock.text.length ? I[e2].isDirty = true : (a2 = R[e2], b2 = a2.height, c2 = I[e2].height, d2 = I[e2].width, b2 >= c2 ? (b2 = e2 != ca3 ? (a2.x4 + a2.x3) / 2 - d2 / 2 : (a2.x5 + a2.x4) / 2 - d2 / 2, c2 = e2 != ca3 ? (a2.y1 + a2.y3) / 2 - c2 / 2 : (a2.y1 + a2.y4) / 2 - c2 / 2, I[e2].textBlock.x = b2, I[e2].textBlock.y = c2) : I[e2].isDirty = true);
          }
          function l() {
            function a2(b3, c3) {
              var d3;
              if (0 > b3 || b3 >= I.length)
                return 0;
              var e3, f3 = I[b3].textBlock;
              if (0 > c3) {
                c3 *= -1;
                e3 = p(b3);
                d3 = h2(e3, b3);
                if (d3 >= c3)
                  return f3.y -= c3, c3;
                if (0 == b3)
                  return 0 < d3 && (f3.y -= d3), d3;
                d3 += a2(e3, -(c3 - d3));
                0 < d3 && (f3.y -= d3);
                return d3;
              }
              e3 = q(b3);
              d3 = h2(b3, e3);
              if (d3 >= c3)
                return f3.y += c3, c3;
              if (b3 == R.length - 1)
                return 0 < d3 && (f3.y += d3), d3;
              d3 += a2(e3, c3 - d3);
              0 < d3 && (f3.y += d3);
              return d3;
            }
            function b2() {
              var a3, d3, e3, f3, g3 = 0, l3;
              f3 = (N2 - $ + 2 * z) / m2;
              l3 = m2;
              for (var k3, h3 = 1; h3 < l3; h3++) {
                e3 = h3 * f3;
                for (var t = I.length - 1; 0 <= t; t--)
                  !I[t].isDirty && (I[t].textBlock.y < e3 && I[t].textBlock.y + I[t].height > e3) && (k3 = q(t), !(k3 >= I.length - 1) && I[t].textBlock.y + I[t].height + da2 > I[k3].textBlock.y && (I[t].textBlock.y = I[t].textBlock.y + I[t].height - e3 > e3 - I[t].textBlock.y ? e3 + 1 : e3 - I[t].height - 1));
              }
              for (k3 = R.length - 1; 0 < k3; k3--)
                if (!I[k3].isDirty) {
                  e3 = p(k3);
                  if (0 > e3 && (e3 = 0, I[e3].isDirty))
                    break;
                  if (I[k3].textBlock.y < I[e3].textBlock.y + I[e3].height) {
                    d3 = d3 || k3;
                    f3 = k3;
                    for (l3 = 0; I[f3].textBlock.y < I[e3].textBlock.y + I[e3].height + da2; ) {
                      a3 = a3 || I[f3].textBlock.y + I[f3].height;
                      l3 += I[f3].height;
                      l3 += da2;
                      f3 = e3;
                      if (0 >= f3) {
                        f3 = 0;
                        l3 += I[f3].height;
                        break;
                      }
                      e3 = p(f3);
                      if (0 > e3) {
                        f3 = 0;
                        l3 += I[f3].height;
                        break;
                      }
                    }
                    if (f3 != k3) {
                      g3 = I[f3].textBlock.y;
                      a3 -= g3;
                      a3 = l3 - a3;
                      g3 = c2(a3, d3, f3);
                      break;
                    }
                  }
                }
              return g3;
            }
            function c2(a3, b3, d3) {
              var e3 = [], f3 = 0, g3 = 0;
              for (a3 = Math.abs(a3); d3 <= b3; d3++)
                e3.push(R[d3]);
              e3.sort(function(a4, b4) {
                return a4.height - b4.height;
              });
              for (d3 = 0; d3 < e3.length; d3++)
                if (b3 = e3[d3], f3 < a3)
                  g3++, f3 += I[b3.id].height + da2, I[b3.id].textBlock.text = "", I[b3.id].indexLabelText = "", I[b3.id].isDirty = true, I[b3.id].textBlock.measureText();
                else
                  break;
              return g3;
            }
            for (var d2, e2, f2, g2, l2, k2, m2 = 1, r2 = 0; r2 < 2 * m2; r2++) {
              for (var n3 = I.length - 1; 0 <= n3 && !(0 <= p(n3) && p(n3), f2 = I[n3], g2 = f2.textBlock, k2 = (l2 = q(n3) < R.length ? I[q(n3)] : null) ? l2.textBlock : null, d2 = +f2.height.toFixed(6), e2 = +g2.y.toFixed(6), !f2.isDirty && (l2 && e2 + d2 + da2 > +k2.y.toFixed(6)) && (d2 = g2.y + d2 + da2 - k2.y, e2 = a2(n3, -d2), e2 < d2 && (0 < e2 && (d2 -= e2), e2 = a2(q(n3), d2), e2 != d2))); n3--)
                ;
              b2();
            }
          }
          function h2(a2, b2) {
            return (b2 < R.length ? I[b2].textBlock.y : u.reversed ? U3 + z : ta + z) - (0 > a2 ? u.reversed ? ta - z : U3 - z : I[a2].textBlock.y + I[a2].height + da2);
          }
          function n2(a2, b2, c2) {
            var d2, e2, g2, l2 = [], h3 = z, p2 = [];
            -1 !== b2 && (0 <= Z3.indexOf(b2) ? (e2 = Z3.indexOf(b2), Z3.splice(e2, 1)) : (Z3.push(b2), Z3 = Z3.sort(function(a3, b3) {
              return a3 - b3;
            })));
            if (0 === Z3.length)
              l2 = ia3;
            else {
              e2 = z * (1 != Z3.length || 0 != Z3[0] && Z3[0] != R.length - 1 ? 2 : 1) / k();
              for (var q2 = 0; q2 < R.length; q2++) {
                if (1 == Z3.length && 0 == Z3[0]) {
                  if (0 === q2) {
                    l2.push(ia3[q2]);
                    d2 = h3;
                    continue;
                  }
                } else
                  0 === q2 && (d2 = -1 * h3);
                l2.push(ia3[q2] + d2);
                if (0 <= Z3.indexOf(q2) || q2 < R.length && 0 <= Z3.indexOf(q2 + 1))
                  d2 += e2;
              }
            }
            g2 = function() {
              for (var a3 = [], b3 = 0; b3 < R.length; b3++)
                a3.push(l2[b3] - R[b3].y1);
              return a3;
            }();
            var t = { startTime: (/* @__PURE__ */ new Date()).getTime(), duration: c2 || 500, easingFunction: function(a3, b3, c3, d3) {
              return M.easing.easeOutQuart(a3, b3, c3, d3);
            }, changeSection: function(a3) {
              for (var b3, c3, d3 = 0; d3 < R.length; d3++)
                b3 = g2[d3], c3 = R[d3], b3 *= a3, "undefined" === typeof p2[d3] && (p2[d3] = 0), 0 > p2 && (p2 *= -1), c3.y1 += b3 - p2[d3], c3.y2 += b3 - p2[d3], c3.y3 += b3 - p2[d3], c3.y4 += b3 - p2[d3], c3.y5 && (c3.y5 += b3 - p2[d3], c3.y6 += b3 - p2[d3]), p2[d3] = b3;
            } };
            a2._animator.animate(0, c2, function(c3) {
              var d3 = a2.plotArea.ctx || a2.ctx;
              ha = true;
              d3.clearRect(x.x1, x.y1, x.x2 - x.x1, x.y2 - x.y1);
              d3.fillStyle = a2.backgroundColor;
              d3.fillRect(x.x1, x.y1, x.width, x.height);
              t.changeSection(c3, b2);
              var e3 = {};
              e3.dataSeries = u;
              e3.dataPoint = u.reversed ? u.dataPoints[y.length - 1 - b2] : u.dataPoints[b2];
              e3.index = u.reversed ? y.length - 1 - b2 : b2;
              a2.toolTip.highlightObjects([e3]);
              for (e3 = 0; e3 < R.length; e3++)
                ra2(d3, R[e3], u.fillOpacity);
              v3(d3);
              L && ("inside" !== u.indexLabelPlacement ? m(d3) : f(), r(d3));
              1 <= c3 && (ha = false);
            }, null, M.easing.easeOutQuart);
          }
          function k() {
            for (var a2 = 0, b2 = 0; b2 < R.length - 1; b2++)
              (0 <= Z3.indexOf(b2) || 0 <= Z3.indexOf(b2 + 1)) && a2++;
            return a2;
          }
          function m(a2) {
            for (var b2, c2, d2, e2, f2 = 0; f2 < R.length; f2++)
              e2 = 1 === I[f2].lineThickness % 2 ? 0.5 : 0, c2 = ((R[f2].y2 + R[f2].y4) / 2 << 0) + e2, b2 = g(c2).x2 - 1, d2 = I[f2].textBlock.x, e2 = (I[f2].textBlock.y + I[f2].height / 2 << 0) + e2, I[f2].isDirty || 0 == I[f2].lineThickness || (a2.strokeStyle = I[f2].lineColor, a2.lineWidth = I[f2].lineThickness, a2.setLineDash && a2.setLineDash(J(I[f2].lineDashType, I[f2].lineThickness)), a2.beginPath(), a2.moveTo(b2, c2), a2.lineTo(d2, e2), a2.stroke());
          }
          function p(a2) {
            for (a2 -= 1; -1 <= a2 && -1 != a2 && I[a2].isDirty; a2--)
              ;
            return a2;
          }
          function q(a2) {
            for (a2 += 1; a2 <= R.length && a2 != R.length && I[a2].isDirty; a2++)
              ;
            return a2;
          }
          function g(a2) {
            for (var b2, c2 = 0; c2 < y.length; c2++)
              if (R[c2].y1 < a2 && R[c2].y4 > a2) {
                b2 = R[c2];
                break;
              }
            return b2 ? (a2 = b2.y6 ? a2 > b2.y6 ? b2.x3 + (b2.x4 - b2.x3) / (b2.y4 - b2.y3) * (a2 - b2.y3) : b2.x2 + (b2.x3 - b2.x2) / (b2.y3 - b2.y2) * (a2 - b2.y2) : b2.x2 + (b2.x3 - b2.x2) / (b2.y3 - b2.y2) * (a2 - b2.y2), { x1: a2, x2: a2 }) : -1;
          }
          function r(a2) {
            for (var b2 = 0; b2 < R.length; b2++)
              I[b2].isDirty || (a2 && (I[b2].textBlock.ctx = a2), I[b2].textBlock.render(true));
          }
          function v3(a2) {
            A2.plotArea.layoutManager.reset();
            a2.roundRect || Da(a2);
            A2.title && (A2.title.dockInsidePlotArea || "center" === A2.title.horizontalAlign && "center" === A2.title.verticalAlign) && (A2.title.ctx = a2, A2.title.render());
            if (A2.subtitles)
              for (var b2 = 0; b2 < A2.subtitles.length; b2++) {
                var c2 = A2.subtitles[b2];
                if (c2.dockInsidePlotArea || "center" === c2.horizontalAlign && "center" === c2.verticalAlign)
                  A2.subtitles.ctx = a2, c2.render();
              }
            A2.legend && (A2.legend.dockInsidePlotArea || "center" === A2.legend.horizontalAlign && "center" === A2.legend.verticalAlign) && (A2.legend.ctx = a2, A2.legend.setLayout(), A2.legend.render());
            va.fNg && va.fNg(A2);
          }
          var A2 = this;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            for (var u = this.data[a.dataSeriesIndexes[0]], y = u.dataPoints, x = this.plotArea, z = 0.025 * x.width, B3 = 0.01 * x.width, D = 0, E = x.height - 2 * z, G2 = Math.min(x.width - 2 * B3, 2.8 * x.height), L = false, S = 0; S < y.length; S++)
              if (!L && ("undefined" !== typeof y[S].indexLabel && null !== y[S].indexLabel && 0 < y[S].indexLabel.toString().length) && (L = true), !L && ("undefined" !== typeof y[S].label && null !== y[S].label && 0 < y[S].label.toString().length) && (L = true), !L && "function" === typeof u.indexLabelFormatter || "function" === typeof y[S].indexLabelFormatter)
                L = true;
            L = L || "undefined" !== typeof u.indexLabel && null !== u.indexLabel && 0 < u.indexLabel.toString().length;
            "inside" !== u.indexLabelPlacement && L || (B3 = (x.width - 0.75 * G2) / 2);
            var S = x.x1 + B3, K3 = x.x2 - B3, $ = x.y1 + z, N2 = x.y2 - z, P2 = a.targetCanvasCtx || this.plotArea.ctx || this.ctx;
            if (0 != u.length && (u.dataPoints && u.visible) && 0 !== y.length) {
              var Q3, F;
              a = 75 * G2 / 100;
              var X2 = 30 * (K3 - a) / 100;
              "funnel" === u.type ? (Q3 = s(u.options.neckHeight) ? 0.35 * E : u.neckHeight, F = s(u.options.neckWidth) ? 0.25 * a : u.neckWidth, "string" === typeof Q3 && Q3.match(/%$/) ? (Q3 = parseInt(Q3), Q3 = Q3 * E / 100) : Q3 = parseInt(Q3), "string" === typeof F && F.match(/%$/) ? (F = parseInt(F), F = F * a / 100) : F = parseInt(F), Q3 > E ? Q3 = E : 0 >= Q3 && (Q3 = 0), F > a ? F = a - 0.5 : 0 >= F && (F = 0)) : "pyramid" === u.type && (F = Q3 = 0, u.reversed = u.reversed ? false : true);
              var B3 = S + a / 2, T2 = S, V2 = S + a, U3 = u.reversed ? N2 : $, O = B3 - F / 2, W2 = B3 + F / 2, Ca = u.reversed ? $ + Q3 : N2 - Q3, ta = u.reversed ? $ : N2;
              a = [];
              var B3 = [], R = [], G2 = [], Y2 = $, ca3, aa3 = (Ca - U3) / (O - T2), fa3 = -aa3, S = "area" === (u.valueRepresents ? u.valueRepresents : "height") ? c() : d();
              if (-1 !== S) {
                if (u.reversed)
                  for (G2.push(Y2), F = S.length - 1; 0 < F; F--)
                    Y2 += S[F], G2.push(Y2);
                else
                  for (F = 0; F < S.length; F++)
                    Y2 += S[F], G2.push(Y2);
                if (u.reversed)
                  for (F = 0; F < S.length; F++)
                    G2[F] < Ca ? (a.push(O), B3.push(W2), ca3 = F) : (a.push((G2[F] - U3 + aa3 * T2) / aa3), B3.push((G2[F] - U3 + fa3 * V2) / fa3));
                else
                  for (F = 0; F < S.length; F++)
                    G2[F] < Ca ? (a.push((G2[F] - U3 + aa3 * T2) / aa3), B3.push((G2[F] - U3 + fa3 * V2) / fa3), ca3 = F) : (a.push(O), B3.push(W2));
                for (F = 0; F < S.length - 1; F++)
                  Y2 = u.reversed ? y[y.length - 1 - F].color ? y[y.length - 1 - F].color : u._colorSet[(y.length - 1 - F) % u._colorSet.length] : y[F].color ? y[F].color : u._colorSet[F % u._colorSet.length], F === ca3 ? R.push({ x1: a[F], y1: G2[F], x2: B3[F], y2: G2[F], x3: W2, y3: Ca, x4: B3[F + 1], y4: G2[F + 1], x5: a[F + 1], y5: G2[F + 1], x6: O, y6: Ca, id: F, height: G2[F + 1] - G2[F], color: Y2 }) : R.push({ x1: a[F], y1: G2[F], x2: B3[F], y2: G2[F], x3: B3[F + 1], y3: G2[F + 1], x4: a[F + 1], y4: G2[F + 1], id: F, height: G2[F + 1] - G2[F], color: Y2 });
                var da2 = 2, I = [], ha = false, Z3 = [], ia3 = [], S = false;
                a = a = 0;
                Ea(Z3);
                for (F = 0; F < y.length; F++)
                  y[F].exploded && (S = true, u.reversed ? Z3.push(y.length - 1 - F) : Z3.push(F));
                P2.clearRect(x.x1, x.y1, x.width, x.height);
                P2.fillStyle = A2.backgroundColor;
                P2.fillRect(x.x1, x.y1, x.width, x.height);
                if (L && u.visible && (b(), f(), e(), "inside" !== u.indexLabelPlacement)) {
                  l();
                  for (F = 0; F < y.length; F++)
                    I[F].isDirty || (a = I[F].textBlock.x + I[F].width, a = (K3 - a) / 2, 0 == F && (D = a), D > a && (D = a));
                  for (F = 0; F < R.length; F++)
                    R[F].x1 += D, R[F].x2 += D, R[F].x3 += D, R[F].x4 += D, R[F].x5 && (R[F].x5 += D, R[F].x6 += D), I[F].textBlock.x += D;
                }
                for (F = 0; F < R.length; F++)
                  D = R[F], ra2(P2, D, u.fillOpacity), ia3.push(D.y1);
                v3(P2);
                L && u.visible && ("inside" === u.indexLabelPlacement || A2.animationEnabled || m(P2), A2.animationEnabled || r());
                if (!L)
                  for (F = 0; F < y.length; F++)
                    D = u.dataPointIds[F], a = { id: D, objectType: "dataPoint", dataPointIndex: F, dataSeriesIndex: 0, funnelSection: R[u.reversed ? y.length - 1 - F : F] }, A2._eventManager.objectMap[D] = a;
                !A2.animationEnabled && S ? n2(A2, -1, 0) : A2.animationEnabled && !A2.animatedRender && n2(A2, -1, 0);
                this.funnelPyramidClickHandler = function(a2) {
                  var b2 = -1;
                  if (!ha && !A2.isAnimating && (s(a2.dataSeries.explodeOnClick) || a2.dataSeries.explodeOnClick) && (b2 = u.reversed ? y.length - 1 - a2.dataPointIndex : a2.dataPointIndex, 0 <= b2)) {
                    a2 = b2;
                    if ("funnel" === u.type || "pyramid" === u.type)
                      u.reversed ? y[y.length - 1 - a2].exploded = y[y.length - 1 - a2].exploded ? false : true : y[a2].exploded = y[a2].exploded ? false : true;
                    n2(A2, b2, 500);
                  }
                };
                return { source: P2, dest: this.plotArea.ctx, animationCallback: function(a2, b2) {
                  M.fadeInAnimation(a2, b2);
                  1 <= a2 && (n2(A2, -1, 500), v3(A2.plotArea.ctx || A2.ctx));
                }, easingFunction: M.easing.easeInQuad, animationBase: 0 };
              }
            }
          }
        };
        n.prototype.requestAnimFrame = function() {
          return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(a) {
            window.setTimeout(a, 1e3 / 60);
          };
        }();
        n.prototype.cancelRequestAnimFrame = window.cancelAnimationFrame || window.webkitCancelRequestAnimationFrame || window.mozCancelRequestAnimationFrame || window.oCancelRequestAnimationFrame || window.msCancelRequestAnimationFrame || clearTimeout;
        n.prototype.set = function(a, d, c) {
          c = "undefined" === typeof c ? true : c;
          "options" === a ? (this.options = d, c && this.render()) : n.base.set.call(this, a, d, c);
        };
        n.prototype.exportChart = function(a) {
          a = "undefined" === typeof a ? {} : a;
          var d = a.format ? a.format : "png", c = a.fileName ? a.fileName : this.exportFileName;
          if (a.toDataURL)
            return this.canvas.toDataURL("image/" + d);
          var b = this.canvas;
          if (b && d && c) {
            c = c + "." + d;
            a = "image/" + d;
            var b = b.toDataURL(a), e = false, f = document.createElement("a");
            f.download = c;
            f.href = b;
            if ("undefined" !== typeof Blob && new Blob()) {
              for (var l = b.replace(/^data:[a-z\/]*;base64,/, ""), l = atob(l), h2 = new ArrayBuffer(l.length), h2 = new Uint8Array(h2), n2 = 0; n2 < l.length; n2++)
                h2[n2] = l.charCodeAt(n2);
              d = new Blob([h2.buffer], { type: "image/" + d });
              try {
                window.navigator.msSaveBlob(d, c), e = true;
              } catch (k) {
                f.dataset.downloadurl = [a, f.download, f.href].join(":"), f.href = window.URL.createObjectURL(d);
              }
            }
            if (!e)
              try {
                event = document.createEvent("MouseEvents"), event.initMouseEvent(
                  "click",
                  true,
                  false,
                  window,
                  0,
                  0,
                  0,
                  0,
                  0,
                  false,
                  false,
                  false,
                  false,
                  0,
                  null
                ), f.dispatchEvent ? f.dispatchEvent(event) : f.fireEvent && f.fireEvent("onclick");
              } catch (m) {
                d = window.open(), d.document.write("<img src='" + b + "'></img><div>Please right click on the image and save it to your device</div>"), d.document.close();
              }
          }
        };
        n.prototype.print = function() {
          var a = this.exportChart({ toDataURL: true }), d = document.createElement("iframe");
          d.setAttribute("class", "canvasjs-chart-print-frame");
          V(d, {
            position: "absolute",
            width: "100%",
            border: "0px",
            margin: "0px 0px 0px 0px",
            padding: "0px 0px 0px 0px"
          });
          d.style.height = this.height + "px";
          this._canvasJSContainer.appendChild(d);
          var c = this, b = d.contentWindow || d.contentDocument.document || d.contentDocument;
          b.document.open();
          b.document.write('<!DOCTYPE HTML>\n<html><body><img src="' + a + '"/><body/></html>');
          b.document.body && b.document.body.style && (b.document.body.style.margin = "0px 0px 0px 0px", b.document.body.style.padding = "0px 0px 0px 0px");
          b.document.close();
          setTimeout(function() {
            b.focus();
            b.print();
            setTimeout(
              function() {
                c._canvasJSContainer.removeChild(d);
              },
              1e3
            );
          }, 500);
        };
        n.prototype.getPercentAndTotal = function(a, d) {
          var c = null, b = null, e = c = null;
          if (0 <= a.type.indexOf("stacked"))
            b = 0, c = d.x.getTime ? d.x.getTime() : d.x, c in a.plotUnit.yTotals && (b = a.plotUnit.yTotals[c], c = a.plotUnit.yAbsTotals[c], e = isNaN(d.y) ? 0 : 0 === c ? 0 : 100 * (d.y / c));
          else if ("pie" === a.type || "doughnut" === a.type || "funnel" === a.type || "pyramid" === a.type) {
            for (c = b = 0; c < a.dataPoints.length; c++)
              isNaN(a.dataPoints[c].y) || (b += a.dataPoints[c].y);
            e = isNaN(d.y) ? 0 : 100 * (d.y / b);
          }
          return { percent: e, total: b };
        };
        n.prototype.replaceKeywordsWithValue = function(a, d, c, b, e) {
          var f = this;
          e = "undefined" === typeof e ? 0 : e;
          if ((0 <= c.type.indexOf("stacked") || "pie" === c.type || "doughnut" === c.type || "funnel" === c.type || "pyramid" === c.type) && (0 <= a.indexOf("#percent") || 0 <= a.indexOf("#total"))) {
            var l = "#percent", h2 = "#total", n2 = this.getPercentAndTotal(c, d), h2 = isNaN(n2.total) ? h2 : n2.total, l = isNaN(n2.percent) ? l : n2.percent;
            do {
              n2 = "";
              if (c.percentFormatString)
                n2 = c.percentFormatString;
              else {
                var n2 = "#,##0.", k = Math.max(Math.ceil(Math.log(1 / Math.abs(l)) / Math.LN10), 2);
                if (isNaN(k) || !isFinite(k))
                  k = 2;
                for (var m = 0; m < k; m++)
                  n2 += "#";
                c.percentFormatString = n2;
              }
              a = a.replace("#percent", da(l, n2, f._cultureInfo));
              a = a.replace("#total", da(h2, c.yValueFormatString ? c.yValueFormatString : "#,##0.########", f._cultureInfo));
            } while (0 <= a.indexOf("#percent") || 0 <= a.indexOf("#total"));
          }
          return a.replace(/\{.*?\}|"[^"]*"|'[^']*'/g, function(a2) {
            if ('"' === a2[0] && '"' === a2[a2.length - 1] || "'" === a2[0] && "'" === a2[a2.length - 1])
              return a2.slice(1, a2.length - 1);
            a2 = Ha(a2.slice(1, a2.length - 1));
            a2 = a2.replace("#index", e);
            var l2 = null;
            try {
              var g = a2.match(/(.*?)\s*\[\s*(.*?)\s*\]/);
              g && 0 < g.length && (l2 = Ha(g[2]), a2 = Ha(g[1]));
            } catch (k2) {
            }
            g = null;
            if ("color" === a2)
              return "waterfall" === c.type ? d.color ? d.color : 0 < d.y ? c.risingColor : c.fallingColor : "error" === c.type ? c.color ? c.color : c._colorSet[l2 % c._colorSet.length] : d.color ? d.color : c.color ? c.color : c._colorSet[b % c._colorSet.length];
            if (d.hasOwnProperty(a2))
              g = d;
            else if (c.hasOwnProperty(a2))
              g = c;
            else
              return "";
            g = g[a2];
            null !== l2 && (g = g[l2]);
            return "x" === a2 ? (c.axisX && "dateTime" === c.axisX.valueType || "dateTime" === c.xValueType || d.x && d.x.getTime) && !c.axisX.logarithmic ? Ba(g, d.xValueFormatString ? d.xValueFormatString : c.xValueFormatString ? c.xValueFormatString : c.xValueFormatString = f.axisX && f.axisX.autoValueFormatString ? f.axisX.autoValueFormatString : "DD MMM YY", f._cultureInfo) : da(g, d.xValueFormatString ? d.xValueFormatString : c.xValueFormatString ? c.xValueFormatString : c.xValueFormatString = "#,##0.########", f._cultureInfo) : "y" === a2 ? da(g, d.yValueFormatString ? d.yValueFormatString : c.yValueFormatString ? c.yValueFormatString : c.yValueFormatString = "#,##0.########", f._cultureInfo) : "z" === a2 ? da(g, d.zValueFormatString ? d.zValueFormatString : c.zValueFormatString ? c.zValueFormatString : c.zValueFormatString = "#,##0.########", f._cultureInfo) : g;
          });
        };
        oa(K2, G);
        K2.prototype.setLayout = function() {
          var a = this.dockInsidePlotArea ? this.chart.plotArea : this.chart, d = a.layoutManager.getFreeSpace(), c = null, b = 0, e = 0, f = 0, l = 0, h2 = this.markerMargin = this.chart.options.legend && !s(this.chart.options.legend.markerMargin) ? this.chart.options.legend.markerMargin : 0.3 * this.fontSize;
          this.height = 0;
          var n2 = [], k = [];
          if ("top" === this.verticalAlign || "bottom" === this.verticalAlign)
            this.orientation = "horizontal", c = this.verticalAlign, f = this.maxWidth = null !== this.maxWidth ? this.maxWidth : d.width, l = this.maxHeight = null !== this.maxHeight ? this.maxHeight : 0.5 * d.height;
          else if ("center" === this.verticalAlign) {
            this.orientation = "vertical";
            if ("left" === this.horizontalAlign || "center" === this.horizontalAlign || "right" === this.horizontalAlign)
              c = this.horizontalAlign;
            f = this.maxWidth = null !== this.maxWidth ? this.maxWidth : 0.5 * d.width;
            l = this.maxHeight = null !== this.maxHeight ? this.maxHeight : d.height;
          }
          this.errorMarkerColor = [];
          for (var m = 0; m < this.dataSeries.length; m++) {
            var p = this.dataSeries[m];
            if (p.dataPoints && p.dataPoints.length)
              if ("pie" !== p.type && "doughnut" !== p.type && "funnel" !== p.type && "pyramid" !== p.type) {
                var q = p.legendMarkerType = p.legendMarkerType ? p.legendMarkerType : "line" !== p.type && "stepLine" !== p.type && "spline" !== p.type && "scatter" !== p.type && "bubble" !== p.type || !p.markerType ? "error" === p.type && p._linkedSeries ? p._linkedSeries.legendMarkerType ? p._linkedSeries.legendMarkerType : Q2.getDefaultLegendMarker(p._linkedSeries.type) : Q2.getDefaultLegendMarker(p.type) : p.markerType, g = p.legendText ? p.legendText : this.itemTextFormatter ? this.itemTextFormatter({ chart: this.chart, legend: this.options, dataSeries: p, dataPoint: null }) : p.name, r = p.legendMarkerColor = p.legendMarkerColor ? p.legendMarkerColor : p.markerColor ? p.markerColor : "error" === p.type ? s(p.whiskerColor) ? p._colorSet[0] : p.whiskerColor : p._colorSet[0], w2 = p.markerSize || "line" !== p.type && "stepLine" !== p.type && "spline" !== p.type ? 0.75 * this.lineHeight : 0, v3 = p.legendMarkerBorderColor ? p.legendMarkerBorderColor : p.markerBorderColor, u = p.legendMarkerBorderThickness ? p.legendMarkerBorderThickness : p.markerBorderThickness ? Math.max(1, Math.round(0.2 * w2)) : 0;
                "error" === p.type && this.errorMarkerColor.push(r);
                g = this.chart.replaceKeywordsWithValue(g, p.dataPoints[0], p, m);
                q = { markerType: q, markerColor: r, text: g, textBlock: null, chartType: p.type, markerSize: w2, lineColor: p._colorSet[0], dataSeriesIndex: p.index, dataPointIndex: null, markerBorderColor: v3, markerBorderThickness: u };
                n2.push(q);
              } else
                for (var y = 0; y < p.dataPoints.length; y++) {
                  var x = p.dataPoints[y], q = x.legendMarkerType ? x.legendMarkerType : p.legendMarkerType ? p.legendMarkerType : Q2.getDefaultLegendMarker(p.type), g = x.legendText ? x.legendText : p.legendText ? p.legendText : this.itemTextFormatter ? this.itemTextFormatter({ chart: this.chart, legend: this.options, dataSeries: p, dataPoint: x }) : x.name ? x.name : "DataPoint: " + (y + 1), r = x.legendMarkerColor ? x.legendMarkerColor : p.legendMarkerColor ? p.legendMarkerColor : x.color ? x.color : p.color ? p.color : p._colorSet[y % p._colorSet.length], w2 = 0.75 * this.lineHeight, v3 = x.legendMarkerBorderColor ? x.legendMarkerBorderColor : p.legendMarkerBorderColor ? p.legendMarkerBorderColor : x.markerBorderColor ? x.markerBorderColor : p.markerBorderColor, u = x.legendMarkerBorderThickness ? x.legendMarkerBorderThickness : p.legendMarkerBorderThickness ? p.legendMarkerBorderThickness : x.markerBorderThickness || p.markerBorderThickness ? Math.max(1, Math.round(0.2 * w2)) : 0, g = this.chart.replaceKeywordsWithValue(g, x, p, y), q = {
                    markerType: q,
                    markerColor: r,
                    text: g,
                    textBlock: null,
                    chartType: p.type,
                    markerSize: w2,
                    dataSeriesIndex: m,
                    dataPointIndex: y,
                    markerBorderColor: v3,
                    markerBorderThickness: u
                  };
                  (x.showInLegend || p.showInLegend && false !== x.showInLegend) && n2.push(q);
                }
          }
          true === this.reversed && n2.reverse();
          if (0 < n2.length) {
            p = null;
            g = x = y = 0;
            x = null !== this.itemWidth ? null !== this.itemMaxWidth ? Math.min(this.itemWidth, this.itemMaxWidth, f) : this.itemMaxWidth = Math.min(this.itemWidth, f) : null !== this.itemMaxWidth ? Math.min(this.itemMaxWidth, f) : this.itemMaxWidth = f;
            w2 = 0 === w2 ? 0.75 * this.lineHeight : w2;
            x = (this.itemMaxWidth ? this.itemMaxWidth : x) - (w2 + h2);
            for (m = 0; m < n2.length; m++) {
              q = n2[m];
              r = x;
              if ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType)
                r -= 2 * 0.1 * this.lineHeight;
              if (!(0 >= l || "undefined" === typeof l || 0 >= r || "undefined" === typeof r))
                if ("horizontal" === this.orientation) {
                  q.textBlock = new ja(this.ctx, { x: 0, y: 0, maxWidth: r, maxHeight: this.itemWrap ? l : this.lineHeight, angle: 0, text: q.text, horizontalAlign: "left", fontSize: this.fontSize, fontFamily: this.fontFamily, fontWeight: this.fontWeight, fontColor: this.fontColor, fontStyle: this.fontStyle, textBaseline: "middle" });
                  q.textBlock.measureText();
                  null !== this.itemWidth && (q.textBlock.width = this.itemWidth - (w2 + h2 + ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType ? 2 * 0.1 * this.lineHeight : 0)));
                  if (!p || p.width + Math.round(q.textBlock.width + w2 + h2 + (0 === p.width ? 0 : this.horizontalSpacing) + ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType ? 2 * 0.1 * this.lineHeight : 0)) > f)
                    p = { items: [], width: 0 }, k.push(p), this.height += g, g = 0;
                  g = Math.max(g, q.textBlock.height ? q.textBlock.height : this.lineHeight);
                  q.textBlock.x = p.width;
                  q.textBlock.y = 0;
                  p.width += Math.round(q.textBlock.width + w2 + h2 + (0 === p.width ? 0 : this.horizontalSpacing) + ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType ? 2 * 0.1 * this.lineHeight : 0));
                  p.items.push(q);
                  this.width = Math.max(p.width, this.width);
                } else
                  q.textBlock = new ja(this.ctx, {
                    x: 0,
                    y: 0,
                    maxWidth: x,
                    maxHeight: true === this.itemWrap ? l : 1.5 * this.fontSize,
                    angle: 0,
                    text: q.text,
                    horizontalAlign: "left",
                    fontSize: this.fontSize,
                    fontFamily: this.fontFamily,
                    fontWeight: this.fontWeight,
                    fontColor: this.fontColor,
                    fontStyle: this.fontStyle,
                    textBaseline: "middle"
                  }), q.textBlock.measureText(), null !== this.itemWidth && (q.textBlock.width = this.itemWidth - (w2 + h2 + ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType ? 2 * 0.1 * this.lineHeight : 0))), this.height < l - this.lineHeight ? (p = { items: [], width: 0 }, k.push(p)) : (p = k[y], y = (y + 1) % k.length), p && (this.height += q.textBlock.height ? q.textBlock.height : this.lineHeight, q.textBlock.x = p.width, q.textBlock.y = 0, p.width += Math.round(q.textBlock.width + w2 + h2 + (0 === p.width ? 0 : this.horizontalSpacing) + ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType ? 2 * 0.1 * this.lineHeight : 0)), p.items.push(q), this.width = Math.max(p.width, this.width));
            }
            this.height = false === this.itemWrap ? k.length * this.lineHeight : this.height + g;
            this.height = Math.min(l, this.height);
            this.width = Math.min(f, this.width);
          }
          "top" === this.verticalAlign ? (e = "left" === this.horizontalAlign ? d.x1 : "right" === this.horizontalAlign ? d.x2 - this.width : d.x1 + d.width / 2 - this.width / 2, b = d.y1) : "center" === this.verticalAlign ? (e = "left" === this.horizontalAlign ? d.x1 : "right" === this.horizontalAlign ? d.x2 - this.width : d.x1 + d.width / 2 - this.width / 2, b = d.y1 + d.height / 2 - this.height / 2) : "bottom" === this.verticalAlign && (e = "left" === this.horizontalAlign ? d.x1 : "right" === this.horizontalAlign ? d.x2 - this.width : d.x1 + d.width / 2 - this.width / 2, b = d.y2 - this.height);
          this.items = n2;
          for (m = 0; m < this.items.length; m++)
            q = n2[m], q.id = ++this.chart._eventManager.lastObjectId, this.chart._eventManager.objectMap[q.id] = { id: q.id, objectType: "legendItem", legendItemIndex: m, dataSeriesIndex: q.dataSeriesIndex, dataPointIndex: q.dataPointIndex };
          this.markerSize = w2;
          this.rows = k;
          0 < n2.length && a.layoutManager.registerSpace(c, { width: this.width + 2 + 2, height: this.height + 5 + 5 });
          this.bounds = { x1: e, y1: b, x2: e + this.width, y2: b + this.height };
        };
        K2.prototype.render = function() {
          var a = this.bounds.x1, d = this.bounds.y1, c = this.markerMargin, b = this.maxWidth, e = this.maxHeight, f = this.markerSize, l = this.rows;
          (0 < this.borderThickness && this.borderColor || this.backgroundColor) && this.ctx.roundRect(a, d, this.width, this.height, this.cornerRadius, this.borderThickness, this.backgroundColor, this.borderColor);
          for (var h2 = 0, n2 = 0; n2 < l.length; n2++) {
            for (var k = l[n2], m = 0, p = 0; p < k.items.length; p++) {
              var q = k.items[p], g = q.textBlock.x + a + (0 === p ? 0.2 * f : this.horizontalSpacing), r = d + h2, s2 = g;
              this.chart.data[q.dataSeriesIndex].visible || (this.ctx.globalAlpha = 0.5);
              this.ctx.save();
              this.ctx.beginPath();
              this.ctx.rect(a, d, b, Math.max(e - e % this.lineHeight, 0));
              this.ctx.clip();
              if ("line" === q.chartType || "stepLine" === q.chartType || "spline" === q.chartType)
                this.ctx.strokeStyle = q.lineColor, this.ctx.lineWidth = Math.ceil(this.lineHeight / 8), this.ctx.beginPath(), this.ctx.moveTo(g - 0.1 * this.lineHeight, r + this.lineHeight / 2), this.ctx.lineTo(g + 0.85 * this.lineHeight, r + this.lineHeight / 2), this.ctx.stroke(), s2 -= 0.1 * this.lineHeight;
              if ("error" === q.chartType) {
                this.ctx.strokeStyle = this.errorMarkerColor[0];
                this.ctx.lineWidth = f / 8;
                this.ctx.beginPath();
                var w2 = g - 0.08 * this.lineHeight + 0.1 * this.lineHeight, u = r + 0.15 * this.lineHeight, y = 0.7 * this.lineHeight, x = y + 0.02 * this.lineHeight;
                this.ctx.moveTo(w2, u);
                this.ctx.lineTo(w2 + y, u);
                this.ctx.stroke();
                this.ctx.beginPath();
                this.ctx.moveTo(
                  w2 + y / 2,
                  u
                );
                this.ctx.lineTo(w2 + y / 2, u + x);
                this.ctx.stroke();
                this.ctx.beginPath();
                this.ctx.moveTo(w2, u + x);
                this.ctx.lineTo(w2 + y, u + x);
                this.ctx.stroke();
                this.errorMarkerColor.shift();
              }
              W.drawMarker(g + f / 2, r + this.lineHeight / 2, this.ctx, q.markerType, "error" === q.chartType || "line" === q.chartType || "spline" === q.chartType ? q.markerSize / 2 : q.markerSize, q.markerColor, q.markerBorderColor, q.markerBorderThickness);
              q.textBlock.x = g + c + f;
              if ("line" === q.chartType || "stepLine" === q.chartType || "spline" === q.chartType)
                q.textBlock.x += 0.1 * this.lineHeight;
              q.textBlock.y = Math.round(r + this.lineHeight / 2);
              q.textBlock.render(true);
              this.ctx.restore();
              m = 0 < p ? Math.max(m, q.textBlock.height ? q.textBlock.height : this.lineHeight) : q.textBlock.height ? q.textBlock.height : this.lineHeight;
              this.chart.data[q.dataSeriesIndex].visible || (this.ctx.globalAlpha = 1);
              g = X(q.id);
              this.ghostCtx.fillStyle = g;
              this.ghostCtx.beginPath();
              this.ghostCtx.fillRect(s2, q.textBlock.y - this.lineHeight / 2, q.textBlock.x + q.textBlock.width - s2, q.textBlock.height ? q.textBlock.height : this.lineHeight);
              q.x1 = this.chart._eventManager.objectMap[q.id].x1 = s2;
              q.y1 = this.chart._eventManager.objectMap[q.id].y1 = q.textBlock.y - this.lineHeight / 2;
              q.x2 = this.chart._eventManager.objectMap[q.id].x2 = q.textBlock.x + q.textBlock.width;
              q.y2 = this.chart._eventManager.objectMap[q.id].y2 = q.textBlock.y + (q.textBlock.height ? q.textBlock.height : this.lineHeight) - this.lineHeight / 2;
            }
            h2 += m;
          }
        };
        oa(Q2, G);
        Q2.prototype.getDefaultAxisPlacement = function() {
          var a = this.type;
          if ("column" === a || "line" === a || "stepLine" === a || "spline" === a || "area" === a || "stepArea" === a || "splineArea" === a || "stackedColumn" === a || "stackedLine" === a || "bubble" === a || "scatter" === a || "stackedArea" === a || "stackedColumn100" === a || "stackedLine100" === a || "stackedArea100" === a || "candlestick" === a || "ohlc" === a || "rangeColumn" === a || "rangeArea" === a || "rangeSplineArea" === a || "boxAndWhisker" === a || "waterfall" === a)
            return "normal";
          if ("bar" === a || "stackedBar" === a || "stackedBar100" === a || "rangeBar" === a)
            return "xySwapped";
          if ("pie" === a || "doughnut" === a || "funnel" === a || "pyramid" === a)
            return "none";
          "error" !== a && window.console.log("Unknown Chart Type: " + a);
          return null;
        };
        Q2.getDefaultLegendMarker = function(a) {
          if ("column" === a || "stackedColumn" === a || "stackedLine" === a || "bar" === a || "stackedBar" === a || "stackedBar100" === a || "bubble" === a || "scatter" === a || "stackedColumn100" === a || "stackedLine100" === a || "stepArea" === a || "candlestick" === a || "ohlc" === a || "rangeColumn" === a || "rangeBar" === a || "rangeArea" === a || "rangeSplineArea" === a || "boxAndWhisker" === a || "waterfall" === a)
            return "square";
          if ("line" === a || "stepLine" === a || "spline" === a || "pie" === a || "doughnut" === a)
            return "circle";
          if ("area" === a || "splineArea" === a || "stackedArea" === a || "stackedArea100" === a || "funnel" === a || "pyramid" === a)
            return "triangle";
          if ("error" === a)
            return "none";
          window.console.log("Unknown Chart Type: " + a);
          return null;
        };
        Q2.prototype.getDataPointAtX = function(a, d) {
          if (!this.dataPoints || 0 === this.dataPoints.length)
            return null;
          var c = { dataPoint: null, distance: Infinity, index: NaN }, b = null, e = 0, f = 0, l = 1, h2 = Infinity, n2 = 0, k = 0, m = 0;
          "none" !== this.chart.plotInfo.axisPlacement && (this.axisX.logarithmic ? (m = Math.log(this.dataPoints[this.dataPoints.length - 1].x / this.dataPoints[0].x), m = 1 < m ? Math.min(Math.max((this.dataPoints.length - 1) / m * Math.log(a / this.dataPoints[0].x) >> 0, 0), this.dataPoints.length) : 0) : (m = this.dataPoints[this.dataPoints.length - 1].x - this.dataPoints[0].x, m = 0 < m ? Math.min(Math.max((this.dataPoints.length - 1) / m * (a - this.dataPoints[0].x) >> 0, 0), this.dataPoints.length) : 0));
          for (; ; ) {
            f = 0 < l ? m + e : m - e;
            if (0 <= f && f < this.dataPoints.length) {
              var b = this.dataPoints[f], p = this.axisX.logarithmic ? b.x > a ? b.x / a : a / b.x : Math.abs(b.x - a);
              p < c.distance && (c.dataPoint = b, c.distance = p, c.index = f);
              b = p;
              b <= h2 ? h2 = b : 0 < l ? n2++ : k++;
              if (1e3 < n2 && 1e3 < k)
                break;
            } else if (0 > m - e && m + e >= this.dataPoints.length)
              break;
            -1 === l ? (e++, l = 1) : l = -1;
          }
          return d || (c.dataPoint.x.getTime ? c.dataPoint.x.getTime() : c.dataPoint.x) !== (a.getTime ? a.getTime() : a) ? d && null !== c.dataPoint ? c : null : c;
        };
        Q2.prototype.getDataPointAtXY = function(a, d, c) {
          if (!this.dataPoints || 0 === this.dataPoints.length || a < this.chart.plotArea.x1 || a > this.chart.plotArea.x2 || d < this.chart.plotArea.y1 || d > this.chart.plotArea.y2)
            return null;
          c = c || false;
          var b = [], e = 0, f = 0, l = 1, h2 = false, n2 = Infinity, k = 0, m = 0, p = 0;
          if ("none" !== this.chart.plotInfo.axisPlacement)
            if (p = (this.chart.axisX[0] ? this.chart.axisX[0] : this.chart.axisX2[0]).getXValueAt({ x: a, y: d }), this.axisX.logarithmic)
              var q = Math.log(this.dataPoints[this.dataPoints.length - 1].x / this.dataPoints[0].x), p = 1 < q ? Math.min(Math.max((this.dataPoints.length - 1) / q * Math.log(p / this.dataPoints[0].x) >> 0, 0), this.dataPoints.length) : 0;
            else
              q = this.dataPoints[this.dataPoints.length - 1].x - this.dataPoints[0].x, p = 0 < q ? Math.min(Math.max((this.dataPoints.length - 1) / q * (p - this.dataPoints[0].x) >> 0, 0), this.dataPoints.length) : 0;
          for (; ; ) {
            f = 0 < l ? p + e : p - e;
            if (0 <= f && f < this.dataPoints.length) {
              var q = this.chart._eventManager.objectMap[this.dataPointIds[f]], g = this.dataPoints[f], r = null;
              if (q) {
                switch (this.type) {
                  case "column":
                  case "stackedColumn":
                  case "stackedColumn100":
                  case "bar":
                  case "stackedBar":
                  case "stackedBar100":
                  case "rangeColumn":
                  case "rangeBar":
                  case "waterfall":
                  case "error":
                    a >= q.x1 && (a <= q.x2 && d >= q.y1 && d <= q.y2) && (b.push({ dataPoint: g, dataPointIndex: f, dataSeries: this, distance: Math.min(Math.abs(q.x1 - a), Math.abs(q.x2 - a), Math.abs(q.y1 - d), Math.abs(q.y2 - d)) }), h2 = true);
                    break;
                  case "line":
                  case "stepLine":
                  case "spline":
                  case "area":
                  case "stepArea":
                  case "stackedArea":
                  case "stackedArea100":
                  case "splineArea":
                  case "scatter":
                    var w2 = ma("markerSize", g, this) || 4, v3 = c ? 20 : w2, r = Math.sqrt(Math.pow(q.x1 - a, 2) + Math.pow(q.y1 - d, 2));
                    r <= v3 && b.push({ dataPoint: g, dataPointIndex: f, dataSeries: this, distance: r });
                    q = Math.abs(q.x1 - a);
                    q <= n2 ? n2 = q : 0 < l ? k++ : m++;
                    r <= w2 / 2 && (h2 = true);
                    break;
                  case "rangeArea":
                  case "rangeSplineArea":
                    w2 = ma("markerSize", g, this) || 4;
                    v3 = c ? 20 : w2;
                    r = Math.min(Math.sqrt(Math.pow(q.x1 - a, 2) + Math.pow(q.y1 - d, 2)), Math.sqrt(Math.pow(q.x1 - a, 2) + Math.pow(q.y2 - d, 2)));
                    r <= v3 && b.push({ dataPoint: g, dataPointIndex: f, dataSeries: this, distance: r });
                    q = Math.abs(q.x1 - a);
                    q <= n2 ? n2 = q : 0 < l ? k++ : m++;
                    r <= w2 / 2 && (h2 = true);
                    break;
                  case "bubble":
                    w2 = q.size;
                    r = Math.sqrt(Math.pow(q.x1 - a, 2) + Math.pow(q.y1 - d, 2));
                    r <= w2 / 2 && (b.push({ dataPoint: g, dataPointIndex: f, dataSeries: this, distance: r }), h2 = true);
                    break;
                  case "pie":
                  case "doughnut":
                    w2 = q.center;
                    v3 = "doughnut" === this.type ? q.percentInnerRadius * q.radius : 0;
                    r = Math.sqrt(Math.pow(w2.x - a, 2) + Math.pow(w2.y - d, 2));
                    r < q.radius && r > v3 && (r = Math.atan2(d - w2.y, a - w2.x), 0 > r && (r += 2 * Math.PI), r = Number(((180 * (r / Math.PI) % 360 + 360) % 360).toFixed(12)), w2 = Number(((180 * (q.startAngle / Math.PI) % 360 + 360) % 360).toFixed(12)), v3 = Number(((180 * (q.endAngle / Math.PI) % 360 + 360) % 360).toFixed(12)), 0 === v3 && 1 < q.endAngle && (v3 = 360), w2 >= v3 && (0 !== g.y && !s(g.y)) && (v3 += 360, r < w2 && (r += 360)), r > w2 && r < v3 && (b.push({ dataPoint: g, dataPointIndex: f, dataSeries: this, distance: 0 }), h2 = true));
                    break;
                  case "funnel":
                  case "pyramid":
                    r = q.funnelSection;
                    d > r.y1 && d < r.y4 && (r.y6 ? d > r.y6 ? (f = r.x6 + (r.x5 - r.x6) / (r.y5 - r.y6) * (d - r.y6), r = r.x3 + (r.x4 - r.x3) / (r.y4 - r.y3) * (d - r.y3)) : (f = r.x1 + (r.x6 - r.x1) / (r.y6 - r.y1) * (d - r.y1), r = r.x2 + (r.x3 - r.x2) / (r.y3 - r.y2) * (d - r.y2)) : (f = r.x1 + (r.x4 - r.x1) / (r.y4 - r.y1) * (d - r.y1), r = r.x2 + (r.x3 - r.x2) / (r.y3 - r.y2) * (d - r.y2)), a > f && a < r && (b.push({ dataPoint: g, dataPointIndex: q.dataPointIndex, dataSeries: this, distance: 0 }), h2 = true));
                    break;
                  case "boxAndWhisker":
                    if (a >= q.x1 - q.borderThickness / 2 && a <= q.x2 + q.borderThickness / 2 && d >= q.y4 - q.borderThickness / 2 && d <= q.y1 + q.borderThickness / 2 || Math.abs(q.x2 - a + q.x1 - a) < q.borderThickness && d >= q.y1 && d <= q.y4)
                      b.push({ dataPoint: g, dataPointIndex: f, dataSeries: this, distance: Math.min(Math.abs(q.x1 - a), Math.abs(q.x2 - a), Math.abs(q.y2 - d), Math.abs(q.y3 - d)) }), h2 = true;
                    break;
                  case "candlestick":
                    if (a >= q.x1 - q.borderThickness / 2 && a <= q.x2 + q.borderThickness / 2 && d >= q.y2 - q.borderThickness / 2 && d <= q.y3 + q.borderThickness / 2 || Math.abs(q.x2 - a + q.x1 - a) < q.borderThickness && d >= q.y1 && d <= q.y4)
                      b.push({ dataPoint: g, dataPointIndex: f, dataSeries: this, distance: Math.min(
                        Math.abs(q.x1 - a),
                        Math.abs(q.x2 - a),
                        Math.abs(q.y2 - d),
                        Math.abs(q.y3 - d)
                      ) }), h2 = true;
                    break;
                  case "ohlc":
                    if (Math.abs(q.x2 - a + q.x1 - a) < q.borderThickness && d >= q.y2 && d <= q.y3 || a >= q.x1 && a <= (q.x2 + q.x1) / 2 && d >= q.y1 - q.borderThickness / 2 && d <= q.y1 + q.borderThickness / 2 || a >= (q.x1 + q.x2) / 2 && a <= q.x2 && d >= q.y4 - q.borderThickness / 2 && d <= q.y4 + q.borderThickness / 2)
                      b.push({ dataPoint: g, dataPointIndex: f, dataSeries: this, distance: Math.min(Math.abs(q.x1 - a), Math.abs(q.x2 - a), Math.abs(q.y2 - d), Math.abs(q.y3 - d)) }), h2 = true;
                }
                if (h2 || 1e3 < k && 1e3 < m)
                  break;
              }
            } else if (0 > p - e && p + e >= this.dataPoints.length)
              break;
            -1 === l ? (e++, l = 1) : l = -1;
          }
          a = null;
          for (d = 0; d < b.length; d++)
            a ? b[d].distance <= a.distance && (a = b[d]) : a = b[d];
          return a;
        };
        Q2.prototype.getMarkerProperties = function(a, d, c, b) {
          var e = this.dataPoints, f = e[a].markerColor ? e[a].markerColor : this.markerColor ? this.markerColor : e[a].color ? e[a].color : this.color ? this.color : this._colorSet[a % this._colorSet.length], l = e[a].markerBorderColor ? e[a].markerBorderColor : this.markerBorderColor ? this.markerBorderColor : null, h2 = s(e[a].markerBorderThickness) ? this.markerBorderThickness ? this.markerBorderThickness : null : e[a].markerBorderThickness, n2 = e[a].markerType ? e[a].markerType : this.markerType;
          a = s(e[a].markerSize) ? this.markerSize : e[a].markerSize;
          return { x: d, y: c, ctx: b, type: n2, size: a, color: f, borderColor: l, borderThickness: h2 };
        };
        oa(A, G);
        A.prototype.createExtraLabelsForLog = function(a) {
          a = (a || 0) + 1;
          if (!(5 < a)) {
            var d = this.logLabelValues[0] || this.intervalStartPosition;
            if (Math.log(this.range) / Math.log(d / this.viewportMinimum) < this.noTicks - 1) {
              for (var c = A.getNiceNumber((d - this.viewportMinimum) / Math.min(Math.max(
                2,
                this.noTicks - this.logLabelValues.length
              ), 3), true), b = Math.ceil(this.viewportMinimum / c) * c; b < d; b += c)
                b < this.viewportMinimum || this.logLabelValues.push(b);
              this.logLabelValues.sort(Ra);
              this.createExtraLabelsForLog(a);
            }
          }
        };
        A.prototype.createLabels = function() {
          var a, d, c = 0, b = 0, e, f = 0, l = 0, b = 0, b = this.interval, h2 = 0, n2, k = 0.6 * this.chart.height, m;
          a = false;
          var p = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [], q = p.length ? s(this.scaleBreaks.firstBreakIndex) ? 0 : this.scaleBreaks.firstBreakIndex : 0;
          if ("axisX" !== this.type || "dateTime" !== this.valueType || this.logarithmic) {
            e = this.viewportMaximum;
            if (this.labels) {
              a = Math.ceil(b);
              for (var b = Math.ceil(this.intervalStartPosition), g = false, c = b; c < this.viewportMaximum; c += a)
                if (this.labels[c])
                  g = true;
                else {
                  g = false;
                  break;
                }
              g && (this.interval = a, this.intervalStartPosition = b);
            }
            if (this.logarithmic && !this.equidistantInterval)
              for (this.logLabelValues || (this.logLabelValues = [], this.createExtraLabelsForLog()), b = 0, g = q; b < this.logLabelValues.length; b++)
                if (c = this.logLabelValues[b], c < this.viewportMinimum)
                  b++;
                else {
                  for (; g < p.length && c > p[g].endValue; g++)
                    ;
                  a = g < p.length && c >= p[g].startValue && c <= p[g].endValue;
                  m = c;
                  a || (a = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.options, value: m, label: this.labels[m] ? this.labels[m] : null }) : "axisX" === this.type && this.labels[m] ? this.labels[m] : da(m, this.valueFormatString, this.chart._cultureInfo), a = new ja(this.ctx, {
                    x: 0,
                    y: 0,
                    maxWidth: f,
                    maxHeight: l,
                    angle: this.labelAngle,
                    text: this.prefix + a + this.suffix,
                    backgroundColor: this.labelBackgroundColor,
                    borderColor: this.labelBorderColor,
                    cornerRadius: this.labelCornerRadius,
                    textAlign: this.labelTextAlign,
                    fontSize: this.labelFontSize,
                    fontFamily: this.labelFontFamily,
                    fontWeight: this.labelFontWeight,
                    fontColor: this.labelFontColor,
                    fontStyle: this.labelFontStyle,
                    textBaseline: "middle",
                    borderThickness: 0
                  }), this._labels.push({ position: m, textBlock: a, effectiveHeight: null }));
                }
            g = q;
            for (c = this.intervalStartPosition; c <= e; c = parseFloat(1e-12 > this.interval ? this.logarithmic && this.equidistantInterval ? c * Math.pow(this.logarithmBase, this.interval) : c + this.interval : (this.logarithmic && this.equidistantInterval ? c * Math.pow(this.logarithmBase, this.interval) : c + this.interval).toFixed(12))) {
              for (; g < p.length && c > p[g].endValue; g++)
                ;
              a = g < p.length && c >= p[g].startValue && c <= p[g].endValue;
              m = c;
              a || (a = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.options, value: m, label: this.labels[m] ? this.labels[m] : null }) : "axisX" === this.type && this.labels[m] ? this.labels[m] : da(m, this.valueFormatString, this.chart._cultureInfo), a = new ja(this.ctx, {
                x: 0,
                y: 0,
                maxWidth: f,
                maxHeight: l,
                angle: this.labelAngle,
                text: this.prefix + a + this.suffix,
                textAlign: this.labelTextAlign,
                backgroundColor: this.labelBackgroundColor,
                borderColor: this.labelBorderColor,
                borderThickness: this.labelBorderThickness,
                cornerRadius: this.labelCornerRadius,
                fontSize: this.labelFontSize,
                fontFamily: this.labelFontFamily,
                fontWeight: this.labelFontWeight,
                fontColor: this.labelFontColor,
                fontStyle: this.labelFontStyle,
                textBaseline: "middle"
              }), this._labels.push({ position: m, textBlock: a, effectiveHeight: null }));
            }
          } else
            for (this.intervalStartPosition = this.getLabelStartPoint(
              new Date(this.viewportMinimum),
              this.intervalType,
              this.interval
            ), e = Xa(new Date(this.viewportMaximum), this.interval, this.intervalType), g = q, c = this.intervalStartPosition; c < e; Xa(c, b, this.intervalType)) {
              for (a = c.getTime(); g < p.length && a > p[g].endValue; g++)
                ;
              m = a;
              a = g < p.length && a >= p[g].startValue && a <= p[g].endValue;
              a || (a = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.options, value: new Date(m), label: this.labels[m] ? this.labels[m] : null }) : "axisX" === this.type && this.labels[m] ? this.labels[m] : Ba(m, this.valueFormatString, this.chart._cultureInfo), a = new ja(this.ctx, { x: 0, y: 0, maxWidth: f, backgroundColor: this.labelBackgroundColor, borderColor: this.labelBorderColor, borderThickness: this.labelBorderThickness, cornerRadius: this.labelCornerRadius, maxHeight: l, angle: this.labelAngle, text: this.prefix + a + this.suffix, textAlign: this.labelTextAlign, fontSize: this.labelFontSize, fontFamily: this.labelFontFamily, fontWeight: this.labelFontWeight, fontColor: this.labelFontColor, fontStyle: this.labelFontStyle, textBaseline: "middle" }), this._labels.push({
                position: m,
                textBlock: a,
                effectiveHeight: null,
                breaksLabelType: void 0
              }));
            }
          if ("bottom" === this._position || "top" === this._position)
            h2 = this.logarithmic && !this.equidistantInterval && 2 <= this._labels.length ? this.lineCoordinates.width * Math.log(Math.min(this._labels[this._labels.length - 1].position / this._labels[this._labels.length - 2].position, this._labels[1].position / this._labels[0].position)) / Math.log(this.range) : this.lineCoordinates.width / (this.logarithmic && this.equidistantInterval ? Math.log(this.range) / Math.log(this.logarithmBase) : Math.abs(this.range)) * T[this.intervalType + "Duration"] * this.interval, f = "undefined" === typeof this.options.labelMaxWidth ? 0.5 * this.chart.width >> 0 : this.options.labelMaxWidth, this.chart.panEnabled || (l = "undefined" === typeof this.options.labelWrap || this.labelWrap ? 0.8 * this.chart.height >> 0 : 1.5 * this.labelFontSize);
          else if ("left" === this._position || "right" === this._position)
            h2 = this.logarithmic && !this.equidistantInterval && 2 <= this._labels.length ? this.lineCoordinates.height * Math.log(Math.min(this._labels[this._labels.length - 1].position / this._labels[this._labels.length - 2].position, this._labels[1].position / this._labels[0].position)) / Math.log(this.range) : this.lineCoordinates.height / (this.logarithmic && this.equidistantInterval ? Math.log(this.range) / Math.log(this.logarithmBase) : Math.abs(this.range)) * T[this.intervalType + "Duration"] * this.interval, this.chart.panEnabled || (f = "undefined" === typeof this.options.labelMaxWidth ? 0.3 * this.chart.width >> 0 : this.options.labelMaxWidth), l = "undefined" === typeof this.options.labelWrap || this.labelWrap ? 0.3 * this.chart.height >> 0 : 1.5 * this.labelFontSize;
          for (b = 0; b < this._labels.length; b++) {
            a = this._labels[b].textBlock;
            a.maxWidth = f;
            a.maxHeight = l;
            var r = a.measureText();
            n2 = r.height;
          }
          e = [];
          q = p = 0;
          if (this.labelAutoFit || this.options.labelAutoFit) {
            if (s(this.labelAngle) || (this.labelAngle = (this.labelAngle % 360 + 360) % 360, 90 < this.labelAngle && 270 > this.labelAngle ? this.labelAngle -= 180 : 270 <= this.labelAngle && 360 >= this.labelAngle && (this.labelAngle -= 360)), "bottom" === this._position || "top" === this._position)
              if (f = 0.9 * h2 >> 0, q = 0, !this.chart.panEnabled && 1 <= this._labels.length) {
                this.sessionVariables.labelFontSize = this.labelFontSize;
                this.sessionVariables.labelMaxWidth = f;
                this.sessionVariables.labelMaxHeight = l;
                this.sessionVariables.labelAngle = this.labelAngle;
                this.sessionVariables.labelWrap = this.labelWrap;
                for (c = 0; c < this._labels.length; c++)
                  if (!this._labels[c].breaksLabelType) {
                    a = this._labels[c].textBlock;
                    for (var v3, g = a.text.split(" "), b = 0; b < g.length; b++)
                      m = g[b], this.ctx.font = a.fontStyle + " " + a.fontWeight + " " + a.fontSize + "px " + a.fontFamily, m = this.ctx.measureText(m), m.width > q && (v3 = c, q = m.width);
                  }
                c = 0;
                for (c = this.intervalStartPosition < this.viewportMinimum ? 1 : 0; c < this._labels.length; c++)
                  if (!this._labels[c].breaksLabelType) {
                    a = this._labels[c].textBlock;
                    r = a.measureText();
                    for (g = c + 1; g < this._labels.length; g++)
                      if (!this._labels[g].breaksLabelType) {
                        d = this._labels[g].textBlock;
                        d = d.measureText();
                        break;
                      }
                    e.push(a.height);
                    this.sessionVariables.labelMaxHeight = Math.max.apply(Math, e);
                    Math.cos(Math.PI / 180 * Math.abs(this.labelAngle));
                    Math.sin(Math.PI / 180 * Math.abs(this.labelAngle));
                    b = f * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)) + (l - a.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle));
                    if (s(this.options.labelAngle) && isNaN(this.options.labelAngle) && 0 !== this.options.labelAngle)
                      if (this.sessionVariables.labelMaxHeight = 0 === this.labelAngle ? l : Math.min((b - f * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle))) / Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)), b), m = (k - (n2 + a.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(-25))) / Math.sin(Math.PI / 180 * Math.abs(-25)), !s(this.options.labelWrap))
                        this.labelWrap ? s(this.options.labelMaxWidth) ? (this.sessionVariables.labelMaxWidth = Math.min(Math.max(f, q), m), this.sessionVariables.labelWrap = this.labelWrap, d && r.width + d.width >> 0 > 2 * f && (this.sessionVariables.labelAngle = -25)) : (this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth, this.sessionVariables.labelAngle = this.sessionVariables.labelMaxWidth > f ? -25 : this.sessionVariables.labelAngle) : s(this.options.labelMaxWidth) ? (this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxHeight = l, this.sessionVariables.labelMaxWidth = f, d && r.width + d.width >> 0 > 2 * f && (this.sessionVariables.labelAngle = -25, this.sessionVariables.labelMaxWidth = m)) : (this.sessionVariables.labelAngle = this.sessionVariables.labelMaxWidth > f ? -25 : this.sessionVariables.labelAngle, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth, this.sessionVariables.labelMaxHeight = l, this.sessionVariables.labelWrap = this.labelWrap);
                      else {
                        if (s(this.options.labelWrap)) {
                          if (!s(this.options.labelMaxWidth))
                            this.options.labelMaxWidth < f ? (this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth, this.sessionVariables.labelMaxHeight = b) : (this.sessionVariables.labelAngle = -25, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth, this.sessionVariables.labelMaxHeight = l);
                          else if (!s(d)) {
                            if (b = r.width + d.width >> 0, g = this.labelFontSize, q < f)
                              b - 2 * f > p && (p = b - 2 * f, b >= 2 * f && b < 2.2 * f ? (this.sessionVariables.labelMaxWidth = f, s(this.options.labelFontSize) && 12 < g && (g = Math.floor(12 / 13 * g), a.measureText()), this.sessionVariables.labelFontSize = s(this.options.labelFontSize) ? g : this.options.labelFontSize, this.sessionVariables.labelAngle = this.labelAngle) : b >= 2.2 * f && b < 2.8 * f ? (this.sessionVariables.labelAngle = -25, this.sessionVariables.labelMaxWidth = m, this.sessionVariables.labelFontSize = g) : b >= 2.8 * f && b < 3.2 * f ? (this.sessionVariables.labelMaxWidth = Math.max(f, q), this.sessionVariables.labelWrap = true, s(this.options.labelFontSize) && 12 < this.labelFontSize && (this.labelFontSize = Math.floor(12 / 13 * this.labelFontSize), a.measureText()), this.sessionVariables.labelFontSize = s(this.options.labelFontSize) ? g : this.options.labelFontSize, this.sessionVariables.labelAngle = this.labelAngle) : b >= 3.2 * f && b < 3.6 * f ? (this.sessionVariables.labelAngle = -25, this.sessionVariables.labelWrap = true, this.sessionVariables.labelMaxWidth = m, this.sessionVariables.labelFontSize = this.labelFontSize) : b > 3.6 * f && b < 5 * f ? (s(this.options.labelFontSize) && 12 < g && (g = Math.floor(12 / 13 * g), a.measureText()), this.sessionVariables.labelFontSize = s(this.options.labelFontSize) ? g : this.options.labelFontSize, this.sessionVariables.labelWrap = true, this.sessionVariables.labelAngle = -25, this.sessionVariables.labelMaxWidth = m) : b > 5 * f && (this.sessionVariables.labelWrap = true, this.sessionVariables.labelMaxWidth = f, this.sessionVariables.labelFontSize = g, this.sessionVariables.labelMaxHeight = l, this.sessionVariables.labelAngle = this.labelAngle));
                            else if (v3 === c && (0 === v3 && q + this._labels[v3 + 1].textBlock.measureText().width - 2 * f > p || v3 === this._labels.length - 1 && q + this._labels[v3 - 1].textBlock.measureText().width - 2 * f > p || 0 < v3 && v3 < this._labels.length - 1 && q + this._labels[v3 + 1].textBlock.measureText().width - 2 * f > p && q + this._labels[v3 - 1].textBlock.measureText().width - 2 * f > p))
                              p = 0 === v3 ? q + this._labels[v3 + 1].textBlock.measureText().width - 2 * f : q + this._labels[v3 - 1].textBlock.measureText().width - 2 * f, this.sessionVariables.labelFontSize = s(this.options.labelFontSize) ? g : this.options.labelFontSize, this.sessionVariables.labelWrap = true, this.sessionVariables.labelAngle = -25, this.sessionVariables.labelMaxWidth = m;
                            else if (0 === p)
                              for (this.sessionVariables.labelFontSize = s(this.options.labelFontSize) ? g : this.options.labelFontSize, this.sessionVariables.labelWrap = true, b = 0; b < this._labels.length; b++)
                                a = this._labels[b].textBlock, a.maxWidth = this.sessionVariables.labelMaxWidth = Math.min(Math.max(f, q), m), r = a.measureText(), b < this._labels.length - 1 && (g = b + 1, d = this._labels[g].textBlock, d.maxWidth = this.sessionVariables.labelMaxWidth = Math.min(Math.max(f, q), m), d = d.measureText(), r.width + d.width >> 0 > 2 * f && (this.sessionVariables.labelAngle = -25));
                          }
                        }
                      }
                    else
                      (this.sessionVariables.labelAngle = this.labelAngle, this.sessionVariables.labelMaxHeight = 0 === this.labelAngle ? l : Math.min((b - f * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle))) / Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)), b), m = 0 != this.labelAngle ? (k - (n2 + a.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle))) / Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)) : f, this.sessionVariables.labelMaxHeight = this.labelWrap ? (k - m * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle))) / Math.cos(Math.PI / 180 * Math.abs(this.labelAngle)) : 1.5 * this.labelFontSize, s(this.options.labelWrap)) ? s(this.options.labelWrap) && (this.labelWrap && !s(this.options.labelMaxWidth) ? (this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : m, this.sessionVariables.labelMaxHeight = l) : (this.sessionVariables.labelAngle = this.labelAngle, this.sessionVariables.labelMaxWidth = m, this.sessionVariables.labelMaxHeight = b < 0.9 * h2 ? 0.9 * h2 : b, this.sessionVariables.labelWrap = this.labelWrap)) : (this.options.labelWrap ? (this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : m) : (s(this.options.labelMaxWidth), this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : m, this.sessionVariables.labelWrap = this.labelWrap), this.sessionVariables.labelMaxHeight = l);
                  }
                for (b = 0; b < this._labels.length; b++)
                  a = this._labels[b].textBlock, a.maxWidth = this.labelMaxWidth = this.sessionVariables.labelMaxWidth, a.fontSize = this.sessionVariables.labelFontSize, a.angle = this.labelAngle = this.sessionVariables.labelAngle, a.wrap = this.labelWrap = this.sessionVariables.labelWrap, a.maxHeight = this.sessionVariables.labelMaxHeight, a.measureText();
              } else
                for (c = 0; c < this._labels.length; c++)
                  a = this._labels[c].textBlock, a.maxWidth = this.labelMaxWidth = s(this.options.labelMaxWidth) ? s(this.sessionVariables.labelMaxWidth) ? this.sessionVariables.labelMaxWidth = f : this.sessionVariables.labelMaxWidth : this.options.labelMaxWidth, a.fontSize = this.labelFontSize = s(this.options.labelFontSize) ? s(this.sessionVariables.labelFontSize) ? this.sessionVariables.labelFontSize = this.labelFontSize : this.sessionVariables.labelFontSize : this.options.labelFontSize, a.angle = this.labelAngle = s(this.options.labelAngle) ? s(this.sessionVariables.labelAngle) ? this.sessionVariables.labelAngle = this.labelAngle : this.sessionVariables.labelAngle : this.labelAngle, a.wrap = this.labelWrap = s(this.options.labelWrap) ? s(this.sessionVariables.labelWrap) ? this.sessionVariables.labelWrap = this.labelWrap : this.sessionVariables.labelWrap : this.options.labelWrap, a.maxHeight = s(this.sessionVariables.labelMaxHeight) ? this.sessionVariables.labelMaxHeight = l : this.sessionVariables.labelMaxHeight, a.measureText();
            else if ("left" === this._position || "right" === this._position)
              if (f = s(this.options.labelMaxWidth) ? 0.3 * this.chart.width >> 0 : this.options.labelMaxWidth, l = "undefined" === typeof this.options.labelWrap || this.labelWrap ? 0.3 * this.chart.height >> 0 : 1.5 * this.labelFontSize, !this.chart.panEnabled && 1 <= this._labels.length) {
                this.sessionVariables.labelFontSize = this.labelFontSize;
                this.sessionVariables.labelMaxWidth = f;
                this.sessionVariables.labelMaxHeight = l;
                this.sessionVariables.labelAngle = s(this.sessionVariables.labelAngle) ? 0 : this.sessionVariables.labelAngle;
                this.sessionVariables.labelWrap = this.labelWrap;
                for (c = 0; c < this._labels.length; c++)
                  if (!this._labels[c].breaksLabelType) {
                    a = this._labels[c].textBlock;
                    r = a.measureText();
                    for (g = c + 1; g < this._labels.length; g++)
                      if (!this._labels[g].breaksLabelType) {
                        d = this._labels[g].textBlock;
                        d = d.measureText();
                        break;
                      }
                    e.push(a.height);
                    this.sessionVariables.labelMaxHeight = Math.max.apply(Math, e);
                    b = f * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)) + (l - a.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle));
                    Math.cos(Math.PI / 180 * Math.abs(this.labelAngle));
                    Math.sin(Math.PI / 180 * Math.abs(this.labelAngle));
                    s(this.options.labelAngle) && isNaN(this.options.labelAngle) && 0 !== this.options.labelAngle ? s(this.options.labelWrap) ? s(this.options.labelWrap) && (s(this.options.labelMaxWidth) ? s(d) || (h2 = r.height + d.height >> 0, h2 - 2 * l > q && (q = h2 - 2 * l, h2 >= 2 * l && h2 < 2.4 * l ? (s(this.options.labelFontSize) && 12 < this.labelFontSize && (this.labelFontSize = Math.floor(12 / 13 * this.labelFontSize), a.measureText()), this.sessionVariables.labelMaxHeight = l, this.sessionVariables.labelFontSize = s(this.options.labelFontSize) ? this.labelFontSize : this.options.labelFontSize) : h2 >= 2.4 * l && h2 < 2.8 * l ? (this.sessionVariables.labelMaxHeight = b, this.sessionVariables.labelFontSize = this.labelFontSize, this.sessionVariables.labelWrap = true) : h2 >= 2.8 * l && h2 < 3.2 * l ? (this.sessionVariables.labelMaxHeight = l, this.sessionVariables.labelWrap = true, s(this.options.labelFontSize) && 12 < this.labelFontSize && (this.labelFontSize = Math.floor(12 / 13 * this.labelFontSize), a.measureText()), this.sessionVariables.labelFontSize = s(this.options.labelFontSize) ? this.labelFontSize : this.options.labelFontSize, this.sessionVariables.labelAngle = s(this.sessionVariables.labelAngle) ? 0 : this.sessionVariables.labelAngle) : h2 >= 3.2 * l && h2 < 3.6 * l ? (this.sessionVariables.labelMaxHeight = b, this.sessionVariables.labelWrap = true, this.sessionVariables.labelFontSize = this.labelFontSize) : h2 > 3.6 * l && h2 < 10 * l ? (s(this.options.labelFontSize) && 12 < this.labelFontSize && (this.labelFontSize = Math.floor(12 / 13 * this.labelFontSize), a.measureText()), this.sessionVariables.labelFontSize = s(this.options.labelFontSize) ? this.labelFontSize : this.options.labelFontSize, this.sessionVariables.labelMaxWidth = f, this.sessionVariables.labelMaxHeight = l, this.sessionVariables.labelAngle = s(this.sessionVariables.labelAngle) ? 0 : this.sessionVariables.labelAngle) : h2 > 10 * l && h2 < 50 * l && (s(this.options.labelFontSize) && 12 < this.labelFontSize && (this.labelFontSize = Math.floor(12 / 13 * this.labelFontSize), a.measureText()), this.sessionVariables.labelFontSize = s(this.options.labelFontSize) ? this.labelFontSize : this.options.labelFontSize, this.sessionVariables.labelMaxHeight = l, this.sessionVariables.labelMaxWidth = f, this.sessionVariables.labelAngle = s(this.sessionVariables.labelAngle) ? 0 : this.sessionVariables.labelAngle))) : (this.sessionVariables.labelMaxHeight = l, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : this.sessionVariables.labelMaxWidth)) : (this.sessionVariables.labelMaxWidth = this.labelWrap ? this.options.labelMaxWidth ? this.options.labelMaxWidth : this.sessionVariables.labelMaxWidth : this.labelMaxWidth ? this.options.labelMaxWidth ? this.options.labelMaxWidth : this.sessionVariables.labelMaxWidth : f, this.sessionVariables.labelMaxHeight = l) : (this.sessionVariables.labelAngle = this.labelAngle, this.sessionVariables.labelMaxWidth = 0 === this.labelAngle ? f : Math.min((b - l * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle))) / Math.cos(Math.PI / 180 * Math.abs(this.labelAngle)), l), s(this.options.labelWrap)) ? s(this.options.labelWrap) && (this.labelWrap && !s(this.options.labelMaxWidth) ? (this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : this.sessionVariables.labelMaxWidth, this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxHeight = b) : (this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : f, this.sessionVariables.labelMaxHeight = 0 === this.labelAngle ? l : b, s(this.options.labelMaxWidth) && (this.sessionVariables.labelAngle = this.labelAngle))) : this.options.labelWrap ? (this.sessionVariables.labelMaxHeight = 0 === this.labelAngle ? l : b, this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxWidth = f) : (this.sessionVariables.labelMaxHeight = l, s(this.options.labelMaxWidth), this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : this.sessionVariables.labelMaxWidth, this.sessionVariables.labelWrap = this.labelWrap);
                  }
                for (b = 0; b < this._labels.length; b++)
                  a = this._labels[b].textBlock, a.maxWidth = this.labelMaxWidth = this.sessionVariables.labelMaxWidth, a.fontSize = this.labelFontSize = this.sessionVariables.labelFontSize, a.angle = this.labelAngle = this.sessionVariables.labelAngle, a.wrap = this.labelWrap = this.sessionVariables.labelWrap, a.maxHeight = this.sessionVariables.labelMaxHeight, a.measureText();
              } else
                for (c = 0; c < this._labels.length; c++)
                  a = this._labels[c].textBlock, a.maxWidth = this.labelMaxWidth = s(this.options.labelMaxWidth) ? s(this.sessionVariables.labelMaxWidth) ? this.sessionVariables.labelMaxWidth = f : this.sessionVariables.labelMaxWidth : this.options.labelMaxWidth, a.fontSize = this.labelFontSize = s(this.options.labelFontSize) ? s(this.sessionVariables.labelFontSize) ? this.sessionVariables.labelFontSize = this.labelFontSize : this.sessionVariables.labelFontSize : this.options.labelFontSize, a.angle = this.labelAngle = s(this.options.labelAngle) ? s(this.sessionVariables.labelAngle) ? this.sessionVariables.labelAngle = this.labelAngle : this.sessionVariables.labelAngle : this.labelAngle, a.wrap = this.labelWrap = s(this.options.labelWrap) ? s(this.sessionVariables.labelWrap) ? this.sessionVariables.labelWrap = this.labelWrap : this.sessionVariables.labelWrap : this.options.labelWrap, a.maxHeight = s(this.sessionVariables.labelMaxHeight) ? this.sessionVariables.labelMaxHeight = l : this.sessionVariables.labelMaxHeight, a.measureText();
          }
          for (c = 0; c < this.stripLines.length; c++) {
            var f = this.stripLines[c], A2;
            if ("outside" === f.labelPlacement) {
              l = this.sessionVariables.labelMaxWidth;
              if ("bottom" === this._position || "top" === this._position)
                s(f.options.labelWrap) && !s(this.sessionVariables.stripLineLabelMaxHeight) ? A2 = this.sessionVariables.stripLineLabelMaxHeight : this.sessionVariables.stripLineLabelMaxHeight = A2 = f.labelWrap ? 0.8 * this.chart.height >> 0 : 1.5 * this.labelFontSize;
              if ("left" === this._position || "right" === this._position)
                s(f.options.labelWrap) && !s(this.sessionVariables.stripLineLabelMaxHeight) ? A2 = this.sessionVariables.stripLineLabelMaxHeight : this.sessionVariables.stripLineLabelMaxHeight = A2 = f.labelWrap ? 0.8 * this.chart.width >> 0 : 1.5 * this.labelFontSize;
              s(f.labelBackgroundColor) && (f.labelBackgroundColor = "#EEEEEE");
            } else
              l = "bottom" === this._position || "top" === this._position ? 0.9 * this.chart.width >> 0 : 0.9 * this.chart.height >> 0, A2 = s(f.options.labelWrap) || f.labelWrap ? "bottom" === this._position || "top" === this._position ? 0.8 * this.chart.width >> 0 : 0.8 * this.chart.height >> 0 : 1.5 * this.labelFontSize, s(f.labelBackgroundColor) && (s(f.startValue) && 0 !== f.startValue ? f.labelBackgroundColor = w ? "transparent" : null : f.labelBackgroundColor = "#EEEEEE");
            a = new ja(this.ctx, { x: 0, y: 0, backgroundColor: f.labelBackgroundColor, borderColor: f.labelBorderColor, borderThickness: f.labelBorderThickness, cornerRadius: f.labelCornerRadius, maxWidth: f.options.labelMaxWidth ? f.options.labelMaxWidth : l, maxHeight: A2, angle: this.labelAngle, text: f.labelFormatter ? f.labelFormatter({ chart: this.chart, axis: this, stripLine: f }) : f.label, textAlign: this.labelTextAlign, fontSize: "outside" === f.labelPlacement ? f.options.labelFontSize ? f.labelFontSize : this.labelFontSize : f.labelFontSize, fontFamily: "outside" === f.labelPlacement ? f.options.labelFontFamily ? f.labelFontFamily : this.labelFontFamily : f.labelFontFamily, fontWeight: "outside" === f.labelPlacement ? f.options.labelFontWeight ? f.labelFontWeight : this.labelFontWeight : f.labelFontWeight, fontColor: f.labelFontColor || f.color, fontStyle: "outside" === f.labelPlacement ? f.options.labelFontStyle ? f.labelFontStyle : this.fontWeight : f.labelFontStyle, textBaseline: "middle" });
            this._stripLineLabels.push({ position: f.value, textBlock: a, effectiveHeight: null, stripLine: f });
          }
        };
        A.prototype.createLabelsAndCalculateWidth = function() {
          var a = 0, d = 0;
          this._labels = [];
          this._stripLineLabels = [];
          var c = this.chart.isNavigator ? 0 : 5;
          if ("left" === this._position || "right" === this._position) {
            this.createLabels();
            if ("inside" != this.labelPlacement || "inside" === this.labelPlacement && 0 < this._index)
              for (d = 0; d < this._labels.length; d++) {
                var b = this._labels[d].textBlock, e = b.measureText(), f = 0, f = 0 === this.labelAngle ? e.width : e.width * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle)) + (e.height - b.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle));
                a < f && (this.labelEffectiveWidth = a = f);
                this._labels[d].effectiveWidth = f;
              }
            for (d = 0; d < this._stripLineLabels.length; d++)
              "outside" === this._stripLineLabels[d].stripLine.labelPlacement && (this._stripLineLabels[d].stripLine.value >= this.viewportMinimum && this._stripLineLabels[d].stripLine.value <= this.viewportMaximum) && (b = this._stripLineLabels[d].textBlock, e = b.measureText(), f = 0 === this.labelAngle ? e.width : e.width * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle)) + (e.height - b.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)), "inside" === this.tickPlacement && (f += this.tickLength), "inside" === this.labelPlacement && (a += 0 < this._index ? f : 0), a < f && (a = f), this.stripLineLabelEffectiveWidth = this._stripLineLabels[d].effectiveWidth = f);
          }
          return (this.title ? this._titleTextBlock.measureText().height + 2 : 0) + a + ("inside" === this.tickPlacement ? 0 < this._index ? this.tickLength : 0 : this.tickLength) + c;
        };
        A.prototype.createLabelsAndCalculateHeight = function() {
          var a = 0;
          this._labels = [];
          this._stripLineLabels = [];
          var d, c = 0, b = this.chart.isNavigator ? 0 : 5;
          if ("bottom" === this._position || "top" === this._position) {
            this.createLabels();
            if ("inside" != this.labelPlacement || "inside" === this.labelPlacement && 0 < this._index)
              for (c = 0; c < this._labels.length; c++) {
                d = this._labels[c].textBlock;
                var e = d.measureText(), f = 0, f = 0 === this.labelAngle ? e.height : e.width * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)) + (e.height - d.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle));
                a < f && (this.labelEffectiveHeight = a = f);
                this._labels[c].effectiveHeight = f;
              }
            for (c = 0; c < this._stripLineLabels.length; c++)
              "outside" === this._stripLineLabels[c].stripLine.labelPlacement && (this._stripLineLabels[c].stripLine.value >= this.viewportMinimum && this._stripLineLabels[c].stripLine.value <= this.viewportMaximum) && (d = this._stripLineLabels[c].textBlock, e = d.measureText(), f = 0 === this.labelAngle ? e.height : e.width * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)) + (e.height - d.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle)), "inside" === this.tickPlacement && (f += this.tickLength), "inside" === this.labelPlacement && (a += 0 < this._index ? f : 0), a < f && (a = f), this.stripLineLabelEffectiveHeight = this._stripLineLabels[c].effectiveHeight = f);
          }
          return (this.title ? this._titleTextBlock.measureText().height + 2 : 0) + a + ("inside" === this.tickPlacement ? 0 < this._index ? this.tickLength : 0 : this.tickLength) + b;
        };
        A.setLayout = function(a, d, c, b, e, f) {
          var l, h2, n2, k, m = a[0] ? a[0].chart : d[0].chart, p = m.isNavigator ? 0 : 10, q = m._axes;
          if (a && 0 < a.length)
            for (var g = 0; g < a.length; g++)
              a[g] && a[g].calculateAxisParameters();
          if (d && 0 < d.length)
            for (g = 0; g < d.length; g++)
              d[g].calculateAxisParameters();
          if (c && 0 < c.length)
            for (g = 0; g < c.length; g++)
              c[g].calculateAxisParameters();
          if (b && 0 < b.length)
            for (g = 0; g < b.length; g++)
              b[g].calculateAxisParameters();
          for (g = 0; g < q.length; g++)
            if (q[g] && q[g].scaleBreaks && q[g].scaleBreaks._appliedBreaks.length)
              for (var r = q[g].scaleBreaks._appliedBreaks, w2 = 0; w2 < r.length && !(r[w2].startValue > q[g].viewportMaximum); w2++)
                r[w2].endValue < q[g].viewportMinimum || (s(q[g].scaleBreaks.firstBreakIndex) && (q[g].scaleBreaks.firstBreakIndex = w2), r[w2].startValue >= q[g].viewPortMinimum && (q[g].scaleBreaks.lastBreakIndex = w2));
          for (var v3 = w2 = 0, u = 0, y = 0, x = 0, z = 0, A2 = 0, D, B3, E = h2 = 0, G2, J2, K3, r = G2 = J2 = K3 = false, g = 0; g < q.length; g++)
            q[g] && q[g].title && (q[g]._titleTextBlock = new ja(q[g].ctx, {
              text: q[g].title,
              horizontalAlign: "center",
              fontSize: q[g].titleFontSize,
              fontFamily: q[g].titleFontFamily,
              fontWeight: q[g].titleFontWeight,
              fontColor: q[g].titleFontColor,
              fontStyle: q[g].titleFontStyle,
              borderColor: q[g].titleBorderColor,
              borderThickness: q[g].titleBorderThickness,
              backgroundColor: q[g].titleBackgroundColor,
              cornerRadius: q[g].titleCornerRadius,
              textBaseline: "top"
            }));
          for (g = 0; g < q.length; g++)
            if (q[g].title)
              switch (q[g]._position) {
                case "left":
                  q[g]._titleTextBlock.maxWidth = q[g].titleMaxWidth || f.height;
                  q[g]._titleTextBlock.maxHeight = q[g].titleWrap ? 0.8 * f.width : 1.5 * q[g].titleFontSize;
                  q[g]._titleTextBlock.angle = -90;
                  break;
                case "right":
                  q[g]._titleTextBlock.maxWidth = q[g].titleMaxWidth || f.height;
                  q[g]._titleTextBlock.maxHeight = q[g].titleWrap ? 0.8 * f.width : 1.5 * q[g].titleFontSize;
                  q[g]._titleTextBlock.angle = 90;
                  break;
                default:
                  q[g]._titleTextBlock.maxWidth = q[g].titleMaxWidth || f.width, q[g]._titleTextBlock.maxHeight = q[g].titleWrap ? 0.8 * f.height : 1.5 * q[g].titleFontSize, q[g]._titleTextBlock.angle = 0;
              }
          if ("normal" === e) {
            for (var y = [], x = [], z = [], A2 = [], M2 = [], Q3 = [], N2 = [], P2 = []; 4 > w2; ) {
              var F = 0, X2 = 0, T2 = 0, U3 = 0, V2 = e = 0, O = 0, Z3 = 0, W2 = 0, Y2 = 0, R = 0, aa3 = 0;
              if (c && 0 < c.length)
                for (z = [], g = R = 0; g < c.length; g++)
                  z.push(Math.ceil(c[g] ? c[g].createLabelsAndCalculateWidth() : 0)), R += z[g], O += c[g] && !m.isNavigator ? c[g].margin : 0;
              else
                z.push(Math.ceil(c[0] ? c[0].createLabelsAndCalculateWidth() : 0));
              N2.push(z);
              if (b && 0 < b.length)
                for (A2 = [], g = aa3 = 0; g < b.length; g++)
                  A2.push(Math.ceil(b[g] ? b[g].createLabelsAndCalculateWidth() : 0)), aa3 += A2[g], Z3 += b[g] ? b[g].margin : 0;
              else
                A2.push(Math.ceil(b[0] ? b[0].createLabelsAndCalculateWidth() : 0));
              P2.push(A2);
              l = Math.round(f.x1 + R + O);
              n2 = Math.round(f.x2 - aa3 - Z3 > m.width - p ? m.width - p : f.x2 - aa3 - Z3);
              if (a && 0 < a.length)
                for (y = [], g = W2 = 0; g < a.length; g++)
                  a[g] && (a[g].lineCoordinates = {}), a[g].lineCoordinates.width = Math.abs(n2 - l), a[g].title && (a[g]._titleTextBlock.maxWidth = 0 < a[g].titleMaxWidth && a[g].titleMaxWidth < a[g].lineCoordinates.width ? a[g].titleMaxWidth : a[g].lineCoordinates.width), y.push(Math.ceil(a[g] ? a[g].createLabelsAndCalculateHeight() : 0)), W2 += y[g], e += a[g] && !m.isNavigator ? a[g].margin : 0;
              else
                y.push(Math.ceil(a[0] ? a[0].createLabelsAndCalculateHeight() : 0));
              M2.push(y);
              if (d && 0 < d.length)
                for (x = [], g = Y2 = 0; g < d.length; g++)
                  d[g] && (d[g].lineCoordinates = {}), d[g].lineCoordinates.width = Math.abs(n2 - l), d[g].title && (d[g]._titleTextBlock.maxWidth = 0 < d[g].titleMaxWidth && d[g].titleMaxWidth < d[g].lineCoordinates.width ? d[g].titleMaxWidth : d[g].lineCoordinates.width), x.push(Math.ceil(d[g] ? d[g].createLabelsAndCalculateHeight() : 0)), Y2 += x[g], V2 += d[g] && !m.isNavigator ? d[g].margin : 0;
              else
                x.push(Math.ceil(d[0] ? d[0].createLabelsAndCalculateHeight() : 0));
              Q3.push(x);
              if (a && 0 < a.length)
                for (g = 0; g < a.length; g++)
                  a[g] && (a[g].lineCoordinates.x1 = l, n2 = Math.round(f.x2 - aa3 - Z3 > m.width - p ? m.width - p : f.x2 - aa3 - Z3), a[g]._labels && 1 < a[g]._labels.length && (h2 = k = 0, k = a[g]._labels[1], h2 = "dateTime" === a[g].valueType ? a[g]._labels[a[g]._labels.length - 2] : a[g]._labels[a[g]._labels.length - 1], v3 = k.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(k.textBlock.angle)) + (k.textBlock.height - h2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(k.textBlock.angle)), u = h2.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(h2.textBlock.angle)) + (h2.textBlock.height - h2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(h2.textBlock.angle))), !a[g] || (!a[g].labelAutoFit || s(D) || s(B3) || m.isNavigator || m.stockChart) || (h2 = 0, 0 < a[g].labelAngle ? B3 + u > n2 && (h2 += 0 < a[g].labelAngle ? B3 + u - n2 - aa3 : 0) : 0 > a[g].labelAngle ? D - v3 < l && D - v3 < a[g].viewportMinimum && (E = l - (O + a[g].tickLength + z + D - v3 + a[g].labelFontSize / 2)) : 0 === a[g].labelAngle && (B3 + u > n2 && (h2 = B3 + u / 2 - n2 - aa3), D - v3 < l && D - v3 < a[g].viewportMinimum && (E = l - O - a[g].tickLength - z - D + v3 / 2)), a[g].viewportMaximum === a[g].maximum && a[g].viewportMinimum === a[g].minimum && 0 < a[g].labelAngle && 0 < h2 ? n2 -= h2 : a[g].viewportMaximum === a[g].maximum && a[g].viewportMinimum === a[g].minimum && 0 > a[g].labelAngle && 0 < E ? l += E : a[g].viewportMaximum === a[g].maximum && a[g].viewportMinimum === a[g].minimum && 0 === a[g].labelAngle && (0 < E && (l += E), 0 < h2 && (n2 -= h2))), m.panEnabled ? W2 = s(m.sessionVariables.axisX.height) ? m.sessionVariables.axisX.height = W2 : m.sessionVariables.axisX.height : m.sessionVariables.axisX.height = W2, h2 = Math.round(f.y2 - W2 - e + F), k = Math.round(f.y2), a[g].lineCoordinates.x2 = n2, a[g].lineCoordinates.width = n2 - l, a[g].lineCoordinates.y1 = h2, a[g].lineCoordinates.y2 = h2 + a[g].lineThickness / 2, "inside" === a[g].labelPlacement && 0 < g && (a[g].lineCoordinates.y1 = a[g - 1].lineCoordinates.y2 + F + (a[g].labelEffectiveHeight || 0), a[g].lineCoordinates.y2 = a[g].lineCoordinates.y1 + a[g].lineThickness / 2), "inside" === a[g].tickPlacement && 0 < g && (a[g].lineCoordinates.y1 += a[g].tickLength, a[g].lineCoordinates.y2 = a[g].lineCoordinates.y1 + a[g].lineThickness / 2), a[g].bounds = { x1: l, y1: h2, x2: n2, y2: k - (W2 + e - y[g] - F), width: n2 - l }, a[g].bounds.height = a[g].bounds.y2 - a[g].bounds.y1), F += y[g] + a[g].margin;
              if (d && 0 < d.length)
                for (g = 0; g < d.length; g++)
                  d[g].lineCoordinates.x1 = Math.round(f.x1 + R + O), d[g].lineCoordinates.x2 = Math.round(f.x2 - aa3 - Z3 > m.width - p ? m.width - p : f.x2 - aa3 - Z3), d[g].lineCoordinates.width = Math.abs(n2 - l), d[g]._labels && 1 < d[g]._labels.length && (k = d[g]._labels[1], h2 = "dateTime" === d[g].valueType ? d[g]._labels[d[g]._labels.length - 2] : d[g]._labels[d[g]._labels.length - 1], v3 = k.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(k.textBlock.angle)) + (k.textBlock.height - h2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(k.textBlock.angle)), u = h2.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(h2.textBlock.angle)) + (h2.textBlock.height - h2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(h2.textBlock.angle))), m.panEnabled ? Y2 = s(m.sessionVariables.axisX2.height) ? m.sessionVariables.axisX2.height = Y2 : m.sessionVariables.axisX2.height : m.sessionVariables.axisX2.height = Y2, h2 = Math.round(f.y1), k = d[g].lineCoordinates.y1 = h2 + Y2 + V2 - X2, d[g].lineCoordinates.y2 = h2, "inside" === d[g].labelPlacement && 0 < g && (d[g].lineCoordinates.y1 = d[g - 1].lineCoordinates.y1 - X2 - (d[g].labelEffectiveHeight || 0)), "inside" === d[g].tickPlacement && 0 < g && (d[g].lineCoordinates.y1 -= d[g].tickLength), d[g].bounds = { x1: l, y1: h2 + (Y2 + V2 - x[g] - X2), x2: n2, y2: k, width: n2 - l }, d[g].bounds.height = d[g].bounds.y2 - d[g].bounds.y1, X2 += x[g] + d[g].margin;
              if (c && 0 < c.length)
                for (g = 0; g < c.length; g++)
                  O = m.isNavigator ? 0 : 10, c[g] && (l = Math.round(a[0] ? a[0].lineCoordinates.x1 : d[0].lineCoordinates.x1), O = c[g]._labels && 0 < c[g]._labels.length ? c[g]._labels[c[g]._labels.length - 1].textBlock.height / 2 : p, h2 = Math.round(f.y1 + Y2 + V2 < Math.max(O, p) ? Math.max(O, p) : f.y1 + Y2 + V2), n2 = Math.round(a[0] ? a[0].lineCoordinates.x1 : d[0].lineCoordinates.x1), O = 0 < a.length ? 0 : c[g]._labels && 0 < c[g]._labels.length ? c[g]._labels[0].textBlock.height / 2 : p, k = Math.round(f.y2 - W2 - e - O), c[g].lineCoordinates = { x1: l - T2, y1: h2, x2: n2 - T2, y2: k, height: Math.abs(k - h2) }, "inside" === c[g].labelPlacement && 0 < g && (c[g].lineCoordinates.x1 = c[g - 1].lineCoordinates.x1 - T2 - (c[g].labelEffectiveWidth || 0), c[g].lineCoordinates.x2 = c[g].lineCoordinates.x1 + c[g].lineThickness / 2), "inside" === c[g].tickPlacement && 0 < g && (c[g].lineCoordinates.x1 -= c[g].tickLength, c[g].lineCoordinates.x2 = c[g].lineCoordinates.x1 + c[g].lineThickness / 2), c[g].bounds = { x1: l - (z[g] + T2), y1: h2, x2: n2 - T2, y2: k, height: k - h2 }, c[g].bounds.width = c[g].bounds.x2 - c[g].bounds.x1, c[g].title && (c[g]._titleTextBlock.maxWidth = 0 < c[g].titleMaxWidth && c[g].titleMaxWidth < c[g].lineCoordinates.height ? c[g].titleMaxWidth : c[g].lineCoordinates.height), T2 += z[g] + c[g].margin);
              if (b && 0 < b.length)
                for (g = 0; g < b.length; g++)
                  b[g] && (l = Math.round(a[0] ? a[0].lineCoordinates.x2 : d[0].lineCoordinates.x2), n2 = Math.round(l), O = b[g]._labels && 0 < b[g]._labels.length ? b[g]._labels[b[g]._labels.length - 1].textBlock.height / 2 : 0, h2 = Math.round(f.y1 + Y2 + V2 < Math.max(O, p) ? Math.max(O, p) : f.y1 + Y2 + V2), O = 0 < a.length ? 0 : b[g]._labels && 0 < b[g]._labels.length ? b[g]._labels[0].textBlock.height / 2 : 0, k = Math.round(f.y2 - (W2 + e + O)), b[g].lineCoordinates = { x1: l + U3, y1: h2, x2: l + U3, y2: k, height: Math.abs(k - h2) }, "inside" === b[g].labelPlacement && 0 < g && (b[g].lineCoordinates.x1 = b[g - 1].lineCoordinates.x2 + U3 + (b[g].labelEffectiveWidth || 0), b[g].lineCoordinates.x2 = b[g].lineCoordinates.x1 + b[g].lineThickness / 2), "inside" === b[g].tickPlacement && 0 < g && (b[g].lineCoordinates.x1 += b[g].tickLength, b[g].lineCoordinates.x2 = b[g].lineCoordinates.x1 + b[g].lineThickness / 2), b[g].bounds = { x1: l + U3, y1: h2, x2: n2 + (A2[g] + U3), y2: k, height: k - h2 }, b[g].bounds.width = b[g].bounds.x2 - b[g].bounds.x1, b[g].title && (b[g]._titleTextBlock.maxWidth = 0 < b[g].titleMaxWidth && b[g].titleMaxWidth < b[g].lineCoordinates.height ? b[g].titleMaxWidth : b[g].lineCoordinates.height), U3 += A2[g] + b[g].margin);
              if (a && 0 < a.length)
                for (g = 0; g < a.length; g++)
                  a[g] && (a[g].calculateValueToPixelConversionParameters(), a[g].calculateBreaksSizeInValues(), a[g]._labels && 1 < a[g]._labels.length && (D = (a[g].logarithmic ? Math.log(a[g]._labels[1].position / a[g].viewportMinimum) / a[g].conversionParameters.lnLogarithmBase : a[g]._labels[1].position - a[g].viewportMinimum) * Math.abs(a[g].conversionParameters.pixelPerUnit) + a[g].lineCoordinates.x1, l = a[g]._labels[a[g]._labels.length - ("dateTime" === a[g].valueType ? 2 : 1)].position, l = a[g].getApparentDifference(a[g].viewportMinimum, l), B3 = a[g].logarithmic ? (1 < l ? Math.log(l) / a[g].conversionParameters.lnLogarithmBase * Math.abs(a[g].conversionParameters.pixelPerUnit) : 0) + a[g].lineCoordinates.x1 : (0 < l ? l * Math.abs(a[g].conversionParameters.pixelPerUnit) : 0) + a[g].lineCoordinates.x1));
              if (d && 0 < d.length)
                for (g = 0; g < d.length; g++)
                  d[g].calculateValueToPixelConversionParameters(), d[g].calculateBreaksSizeInValues(), d[g]._labels && 1 < d[g]._labels.length && (D = (d[g].logarithmic ? Math.log(d[g]._labels[1].position / d[g].viewportMinimum) / d[g].conversionParameters.lnLogarithmBase : d[g]._labels[1].position - d[g].viewportMinimum) * Math.abs(d[g].conversionParameters.pixelPerUnit) + d[g].lineCoordinates.x1, l = d[g]._labels[d[g]._labels.length - ("dateTime" === d[g].valueType ? 2 : 1)].position, l = d[g].getApparentDifference(d[g].viewportMinimum, l), B3 = d[g].logarithmic ? (1 < l ? Math.log(l) / d[g].conversionParameters.lnLogarithmBase * Math.abs(d[g].conversionParameters.pixelPerUnit) : 0) + d[g].lineCoordinates.x1 : (0 < l ? l * Math.abs(d[g].conversionParameters.pixelPerUnit) : 0) + d[g].lineCoordinates.x1);
              for (g = 0; g < q.length; g++)
                "axisY" === q[g].type && (q[g].calculateValueToPixelConversionParameters(), q[g].calculateBreaksSizeInValues());
              if (0 < w2) {
                if (a && 0 < a.length)
                  for (g = 0; g < a.length; g++)
                    r = M2[w2 - 1][g] === M2[w2][g] ? true : false;
                else
                  r = true;
                if (d && 0 < d.length)
                  for (g = 0; g < d.length; g++)
                    G2 = Q3[w2 - 1][g] === Q3[w2][g] ? true : false;
                else
                  G2 = true;
                if (c && 0 < c.length)
                  for (g = 0; g < c.length; g++)
                    J2 = N2[w2 - 1][g] === N2[w2][g] ? true : false;
                else
                  J2 = true;
                if (b && 0 < b.length)
                  for (g = 0; g < b.length; g++)
                    K3 = P2[w2 - 1][g] === P2[w2][g] ? true : false;
                else
                  K3 = true;
              }
              if (r && G2 && J2 && K3)
                break;
              w2++;
            }
            if (a && 0 < a.length)
              for (g = 0; g < a.length; g++)
                a[g].calculateStripLinesThicknessInValues(), a[g].calculateBreaksInPixels();
            if (d && 0 < d.length)
              for (g = 0; g < d.length; g++)
                d[g].calculateStripLinesThicknessInValues(), d[g].calculateBreaksInPixels();
            if (c && 0 < c.length)
              for (g = 0; g < c.length; g++)
                c[g].calculateStripLinesThicknessInValues(), c[g].calculateBreaksInPixels();
            if (b && 0 < b.length)
              for (g = 0; g < b.length; g++)
                b[g].calculateStripLinesThicknessInValues(), b[g].calculateBreaksInPixels();
          } else {
            p = [];
            D = [];
            E = [];
            v3 = [];
            B3 = [];
            u = [];
            M2 = [];
            for (Q3 = []; 4 > w2; ) {
              W2 = U3 = T2 = Z3 = O = V2 = e = P2 = N2 = F = Y2 = 0;
              if (a && 0 < a.length)
                for (E = [], g = U3 = 0; g < a.length; g++)
                  E.push(Math.ceil(a[g] ? a[g].createLabelsAndCalculateWidth() : 0)), U3 += E[g], e += a[g] && !m.isNavigator ? a[g].margin : 0;
              else
                E.push(Math.ceil(a[0] ? a[0].createLabelsAndCalculateWidth() : 0));
              M2.push(E);
              if (d && 0 < d.length)
                for (v3 = [], g = W2 = 0; g < d.length; g++)
                  v3.push(Math.ceil(d[g] ? d[g].createLabelsAndCalculateWidth() : 0)), W2 += v3[g], V2 += d[g] ? d[g].margin : 0;
              else
                v3.push(Math.ceil(d[0] ? d[0].createLabelsAndCalculateWidth() : 0));
              Q3.push(v3);
              if (c && 0 < c.length)
                for (g = 0; g < c.length; g++)
                  c[g].lineCoordinates = {}, l = Math.round(f.x1 + U3 + e), n2 = Math.round(f.x2 - W2 - V2 > m.width - 10 ? m.width - 10 : f.x2 - W2 - V2), c[g].labelAutoFit && !s(y) && (0 < !a.length && (l = 0 > c[g].labelAngle ? Math.max(l, y) : 0 === c[g].labelAngle ? Math.max(l, y / 2) : l), 0 < !d.length && (n2 = 0 < c[g].labelAngle ? n2 - x / 2 : 0 === c[g].labelAngle ? n2 - x / 2 : n2)), c[g].lineCoordinates.x1 = l, c[g].lineCoordinates.x2 = n2, c[g].lineCoordinates.width = Math.abs(n2 - l), c[g].title && (c[g]._titleTextBlock.maxWidth = 0 < c[g].titleMaxWidth && c[g].titleMaxWidth < c[g].lineCoordinates.width ? c[g].titleMaxWidth : c[g].lineCoordinates.width);
              if (b && 0 < b.length)
                for (g = 0; g < b.length; g++)
                  b[g].lineCoordinates = {}, l = Math.round(f.x1 + U3 + e), n2 = Math.round(f.x2 - W2 - V2 > b[g].chart.width - 10 ? b[g].chart.width - 10 : f.x2 - W2 - V2), b[g] && b[g].labelAutoFit && !s(z) && (0 < !a.length && (l = 0 < b[g].labelAngle ? Math.max(l, z) : 0 === b[g].labelAngle ? Math.max(l, z / 2) : l), 0 < !d.length && (n2 -= A2 / 2)), b[g].lineCoordinates.x1 = l, b[g].lineCoordinates.x2 = n2, b[g].lineCoordinates.width = Math.abs(n2 - l), b[g].title && (b[g]._titleTextBlock.maxWidth = 0 < b[g].titleMaxWidth && b[g].titleMaxWidth < b[g].lineCoordinates.width ? b[g].titleMaxWidth : b[g].lineCoordinates.width);
              if (c && 0 < c.length)
                for (p = [], g = T2 = 0; g < c.length; g++)
                  p.push(Math.ceil(c[g] ? c[g].createLabelsAndCalculateHeight() : 0)), T2 += p[g] + c[g].margin, O += c[g].margin;
              else
                p.push(Math.ceil(c[0] ? c[0].createLabelsAndCalculateHeight() : 0));
              B3.push(p);
              if (b && 0 < b.length)
                for (D = [], g = 0; g < b.length; g++)
                  D.push(Math.ceil(b[g] ? b[g].createLabelsAndCalculateHeight() : 0)), Z3 += b[g].margin;
              else
                D.push(Math.ceil(b[0] ? b[0].createLabelsAndCalculateHeight() : 0));
              u.push(D);
              if (c && 0 < c.length)
                for (g = 0; g < c.length; g++)
                  0 < c[g]._labels.length && (k = c[g]._labels[0], h2 = c[g]._labels[c[g]._labels.length - 1], y = k.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(k.textBlock.angle)) + (k.textBlock.height - h2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(k.textBlock.angle)), x = h2.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(h2.textBlock.angle)) + (h2.textBlock.height - h2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(h2.textBlock.angle)));
              if (b && 0 < b.length)
                for (g = 0; g < b.length; g++)
                  b[g] && 0 < b[g]._labels.length && (k = b[g]._labels[0], h2 = b[g]._labels[b[g]._labels.length - 1], z = k.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(k.textBlock.angle)) + (k.textBlock.height - h2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(k.textBlock.angle)), A2 = h2.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(h2.textBlock.angle)) + (h2.textBlock.height - h2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(h2.textBlock.angle)));
              if (m.panEnabled)
                for (g = 0; g < c.length; g++)
                  p[g] = s(m.sessionVariables.axisY[g].height) ? m.sessionVariables.axisY[g].height = p[g] : m.sessionVariables.axisY[g].height;
              else
                for (g = 0; g < c.length; g++)
                  m.sessionVariables.axisY[g].height = p[g];
              if (c && 0 < c.length)
                for (g = c.length - 1; 0 <= g; g--)
                  h2 = Math.round(f.y2), k = Math.round(f.y2 > c[g].chart.height ? c[g].chart.height : f.y2), c[g].lineCoordinates.y1 = h2 - (p[g] + c[g].margin + Y2), c[g].lineCoordinates.y2 = h2 - (p[g] + c[g].margin + Y2), "inside" === c[g].labelPlacement && 0 < g && (c[g].lineCoordinates.y1 = c[g].lineCoordinates.y1 + p[g] - (c[g]._titleTextBlock ? c[g]._titleTextBlock.height : 0) - c[g].tickLength - (c[g].stripLineLabelEffectiveHeight || 0) - 5, c[g].lineCoordinates.y2 = c[g].lineCoordinates.y1 + c[g].lineThickness / 2), "inside" === c[g].tickPlacement && 0 < g && (c[g].lineCoordinates.y1 += c[g].tickLength, c[g].lineCoordinates.y2 = c[g].lineCoordinates.y1 + c[g].lineThickness / 2), c[g].bounds = { x1: l, y1: h2 - (p[g] + Y2 + c[g].margin), x2: n2, y2: k - (Y2 + c[g].margin), width: n2 - l, height: p[g] }, c[g].title && (c[g]._titleTextBlock.maxWidth = 0 < c[g].titleMaxWidth && c[g].titleMaxWidth < c[g].lineCoordinates.width ? c[g].titleMaxWidth : c[g].lineCoordinates.width), Y2 += p[g] + c[g].margin;
              if (b && 0 < b.length)
                for (g = b.length - 1; 0 <= g; g--)
                  b[g] && (h2 = Math.round(f.y1), k = Math.round(f.y1 + (D[g] + b[g].margin + F)), b[g].lineCoordinates.y1 = k, b[g].lineCoordinates.y2 = k, "inside" === b[g].labelPlacement && 0 < g && (b[g].lineCoordinates.y1 = k - D[g] + (b[g]._titleTextBlock ? b[g]._titleTextBlock.height : 0) + b[g].tickLength + (b[g].stripLineLabelEffectiveHeight || 0), b[g].lineCoordinates.y2 = b[g].lineCoordinates.y1 - b[g].lineThickness / 2), "inside" === b[g].tickPlacement && 0 < g && (b[g].lineCoordinates.y1 -= b[g].tickLength, b[g].lineCoordinates.y2 = b[g].lineCoordinates.y1 - b[g].lineThickness / 2), b[g].bounds = { x1: l, y1: h2 + (b[g].margin + F), x2: n2, y2: k, width: n2 - l }, b[g].bounds.height = b[g].bounds.y2 - b[g].bounds.y1, b[g].title && (b[g]._titleTextBlock.maxWidth = 0 < b[g].titleMaxWidth && b[g].titleMaxWidth < b[g].lineCoordinates.width ? b[g].titleMaxWidth : b[g].lineCoordinates.width), F += D[g] + b[g].margin);
              if (a && 0 < a.length)
                for (g = 0; g < a.length; g++) {
                  O = a[g]._labels && 0 < a[g]._labels.length ? a[g]._labels[0].textBlock.fontSize / 2 : 0;
                  l = Math.round(f.x1 + e);
                  h2 = b && 0 < b.length ? Math.round(b[0] ? b[0].lineCoordinates.y2 : f.y1 < Math.max(O, 10) ? Math.max(O, 10) : f.y1) : f.y1 < Math.max(O, 10) ? Math.max(O, 10) : f.y1;
                  n2 = Math.round(f.x1 + U3 + e);
                  k = c && 0 < c.length ? Math.round(c[0] ? c[0].lineCoordinates.y1 : f.y2 - T2 > m.height - Math.max(O, 10) ? m.height - Math.max(O, 10) : f.y2 - T2) : f.y2 > m.height - Math.max(
                    O,
                    10
                  ) ? m.height - Math.max(O, 10) : f.y2;
                  if (c && 0 < c.length)
                    for (O = 0; O < c.length; O++)
                      c[O] && c[O].labelAutoFit && (n2 = c[O].lineCoordinates.x1, l = 0 > c[O].labelAngle || 0 === c[O].labelAngle ? n2 - U3 : l);
                  if (b && 0 < b.length)
                    for (O = 0; O < b.length; O++)
                      b[O] && b[O].labelAutoFit && (n2 = b[O].lineCoordinates.x1, l = n2 - U3);
                  a[g].lineCoordinates = { x1: n2 - N2, y1: h2, x2: n2 - N2, y2: k, height: Math.abs(k - h2) };
                  "inside" === a[g].labelPlacement && 0 < g && (a[g].lineCoordinates.x1 = a[g].lineCoordinates.x1 - (E[g] - (a[g]._titleTextBlock ? a[g]._titleTextBlock.height : 0)) + a[g].tickLength + (a[g].stripLineLabelEffectiveWidth || 0), a[g].lineCoordinates.x2 = a[g].lineCoordinates.x1 + a[g].lineThickness / 2);
                  "inside" === a[g].tickPlacement && 0 < g && (a[g].lineCoordinates.x1 -= a[g].tickLength, a[g].lineCoordinates.x2 = a[g].lineCoordinates.x1 + a[g].lineThickness / 2);
                  a[g].bounds = { x1: n2 - (E[g] + N2), y1: h2, x2: n2 - N2, y2: k, height: k - h2 };
                  a[g].bounds.width = a[g].bounds.x2 - a[g].bounds.x1;
                  a[g].title && (a[g]._titleTextBlock.maxWidth = 0 < a[g].titleMaxWidth && a[g].titleMaxWidth < a[g].lineCoordinates.height ? a[g].titleMaxWidth : a[g].lineCoordinates.height);
                  a[g].calculateValueToPixelConversionParameters();
                  a[g].calculateBreaksSizeInValues();
                  N2 += E[g] + a[g].margin;
                }
              if (d && 0 < d.length)
                for (g = 0; g < d.length; g++) {
                  O = d[g]._labels && 0 < d[g]._labels.length ? d[g]._labels[0].textBlock.fontSize / 2 : 0;
                  l = Math.round(f.x1 - e);
                  h2 = b && 0 < b.length ? Math.round(b[0] ? b[0].lineCoordinates.y2 : f.y1 < Math.max(O, 10) ? Math.max(O, 10) : f.y1) : f.y1 < Math.max(O, 10) ? Math.max(O, 10) : f.y1;
                  n2 = Math.round(f.x2 - W2 - V2);
                  k = c && 0 < c.length ? Math.round(c[0] ? c[0].lineCoordinates.y1 : f.y2 - T2 > m.height - Math.max(O, 10) ? m.height - Math.max(
                    O,
                    10
                  ) : f.y2 - T2) : f.y2 > m.height - Math.max(O, 10) ? m.height - Math.max(O, 10) : f.y2;
                  if (c && 0 < c.length)
                    for (O = 0; O < c.length; O++)
                      c[O] && c[O].labelAutoFit && (n2 = 0 > c[O].labelAngle ? Math.max(n2, y) : 0 === c[O].labelAngle ? Math.max(n2, y / 2) : n2, l = 0 > c[O].labelAngle || 0 === c[O].labelAngle ? n2 - W2 : l);
                  if (b && 0 < b.length)
                    for (O = 0; O < b.length; O++)
                      b[O] && b[O].labelAutoFit && (n2 = b[O].lineCoordinates.x2, l = n2 - W2);
                  d[g].lineCoordinates = { x1: n2 + P2, y1: h2, x2: n2 + P2, y2: k, height: Math.abs(k - h2) };
                  "inside" === d[g].labelPlacement && 0 < g && (d[g].lineCoordinates.x1 = d[g].lineCoordinates.x1 + (v3[g] - (d[g]._titleTextBlock ? d[g]._titleTextBlock.height : 0) - 2) - d[g].tickLength - (d[g].stripLineLabelEffectiveWidth || 0), d[g].lineCoordinates.x2 = d[g].lineCoordinates.x1 + d[g].lineThickness / 2);
                  "inside" === d[g].tickPlacement && 0 < g && (d[g].lineCoordinates.x1 += d[g].tickLength, d[g].lineCoordinates.x2 = d[g].lineCoordinates.x1 + d[g].lineThickness / 2);
                  d[g].bounds = { x1: d[g].lineCoordinates.x1, y1: h2, x2: n2 + v3[g] + P2, y2: k, width: n2 - l, height: k - h2 };
                  d[g].bounds.width = d[g].bounds.x2 - d[g].bounds.x1;
                  d[g].title && (d[g]._titleTextBlock.maxWidth = 0 < d[g].titleMaxWidth && d[g].titleMaxWidth < d[g].lineCoordinates.height ? d[g].titleMaxWidth : d[g].lineCoordinates.height);
                  d[g].calculateValueToPixelConversionParameters();
                  d[g].calculateBreaksSizeInValues();
                  P2 += v3[g] + d[g].margin;
                }
              for (g = 0; g < q.length; g++)
                "axisY" === q[g].type && (q[g].calculateValueToPixelConversionParameters(), q[g].calculateBreaksSizeInValues());
              if (0 < w2) {
                if (a && 0 < a.length)
                  for (g = 0; g < a.length; g++)
                    r = M2[w2 - 1][g] === M2[w2][g] ? true : false;
                else
                  r = true;
                if (d && 0 < d.length)
                  for (g = 0; g < d.length; g++)
                    G2 = Q3[w2 - 1][g] === Q3[w2][g] ? true : false;
                else
                  G2 = true;
                if (c && 0 < c.length)
                  for (g = 0; g < c.length; g++)
                    J2 = B3[w2 - 1][g] === B3[w2][g] ? true : false;
                else
                  J2 = true;
                if (b && 0 < b.length)
                  for (g = 0; g < b.length; g++)
                    K3 = u[w2 - 1][g] === u[w2][g] ? true : false;
                else
                  K3 = true;
              }
              if (r && G2 && J2 && K3)
                break;
              w2++;
            }
            if (c && 0 < c.length)
              for (g = 0; g < c.length; g++)
                c[g].calculateStripLinesThicknessInValues(), c[g].calculateBreaksInPixels();
            if (b && 0 < b.length)
              for (g = 0; g < b.length; g++)
                b[g].calculateStripLinesThicknessInValues(), b[g].calculateBreaksInPixels();
            if (a && 0 < a.length)
              for (g = 0; g < a.length; g++)
                a[g].calculateStripLinesThicknessInValues(), a[g].calculateBreaksInPixels();
            if (d && 0 < d.length)
              for (g = 0; g < d.length; g++)
                d[g].calculateStripLinesThicknessInValues(), d[g].calculateBreaksInPixels();
          }
        };
        A.render = function(a, d, c, b, e) {
          var f = a[0] ? a[0].chart : d[0].chart;
          e = f.ctx;
          f.alignVerticalAxes && f.alignVerticalAxes();
          e.save();
          e.beginPath();
          a && a.length && e.rect(5, a[0].bounds.y1, a[0].chart.width - 10, a[a.length - 1].bounds.y2);
          d && d.length && e.rect(5, d[d.length - 1].bounds.y1, d[0].chart.width - 10, d[0].bounds.y2);
          e.clip();
          if (a && 0 < a.length)
            for (var l = 0; l < a.length; l++)
              a[l].renderLabelsTicksAndTitle();
          if (d && 0 < d.length)
            for (l = 0; l < d.length; l++)
              d[l].renderLabelsTicksAndTitle();
          e.restore();
          if (c && 0 < c.length)
            for (l = 0; l < c.length; l++)
              c[l].renderLabelsTicksAndTitle();
          if (b && 0 < b.length)
            for (l = 0; l < b.length; l++)
              b[l].renderLabelsTicksAndTitle();
          f.preparePlotArea();
          f = f.plotArea;
          e.save();
          e.beginPath();
          e.rect(f.x1, f.y1, Math.abs(f.x2 - f.x1), Math.abs(f.y2 - f.y1));
          e.clip();
          if (a && 0 < a.length)
            for (l = 0; l < a.length; l++)
              a[l].renderStripLinesOfThicknessType("value");
          if (d && 0 < d.length)
            for (l = 0; l < d.length; l++)
              d[l].renderStripLinesOfThicknessType("value");
          if (c && 0 < c.length)
            for (l = 0; l < c.length; l++)
              c[l].renderStripLinesOfThicknessType("value");
          if (b && 0 < b.length)
            for (l = 0; l < b.length; l++)
              b[l].renderStripLinesOfThicknessType("value");
          if (a && 0 < a.length)
            for (l = 0; l < a.length; l++)
              a[l].renderInterlacedColors();
          if (d && 0 < d.length)
            for (l = 0; l < d.length; l++)
              d[l].renderInterlacedColors();
          if (c && 0 < c.length)
            for (l = 0; l < c.length; l++)
              c[l].renderInterlacedColors();
          if (b && 0 < b.length)
            for (l = 0; l < b.length; l++)
              b[l].renderInterlacedColors();
          e.restore();
          if (a && 0 < a.length)
            for (l = 0; l < a.length; l++)
              a[l].renderGrid(), w && (a[l].createMask(), a[l].renderBreaksBackground());
          if (d && 0 < d.length)
            for (l = 0; l < d.length; l++)
              d[l].renderGrid(), w && (d[l].createMask(), d[l].renderBreaksBackground());
          if (c && 0 < c.length)
            for (l = 0; l < c.length; l++)
              c[l].renderGrid(), w && (c[l].createMask(), c[l].renderBreaksBackground());
          if (b && 0 < b.length)
            for (l = 0; l < b.length; l++)
              b[l].renderGrid(), w && (b[l].createMask(), b[l].renderBreaksBackground());
          if (a && 0 < a.length)
            for (l = 0; l < a.length; l++)
              a[l].renderAxisLine();
          if (d && 0 < d.length)
            for (l = 0; l < d.length; l++)
              d[l].renderAxisLine();
          if (c && 0 < c.length)
            for (l = 0; l < c.length; l++)
              c[l].renderAxisLine();
          if (b && 0 < b.length)
            for (l = 0; l < b.length; l++)
              b[l].renderAxisLine();
          if (a && 0 < a.length)
            for (l = 0; l < a.length; l++)
              a[l].renderStripLinesOfThicknessType("pixel");
          if (d && 0 < d.length)
            for (l = 0; l < d.length; l++)
              d[l].renderStripLinesOfThicknessType("pixel");
          if (c && 0 < c.length)
            for (l = 0; l < c.length; l++)
              c[l].renderStripLinesOfThicknessType("pixel");
          if (b && 0 < b.length)
            for (l = 0; l < b.length; l++)
              b[l].renderStripLinesOfThicknessType("pixel");
        };
        A.prototype.calculateStripLinesThicknessInValues = function() {
          for (var a = 0; a < this.stripLines.length; a++)
            if (null !== this.stripLines[a].startValue && null !== this.stripLines[a].endValue) {
              var d = Math.min(this.stripLines[a].startValue, this.stripLines[a].endValue), c = Math.max(this.stripLines[a].startValue, this.stripLines[a].endValue), d = this.getApparentDifference(d, c);
              this.stripLines[a].value = this.logarithmic ? this.stripLines[a].value * Math.sqrt(Math.log(Math.max(this.stripLines[a].startValue, this.stripLines[a].endValue) / Math.min(this.stripLines[a].startValue, this.stripLines[a].endValue)) / Math.log(d)) : this.stripLines[a].value + (Math.abs(this.stripLines[a].endValue - this.stripLines[a].startValue) - d) / 2;
              this.stripLines[a].thickness = d;
              this.stripLines[a]._thicknessType = "value";
            }
        };
        A.prototype.calculateBreaksSizeInValues = function() {
          for (var a = "left" === this._position || "right" === this._position ? this.lineCoordinates.height || this.chart.height : this.lineCoordinates.width || this.chart.width, d = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [], c = this.conversionParameters.pixelPerUnit || a / (this.logarithmic ? this.conversionParameters.maximum / this.conversionParameters.minimum : this.conversionParameters.maximum - this.conversionParameters.minimum), b = this.scaleBreaks && !s(this.scaleBreaks.options.spacing), e, f = 0; f < d.length; f++)
            e = b || !s(d[f].options.spacing), d[f].spacing = Ta(d[f].spacing, a, 8, e ? 0.1 * a : 8, e ? 0 : 3) << 0, d[f].size = 0 > d[f].spacing ? 0 : Math.abs(d[f].spacing / c), this.logarithmic && (d[f].size = Math.pow(this.logarithmBase, d[f].size));
        };
        A.prototype.calculateBreaksInPixels = function() {
          if (!(this.scaleBreaks && 0 >= this.scaleBreaks._appliedBreaks.length)) {
            var a = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [];
            a.length && (this.scaleBreaks.firstBreakIndex = this.scaleBreaks.lastBreakIndex = null);
            for (var d = 0; d < a.length && !(a[d].startValue > this.conversionParameters.maximum); d++)
              a[d].endValue < this.conversionParameters.minimum || (s(this.scaleBreaks.firstBreakIndex) && (this.scaleBreaks.firstBreakIndex = d), a[d].startValue >= this.conversionParameters.minimum && (a[d].startPixel = this.convertValueToPixel(a[d].startValue), this.scaleBreaks.lastBreakIndex = d), a[d].endValue <= this.conversionParameters.maximum && (a[d].endPixel = this.convertValueToPixel(a[d].endValue)));
          }
        };
        A.prototype.renderLabelsTicksAndTitle = function() {
          var a = this, d = false, c = 0, b = 0, e = 1, f = 0;
          0 !== this.labelAngle && 360 !== this.labelAngle && (e = 1.2);
          if ("undefined" === typeof this.options.interval) {
            if ("bottom" === this._position || "top" === this._position)
              if (this.logarithmic && !this.equidistantInterval && this.labelAutoFit) {
                for (var c = [], e = 0 !== this.labelAngle && 360 !== this.labelAngle ? 1 : 1.2, l, h2 = this.viewportMaximum, n2 = this.lineCoordinates.width / Math.log(this.range), k = this._labels.length - 1; 0 <= k; k--) {
                  p = this._labels[k];
                  if (p.position < this.viewportMinimum)
                    break;
                  p.position > this.viewportMaximum || !(k === this._labels.length - 1 || l < Math.log(h2 / p.position) * n2 / e) || (c.push(p), h2 = p.position, l = p.textBlock.width * Math.abs(Math.cos(Math.PI / 180 * this.labelAngle)) + p.textBlock.height * Math.abs(Math.sin(Math.PI / 180 * this.labelAngle)));
                }
                this._labels = c;
              } else {
                for (k = 0; k < this._labels.length; k++)
                  p = this._labels[k], p.position < this.viewportMinimum || (l = p.textBlock.width * Math.abs(Math.cos(Math.PI / 180 * this.labelAngle)) + p.textBlock.height * Math.abs(Math.sin(Math.PI / 180 * this.labelAngle)), c += l);
                c > this.lineCoordinates.width * e && this.labelAutoFit && (d = true);
              }
            if ("left" === this._position || "right" === this._position)
              if (this.logarithmic && !this.equidistantInterval && this.labelAutoFit) {
                for (var c = [], m, h2 = this.viewportMaximum, n2 = this.lineCoordinates.height / Math.log(this.range), k = this._labels.length - 1; 0 <= k; k--) {
                  p = this._labels[k];
                  if (p.position < this.viewportMinimum)
                    break;
                  p.position > this.viewportMaximum || !(k === this._labels.length - 1 || m < Math.log(h2 / p.position) * n2) || (c.push(p), h2 = p.position, m = p.textBlock.height * Math.abs(Math.cos(Math.PI / 180 * this.labelAngle)) + p.textBlock.width * Math.abs(Math.sin(Math.PI / 180 * this.labelAngle)));
                }
                this._labels = c;
              } else {
                for (k = 0; k < this._labels.length; k++)
                  p = this._labels[k], p.position < this.viewportMinimum || (m = p.textBlock.height * Math.abs(Math.cos(Math.PI / 180 * this.labelAngle)) + p.textBlock.width * Math.abs(Math.sin(Math.PI / 180 * this.labelAngle)), b += m);
                b > this.lineCoordinates.height * e && this.labelAutoFit && (d = true);
              }
          }
          this.logarithmic && (!this.equidistantInterval && this.labelAutoFit) && this._labels.sort(function(a2, b2) {
            return a2.position - b2.position;
          });
          var k = 0, p, q;
          if ("bottom" === this._position) {
            for (k = 0; k < this._labels.length; k++)
              p = this._labels[k], p.position < this.viewportMinimum || p.position > this.viewportMaximum || (q = this.getPixelCoordinatesOnAxis(p.position), this.tickThickness && "inside" != this.tickPlacement && (this.ctx.lineWidth = this.tickThickness, this.ctx.strokeStyle = this.tickColor, b = 1 === this.ctx.lineWidth % 2 ? (q.x << 0) + 0.5 : q.x << 0, this.ctx.beginPath(), this.ctx.moveTo(b, q.y << 0), this.ctx.lineTo(b, q.y + this.tickLength << 0), this.ctx.stroke()), d && 0 !== f++ % 2 && this.labelAutoFit || (0 === p.textBlock.angle ? (q.x -= p.textBlock.width / 2, q.y = "inside" === this.labelPlacement ? q.y - (("inside" === this.tickPlacement ? this.tickLength : 0) + p.textBlock.height - p.textBlock.fontSize / 2) : q.y + ("inside" === this.tickPlacement ? 0 : this.tickLength) + p.textBlock.fontSize / 2 + 5) : (q.x = "inside" === this.labelPlacement ? 0 > this.labelAngle ? q.x : q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : q.x - (0 > this.labelAngle ? p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : 0), q.y = "inside" === this.labelPlacement ? 0 > this.labelAngle ? q.y - ("inside" === this.tickPlacement ? this.tickLength : 0) - 5 : q.y - ("inside" === this.tickPlacement ? this.tickLength : 0) - Math.abs(p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) + 5) : q.y + ("inside" === this.tickPlacement ? 0 : this.tickLength) + Math.abs(0 > this.labelAngle ? p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) - 5 : 5)), p.textBlock.x = q.x, p.textBlock.y = q.y));
            "inside" === this.tickPlacement && this.chart.addEventListener(
              "dataAnimationIterationEnd",
              function() {
                for (k = 0; k < a._labels.length; k++)
                  if (p = a._labels[k], !(p.position < a.viewportMinimum || p.position > a.viewportMaximum) && (q = a.getPixelCoordinatesOnAxis(p.position), a.tickThickness)) {
                    a.ctx.lineWidth = a.tickThickness;
                    a.ctx.strokeStyle = a.tickColor;
                    var b2 = 1 === a.ctx.lineWidth % 2 ? (q.x << 0) + 0.5 : q.x << 0;
                    a.ctx.save();
                    a.ctx.beginPath();
                    a.ctx.moveTo(b2, q.y << 0);
                    a.ctx.lineTo(b2, q.y - a.tickLength << 0);
                    a.ctx.stroke();
                    a.ctx.restore();
                  }
              },
              this
            );
            this.title && (this._titleTextBlock.measureText(), this._titleTextBlock.x = this.lineCoordinates.x1 + this.lineCoordinates.width / 2 - this._titleTextBlock.width / 2, this._titleTextBlock.y = this.bounds.y2 - this._titleTextBlock.height - 3, this.titleMaxWidth = this._titleTextBlock.maxWidth, this._titleTextBlock.render(true));
          } else if ("top" === this._position) {
            for (k = 0; k < this._labels.length; k++)
              p = this._labels[k], p.position < this.viewportMinimum || p.position > this.viewportMaximum || (q = this.getPixelCoordinatesOnAxis(p.position), this.tickThickness && "inside" != this.tickPlacement && (this.ctx.lineWidth = this.tickThickness, this.ctx.strokeStyle = this.tickColor, b = 1 === this.ctx.lineWidth % 2 ? (q.x << 0) + 0.5 : q.x << 0, this.ctx.beginPath(), this.ctx.moveTo(b, q.y << 0), this.ctx.lineTo(b, q.y - this.tickLength << 0), this.ctx.stroke()), d && 0 !== f++ % 2 && this.labelAutoFit || (0 === p.textBlock.angle ? (q.x -= p.textBlock.width / 2, q.y = "inside" === this.labelPlacement ? q.y + this.labelFontSize / 2 + ("inside" === this.tickPlacement ? this.tickLength : 0) + 5 : q.y - (("inside" === this.tickPlacement ? 0 : this.tickLength) + p.textBlock.height - p.textBlock.fontSize / 2)) : (q.x = "inside" === this.labelPlacement ? 0 < this.labelAngle ? q.x : q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : q.x + (p.textBlock.height - this.labelFontSize) * Math.sin(Math.PI / 180 * this.labelAngle) - (0 < this.labelAngle ? p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : 0), q.y = "inside" === this.labelPlacement ? 0 < this.labelAngle ? q.y + ("inside" === this.tickPlacement ? this.tickLength : 0) + 5 : q.y - p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) + ("inside" === this.tickPlacement ? this.tickLength : 0) + 5 : q.y - (("inside" === this.tickPlacement ? 0 : this.tickLength) + ((p.textBlock.height - p.textBlock.fontSize / 2) * Math.cos(Math.PI / 180 * this.labelAngle) + (0 < this.labelAngle ? p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) : 0)))), p.textBlock.x = q.x, p.textBlock.y = q.y));
            "inside" === this.tickPlacement && this.chart.addEventListener("dataAnimationIterationEnd", function() {
              for (k = 0; k < a._labels.length; k++)
                if (p = a._labels[k], !(p.position < a.viewportMinimum || p.position > a.viewportMaximum) && (q = a.getPixelCoordinatesOnAxis(p.position), a.tickThickness)) {
                  a.ctx.lineWidth = a.tickThickness;
                  a.ctx.strokeStyle = a.tickColor;
                  var b2 = 1 === a.ctx.lineWidth % 2 ? (q.x << 0) + 0.5 : q.x << 0;
                  a.ctx.save();
                  a.ctx.beginPath();
                  a.ctx.moveTo(b2, q.y << 0);
                  a.ctx.lineTo(b2, q.y + a.tickLength << 0);
                  a.ctx.stroke();
                  a.ctx.restore();
                }
            }, this);
            this.title && (this._titleTextBlock.measureText(), this._titleTextBlock.x = this.lineCoordinates.x1 + this.lineCoordinates.width / 2 - this._titleTextBlock.width / 2, this._titleTextBlock.y = this.bounds.y1 + 1, this.titleMaxWidth = this._titleTextBlock.maxWidth, this._titleTextBlock.render(true));
          } else if ("left" === this._position) {
            for (k = 0; k < this._labels.length; k++)
              p = this._labels[k], p.position < this.viewportMinimum || p.position > this.viewportMaximum || (q = this.getPixelCoordinatesOnAxis(p.position), this.tickThickness && "inside" != this.tickPlacement && (this.ctx.lineWidth = this.tickThickness, this.ctx.strokeStyle = this.tickColor, b = 1 === this.ctx.lineWidth % 2 ? (q.y << 0) + 0.5 : q.y << 0, this.ctx.beginPath(), this.ctx.moveTo(q.x << 0, b), this.ctx.lineTo(q.x - this.tickLength << 0, b), this.ctx.stroke()), d && 0 !== f++ % 2 && this.labelAutoFit || (0 === this.labelAngle ? (p.textBlock.y = q.y, p.textBlock.x = "inside" === this.labelPlacement ? q.x + ("inside" === this.tickPlacement ? this.tickLength : 0) + 5 : q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) - ("inside" === this.tickPlacement ? 0 : this.tickLength) - 5) : (p.textBlock.y = "inside" === this.labelPlacement ? q.y : q.y - p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle), p.textBlock.x = "inside" === this.labelPlacement ? q.x + ("inside" === this.tickPlacement ? this.tickLength : 0) + 5 : 0 < this.labelAngle ? q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) - ("inside" === this.tickPlacement ? 0 : this.tickLength) - 5 : q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) + (p.textBlock.height - p.textBlock.fontSize / 2 - 5) * Math.sin(Math.PI / 180 * this.labelAngle) - ("inside" === this.tickPlacement ? 0 : this.tickLength))));
            "inside" === this.tickPlacement && this.chart.addEventListener("dataAnimationIterationEnd", function() {
              for (k = 0; k < a._labels.length; k++)
                if (p = a._labels[k], !(p.position < a.viewportMinimum || p.position > a.viewportMaximum) && (q = a.getPixelCoordinatesOnAxis(p.position), a.tickThickness)) {
                  a.ctx.lineWidth = a.tickThickness;
                  a.ctx.strokeStyle = a.tickColor;
                  var b2 = 1 === a.ctx.lineWidth % 2 ? (q.y << 0) + 0.5 : q.y << 0;
                  a.ctx.save();
                  a.ctx.beginPath();
                  a.ctx.moveTo(q.x << 0, b2);
                  a.ctx.lineTo(q.x + a.tickLength << 0, b2);
                  a.ctx.stroke();
                  a.ctx.restore();
                }
            }, this);
            this.title && (this._titleTextBlock.measureText(), this._titleTextBlock.x = this.bounds.x1 + 1, this._titleTextBlock.y = this.lineCoordinates.height / 2 + this._titleTextBlock.width / 2 + this.lineCoordinates.y1, this.titleMaxWidth = this._titleTextBlock.maxWidth, this._titleTextBlock.render(true));
          } else if ("right" === this._position) {
            for (k = 0; k < this._labels.length; k++)
              p = this._labels[k], p.position < this.viewportMinimum || p.position > this.viewportMaximum || (q = this.getPixelCoordinatesOnAxis(p.position), this.tickThickness && "inside" != this.tickPlacement && (this.ctx.lineWidth = this.tickThickness, this.ctx.strokeStyle = this.tickColor, b = 1 === this.ctx.lineWidth % 2 ? (q.y << 0) + 0.5 : q.y << 0, this.ctx.beginPath(), this.ctx.moveTo(q.x << 0, b), this.ctx.lineTo(q.x + this.tickLength << 0, b), this.ctx.stroke()), d && 0 !== f++ % 2 && this.labelAutoFit || (0 === this.labelAngle ? (p.textBlock.y = q.y, p.textBlock.x = "inside" === this.labelPlacement ? q.x - p.textBlock.width - ("inside" === this.tickPlacement ? this.tickLength : 0) - 5 : q.x + ("inside" === this.tickPlacement ? 0 : this.tickLength) + 5) : (p.textBlock.y = "inside" === this.labelPlacement ? q.y - p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) : 0 > this.labelAngle ? q.y : q.y - (p.textBlock.height - p.textBlock.fontSize / 2 - 5) * Math.cos(Math.PI / 180 * this.labelAngle), p.textBlock.x = "inside" === this.labelPlacement ? q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) - ("inside" === this.tickPlacement ? this.tickLength : 0) - 5 : 0 < this.labelAngle ? q.x + (p.textBlock.height - p.textBlock.fontSize / 2 - 5) * Math.sin(Math.PI / 180 * this.labelAngle) + ("inside" === this.tickPlacement ? 0 : this.tickLength) : q.x + ("inside" === this.tickPlacement ? 0 : this.tickLength) + 5)));
            "inside" === this.tickPlacement && this.chart.addEventListener("dataAnimationIterationEnd", function() {
              for (k = 0; k < a._labels.length; k++)
                if (p = a._labels[k], !(p.position < a.viewportMinimum || p.position > a.viewportMaximum) && (q = a.getPixelCoordinatesOnAxis(p.position), a.tickThickness)) {
                  a.ctx.lineWidth = a.tickThickness;
                  a.ctx.strokeStyle = a.tickColor;
                  var b2 = 1 === a.ctx.lineWidth % 2 ? (q.y << 0) + 0.5 : q.y << 0;
                  a.ctx.save();
                  a.ctx.beginPath();
                  a.ctx.moveTo(q.x << 0, b2);
                  a.ctx.lineTo(q.x - a.tickLength << 0, b2);
                  a.ctx.stroke();
                  a.ctx.restore();
                }
            }, this);
            this.title && (this._titleTextBlock.measureText(), this._titleTextBlock.x = this.bounds.x2 - 1, this._titleTextBlock.y = this.lineCoordinates.height / 2 - this._titleTextBlock.width / 2 + this.lineCoordinates.y1, this.titleMaxWidth = this._titleTextBlock.maxWidth, this._titleTextBlock.render(true));
          }
          f = 0;
          if ("inside" === this.labelPlacement)
            this.chart.addEventListener("dataAnimationIterationEnd", function() {
              for (k = 0; k < a._labels.length; k++)
                p = a._labels[k], p.position < a.viewportMinimum || (p.position > a.viewportMaximum || d && 0 !== f++ % 2 && a.labelAutoFit) || (a.ctx.save(), a.ctx.beginPath(), p.textBlock.render(true), a.ctx.restore());
            }, this);
          else
            for (k = 0; k < this._labels.length; k++)
              p = this._labels[k], p.position < this.viewportMinimum || (p.position > this.viewportMaximum || d && 0 !== f++ % 2 && this.labelAutoFit) || p.textBlock.render(true);
        };
        A.prototype.renderInterlacedColors = function() {
          var a = this.chart.plotArea.ctx, d, c, b = this.chart.plotArea, e = 0;
          d = true;
          if (("bottom" === this._position || "top" === this._position) && this.interlacedColor)
            for (a.fillStyle = this.interlacedColor, e = 0; e < this._labels.length; e++)
              d ? (d = this.getPixelCoordinatesOnAxis(this._labels[e].position), c = e + 1 > this._labels.length - 1 ? this.getPixelCoordinatesOnAxis(this.viewportMaximum) : this.getPixelCoordinatesOnAxis(this._labels[e + 1].position), a.fillRect(Math.min(c.x, d.x), b.y1, Math.abs(c.x - d.x), Math.abs(b.y1 - b.y2)), d = false) : d = true;
          else if (("left" === this._position || "right" === this._position) && this.interlacedColor)
            for (a.fillStyle = this.interlacedColor, e = 0; e < this._labels.length; e++)
              d ? (c = this.getPixelCoordinatesOnAxis(this._labels[e].position), d = e + 1 > this._labels.length - 1 ? this.getPixelCoordinatesOnAxis(this.viewportMaximum) : this.getPixelCoordinatesOnAxis(this._labels[e + 1].position), a.fillRect(b.x1, Math.min(c.y, d.y), Math.abs(b.x1 - b.x2), Math.abs(d.y - c.y)), d = false) : d = true;
          a.beginPath();
        };
        A.prototype.renderStripLinesOfThicknessType = function(a) {
          if (this.stripLines && 0 < this.stripLines.length && a) {
            for (var d = this, c, b = 0, e = 0, f = false, l = false, h2 = [], n2 = [], l = false, b = 0; b < this.stripLines.length; b++) {
              var k = this.stripLines[b];
              k._thicknessType === a && ("pixel" === a && (k.value < this.viewportMinimum || k.value > this.viewportMaximum || s(k.value) || isNaN(this.range)) || "value" === a && (k.startValue <= this.viewportMinimum && k.endValue <= this.viewportMinimum || k.startValue >= this.viewportMaximum && k.endValue >= this.viewportMaximum || s(k.startValue) || s(k.endValue) || isNaN(this.range)) || h2.push(k));
            }
            for (b = 0; b < this._stripLineLabels.length; b++)
              if (k = this.stripLines[b], c = this._stripLineLabels[b], !(c.position < this.viewportMinimum || c.position > this.viewportMaximum || isNaN(this.range))) {
                a = this.getPixelCoordinatesOnAxis(c.position);
                if ("outside" === c.stripLine.labelPlacement)
                  if (k && (this.ctx.strokeStyle = k.color, this.ctx.lineWidth = "pixel" === k._thicknessType ? k.thickness : this.tickThickness), "bottom" === this._position) {
                    var m = 1 === this.ctx.lineWidth % 2 ? (a.x << 0) + 0.5 : a.x << 0;
                    this.ctx.beginPath();
                    this.ctx.moveTo(
                      m,
                      a.y << 0
                    );
                    this.ctx.lineTo(m, a.y + this.tickLength << 0);
                    this.ctx.stroke();
                    0 === this.labelAngle ? (a.x -= c.textBlock.width / 2, a.y += this.tickLength + c.textBlock.fontSize / 2 + 5) : (a.x -= 0 > this.labelAngle ? c.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : 0, a.y += this.tickLength + Math.abs(0 > this.labelAngle ? c.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) - 5 : 5));
                  } else
                    "top" === this._position ? (m = 1 === this.ctx.lineWidth % 2 ? (a.x << 0) + 0.5 : a.x << 0, this.ctx.beginPath(), this.ctx.moveTo(m, a.y << 0), this.ctx.lineTo(m, a.y - this.tickLength << 0), this.ctx.stroke(), 0 === this.labelAngle ? (a.x -= c.textBlock.width / 2, a.y -= this.tickLength + c.textBlock.height - c.textBlock.fontSize / 2) : (a.x += (c.textBlock.height - this.tickLength - this.labelFontSize / 2) * Math.sin(Math.PI / 180 * this.labelAngle) - (0 < this.labelAngle ? c.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : 0), a.y -= this.tickLength + (c.textBlock.height * Math.cos(Math.PI / 180 * this.labelAngle) + (0 < this.labelAngle ? c.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) : 0)))) : "left" === this._position ? (m = 1 === this.ctx.lineWidth % 2 ? (a.y << 0) + 0.5 : a.y << 0, this.ctx.beginPath(), this.ctx.moveTo(a.x << 0, m), this.ctx.lineTo(a.x - this.tickLength << 0, m), this.ctx.stroke(), 0 === this.labelAngle ? a.x = a.x - c.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) - this.tickLength - 5 : (a.y -= c.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle), a.x = 0 < this.labelAngle ? a.x - c.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) - this.tickLength - 5 : a.x - c.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) + (c.textBlock.height - c.textBlock.fontSize / 2 - 5) * Math.sin(Math.PI / 180 * this.labelAngle) - this.tickLength)) : "right" === this._position && (m = 1 === this.ctx.lineWidth % 2 ? (a.y << 0) + 0.5 : a.y << 0, this.ctx.beginPath(), this.ctx.moveTo(a.x << 0, m), this.ctx.lineTo(a.x + this.tickLength << 0, m), this.ctx.stroke(), 0 === this.labelAngle ? a.x = a.x + this.tickLength + 5 : (a.y = 0 > this.labelAngle ? a.y : a.y - (c.textBlock.height - c.textBlock.fontSize / 2 - 5) * Math.cos(Math.PI / 180 * this.labelAngle), a.x = 0 < this.labelAngle ? a.x + (c.textBlock.height - c.textBlock.fontSize / 2 - 5) * Math.sin(Math.PI / 180 * this.labelAngle) + this.tickLength : a.x + this.tickLength + 5));
                else
                  c.textBlock.angle = -90, "bottom" === this._position ? (c.textBlock.maxWidth = this.options.stripLines[b].labelMaxWidth ? this.options.stripLines[b].labelMaxWidth : this.chart.plotArea.height - 3, c.textBlock.measureText(), a.x - c.textBlock.height - k.thickness / 2 > this.chart.plotArea.x1 ? s(k.startValue) ? a.x -= c.textBlock.height - c.textBlock.fontSize / 2 + k.thickness / 2 : a.x -= c.textBlock.height / 2 - c.textBlock.fontSize / 2 : (c.textBlock.angle = 90, s(k.startValue) ? a.x += c.textBlock.height - c.textBlock.fontSize / 2 + k.thickness / 2 : a.x += c.textBlock.height / 2 - c.textBlock.fontSize / 2), a.y = -90 === c.textBlock.angle ? "near" === c.stripLine.labelAlign ? this.chart.plotArea.y2 - 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.y2 + this.chart.plotArea.y1 + c.textBlock.width) / 2 : this.chart.plotArea.y1 + c.textBlock.width + 3 : "near" === c.stripLine.labelAlign ? this.chart.plotArea.y2 - c.textBlock.width - 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.y2 + this.chart.plotArea.y1 - c.textBlock.width) / 2 : this.chart.plotArea.y1 + 3) : "top" === this._position ? (c.textBlock.maxWidth = this.options.stripLines[b].labelMaxWidth ? this.options.stripLines[b].labelMaxWidth : this.chart.plotArea.height - 3, c.textBlock.measureText(), a.x - c.textBlock.height - k.thickness / 2 > this.chart.plotArea.x1 ? s(k.startValue) ? a.x -= c.textBlock.height - c.textBlock.fontSize / 2 + k.thickness / 2 : a.x -= c.textBlock.height / 2 - c.textBlock.fontSize / 2 : (c.textBlock.angle = 90, s(k.startValue) ? a.x += c.textBlock.height - c.textBlock.fontSize / 2 + k.thickness / 2 : a.x += c.textBlock.height / 2 - c.textBlock.fontSize / 2), a.y = -90 === c.textBlock.angle ? "near" === c.stripLine.labelAlign ? this.chart.plotArea.y1 + c.textBlock.width + 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.y2 + this.chart.plotArea.y1 + c.textBlock.width) / 2 : this.chart.plotArea.y2 - 3 : "near" === c.stripLine.labelAlign ? this.chart.plotArea.y1 + 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.y2 + this.chart.plotArea.y1 - c.textBlock.width) / 2 : this.chart.plotArea.y2 - c.textBlock.width - 3) : "left" === this._position ? (c.textBlock.maxWidth = this.options.stripLines[b].labelMaxWidth ? this.options.stripLines[b].labelMaxWidth : this.chart.plotArea.width - 3, c.textBlock.angle = 0, c.textBlock.measureText(), a.y - c.textBlock.height - k.thickness / 2 > this.chart.plotArea.y1 ? s(k.startValue) ? a.y -= c.textBlock.height - c.textBlock.fontSize / 2 + k.thickness / 2 : a.y -= c.textBlock.height / 2 - c.textBlock.fontSize / 2 : s(k.startValue) ? a.y += c.textBlock.height - c.textBlock.fontSize / 2 + k.thickness / 2 : a.y += c.textBlock.height / 2 - c.textBlock.fontSize + 3, a.x = "near" === c.stripLine.labelAlign ? this.chart.plotArea.x1 + 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.x2 + this.chart.plotArea.x1) / 2 - c.textBlock.width / 2 : this.chart.plotArea.x2 - c.textBlock.width - 3) : "right" === this._position && (c.textBlock.maxWidth = this.options.stripLines[b].labelMaxWidth ? this.options.stripLines[b].labelMaxWidth : this.chart.plotArea.width - 3, c.textBlock.angle = 0, c.textBlock.measureText(), a.y - c.textBlock.height - k.thickness / 2 > this.chart.plotArea.y1 ? s(k.startValue) ? a.y -= c.textBlock.height - c.textBlock.fontSize / 2 + k.thickness / 2 : a.y -= c.textBlock.height / 2 - c.textBlock.fontSize / 2 : s(k.startValue) ? a.y += c.textBlock.height - c.textBlock.fontSize / 2 + k.thickness / 2 : a.y -= c.textBlock.height / 2 - c.textBlock.fontSize / 2 + 3, a.x = "near" === c.stripLine.labelAlign ? this.chart.plotArea.x2 - c.textBlock.width - 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.x2 + this.chart.plotArea.x1) / 2 - c.textBlock.width / 2 : this.chart.plotArea.x1 + 3);
                c.textBlock.x = a.x;
                c.textBlock.y = a.y;
                n2.push(c);
              }
            if (!l) {
              l = false;
              this.ctx.save();
              this.ctx.beginPath();
              this.ctx.rect(
                this.chart.plotArea.x1,
                this.chart.plotArea.y1,
                this.chart.plotArea.width,
                this.chart.plotArea.height
              );
              this.ctx.clip();
              for (b = 0; b < h2.length; b++)
                k = h2[b], k.showOnTop ? f || (f = true, this.chart.addEventListener("dataAnimationIterationEnd", function() {
                  this.ctx.save();
                  this.ctx.beginPath();
                  this.ctx.rect(this.chart.plotArea.x1, this.chart.plotArea.y1, this.chart.plotArea.width, this.chart.plotArea.height);
                  this.ctx.clip();
                  for (e = 0; e < h2.length; e++)
                    k = h2[e], k.showOnTop && k.render();
                  this.ctx.restore();
                }, k)) : k.render();
              for (b = 0; b < n2.length; b++)
                c = n2[b], c.stripLine.showOnTop ? l || (l = true, this.chart.addEventListener(
                  "dataAnimationIterationEnd",
                  function() {
                    for (e = 0; e < n2.length; e++)
                      c = n2[e], "inside" === c.stripLine.labelPlacement && c.stripLine.showOnTop && (d.ctx.save(), d.ctx.beginPath(), d.ctx.rect(d.chart.plotArea.x1, d.chart.plotArea.y1, d.chart.plotArea.width, d.chart.plotArea.height), d.ctx.clip(), c.textBlock.render(true), d.ctx.restore());
                  },
                  c.textBlock
                )) : "inside" === c.stripLine.labelPlacement && c.textBlock.render(true);
              this.ctx.restore();
              l = true;
            }
            if (l)
              for (l = false, b = 0; b < n2.length; b++)
                c = n2[b], "outside" === c.stripLine.labelPlacement && c.textBlock.render(true);
          }
        };
        A.prototype.renderBreaksBackground = function() {
          this.chart._breaksCanvas && (this.scaleBreaks && 0 < this.scaleBreaks._appliedBreaks.length && this.maskCanvas) && (this.chart._breaksCanvasCtx.save(), this.chart._breaksCanvasCtx.beginPath(), this.chart._breaksCanvasCtx.rect(this.chart.plotArea.x1, this.chart.plotArea.y1, this.chart.plotArea.width, this.chart.plotArea.height), this.chart._breaksCanvasCtx.clip(), this.chart._breaksCanvasCtx.drawImage(this.maskCanvas, 0, 0, this.chart.width, this.chart.height), this.chart._breaksCanvasCtx.restore());
        };
        A.prototype.createMask = function() {
          if (this.scaleBreaks && 0 < this.scaleBreaks._appliedBreaks.length) {
            var a = this.scaleBreaks._appliedBreaks;
            w ? (this.maskCanvas = ua(this.chart.width, this.chart.height), this.maskCtx = this.maskCanvas.getContext("2d")) : (this.maskCanvas = this.chart.plotArea.canvas, this.maskCtx = this.chart.plotArea.ctx);
            this.maskCtx.save();
            this.maskCtx.beginPath();
            this.maskCtx.rect(this.chart.plotArea.x1, this.chart.plotArea.y1, this.chart.plotArea.width, this.chart.plotArea.height);
            this.maskCtx.clip();
            for (var d = 0; d < a.length; d++)
              a[d].endValue < this.viewportMinimum || (a[d].startValue > this.viewportMaximum || isNaN(this.range)) || a[d].render(this.maskCtx);
            this.maskCtx.restore();
          }
        };
        A.prototype.renderCrosshair = function(a, d) {
          isFinite(this.minimum) && isFinite(this.maximum) && this.crosshair.render(a, d);
        };
        A.prototype.showCrosshair = function(a) {
          s(a) || (a < this.viewportMinimum || a > this.viewportMaximum) || ("top" === this._position || "bottom" === this._position ? this.crosshair.render(this.convertValueToPixel(a), null, a) : this.crosshair.render(
            null,
            this.convertValueToPixel(a),
            a
          ));
        };
        A.prototype.renderGrid = function() {
          if (this.gridThickness && 0 < this.gridThickness) {
            var a = this.chart.ctx;
            a.save();
            var d, c = this.chart.plotArea;
            a.lineWidth = this.gridThickness;
            a.strokeStyle = this.gridColor;
            a.setLineDash && a.setLineDash(J(this.gridDashType, this.gridThickness));
            if ("bottom" === this._position || "top" === this._position)
              for (b = 0; b < this._labels.length; b++)
                this._labels[b].position < this.viewportMinimum || (this._labels[b].position > this.viewportMaximum || this._labels[b].breaksLabelType) || (a.beginPath(), d = this.getPixelCoordinatesOnAxis(this._labels[b].position), d = 1 === a.lineWidth % 2 ? (d.x << 0) + 0.5 : d.x << 0, a.moveTo(d, c.y1 << 0), a.lineTo(d, c.y2 << 0), a.stroke());
            else if ("left" === this._position || "right" === this._position)
              for (var b = 0; b < this._labels.length; b++)
                this._labels[b].position < this.viewportMinimum || (this._labels[b].position > this.viewportMaximum || this._labels[b].breaksLabelType) || (a.beginPath(), d = this.getPixelCoordinatesOnAxis(this._labels[b].position), d = 1 === a.lineWidth % 2 ? (d.y << 0) + 0.5 : d.y << 0, a.moveTo(c.x1 << 0, d), a.lineTo(c.x2 << 0, d), a.stroke());
            a.restore();
          }
        };
        A.prototype.renderAxisLine = function() {
          var a = this.chart.ctx, d = w ? this.chart._preRenderCtx : a, c = Math.ceil(this.tickThickness / (this.reversed ? -2 : 2)), b = Math.ceil(this.tickThickness / (this.reversed ? 2 : -2)), e, f;
          d.save();
          if ("bottom" === this._position || "top" === this._position) {
            if (this.lineThickness) {
              this.reversed ? (e = this.lineCoordinates.x2, f = this.lineCoordinates.x1) : (e = this.lineCoordinates.x1, f = this.lineCoordinates.x2);
              d.lineWidth = this.lineThickness;
              d.strokeStyle = this.lineColor ? this.lineColor : "black";
              d.setLineDash && d.setLineDash(J(this.lineDashType, this.lineThickness));
              var l = 1 === this.lineThickness % 2 ? (this.lineCoordinates.y1 << 0) + 0.5 : this.lineCoordinates.y1 << 0;
              d.beginPath();
              if (this.scaleBreaks && !s(this.scaleBreaks.firstBreakIndex))
                if (s(this.scaleBreaks.lastBreakIndex))
                  e = this.scaleBreaks._appliedBreaks[this.scaleBreaks.firstBreakIndex].endPixel + b;
                else
                  for (var h2 = this.scaleBreaks.firstBreakIndex; h2 <= this.scaleBreaks.lastBreakIndex; h2++)
                    d.moveTo(e, l), d.lineTo(this.scaleBreaks._appliedBreaks[h2].startPixel + c, l), e = this.scaleBreaks._appliedBreaks[h2].endPixel + b;
              e && (d.moveTo(e, l), d.lineTo(f, l));
              d.stroke();
            }
          } else if (("left" === this._position || "right" === this._position) && this.lineThickness) {
            this.reversed ? (e = this.lineCoordinates.y1, f = this.lineCoordinates.y2) : (e = this.lineCoordinates.y2, f = this.lineCoordinates.y1);
            d.lineWidth = this.lineThickness;
            d.strokeStyle = this.lineColor;
            d.setLineDash && d.setLineDash(J(this.lineDashType, this.lineThickness));
            l = 1 === this.lineThickness % 2 ? (this.lineCoordinates.x1 << 0) + 0.5 : this.lineCoordinates.x1 << 0;
            d.beginPath();
            if (this.scaleBreaks && !s(this.scaleBreaks.firstBreakIndex))
              if (s(this.scaleBreaks.lastBreakIndex))
                e = this.scaleBreaks._appliedBreaks[this.scaleBreaks.firstBreakIndex].endPixel + c;
              else
                for (h2 = this.scaleBreaks.firstBreakIndex; h2 <= this.scaleBreaks.lastBreakIndex; h2++)
                  d.moveTo(l, e), d.lineTo(l, this.scaleBreaks._appliedBreaks[h2].startPixel + b), e = this.scaleBreaks._appliedBreaks[h2].endPixel + c;
            e && (d.moveTo(l, e), d.lineTo(l, f));
            d.stroke();
          }
          w && (a.drawImage(
            this.chart._preRenderCanvas,
            0,
            0,
            this.chart.width,
            this.chart.height
          ), this.chart._breaksCanvasCtx && this.chart._breaksCanvasCtx.drawImage(this.chart._preRenderCanvas, 0, 0, this.chart.width, this.chart.height), d.clearRect(0, 0, this.chart.width, this.chart.height));
          d.restore();
        };
        A.prototype.getPixelCoordinatesOnAxis = function(a) {
          var d = {};
          if ("bottom" === this._position || "top" === this._position)
            d.x = this.convertValueToPixel(a), d.y = this.lineCoordinates.y1;
          if ("left" === this._position || "right" === this._position)
            d.y = this.convertValueToPixel(a), d.x = this.lineCoordinates.x2;
          return d;
        };
        A.prototype.convertPixelToValue = function(a) {
          if ("undefined" === typeof a)
            return null;
          var d = 0, c = 0, b, d = true, e = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [], c = "number" === typeof a ? a : "left" === this._position || "right" === this._position ? a.y : a.x;
          if (this.logarithmic) {
            a = b = Math.pow(this.logarithmBase, (c - this.conversionParameters.reference) / this.conversionParameters.pixelPerUnit);
            if (c <= this.conversionParameters.reference === ("left" === this._position || "right" === this._position) !== this.reversed)
              for (c = 0; c < e.length; c++) {
                if (!(e[c].endValue < this.conversionParameters.minimum))
                  if (d)
                    if (e[c].startValue < this.conversionParameters.minimum) {
                      if (1 < e[c].size && this.conversionParameters.minimum * Math.pow(e[c].endValue / e[c].startValue, Math.log(b) / Math.log(e[c].size)) < e[c].endValue) {
                        a = Math.pow(e[c].endValue / e[c].startValue, Math.log(b) / Math.log(e[c].size));
                        break;
                      } else
                        a *= e[c].endValue / this.conversionParameters.minimum / Math.pow(e[c].size, Math.log(e[c].endValue / this.conversionParameters.minimum) / Math.log(e[c].endValue / e[c].startValue)), b /= Math.pow(e[c].size, Math.log(e[c].endValue / this.conversionParameters.minimum) / Math.log(e[c].endValue / e[c].startValue));
                      d = false;
                    } else if (b > e[c].startValue / this.conversionParameters.minimum) {
                      b /= e[c].startValue / this.conversionParameters.minimum;
                      if (b < e[c].size) {
                        a *= Math.pow(e[c].endValue / e[c].startValue, 1 === e[c].size ? 1 : Math.log(b) / Math.log(e[c].size)) / b;
                        break;
                      } else
                        a *= e[c].endValue / e[c].startValue / e[c].size;
                      b /= e[c].size;
                      d = false;
                    } else
                      break;
                  else if (b > e[c].startValue / e[c - 1].endValue) {
                    b /= e[c].startValue / e[c - 1].endValue;
                    if (b < e[c].size) {
                      a *= Math.pow(e[c].endValue / e[c].startValue, 1 === e[c].size ? 1 : Math.log(b) / Math.log(e[c].size)) / b;
                      break;
                    } else
                      a *= e[c].endValue / e[c].startValue / e[c].size;
                    b /= e[c].size;
                  } else
                    break;
              }
            else
              for (c = e.length - 1; 0 <= c; c--)
                if (!(e[c].startValue > this.conversionParameters.minimum))
                  if (d)
                    if (e[c].endValue > this.conversionParameters.minimum) {
                      if (1 < e[c].size && this.conversionParameters.minimum * Math.pow(e[c].endValue / e[c].startValue, Math.log(b) / Math.log(e[c].size)) > e[c].startValue) {
                        a = Math.pow(
                          e[c].endValue / e[c].startValue,
                          Math.log(b) / Math.log(e[c].size)
                        );
                        break;
                      } else
                        a *= e[c].startValue / this.conversionParameters.minimum * Math.pow(e[c].size, Math.log(e[c].startValue / this.conversionParameters.minimum) / Math.log(e[c].endValue / e[c].startValue)) * b, b *= Math.pow(e[c].size, Math.log(this.conversionParameters.minimum / e[c].startValue) / Math.log(e[c].endValue / e[c].startValue));
                      d = false;
                    } else if (b < e[c].endValue / this.conversionParameters.minimum) {
                      b /= e[c].endValue / this.conversionParameters.minimum;
                      if (b > 1 / e[c].size) {
                        a *= Math.pow(e[c].endValue / e[c].startValue, 1 >= e[c].size ? 1 : Math.log(b) / Math.log(e[c].size)) * b;
                        break;
                      } else
                        a /= e[c].endValue / e[c].startValue / e[c].size;
                      b *= e[c].size;
                      d = false;
                    } else
                      break;
                  else if (b < e[c].endValue / e[c + 1].startValue) {
                    b /= e[c].endValue / e[c + 1].startValue;
                    if (b > 1 / e[c].size) {
                      a *= Math.pow(e[c].endValue / e[c].startValue, 1 >= e[c].size ? 1 : Math.log(b) / Math.log(e[c].size)) * b;
                      break;
                    } else
                      a /= e[c].endValue / e[c].startValue / e[c].size;
                    b *= e[c].size;
                  } else
                    break;
            d = a * this.viewportMinimum;
          } else {
            a = b = (c - this.conversionParameters.reference) / this.conversionParameters.pixelPerUnit;
            if (c <= this.conversionParameters.reference === ("left" === this._position || "right" === this._position) !== this.reversed)
              for (c = 0; c < e.length; c++) {
                if (!(e[c].endValue < this.conversionParameters.minimum))
                  if (d)
                    if (e[c].startValue < this.conversionParameters.minimum) {
                      if (e[c].size && this.conversionParameters.minimum + b * (e[c].endValue - e[c].startValue) / e[c].size < e[c].endValue) {
                        a = 0 >= e[c].size ? 0 : b * (e[c].endValue - e[c].startValue) / e[c].size;
                        break;
                      } else
                        a += e[c].endValue - this.conversionParameters.minimum - e[c].size * (e[c].endValue - this.conversionParameters.minimum) / (e[c].endValue - e[c].startValue), b -= e[c].size * (e[c].endValue - this.conversionParameters.minimum) / (e[c].endValue - e[c].startValue);
                      d = false;
                    } else if (b > e[c].startValue - this.conversionParameters.minimum) {
                      b -= e[c].startValue - this.conversionParameters.minimum;
                      if (b < e[c].size) {
                        a += (e[c].endValue - e[c].startValue) * (0 === e[c].size ? 1 : b / e[c].size) - b;
                        break;
                      } else
                        a += e[c].endValue - e[c].startValue - e[c].size;
                      b -= e[c].size;
                      d = false;
                    } else
                      break;
                  else if (b > e[c].startValue - e[c - 1].endValue) {
                    b -= e[c].startValue - e[c - 1].endValue;
                    if (b < e[c].size) {
                      a += (e[c].endValue - e[c].startValue) * (0 === e[c].size ? 1 : b / e[c].size) - b;
                      break;
                    } else
                      a += e[c].endValue - e[c].startValue - e[c].size;
                    b -= e[c].size;
                  } else
                    break;
              }
            else
              for (c = e.length - 1; 0 <= c; c--)
                if (!(e[c].startValue > this.conversionParameters.minimum))
                  if (d)
                    if (e[c].endValue > this.conversionParameters.minimum)
                      if (e[c].size && this.conversionParameters.minimum + b * (e[c].endValue - e[c].startValue) / e[c].size > e[c].startValue) {
                        a = 0 >= e[c].size ? 0 : b * (e[c].endValue - e[c].startValue) / e[c].size;
                        break;
                      } else
                        a += e[c].startValue - this.conversionParameters.minimum + e[c].size * (this.conversionParameters.minimum - e[c].startValue) / (e[c].endValue - e[c].startValue), b += e[c].size * (this.conversionParameters.minimum - e[c].startValue) / (e[c].endValue - e[c].startValue), d = false;
                    else if (b < e[c].endValue - this.conversionParameters.minimum) {
                      b -= e[c].endValue - this.conversionParameters.minimum;
                      if (b > -1 * e[c].size) {
                        a += (e[c].endValue - e[c].startValue) * (0 === e[c].size ? 1 : b / e[c].size) + b;
                        break;
                      } else
                        a -= e[c].endValue - e[c].startValue - e[c].size;
                      b += e[c].size;
                      d = false;
                    } else
                      break;
                  else if (b < e[c].endValue - e[c + 1].startValue) {
                    b -= e[c].endValue - e[c + 1].startValue;
                    if (b > -1 * e[c].size) {
                      a += (e[c].endValue - e[c].startValue) * (0 === e[c].size ? 1 : b / e[c].size) + b;
                      break;
                    } else
                      a -= e[c].endValue - e[c].startValue - e[c].size;
                    b += e[c].size;
                  } else
                    break;
            d = this.conversionParameters.minimum + a;
          }
          return d;
        };
        A.prototype.convertValueToPixel = function(a) {
          a = this.getApparentDifference(this.conversionParameters.minimum, a, a);
          return this.logarithmic ? this.conversionParameters.reference + this.conversionParameters.pixelPerUnit * Math.log(a / this.conversionParameters.minimum) / this.conversionParameters.lnLogarithmBase + 0.5 << 0 : "axisX" === this.type ? this.conversionParameters.reference + this.conversionParameters.pixelPerUnit * (a - this.conversionParameters.minimum) + 0.5 << 0 : this.conversionParameters.reference + this.conversionParameters.pixelPerUnit * (a - this.conversionParameters.minimum) + 0.5;
        };
        A.prototype.getApparentDifference = function(a, d, c, b) {
          var e = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [];
          if (this.logarithmic) {
            c = s(c) ? d / a : c;
            for (var f = 0; f < e.length && !(d < e[f].startValue); f++)
              a > e[f].endValue || (a <= e[f].startValue && d >= e[f].endValue ? c = c / e[f].endValue * e[f].startValue * e[f].size : a >= e[f].startValue && d >= e[f].endValue ? c = c / e[f].endValue * a * Math.pow(e[f].size, Math.log(e[f].endValue / a) / Math.log(e[f].endValue / e[f].startValue)) : a <= e[f].startValue && d <= e[f].endValue ? c = c / d * e[f].startValue * Math.pow(e[f].size, Math.log(d / e[f].startValue) / Math.log(e[f].endValue / e[f].startValue)) : !b && (a > e[f].startValue && d < e[f].endValue) && (c = a * Math.pow(e[f].size, Math.log(d / a) / Math.log(e[f].endValue / e[f].startValue))));
          } else
            for (c = s(c) ? Math.abs(d - a) : c, f = 0; f < e.length && !(d < e[f].startValue); f++)
              a > e[f].endValue || (a <= e[f].startValue && d >= e[f].endValue ? c = c - e[f].endValue + e[f].startValue + e[f].size : a > e[f].startValue && d >= e[f].endValue ? c = c - e[f].endValue + a + e[f].size * (e[f].endValue - a) / (e[f].endValue - e[f].startValue) : a <= e[f].startValue && d < e[f].endValue ? c = c - d + e[f].startValue + e[f].size * (d - e[f].startValue) / (e[f].endValue - e[f].startValue) : !b && (a > e[f].startValue && d < e[f].endValue) && (c = a + e[f].size * (d - a) / (e[f].endValue - e[f].startValue)));
          return c;
        };
        A.prototype.setViewPortRange = function(a, d) {
          this.sessionVariables.newViewportMinimum = this.viewportMinimum = Math.min(a, d);
          this.sessionVariables.newViewportMaximum = this.viewportMaximum = Math.max(a, d);
        };
        A.prototype.getXValueAt = function(a) {
          if (!a)
            return null;
          var d = null;
          "left" === this._position ? d = this.convertPixelToValue(a.y) : "bottom" === this._position && (d = this.convertPixelToValue(a.x));
          return d;
        };
        A.prototype.calculateValueToPixelConversionParameters = function(a) {
          a = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [];
          var d = { pixelPerUnit: null, minimum: null, reference: null }, c = this.lineCoordinates.width, b = this.lineCoordinates.height, c = "bottom" === this._position || "top" === this._position ? c : b, b = Math.abs(this.range);
          if (this.logarithmic)
            for (var e = 0; e < a.length && !(this.viewportMaximum < a[e].startValue); e++)
              this.viewportMinimum > a[e].endValue || (this.viewportMinimum >= a[e].startValue && this.viewportMaximum <= a[e].endValue ? c = 0 : this.viewportMinimum <= a[e].startValue && this.viewportMaximum >= a[e].endValue ? (b = b / a[e].endValue * a[e].startValue, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100) : c - Math.min(a[e].spacing, 0.1 * c)) : this.viewportMinimum > a[e].startValue && this.viewportMaximum >= a[e].endValue ? (b = b / a[e].endValue * this.viewportMinimum, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100 * Math.log(a[e].endValue / this.viewportMinimum) / Math.log(a[e].endValue / a[e].startValue)) : c - Math.min(a[e].spacing, 0.1 * c) * Math.log(a[e].endValue / this.viewportMinimum) / Math.log(a[e].endValue / a[e].startValue)) : this.viewportMinimum <= a[e].startValue && this.viewportMaximum < a[e].endValue && (b = b / this.viewportMaximum * a[e].startValue, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100 * Math.log(this.viewportMaximum / a[e].startValue) / Math.log(a[e].endValue / a[e].startValue)) : c - Math.min(a[e].spacing, 0.1 * c) * Math.log(this.viewportMaximum / a[e].startValue) / Math.log(a[e].endValue / a[e].startValue)));
          else
            for (e = 0; e < a.length && !(this.viewportMaximum < a[e].startValue); e++)
              this.viewportMinimum > a[e].endValue || (this.viewportMinimum >= a[e].startValue && this.viewportMaximum <= a[e].endValue ? c = 0 : this.viewportMinimum <= a[e].startValue && this.viewportMaximum >= a[e].endValue ? (b = b - a[e].endValue + a[e].startValue, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100) : c - Math.min(a[e].spacing, 0.1 * c)) : this.viewportMinimum > a[e].startValue && this.viewportMaximum >= a[e].endValue ? (b = b - a[e].endValue + this.viewportMinimum, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100 * (a[e].endValue - this.viewportMinimum) / (a[e].endValue - a[e].startValue)) : c - Math.min(a[e].spacing, 0.1 * c) * (a[e].endValue - this.viewportMinimum) / (a[e].endValue - a[e].startValue)) : this.viewportMinimum <= a[e].startValue && this.viewportMaximum < a[e].endValue && (b = b - this.viewportMaximum + a[e].startValue, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100 * (this.viewportMaximum - a[e].startValue) / (a[e].endValue - a[e].startValue)) : c - Math.min(a[e].spacing, 0.1 * c) * (this.viewportMaximum - a[e].startValue) / (a[e].endValue - a[e].startValue)));
          d.minimum = this.viewportMinimum;
          d.maximum = this.viewportMaximum;
          d.range = b;
          if ("bottom" === this._position || "top" === this._position)
            this.logarithmic ? (d.lnLogarithmBase = Math.log(this.logarithmBase), d.pixelPerUnit = (this.reversed ? -1 : 1) * c * d.lnLogarithmBase / Math.log(Math.abs(b))) : d.pixelPerUnit = (this.reversed ? -1 : 1) * c / Math.abs(b), d.reference = this.reversed ? this.lineCoordinates.x2 : this.lineCoordinates.x1;
          if ("left" === this._position || "right" === this._position)
            this.logarithmic ? (d.lnLogarithmBase = Math.log(this.logarithmBase), d.pixelPerUnit = (this.reversed ? 1 : -1) * c * d.lnLogarithmBase / Math.log(Math.abs(b))) : d.pixelPerUnit = (this.reversed ? 1 : -1) * c / Math.abs(b), d.reference = this.reversed ? this.lineCoordinates.y1 : this.lineCoordinates.y2;
          this.conversionParameters = d;
        };
        A.prototype.calculateAxisParameters = function() {
          if (this.logarithmic)
            this.calculateLogarithmicAxisParameters();
          else {
            var a = this.chart.layoutManager.getFreeSpace(), d = false, c = false;
            "bottom" === this._position || "top" === this._position ? (this.maxWidth = a.width, this.maxHeight = a.height) : (this.maxWidth = a.height, this.maxHeight = a.width);
            var a = "axisX" === this.type ? "xySwapped" === this.chart.plotInfo.axisPlacement ? 62 : 70 : "xySwapped" === this.chart.plotInfo.axisPlacement ? 50 : 40, b = 4;
            "axisX" === this.type && (b = 600 > this.maxWidth ? 8 : 6);
            var a = Math.max(b, Math.floor(this.maxWidth / a)), e, f, l, b = 0;
            !s(this.options.viewportMinimum) && (!s(this.options.viewportMaximum) && this.options.viewportMinimum >= this.options.viewportMaximum) && (this.viewportMinimum = this.viewportMaximum = null);
            if (s(this.options.viewportMinimum) && !s(this.sessionVariables.newViewportMinimum) && !isNaN(this.sessionVariables.newViewportMinimum))
              this.viewportMinimum = this.sessionVariables.newViewportMinimum;
            else if (null === this.viewportMinimum || isNaN(this.viewportMinimum))
              this.viewportMinimum = this.minimum;
            if (s(this.options.viewportMaximum) && !s(this.sessionVariables.newViewportMaximum) && !isNaN(this.sessionVariables.newViewportMaximum))
              this.viewportMaximum = this.sessionVariables.newViewportMaximum;
            else if (null === this.viewportMaximum || isNaN(this.viewportMaximum))
              this.viewportMaximum = this.maximum;
            if (this.scaleBreaks) {
              for (b = 0; b < this.scaleBreaks._appliedBreaks.length; b++)
                if ((!s(this.sessionVariables.newViewportMinimum) && this.sessionVariables.newViewportMinimum >= this.scaleBreaks._appliedBreaks[b].startValue || !s(this.options.minimum) && this.options.minimum >= this.scaleBreaks._appliedBreaks[b].startValue || !s(this.options.viewportMinimum) && this.viewportMinimum >= this.scaleBreaks._appliedBreaks[b].startValue) && (!s(this.sessionVariables.newViewportMaximum) && this.sessionVariables.newViewportMaximum <= this.scaleBreaks._appliedBreaks[b].endValue || !s(this.options.maximum) && this.options.maximum <= this.scaleBreaks._appliedBreaks[b].endValue || !s(this.options.viewportMaximum) && this.viewportMaximum <= this.scaleBreaks._appliedBreaks[b].endValue)) {
                  this.scaleBreaks._appliedBreaks.splice(b, 1);
                  break;
                }
            }
            if ("axisX" === this.type) {
              if (this.dataSeries && 0 < this.dataSeries.length)
                for (e = 0; e < this.dataSeries.length; e++)
                  "dateTime" === this.dataSeries[e].xValueType && (c = true);
              e = null !== this.viewportMinimum ? this.viewportMinimum : this.dataInfo.viewPortMin;
              f = null !== this.viewportMaximum ? this.viewportMaximum : this.dataInfo.viewPortMax;
              0 === f - e && (b = "undefined" === typeof this.options.interval ? 0.4 : this.options.interval, f += b, e -= b);
              Infinity !== this.dataInfo.minDiff ? l = this.dataInfo.minDiff : 1 < f - e ? l = 0.5 * Math.abs(f - e) : (l = 1, c && (d = true));
            } else
              "axisY" === this.type && (e = null !== this.viewportMinimum ? this.viewportMinimum : this.dataInfo.viewPortMin, f = null !== this.viewportMaximum ? this.viewportMaximum : this.dataInfo.viewPortMax, isFinite(e) || isFinite(f) ? isFinite(e) ? isFinite(f) || (f = e) : e = f : (f = "undefined" === typeof this.options.interval ? -Infinity : this.options.interval, e = "undefined" !== typeof this.options.interval || isFinite(this.dataInfo.minDiff) ? 0 : Infinity), 0 === e && 0 === f ? (f += 9, e = 0) : 0 === f - e ? (b = Math.min(Math.abs(0.01 * Math.abs(f)), 5), f += b, e -= b) : e > f ? (b = Math.min(0.01 * Math.abs(this.getApparentDifference(f, e, null, true)), 5), 0 <= f ? e = f - b : f = isFinite(e) ? e + b : 0) : (b = Math.min(0.01 * Math.abs(this.getApparentDifference(e, f, null, true)), 0.05), 0 !== f && (f += b), 0 !== e && (e -= b)), l = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : 1 < f - e ? 0.5 * Math.abs(f - e) : 1, this.includeZero && (null === this.viewportMinimum || isNaN(this.viewportMinimum)) && 0 < e && (e = 0), this.includeZero && (null === this.viewportMaximum || isNaN(this.viewportMaximum)) && 0 > f && (f = 0));
            b = this.getApparentDifference(isNaN(this.viewportMinimum) || null === this.viewportMinimum ? e : this.viewportMinimum, isNaN(this.viewportMaximum) || null === this.viewportMaximum ? f : this.viewportMaximum, null, true);
            if ("axisX" === this.type && c) {
              this.valueType = "dateTime";
              this.intervalType || (b / 1 <= a ? (this.interval = 1, this.intervalType = "millisecond") : b / 2 <= a ? (this.interval = 2, this.intervalType = "millisecond") : b / 5 <= a ? (this.interval = 5, this.intervalType = "millisecond") : b / 10 <= a ? (this.interval = 10, this.intervalType = "millisecond") : b / 20 <= a ? (this.interval = 20, this.intervalType = "millisecond") : b / 50 <= a ? (this.interval = 50, this.intervalType = "millisecond") : b / 100 <= a ? (this.interval = 100, this.intervalType = "millisecond") : b / 200 <= a ? (this.interval = 200, this.intervalType = "millisecond") : b / 250 <= a ? (this.interval = 250, this.intervalType = "millisecond") : b / 300 <= a ? (this.interval = 300, this.intervalType = "millisecond") : b / 400 <= a ? (this.interval = 400, this.intervalType = "millisecond") : b / 500 <= a ? (this.interval = 500, this.intervalType = "millisecond") : b / (1 * T.secondDuration) <= a ? (this.interval = 1, this.intervalType = "second") : b / (2 * T.secondDuration) <= a ? (this.interval = 2, this.intervalType = "second") : b / (5 * T.secondDuration) <= a ? (this.interval = 5, this.intervalType = "second") : b / (10 * T.secondDuration) <= a ? (this.interval = 10, this.intervalType = "second") : b / (15 * T.secondDuration) <= a ? (this.interval = 15, this.intervalType = "second") : b / (20 * T.secondDuration) <= a ? (this.interval = 20, this.intervalType = "second") : b / (30 * T.secondDuration) <= a ? (this.interval = 30, this.intervalType = "second") : b / (1 * T.minuteDuration) <= a ? (this.interval = 1, this.intervalType = "minute") : b / (2 * T.minuteDuration) <= a ? (this.interval = 2, this.intervalType = "minute") : b / (5 * T.minuteDuration) <= a ? (this.interval = 5, this.intervalType = "minute") : b / (10 * T.minuteDuration) <= a ? (this.interval = 10, this.intervalType = "minute") : b / (15 * T.minuteDuration) <= a ? (this.interval = 15, this.intervalType = "minute") : b / (20 * T.minuteDuration) <= a ? (this.interval = 20, this.intervalType = "minute") : b / (30 * T.minuteDuration) <= a ? (this.interval = 30, this.intervalType = "minute") : b / (1 * T.hourDuration) <= a ? (this.interval = 1, this.intervalType = "hour") : b / (2 * T.hourDuration) <= a ? (this.interval = 2, this.intervalType = "hour") : b / (3 * T.hourDuration) <= a ? (this.interval = 3, this.intervalType = "hour") : b / (6 * T.hourDuration) <= a ? (this.interval = 6, this.intervalType = "hour") : b / (1 * T.dayDuration) <= a ? (this.interval = 1, this.intervalType = "day") : b / (2 * T.dayDuration) <= a ? (this.interval = 2, this.intervalType = "day") : b / (4 * T.dayDuration) <= a ? (this.interval = 4, this.intervalType = "day") : b / (1 * T.weekDuration) <= a ? (this.interval = 1, this.intervalType = "week") : b / (2 * T.weekDuration) <= a ? (this.interval = 2, this.intervalType = "week") : b / (3 * T.weekDuration) <= a ? (this.interval = 3, this.intervalType = "week") : b / (1 * T.monthDuration) <= a ? (this.interval = 1, this.intervalType = "month") : b / (2 * T.monthDuration) <= a ? (this.interval = 2, this.intervalType = "month") : b / (3 * T.monthDuration) <= a ? (this.interval = 3, this.intervalType = "month") : b / (6 * T.monthDuration) <= a ? (this.interval = 6, this.intervalType = "month") : (this.interval = b / (1 * T.yearDuration) <= a ? 1 : b / (2 * T.yearDuration) <= a ? 2 : b / (4 * T.yearDuration) <= a ? 4 : Math.floor(A.getNiceNumber(b / (a - 1), true) / T.yearDuration), this.intervalType = "year"));
              if (null === this.viewportMinimum || isNaN(this.viewportMinimum))
                this.viewportMinimum = e - l / 2;
              if (null === this.viewportMaximum || isNaN(this.viewportMaximum))
                this.viewportMaximum = f + l / 2;
              d ? this.autoValueFormatString = "MMM DD YYYY HH:mm" : "year" === this.intervalType ? this.autoValueFormatString = "YYYY" : "month" === this.intervalType ? this.autoValueFormatString = "MMM YYYY" : "week" === this.intervalType ? this.autoValueFormatString = "MMM DD YYYY" : "day" === this.intervalType ? this.autoValueFormatString = "MMM DD YYYY" : "hour" === this.intervalType ? this.autoValueFormatString = "hh:mm TT" : "minute" === this.intervalType ? this.autoValueFormatString = "hh:mm TT" : "second" === this.intervalType ? this.autoValueFormatString = "hh:mm:ss TT" : "millisecond" === this.intervalType && (this.autoValueFormatString = "fff'ms'");
              this.valueFormatString || (this.valueFormatString = this.autoValueFormatString);
            } else {
              this.intervalType = "number";
              b = A.getNiceNumber(b, false);
              this.interval = this.options && 0 < this.options.interval ? this.options.interval : A.getNiceNumber(b / (a - 1), true);
              if (null === this.viewportMinimum || isNaN(this.viewportMinimum))
                this.viewportMinimum = "axisX" === this.type ? e - l / 2 : Math.floor(e / this.interval) * this.interval;
              if (null === this.viewportMaximum || isNaN(this.viewportMaximum))
                this.viewportMaximum = "axisX" === this.type ? f + l / 2 : Math.ceil(f / this.interval) * this.interval;
              0 === this.viewportMaximum && 0 === this.viewportMinimum && (0 === this.options.viewportMinimum ? this.viewportMaximum += 10 : 0 === this.options.viewportMaximum && (this.viewportMinimum -= 10), this.options && "undefined" === typeof this.options.interval && (this.interval = A.getNiceNumber((this.viewportMaximum - this.viewportMinimum) / (a - 1), true)));
            }
            if (null === this.minimum || null === this.maximum)
              if ("axisX" === this.type ? (e = null !== this.minimum ? this.minimum : this.dataInfo.min, f = null !== this.maximum ? this.maximum : this.dataInfo.max, 0 === f - e && (b = "undefined" === typeof this.options.interval ? 0.4 : this.options.interval, f += b, e -= b), l = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : 1 < f - e ? 0.5 * Math.abs(f - e) : 1) : "axisY" === this.type && (e = null !== this.minimum ? this.minimum : this.dataInfo.min, f = null !== this.maximum ? this.maximum : this.dataInfo.max, isFinite(e) || isFinite(f) ? 0 === e && 0 === f ? (f += 9, e = 0) : 0 === f - e ? (b = Math.min(
                Math.abs(0.01 * Math.abs(f)),
                5
              ), f += b, e -= b) : e > f ? (b = Math.min(0.01 * Math.abs(this.getApparentDifference(f, e, null, true)), 5), 0 <= f ? e = f - b : f = isFinite(e) ? e + b : 0) : (b = Math.min(0.01 * Math.abs(this.getApparentDifference(e, f, null, true)), 0.05), 0 !== f && (f += b), 0 !== e && (e -= b)) : (f = "undefined" === typeof this.options.interval ? -Infinity : this.options.interval, e = "undefined" !== typeof this.options.interval || isFinite(this.dataInfo.minDiff) ? 0 : Infinity), l = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : 1 < f - e ? 0.5 * Math.abs(f - e) : 1, this.includeZero && (null === this.minimum || isNaN(this.minimum)) && 0 < e && (e = 0), this.includeZero && (null === this.maximum || isNaN(this.maximum)) && 0 > f && (f = 0)), Math.abs(this.getApparentDifference(e, f, null, true)), "axisX" === this.type && c) {
                this.valueType = "dateTime";
                if (null === this.minimum || isNaN(this.minimum))
                  this.minimum = e - l / 2, this.minimum = Math.min(this.minimum, null === this.sessionVariables.viewportMinimum || isNaN(this.sessionVariables.viewportMinimum) ? Infinity : this.sessionVariables.viewportMinimum);
                if (null === this.maximum || isNaN(this.maximum))
                  this.maximum = f + l / 2, this.maximum = Math.max(this.maximum, null === this.sessionVariables.viewportMaximum || isNaN(this.sessionVariables.viewportMaximum) ? -Infinity : this.sessionVariables.viewportMaximum);
              } else
                this.intervalType = this.valueType = "number", null === this.minimum && (this.minimum = "axisX" === this.type ? e - l / 2 : Math.floor(e / this.interval) * this.interval, this.minimum = Math.min(this.minimum, null === this.sessionVariables.viewportMinimum || isNaN(this.sessionVariables.viewportMinimum) ? Infinity : this.sessionVariables.viewportMinimum)), null === this.maximum && (this.maximum = "axisX" === this.type ? f + l / 2 : Math.ceil(f / this.interval) * this.interval, this.maximum = Math.max(this.maximum, null === this.sessionVariables.viewportMaximum || isNaN(this.sessionVariables.viewportMaximum) ? -Infinity : this.sessionVariables.viewportMaximum)), 0 === this.maximum && 0 === this.minimum && (0 === this.options.minimum ? this.maximum += 10 : 0 === this.options.maximum && (this.minimum -= 10));
            s(this.sessionVariables.newViewportMinimum) && (this.viewportMinimum = Math.max(this.viewportMinimum, this.minimum));
            s(this.sessionVariables.newViewportMaximum) && (this.viewportMaximum = Math.min(this.viewportMaximum, this.maximum));
            this.range = this.viewportMaximum - this.viewportMinimum;
            this.intervalStartPosition = "axisX" === this.type && c ? this.getLabelStartPoint(new Date(this.viewportMinimum), this.intervalType, this.interval) : Math.floor((this.viewportMinimum + 0.2 * this.interval) / this.interval) * this.interval;
            this.valueFormatString || (this.valueFormatString = A.generateValueFormatString(this.range, 2));
          }
        };
        A.prototype.calculateLogarithmicAxisParameters = function() {
          var a = this.chart.layoutManager.getFreeSpace(), d = Math.log(this.logarithmBase), c;
          "bottom" === this._position || "top" === this._position ? (this.maxWidth = a.width, this.maxHeight = a.height) : (this.maxWidth = a.height, this.maxHeight = a.width);
          var a = "axisX" === this.type ? 500 > this.maxWidth ? 7 : Math.max(7, Math.floor(this.maxWidth / 100)) : Math.max(Math.floor(this.maxWidth / 50), 3), b, e, f, l;
          l = 1;
          if (null === this.viewportMinimum || isNaN(this.viewportMinimum))
            this.viewportMinimum = this.minimum;
          if (null === this.viewportMaximum || isNaN(this.viewportMaximum))
            this.viewportMaximum = this.maximum;
          if (this.scaleBreaks) {
            for (l = 0; l < this.scaleBreaks._appliedBreaks.length; l++)
              if ((!s(this.sessionVariables.newViewportMinimum) && this.sessionVariables.newViewportMinimum >= this.scaleBreaks._appliedBreaks[l].startValue || !s(this.options.minimum) && this.options.minimum >= this.scaleBreaks._appliedBreaks[l].startValue || !s(this.options.viewportMinimum) && this.viewportMinimum >= this.scaleBreaks._appliedBreaks[l].startValue) && (!s(this.sessionVariables.newViewportMaximum) && this.sessionVariables.newViewportMaximum <= this.scaleBreaks._appliedBreaks[l].endValue || !s(this.options.maximum) && this.options.maximum <= this.scaleBreaks._appliedBreaks[l].endValue || !s(this.options.viewportMaximum) && this.viewportMaximum <= this.scaleBreaks._appliedBreaks[l].endValue)) {
                this.scaleBreaks._appliedBreaks.splice(l, 1);
                break;
              }
          }
          "axisX" === this.type ? (b = null !== this.viewportMinimum ? this.viewportMinimum : this.dataInfo.viewPortMin, e = null !== this.viewportMaximum ? this.viewportMaximum : this.dataInfo.viewPortMax, 1 === e / b && (l = Math.pow(this.logarithmBase, "undefined" === typeof this.options.interval ? 0.4 : this.options.interval), e *= l, b /= l), f = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : e / b > this.logarithmBase ? e / b * Math.pow(this.logarithmBase, 0.5) : this.logarithmBase) : "axisY" === this.type && (b = null !== this.viewportMinimum ? this.viewportMinimum : this.dataInfo.viewPortMin, e = null !== this.viewportMaximum ? this.viewportMaximum : this.dataInfo.viewPortMax, 0 >= b && !isFinite(e) ? (e = "undefined" === typeof this.options.interval ? 0 : this.options.interval, b = 1) : 0 >= b ? b = e : isFinite(e) || (e = b), 1 === b && 1 === e ? (e *= this.logarithmBase - 1 / this.logarithmBase, b = 1) : 1 === e / b ? (l = Math.min(e * Math.pow(this.logarithmBase, 0.01), Math.pow(this.logarithmBase, 5)), e *= l, b /= l) : b > e ? (l = Math.min(b / e * Math.pow(this.logarithmBase, 0.01), Math.pow(this.logarithmBase, 5)), 1 <= e ? b = e / l : e = b * l) : (l = Math.min(e / b * Math.pow(this.logarithmBase, 0.01), Math.pow(this.logarithmBase, 0.04)), 1 !== e && (e *= l), 1 !== b && (b /= l)), f = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : e / b > this.logarithmBase ? e / b * Math.pow(this.logarithmBase, 0.5) : this.logarithmBase, this.includeZero && (null === this.viewportMinimum || isNaN(this.viewportMinimum)) && 1 < b && (b = 1), this.includeZero && (null === this.viewportMaximum || isNaN(this.viewportMaximum)) && 1 > e && (e = 1));
          l = (isNaN(this.viewportMaximum) || null === this.viewportMaximum ? e : this.viewportMaximum) / (isNaN(this.viewportMinimum) || null === this.viewportMinimum ? b : this.viewportMinimum);
          var h2 = (isNaN(this.viewportMaximum) || null === this.viewportMaximum ? e : this.viewportMaximum) - (isNaN(this.viewportMinimum) || null === this.viewportMinimum ? b : this.viewportMinimum);
          this.intervalType = "number";
          l = Math.pow(this.logarithmBase, A.getNiceNumber(Math.abs(Math.log(l) / d), false));
          this.options && 0 < this.options.interval ? this.interval = this.options.interval : (this.interval = A.getNiceExponent(Math.log(l) / d / (a - 1), true), c = A.getNiceNumber(h2 / (a - 1), true));
          if (null === this.viewportMinimum || isNaN(this.viewportMinimum))
            this.viewportMinimum = "axisX" === this.type ? b / Math.sqrt(f) : Math.pow(this.logarithmBase, this.interval * Math.floor(Math.log(b) / d / this.interval));
          if (null === this.viewportMaximum || isNaN(this.viewportMaximum))
            this.viewportMaximum = "axisX" === this.type ? e * Math.sqrt(f) : Math.pow(this.logarithmBase, this.interval * Math.ceil(Math.log(e) / d / this.interval));
          1 === this.viewportMaximum && 1 === this.viewportMinimum && (1 === this.options.viewportMinimum ? this.viewportMaximum *= this.logarithmBase - 1 / this.logarithmBase : 1 === this.options.viewportMaximum && (this.viewportMinimum /= this.logarithmBase - 1 / this.logarithmBase), this.options && "undefined" === typeof this.options.interval && (this.interval = A.getNiceExponent(Math.ceil(Math.log(l) / d) / (a - 1)), c = A.getNiceNumber((this.viewportMaximum - this.viewportMinimum) / (a - 1), true)));
          if (null === this.minimum || null === this.maximum)
            "axisX" === this.type ? (b = null !== this.minimum ? this.minimum : this.dataInfo.min, e = null !== this.maximum ? this.maximum : this.dataInfo.max, 1 === e / b && (l = Math.pow(this.logarithmBase, "undefined" === typeof this.options.interval ? 0.4 : this.options.interval), e *= l, b /= l), f = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : e / b > this.logarithmBase ? e / b * Math.pow(this.logarithmBase, 0.5) : this.logarithmBase) : "axisY" === this.type && (b = null !== this.minimum ? this.minimum : this.dataInfo.min, e = null !== this.maximum ? this.maximum : this.dataInfo.max, isFinite(b) || isFinite(e) ? 1 === b && 1 === e ? (e *= this.logarithmBase, b /= this.logarithmBase) : 1 === e / b ? (l = Math.pow(this.logarithmBase, this.interval), e *= l, b /= l) : b > e ? (l = Math.min(0.01 * (b / e), 5), 1 <= e ? b = e / l : e = b * l) : (l = Math.min(e / b * Math.pow(this.logarithmBase, 0.01), Math.pow(this.logarithmBase, 0.04)), 1 !== e && (e *= l), 1 !== b && (b /= l)) : (e = "undefined" === typeof this.options.interval ? 0 : this.options.interval, b = 1), f = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : e / b > this.logarithmBase ? e / b * Math.pow(this.logarithmBase, 0.5) : this.logarithmBase, this.includeZero && (null === this.minimum || isNaN(this.minimum)) && 1 < b && (b = 1), this.includeZero && (null === this.maximum || isNaN(this.maximum)) && 1 > e && (e = 1)), this.intervalType = "number", null === this.minimum && (this.minimum = "axisX" === this.type ? b / Math.sqrt(f) : Math.pow(this.logarithmBase, this.interval * Math.floor(Math.log(b) / d / this.interval)), s(null === this.sessionVariables.viewportMinimum || isNaN(this.sessionVariables.viewportMinimum) ? "undefined" === typeof this.sessionVariables.newViewportMinimum ? Infinity : this.sessionVariables.newViewportMinimum : this.sessionVariables.viewportMinimum) || (this.minimum = Math.min(this.minimum, null === this.sessionVariables.viewportMinimum || isNaN(this.sessionVariables.viewportMinimum) ? "undefined" === typeof this.sessionVariables.newViewportMinimum ? Infinity : this.sessionVariables.newViewportMinimum : this.sessionVariables.viewportMinimum))), null === this.maximum && (this.maximum = "axisX" === this.type ? e * Math.sqrt(f) : Math.pow(this.logarithmBase, this.interval * Math.ceil(Math.log(e) / d / this.interval)), s(null === this.sessionVariables.viewportMaximum || isNaN(this.sessionVariables.viewportMaximum) ? "undefined" === typeof this.sessionVariables.newViewportMaximum ? 0 : this.sessionVariables.newViewportMaximum : this.sessionVariables.viewportMaximum) || (this.maximum = Math.max(this.maximum, null === this.sessionVariables.viewportMaximum || isNaN(this.sessionVariables.viewportMaximum) ? "undefined" === typeof this.sessionVariables.newViewportMaximum ? 0 : this.sessionVariables.newViewportMaximum : this.sessionVariables.viewportMaximum))), 1 === this.maximum && 1 === this.minimum && (1 === this.options.minimum ? this.maximum *= this.logarithmBase - 1 / this.logarithmBase : 1 === this.options.maximum && (this.minimum /= this.logarithmBase - 1 / this.logarithmBase));
          this.viewportMinimum = Math.max(this.viewportMinimum, this.minimum);
          this.viewportMaximum = Math.min(
            this.viewportMaximum,
            this.maximum
          );
          this.viewportMinimum > this.viewportMaximum && (!this.options.viewportMinimum && !this.options.minimum || this.options.viewportMaximum || this.options.maximum ? this.options.viewportMinimum || this.options.minimum || !this.options.viewportMaximum && !this.options.maximum || (this.viewportMinimum = this.minimum = (this.options.viewportMaximum || this.options.maximum) / Math.pow(this.logarithmBase, 2 * Math.ceil(this.interval))) : this.viewportMaximum = this.maximum = this.options.viewportMinimum || this.options.minimum);
          b = Math.pow(this.logarithmBase, Math.floor(Math.log(this.viewportMinimum) / (d * this.interval) + 0.2) * this.interval);
          this.range = this.viewportMaximum / this.viewportMinimum;
          this.noTicks = a;
          if (!this.options.interval && this.range < Math.pow(this.logarithmBase, 8 > this.viewportMaximum || 3 > a ? 2 : 3)) {
            for (d = Math.floor(this.viewportMinimum / c + 0.5) * c; d < this.viewportMinimum; )
              d += c;
            this.equidistantInterval = false;
            this.intervalStartPosition = d;
            this.interval = c;
          } else
            this.options.interval || (c = Math.ceil(this.interval), this.range > this.interval && (this.interval = c, b = Math.pow(this.logarithmBase, Math.floor(Math.log(this.viewportMinimum) / (d * this.interval) + 0.2) * this.interval))), this.equidistantInterval = true, this.intervalStartPosition = b;
          if (!this.valueFormatString && (this.valueFormatString = "#,##0.##", 1 > this.viewportMinimum)) {
            d = Math.floor(Math.abs(Math.log(this.viewportMinimum) / Math.LN10)) + 2;
            if (isNaN(d) || !isFinite(d))
              d = 2;
            if (2 < d)
              for (l = 0; l < d - 2; l++)
                this.valueFormatString += "#";
          }
        };
        A.generateValueFormatString = function(a, d) {
          var c = "#,##0.", b = d;
          1 > a && (b += Math.floor(Math.abs(Math.log(a) / Math.LN10)), isNaN(b) || !isFinite(b)) && (b = d);
          for (var e = 0; e < b; e++)
            c += "#";
          return c;
        };
        A.getNiceExponent = function(a, d) {
          var c = Math.floor(Math.log(a) / Math.LN10), b = a / Math.pow(10, c), b = 0 > c ? 1 >= b ? 1 : 5 >= b ? 5 : 10 : Math.max(Math.floor(b), 1);
          return -20 > c ? Number(b * Math.pow(10, c)) : Number((b * Math.pow(10, c)).toFixed(20));
        };
        A.getNiceNumber = function(a, d) {
          var c = Math.floor(Math.log(a) / Math.LN10), b = a / Math.pow(10, c), b = d ? 1.5 > b ? 1 : 3 > b ? 2 : 7 > b ? 5 : 10 : 1 >= b ? 1 : 2 >= b ? 2 : 5 >= b ? 5 : 10;
          return -20 > c ? Number(b * Math.pow(10, c)) : Number((b * Math.pow(10, c)).toFixed(20));
        };
        A.prototype.getLabelStartPoint = function() {
          var a = T[this.intervalType + "Duration"] * this.interval, a = new Date(Math.floor(this.viewportMinimum / a) * a);
          if ("millisecond" !== this.intervalType)
            if ("second" === this.intervalType)
              0 < a.getMilliseconds() && (a.setSeconds(a.getSeconds() + 1), a.setMilliseconds(0));
            else if ("minute" === this.intervalType) {
              if (0 < a.getSeconds() || 0 < a.getMilliseconds())
                a.setMinutes(a.getMinutes() + 1), a.setSeconds(0), a.setMilliseconds(0);
            } else if ("hour" === this.intervalType) {
              if (0 < a.getMinutes() || 0 < a.getSeconds() || 0 < a.getMilliseconds())
                a.setHours(a.getHours() + 1), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0);
            } else if ("day" === this.intervalType) {
              if (0 < a.getHours() || 0 < a.getMinutes() || 0 < a.getSeconds() || 0 < a.getMilliseconds())
                a.setDate(a.getDate() + 1), a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0);
            } else if ("week" === this.intervalType) {
              if (0 < a.getDay() || 0 < a.getHours() || 0 < a.getMinutes() || 0 < a.getSeconds() || 0 < a.getMilliseconds())
                a.setDate(a.getDate() + (7 - a.getDay())), a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0);
            } else if ("month" === this.intervalType) {
              if (1 < a.getDate() || 0 < a.getHours() || 0 < a.getMinutes() || 0 < a.getSeconds() || 0 < a.getMilliseconds())
                a.setMonth(a.getMonth() + 1), a.setDate(1), a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0);
            } else
              "year" === this.intervalType && (0 < a.getMonth() || 1 < a.getDate() || 0 < a.getHours() || 0 < a.getMinutes() || 0 < a.getSeconds() || 0 < a.getMilliseconds()) && (a.setFullYear(a.getFullYear() + 1), a.setMonth(0), a.setDate(1), a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0));
          return a;
        };
        oa(fa2, G);
        oa(aa2, G);
        aa2.prototype.createUserOptions = function(a) {
          if ("undefined" !== typeof a || this.options._isPlaceholder) {
            var d = 0;
            this.parent.options._isPlaceholder && this.parent.createUserOptions();
            this.options._isPlaceholder || (Ea(this.parent[this.optionsName]), d = this.parent.options[this.optionsName].indexOf(this.options));
            this.options = "undefined" === typeof a ? {} : a;
            this.parent.options[this.optionsName][d] = this.options;
          }
        };
        aa2.prototype.render = function(a) {
          if (0 !== this.spacing || 0 !== this.options.lineThickness && ("undefined" !== typeof this.options.lineThickness || 0 !== this.parent.lineThickness)) {
            var d = this.ctx, c = this.ctx.globalAlpha;
            this.ctx = a || this.ctx;
            this.ctx.save();
            this.ctx.beginPath();
            this.ctx.rect(this.chart.plotArea.x1, this.chart.plotArea.y1, this.chart.plotArea.width, this.chart.plotArea.height);
            this.ctx.clip();
            var b = this.scaleBreaks.parent.getPixelCoordinatesOnAxis(this.startValue), e = this.scaleBreaks.parent.getPixelCoordinatesOnAxis(this.endValue);
            this.ctx.strokeStyle = this.lineColor;
            this.ctx.fillStyle = this.color;
            this.ctx.beginPath();
            this.ctx.globalAlpha = 1;
            X(this.id);
            var f, l, h2, n2, k, m;
            a = Math.max(this.spacing, 3);
            var p = Math.max(0, this.lineThickness);
            this.ctx.lineWidth = p;
            this.ctx.setLineDash && this.ctx.setLineDash(J(this.lineDashType, p));
            if ("bottom" === this.scaleBreaks.parent._position || "top" === this.scaleBreaks.parent._position)
              if (b = 1 === p % 2 ? (b.x << 0) + 0.5 : b.x << 0, l = 1 === p % 2 ? (e.x << 0) + 0.5 : e.x << 0, "top" === this.scaleBreaks.parent._position ? (e = this.chart.plotArea.y1, h2 = this.chart.plotArea.y2 + p / 2 + 0.5 << 0) : (e = this.chart.plotArea.y2, h2 = this.chart.plotArea.y1 - p / 2 + 0.5 << 0, a *= -1), this.bounds = { x1: b - p / 2, y1: e, x2: l + p / 2, y2: h2 }, this.ctx.moveTo(b, e), "straight" === this.type || "top" === this.scaleBreaks.parent._position && 0 >= a || "bottom" === this.scaleBreaks.parent._position && 0 <= a)
                this.ctx.lineTo(b, h2), this.ctx.lineTo(l, h2), this.ctx.lineTo(l, e);
              else if ("wavy" === this.type) {
                n2 = b;
                k = e;
                f = 0.5;
                m = (h2 - k) / a / 3;
                for (var q = 0; q < m; q++)
                  this.ctx.bezierCurveTo(n2 + f * a, k + a, n2 + f * a, k + 2 * a, n2, k + 3 * a), k += 3 * a, f *= -1;
                this.ctx.bezierCurveTo(
                  n2 + f * a,
                  k + a,
                  n2 + f * a,
                  k + 2 * a,
                  n2,
                  k + 3 * a
                );
                n2 = l;
                f *= -1;
                this.ctx.lineTo(n2, k);
                for (q = 0; q < m; q++)
                  this.ctx.bezierCurveTo(n2 + f * a, k - a, n2 + f * a, k - 2 * a, n2, k - 3 * a), k -= 3 * a, f *= -1;
              } else {
                if ("zigzag" === this.type) {
                  f = -1;
                  k = e + a;
                  n2 = b + a;
                  m = (h2 - k) / a / 2;
                  for (q = 0; q < m; q++)
                    this.ctx.lineTo(n2, k), n2 += 2 * f * a, k += 2 * a, f *= -1;
                  this.ctx.lineTo(n2, k);
                  n2 += l - b;
                  for (q = 0; q < m + 1; q++)
                    this.ctx.lineTo(n2, k), n2 += 2 * f * a, k -= 2 * a, f *= -1;
                  this.ctx.lineTo(n2 + f * a, k + a);
                }
              }
            else if ("left" === this.scaleBreaks.parent._position || "right" === this.scaleBreaks.parent._position) {
              if (e = 1 === p % 2 ? (e.y << 0) + 0.5 : e.y << 0, h2 = 1 === p % 2 ? (b.y << 0) + 0.5 : b.y << 0, "left" === this.scaleBreaks.parent._position ? (b = this.chart.plotArea.x1, l = this.chart.plotArea.x2 + p / 2 + 0.5 << 0) : (b = this.chart.plotArea.x2, l = this.chart.plotArea.x1 - p / 2 + 0.5 << 0, a *= -1), this.bounds = { x1: b, y1: e - p / 2, x2: l, y2: h2 + p / 2 }, this.ctx.moveTo(b, e), "straight" === this.type || "left" === this.scaleBreaks.parent._position && 0 >= a || "right" === this.scaleBreaks.parent._position && 0 <= a)
                this.ctx.lineTo(l, e), this.ctx.lineTo(l, h2), this.ctx.lineTo(b, h2);
              else if ("wavy" === this.type) {
                n2 = b;
                k = e;
                f = 0.5;
                m = (l - n2) / a / 3;
                for (q = 0; q < m; q++)
                  this.ctx.bezierCurveTo(n2 + a, k + f * a, n2 + 2 * a, k + f * a, n2 + 3 * a, k), n2 += 3 * a, f *= -1;
                this.ctx.bezierCurveTo(n2 + a, k + f * a, n2 + 2 * a, k + f * a, n2 + 3 * a, k);
                k = h2;
                f *= -1;
                this.ctx.lineTo(n2, k);
                for (q = 0; q < m; q++)
                  this.ctx.bezierCurveTo(n2 - a, k + f * a, n2 - 2 * a, k + f * a, n2 - 3 * a, k), n2 -= 3 * a, f *= -1;
              } else if ("zigzag" === this.type) {
                f = 1;
                k = e - a;
                n2 = b + a;
                m = (l - n2) / a / 2;
                for (q = 0; q < m; q++)
                  this.ctx.lineTo(n2, k), k += 2 * f * a, n2 += 2 * a, f *= -1;
                this.ctx.lineTo(n2, k);
                k += h2 - e;
                for (q = 0; q < m + 1; q++)
                  this.ctx.lineTo(n2, k), k += 2 * f * a, n2 -= 2 * a, f *= -1;
                this.ctx.lineTo(n2 + a, k + f * a);
              }
            }
            0 < p && this.ctx.stroke();
            this.ctx.closePath();
            this.ctx.globalAlpha = this.fillOpacity;
            this.ctx.globalCompositeOperation = "destination-over";
            this.ctx.fill();
            this.ctx.restore();
            this.ctx.globalAlpha = c;
            this.ctx = d;
          }
        };
        oa(N, G);
        N.prototype.createUserOptions = function(a) {
          if ("undefined" !== typeof a || this.options._isPlaceholder) {
            var d = 0;
            this.parent.options._isPlaceholder && this.parent.createUserOptions();
            this.options._isPlaceholder || (Ea(this.parent.stripLines), d = this.parent.options.stripLines.indexOf(this.options));
            this.options = "undefined" === typeof a ? {} : a;
            this.parent.options.stripLines[d] = this.options;
          }
        };
        N.prototype.render = function() {
          this.ctx.save();
          var a = this.parent.getPixelCoordinatesOnAxis(this.value), d = Math.abs("pixel" === this._thicknessType ? this.thickness : Math.abs(this.parent.convertValueToPixel(this.endValue) - this.parent.convertValueToPixel(this.startValue)));
          if (0 < d) {
            var c = null === this.opacity ? 1 : this.opacity;
            this.ctx.strokeStyle = this.color;
            this.ctx.beginPath();
            var b = this.ctx.globalAlpha;
            this.ctx.globalAlpha = c;
            X(this.id);
            var e, f, h2, n2;
            this.ctx.lineWidth = d;
            this.ctx.setLineDash && this.ctx.setLineDash(J(this.lineDashType, d));
            if ("bottom" === this.parent._position || "top" === this.parent._position)
              e = f = 1 === this.ctx.lineWidth % 2 ? (a.x << 0) + 0.5 : a.x << 0, h2 = this.chart.plotArea.y1, n2 = this.chart.plotArea.y2, this.bounds = { x1: e - d / 2, y1: h2, x2: f + d / 2, y2: n2 };
            else if ("left" === this.parent._position || "right" === this.parent._position)
              h2 = n2 = 1 === this.ctx.lineWidth % 2 ? (a.y << 0) + 0.5 : a.y << 0, e = this.chart.plotArea.x1, f = this.chart.plotArea.x2, this.bounds = {
                x1: e,
                y1: h2 - d / 2,
                x2: f,
                y2: n2 + d / 2
              };
            this.ctx.moveTo(e, h2);
            this.ctx.lineTo(f, n2);
            this.ctx.stroke();
            this.ctx.globalAlpha = b;
          }
          this.ctx.restore();
        };
        oa(ca2, G);
        ca2.prototype.showAt = function(a) {
          if (!this.enabled)
            return false;
          var d = this.chart, c = false;
          d.resetOverlayedCanvas();
          d.clearedOverlayedCanvas = this.parent.type;
          this.chart.renderCrosshairs(this.parent);
          if ("xySwapped" === d.plotInfo.axisPlacement)
            if ("bottom" === this.parent._position)
              for (var b = 0; b < d.axisY.length; b++)
                this.parent === d.axisY[b] && (d.axisY[b]._crosshairValue = a >= d.axisY[b].viewportMinimum && a <= d.axisY[b].viewportMaximum ? a : null);
            else if ("top" === this.parent._position)
              for (b = 0; b < d.axisY2.length; b++)
                this.parent === d.axisY2[b] && (d.axisY2[b]._crosshairValue = a >= d.axisY2[b].viewportMinimum && a <= d.axisY2[b].viewportMaximum ? a : null);
            else if ("left" === this.parent._position)
              for (b = 0; b < d.axisX.length; b++)
                this.parent === d.axisX[b] && (d.axisX[b]._crosshairValue = a >= d.axisX[b].viewportMinimum && a <= d.axisX[b].viewportMaximum ? a : null);
            else {
              if ("right" === this.parent._position)
                for (b = 0; b < d.axisX2.length; b++)
                  this.parent === d.axisX2[b] && (d.axisX2[b]._crosshairValue = a >= d.axisX2[b].viewportMinimum && a <= d.axisX2[b].viewportMaximum ? a : null);
            }
          else if ("bottom" === this.parent._position)
            for (b = 0; b < d.axisX.length; b++)
              this.parent === d.axisX[b] && (d.axisX[b]._crosshairValue = a >= d.axisX[b].viewportMinimum && a <= d.axisX[b].viewportMaximum ? a : null);
          else if ("top" === this.parent._position)
            for (b = 0; b < d.axisX2.length; b++)
              this.parent === d.axisX2[b] && (d.axisX2[b]._crosshairValue = a >= d.axisX2[b].viewportMinimum && a <= d.axisX2[b].viewportMaximum ? a : null);
          else if ("left" === this.parent._position)
            for (b = 0; b < d.axisY.length; b++)
              this.parent === d.axisY[b] && (d.axisY[b]._crosshairValue = a >= d.axisY[b].viewportMinimum && a <= d.axisY[b].viewportMaximum ? a : null);
          else if ("right" === this.parent._position)
            for (b = 0; b < d.axisY2.length; b++)
              this.parent === d.axisY2[b] && (d.axisY2[b]._crosshairValue = a >= d.axisY2[b].viewportMinimum && a <= d.axisY2[b].viewportMaximum ? a : null);
          for (b = 0; b < d.axisX.length; b++)
            a = d.axisX[b]._crosshairValue, d.axisX[b].crosshair && (d.axisX[b].crosshair.enabled && !s(a) && a >= d.axisX[b].viewportMinimum && a <= d.axisX[b].viewportMaximum) && (d.axisX[b].showCrosshair(a), d.axisX[b].crosshair._updatedValue = a, this === d.axisX[b].crosshair && (c = true));
          for (b = 0; b < d.axisX2.length; b++)
            a = d.axisX2[b]._crosshairValue, d.axisX2[b].crosshair && (d.axisX2[b].crosshair.enabled && !s(a) && a >= d.axisX2[b].viewportMinimum && a <= d.axisX2[b].viewportMaximum) && (d.axisX2[b].showCrosshair(a), d.axisX2[b].crosshair._updatedValue = a, this === d.axisX2[b].crosshair && (c = true));
          for (b = 0; b < d.axisY.length; b++)
            a = d.axisY[b]._crosshairValue, d.axisY[b].crosshair && (d.axisY[b].crosshair.enabled && !s(a) && a >= d.axisY[b].viewportMinimum && a <= d.axisY[b].viewportMaximum) && (d.axisY[b].showCrosshair(a), d.axisY[b].crosshair._updatedValue = a, this === d.axisY[b].crosshair && (c = true));
          for (b = 0; b < d.axisY2.length; b++)
            a = d.axisY2[b]._crosshairValue, d.axisY2[b].crosshair && (d.axisY2[b].crosshair.enabled && !s(a) && a >= d.axisY2[b].viewportMinimum && a <= d.axisY2[b].viewportMaximum) && (d.axisY2[b].showCrosshair(a), d.axisY2[b].crosshair._updatedValue = a, this === d.axisY2[b].crosshair && (c = true));
          this.chart.toolTip && this.chart.toolTip._entries && this.chart.toolTip.highlightObjects(this.chart.toolTip._entries);
          return c;
        };
        ca2.prototype.hide = function() {
          this.chart.resetOverlayedCanvas();
          this.chart.renderCrosshairs(this.parent);
          this._hidden = true;
        };
        ca2.prototype.render = function(a, d, c) {
          var b, e, f, h2, n2 = null, w2 = null, k = null, m = "";
          if (!this.valueFormatString)
            if ("dateTime" === this.parent.valueType)
              this.valueFormatString = this.parent.valueFormatString;
            else {
              var p = 0, p = "xySwapped" === this.chart.plotInfo.axisPlacement ? 50 < this.parent.range ? 0 : 500 < this.chart.width && 25 > this.parent.range ? 2 : Math.floor(Math.abs(Math.log(this.parent.range) / Math.LN10)) + (5 > this.parent.range ? 2 : 10 > this.parent.range ? 1 : 0) : 50 < this.parent.range ? 0 : Math.floor(Math.abs(Math.log(this.parent.range) / Math.LN10)) + (5 > this.parent.range ? 2 : 10 > this.parent.range ? 1 : 0);
              this.valueFormatString = A.generateValueFormatString(this.parent.range, p);
            }
          var k = null === this.opacity ? 1 : this.opacity, p = Math.abs("pixel" === this._thicknessType ? this.thickness : this.parent.conversionParameters.pixelPerUnit * this.thickness), q = this.chart.overlaidCanvasCtx, g = q.globalAlpha;
          q.globalAlpha = k;
          q.beginPath();
          q.strokeStyle = this.color;
          q.lineWidth = p;
          q.save();
          this.labelFontSize = Math.abs(s(this.options.labelFontSize) ? this.parent.labelFontSize : this.labelFontSize);
          this.labelMaxWidth = s(this.options.labelMaxWidth) ? 0.3 * this.chart.width : this.labelMaxWidth;
          this.labelMaxHeight = s(this.options.labelWrap) || this.labelWrap ? 0.3 * this.chart.height : 2 * this.labelFontSize;
          0 < p && q.setLineDash && q.setLineDash(J(this.lineDashType, p));
          k = new ja(
            q,
            { x: 0, y: 0, padding: { top: 2, right: 3, bottom: 2, left: 4 }, backgroundColor: this.labelBackgroundColor, borderColor: this.labelBorderColor, borderThickness: this.labelBorderThickness, cornerRadius: this.labelCornerRadius, maxWidth: this.labelMaxWidth, maxHeight: this.labelMaxHeight, angle: this.labelAngle, text: m, horizontalAlign: "left", fontSize: this.labelFontSize, fontFamily: this.labelFontFamily, fontWeight: this.labelFontWeight, fontColor: this.labelFontColor, fontStyle: this.labelFontStyle, textBaseline: "middle" }
          );
          if (this.snapToDataPoint) {
            var r = 0, m = [];
            if ("xySwapped" === this.chart.plotInfo.axisPlacement) {
              var v3 = null;
              if ("bottom" === this.parent._position || "top" === this.parent._position)
                r = this.parent.dataSeries[0].axisX.convertPixelToValue({ y: d });
              else if ("left" === this.parent._position || "right" === this.parent._position)
                r = this.parent.convertPixelToValue({ y: d });
              for (var B3 = 0; B3 < this.parent.dataSeries.length; B3++)
                (v3 = this.parent.dataSeries[B3].getDataPointAtX(r, true)) && 0 <= v3.index && (v3.dataSeries = this.parent.dataSeries[B3], null !== v3.dataPoint.y && v3.dataSeries.visible && m.push(v3));
              v3 = null;
              if (0 === m.length)
                return;
              m.sort(function(a2, b2) {
                return a2.distance - b2.distance;
              });
              v3 = Math.abs(a - this.parent.convertValueToPixel(m[0].dataPoint.y));
              B3 = 0;
              if ("rangeBar" === m[0].dataSeries.type || "error" === m[0].dataSeries.type)
                for (var v3 = Math.abs(a - this.parent.convertValueToPixel(m[B3].dataPoint.y[0])), u = 0, r = 0; r < m.length; r++)
                  if (m[r].dataPoint.y && m[r].dataPoint.y.length)
                    for (var y = 0; y < m[r].dataPoint.y.length; y++)
                      u = Math.abs(a - this.parent.convertValueToPixel(m[r].dataPoint.y[y])), u < v3 && (v3 = u, B3 = r);
                  else
                    u = Math.abs(a - this.parent.convertValueToPixel(m[r].dataPoint.y)), u < v3 && (v3 = u, B3 = r);
              else if ("stackedBar" === m[0].dataSeries.type)
                for (var v3 = Math.abs(a - this.parent.convertValueToPixel(m[0].dataPoint.y)), x = u = 0, r = B3 = 0; r < m.length; r++)
                  if (m[r].dataPoint.y && m[r].dataPoint.y.length)
                    for (y = 0; y < m[r].dataPoint.y.length; y++)
                      u = Math.abs(a - this.parent.convertValueToPixel(m[r].dataPoint.y[y])), u < v3 && (v3 = u, B3 = r);
                  else
                    x += m[r].dataPoint.y, u = Math.abs(a - this.parent.convertValueToPixel(x)), u < v3 && (v3 = u, B3 = r);
              else if ("stackedBar100" === m[0].dataSeries.type)
                for (var v3 = Math.abs(a - this.parent.convertValueToPixel(m[0].dataPoint.y)), z = x = u = 0, r = 0; r < m.length; r++)
                  if (m[r].dataPoint.y && m[r].dataPoint.y.length)
                    for (y = 0; y < m[r].dataPoint.y.length; y++)
                      u = Math.abs(a - this.parent.convertValueToPixel(m[r].dataPoint.y[y])), u < v3 && (v3 = u, B3 = r);
                  else
                    x += m[r].dataPoint.y, z = m[r].dataPoint.x.getTime ? m[r].dataPoint.x.getTime() : m[r].dataPoint.x, z = 100 * (x / m[r].dataSeries.plotUnit.dataPointYSums[z]), u = Math.abs(a - this.parent.convertValueToPixel(z)), u < v3 && (v3 = u, B3 = r);
              else
                for (v3 = Math.abs(a - this.parent.convertValueToPixel(m[0].dataPoint.y)), r = B3 = u = 0; r < m.length; r++)
                  if (m[r].dataPoint.y && m[r].dataPoint.y.length)
                    for (y = 0; y < m[r].dataPoint.y.length; y++)
                      u = Math.abs(a - this.parent.convertValueToPixel(m[r].dataPoint.y[y])), u < v3 && (v3 = u, B3 = r);
                  else
                    u = Math.abs(a - this.parent.convertValueToPixel(m[r].dataPoint.y)), u < v3 && (v3 = u, B3 = r);
              y = m[B3];
              if ("bottom" === this.parent._position || "top" === this.parent._position) {
                b = 0;
                if ("rangeBar" === this.parent.dataSeries[B3].type || "error" === this.parent.dataSeries[B3].type) {
                  v3 = Math.abs(a - this.parent.convertValueToPixel(y.dataPoint.y[0]));
                  for (r = u = 0; r < y.dataPoint.y.length; r++)
                    u = Math.abs(a - this.parent.convertValueToPixel(y.dataPoint.y[r])), u < v3 && (v3 = u, b = r);
                  n2 = 1 === q.lineWidth % 2 ? (this.parent.convertValueToPixel(y.dataPoint.y[b]) << 0) + 0.5 : this.parent.convertValueToPixel(y.dataPoint.y[b]) << 0;
                  this.value = y.dataPoint.y[b];
                  k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: y.dataPoint.y[b] }) : s(this.options.label) ? da(s(c) ? y.dataPoint.y[b] : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
                } else if ("stackedBar" === this.parent.dataSeries[B3].type) {
                  v3 = Math.abs(a - this.parent.convertValueToPixel(m[0].dataPoint.y));
                  x = u = 0;
                  for (r = B3; 0 <= r; r--)
                    x += m[r].dataPoint.y, u = Math.abs(a - this.parent.convertValueToPixel(x)), u < v3 && (v3 = u, b = r);
                  n2 = 1 === q.lineWidth % 2 ? (this.parent.convertValueToPixel(x) << 0) + 0.5 : this.parent.convertValueToPixel(x) << 0;
                  this.value = x;
                  k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: y.dataPoint.y }) : s(this.options.label) ? da(s(c) ? y.dataPoint.y : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
                } else if ("stackedBar100" === this.parent.dataSeries[B3].type) {
                  v3 = Math.abs(a - this.parent.convertValueToPixel(m[0].dataPoint.y));
                  z = x = u = 0;
                  for (r = B3; 0 <= r; r--)
                    x += m[r].dataPoint.y, z = m[r].dataPoint.x.getTime ? m[r].dataPoint.x.getTime() : m[r].dataPoint.x, z = 100 * (x / m[r].dataSeries.plotUnit.dataPointYSums[z]), u = Math.abs(a - this.parent.convertValueToPixel(z)), u < v3 && (v3 = u, b = r);
                  n2 = 1 === q.lineWidth % 2 ? (this.parent.convertValueToPixel(z) << 0) + 0.5 : this.parent.convertValueToPixel(z) << 0;
                  this.value = z;
                  k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: z }) : s(this.options.label) ? da(s(c) ? z : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
                } else
                  n2 = 1 === q.lineWidth % 2 ? (this.parent.convertValueToPixel(y.dataPoint.y) << 0) + 0.5 : this.parent.convertValueToPixel(y.dataPoint.y) << 0, this.value = y.dataPoint.y, k.text = this.labelFormatter ? this.labelFormatter({
                    chart: this.chart,
                    axis: this.parent.options,
                    crosshair: this.options,
                    value: y.dataPoint.y
                  }) : s(this.options.label) ? da(s(c) ? y.dataPoint.y : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
                b = e = n2;
                f = this.chart.plotArea.y1;
                h2 = this.chart.plotArea.y2;
                this.bounds = { x1: b - p / 2, y1: f, x2: e + p / 2, y2: h2 };
                k.x = b - k.measureText().width / 2;
                k.x + k.width > this.chart.bounds.x2 ? k.x = this.chart.bounds.x2 - k.width : k.x < this.chart.bounds.x1 && (k.x = this.chart.bounds.x1);
                k.y = this.parent.lineCoordinates.y2 + ("top" === this.parent._position ? -k.height + this.parent.tickLength : k.fontSize / 2) + 2;
                k.y + k.height > this.chart.bounds.y2 ? k.y = this.chart.bounds.y2 - k.height : k.y < this.chart.bounds.y1 && (k.y = this.chart.bounds.y1);
              } else if ("left" === this.parent._position || "right" === this.parent._position) {
                f = h2 = w2 = 1 === q.lineWidth % 2 ? (this.parent.convertValueToPixel(y.dataPoint.x) << 0) + 0.5 : this.parent.convertValueToPixel(y.dataPoint.x) << 0;
                b = this.chart.plotArea.x1;
                e = this.chart.plotArea.x2;
                this.bounds = { x1: b, y1: f - p / 2, x2: e, y2: h2 + p / 2 };
                z = false;
                if (this.parent.labels)
                  for (m = Math.ceil(this.parent.interval), r = 0; r < this.parent.viewportMaximum; r += m)
                    if (this.parent.labels[r])
                      z = true;
                    else {
                      z = false;
                      break;
                    }
                if (z) {
                  if ("axisX" === this.parent.type)
                    for (r = this.parent.convertPixelToValue({ y: d }), v3 = null, B3 = 0; B3 < this.parent.dataSeries.length; B3++)
                      (v3 = this.parent.dataSeries[B3].getDataPointAtX(r, true)) && 0 <= v3.index && (k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: y.dataPoint.x }) : s(this.options.label) ? v3.dataPoint.label : this.label);
                } else
                  k.text = "dateTime" !== this.parent.valueType || this.parent.logarithmic ? this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: y.dataPoint.x }) : s(this.options.label) ? da(y.dataPoint.x, this.valueFormatString, this.chart._cultureInfo) : this.label : this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: y.dataPoint.x }) : s(this.options.label) ? Ba(y.dataPoint.x, this.valueFormatString, this.chart._cultureInfo) : this.label;
                this.value = y.dataPoint.x;
                k.y = h2 + k.fontSize / 2 - k.measureText().height / 2 + 2;
                k.y - k.fontSize / 2 < this.chart.bounds.y1 ? k.y = this.chart.bounds.y1 + k.fontSize / 2 + 2 : k.y + k.measureText().height - k.fontSize / 2 > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.measureText().height + k.fontSize / 2);
                "left" === this.parent._position ? k.x = this.parent.lineCoordinates.x2 - k.measureText().width : "right" === this.parent._position && (k.x = this.parent.lineCoordinates.x2);
              }
            } else if ("bottom" === this.parent._position || "top" === this.parent._position) {
              r = this.parent.convertPixelToValue({ x: a });
              for (B3 = 0; B3 < this.parent.dataSeries.length; B3++)
                (v3 = this.parent.dataSeries[B3].getDataPointAtX(r, true)) && 0 <= v3.index && (v3.dataSeries = this.parent.dataSeries[B3], null !== v3.dataPoint.y && v3.dataSeries.visible && m.push(v3));
              if (0 === m.length)
                return;
              m.sort(function(a2, b2) {
                return a2.distance - b2.distance;
              });
              y = m[0];
              b = e = n2 = 1 === q.lineWidth % 2 ? (this.parent.convertValueToPixel(y.dataPoint.x) << 0) + 0.5 : this.parent.convertValueToPixel(y.dataPoint.x) << 0;
              f = this.chart.plotArea.y1;
              h2 = this.chart.plotArea.y2;
              this.bounds = { x1: b - p / 2, y1: f, x2: e + p / 2, y2: h2 };
              z = false;
              if (this.parent.labels)
                for (m = Math.ceil(this.parent.interval), r = 0; r < this.parent.viewportMaximum; r += m)
                  if (this.parent.labels[r])
                    z = true;
                  else {
                    z = false;
                    break;
                  }
              if (z) {
                if ("axisX" === this.parent.type)
                  for (r = this.parent.convertPixelToValue({ x: a }), v3 = null, B3 = 0; B3 < this.parent.dataSeries.length; B3++)
                    (v3 = this.parent.dataSeries[B3].getDataPointAtX(r, true)) && 0 <= v3.index && (k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: y.dataPoint.x }) : s(this.options.label) ? v3.dataPoint.label : this.label);
              } else
                k.text = "dateTime" !== this.parent.valueType || this.parent.logarithmic ? this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: y.dataPoint.x }) : s(this.options.label) ? da(y.dataPoint.x, this.valueFormatString, this.chart._cultureInfo) : this.label : this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: y.dataPoint.x }) : s(this.options.label) ? Ba(y.dataPoint.x, this.valueFormatString, this.chart._cultureInfo) : this.label;
              this.value = y.dataPoint.x;
              k.x = b - k.measureText().width / 2;
              k.x + k.width > this.chart.bounds.x2 && (k.x = this.chart.bounds.x2 - k.width);
              k.x < this.chart.bounds.x1 && (k.x = this.chart.bounds.x1);
              "bottom" === this.parent._position ? k.y = this.parent.lineCoordinates.y2 + k.fontSize / 2 + 2 : "top" === this.parent._position && (k.y = this.parent.lineCoordinates.y1 - k.height + k.fontSize / 2 + 2);
            } else if ("left" === this.parent._position || "right" === this.parent._position) {
              !s(this.parent.dataSeries) && 0 < this.parent.dataSeries.length && (r = this.parent.dataSeries[0].axisX.convertPixelToValue({ x: a }));
              for (B3 = 0; B3 < this.parent.dataSeries.length; B3++)
                (v3 = this.parent.dataSeries[B3].getDataPointAtX(r, true)) && 0 <= v3.index && (v3.dataSeries = this.parent.dataSeries[B3], null !== v3.dataPoint.y && v3.dataSeries.visible && m.push(v3));
              if (0 === m.length)
                return;
              m.sort(function(a2, b2) {
                return a2.distance - b2.distance;
              });
              B3 = 0;
              if ("rangeColumn" === m[0].dataSeries.type || "rangeArea" === m[0].dataSeries.type || "error" === m[0].dataSeries.type || "rangeSplineArea" === m[0].dataSeries.type || "candlestick" === m[0].dataSeries.type || "ohlc" === m[0].dataSeries.type || "boxAndWhisker" === m[0].dataSeries.type)
                for (v3 = Math.abs(d - this.parent.convertValueToPixel(m[0].dataPoint.y[0])), r = u = 0; r < m.length; r++)
                  if (m[r].dataPoint.y && m[r].dataPoint.y.length)
                    for (y = 0; y < m[r].dataPoint.y.length; y++)
                      u = Math.abs(d - this.parent.convertValueToPixel(m[r].dataPoint.y[y])), u < v3 && (v3 = u, B3 = r);
                  else
                    u = Math.abs(d - this.parent.convertValueToPixel(m[r].dataPoint.y)), u < v3 && (v3 = u, B3 = r);
              else if ("stackedColumn" === m[0].dataSeries.type || "stackedArea" === m[0].dataSeries.type)
                for (v3 = Math.abs(d - this.parent.convertValueToPixel(m[0].dataPoint.y)), r = x = u = 0; r < m.length; r++)
                  if (m[r].dataPoint.y && m[r].dataPoint.y.length)
                    for (y = 0; y < m[r].dataPoint.y.length; y++)
                      u = Math.abs(d - this.parent.convertValueToPixel(m[r].dataPoint.y[y])), u < v3 && (v3 = u, B3 = r);
                  else
                    x += m[r].dataPoint.y, u = Math.abs(d - this.parent.convertValueToPixel(x)), u < v3 && (v3 = u, B3 = r);
              else if ("stackedColumn100" === m[0].dataSeries.type || "stackedArea100" === m[0].dataSeries.type)
                for (v3 = Math.abs(d - this.parent.convertValueToPixel(m[0].dataPoint.y)), r = z = x = u = 0; r < m.length; r++)
                  if (m[r].dataPoint.y && m[r].dataPoint.y.length)
                    for (y = 0; y < m[r].dataPoint.y.length; y++)
                      u = Math.abs(d - this.parent.convertValueToPixel(m[r].dataPoint.y[y])), u < v3 && (v3 = u, B3 = r);
                  else
                    x += m[r].dataPoint.y, z = m[r].dataPoint.x.getTime ? m[r].dataPoint.x.getTime() : m[r].dataPoint.x, z = 100 * (x / m[r].dataSeries.plotUnit.dataPointYSums[z]), u = Math.abs(d - this.parent.convertValueToPixel(z)), u < v3 && (v3 = u, B3 = r);
              else
                for (v3 = Math.abs(d - this.parent.convertValueToPixel(m[0].dataPoint.y)), r = u = 0; r < m.length; r++)
                  if (m[r].dataPoint.y && m[r].dataPoint.y.length)
                    for (y = 0; y < m[r].dataPoint.y.length; y++)
                      u = Math.abs(d - this.parent.convertValueToPixel(m[r].dataPoint.y[y])), u < v3 && (v3 = u, B3 = r);
                  else
                    u = Math.abs(d - this.parent.convertValueToPixel(m[r].dataPoint.y)), u < v3 && (v3 = u, B3 = r);
              y = m[B3];
              b = 0;
              if ("rangeColumn" === this.parent.dataSeries[B3].type || "rangeArea" === this.parent.dataSeries[B3].type || "error" === this.parent.dataSeries[B3].type || "rangeSplineArea" === this.parent.dataSeries[B3].type || "candlestick" === this.parent.dataSeries[B3].type || "ohlc" === this.parent.dataSeries[B3].type || "boxAndWhisker" === this.parent.dataSeries[B3].type) {
                v3 = Math.abs(d - this.parent.convertValueToPixel(y.dataPoint.y[0]));
                for (r = u = 0; r < y.dataPoint.y.length; r++)
                  u = Math.abs(d - this.parent.convertValueToPixel(y.dataPoint.y[r])), u < v3 && (v3 = u, b = r);
                w2 = 1 === q.lineWidth % 2 ? (this.parent.convertValueToPixel(y.dataPoint.y[b]) << 0) + 0.5 : this.parent.convertValueToPixel(y.dataPoint.y[b]) << 0;
                k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: y.dataPoint.y[b] }) : s(this.options.label) ? da(
                  s(c) ? y.dataPoint.y[b] : c,
                  this.valueFormatString,
                  this.chart._cultureInfo
                ) : this.label;
                this.value = y.dataPoint.y[b];
              } else if ("stackedColumn" === this.parent.dataSeries[B3].type || "stackedArea" === this.parent.dataSeries[B3].type) {
                v3 = Math.abs(d - this.parent.convertValueToPixel(m[0].dataPoint.y));
                x = u = 0;
                for (r = B3; 0 <= r; r--)
                  x += m[r].dataPoint.y, u = Math.abs(d - this.parent.convertValueToPixel(x)), u < v3 && (v3 = u, b = r);
                w2 = 1 === q.lineWidth % 2 ? (this.parent.convertValueToPixel(x) << 0) + 0.5 : this.parent.convertValueToPixel(x) << 0;
                k.text = this.labelFormatter ? this.labelFormatter({
                  chart: this.chart,
                  axis: this.parent.options,
                  crosshair: this.options,
                  value: y.dataPoint.y
                }) : s(this.options.label) ? da(s(c) ? y.dataPoint.y : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
                this.value = x;
              } else if ("stackedColumn100" === this.parent.dataSeries[B3].type || "stackedArea100" === this.parent.dataSeries[B3].type) {
                v3 = Math.abs(d - this.parent.convertValueToPixel(m[0].dataPoint.y));
                x = u = 0;
                for (r = B3; 0 <= r; r--)
                  x += m[r].dataPoint.y, z = m[r].dataPoint.x.getTime ? m[r].dataPoint.x.getTime() : m[r].dataPoint.x, z = 100 * (x / m[r].dataSeries.plotUnit.dataPointYSums[z]), u = Math.abs(d - this.parent.convertValueToPixel(z)), u < v3 && (v3 = u, b = r);
                w2 = 1 === q.lineWidth % 2 ? (this.parent.convertValueToPixel(z) << 0) + 0.5 : this.parent.convertValueToPixel(z) << 0;
                k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: z }) : s(this.options.label) ? da(s(c) ? z : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
                this.value = z;
              } else
                "waterfall" === this.parent.dataSeries[B3].type ? (w2 = 1 === q.lineWidth % 2 ? (this.parent.convertValueToPixel(y.dataSeries.dataPointEOs[y.index].cumulativeSum) << 0) + 0.5 : this.parent.convertValueToPixel(y.dataSeries.dataPointEOs[y.index].cumulativeSum) << 0, k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: y.dataSeries.dataPointEOs[y.index].cumulativeSum }) : s(this.options.label) ? da(s(c) ? y.dataSeries.dataPointEOs[y.index].cumulativeSum : c, this.valueFormatString, this.chart._cultureInfo) : this.label, this.value = y.dataSeries.dataPointEOs[y.index].cumulativeSum) : (w2 = 1 === q.lineWidth % 2 ? (s(a) ? d : this.parent.convertValueToPixel(y.dataPoint.y) << 0) + 0.5 : s(a) ? d : this.parent.convertValueToPixel(y.dataPoint.y) << 0, k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: s(c) ? y.dataPoint.y : c }) : s(this.options.label) ? da(s(c) ? y.dataPoint.y : c, this.valueFormatString, this.chart._cultureInfo) : this.label, this.value = y.dataPoint.y);
              f = h2 = w2;
              b = this.chart.plotArea.x1;
              e = this.chart.plotArea.x2;
              this.bounds = { x1: b, y1: f - p / 2, x2: e, y2: h2 + p / 2 };
              k.y = h2 + k.fontSize / 2 - k.measureText().height / 2 + 2;
              k.y - k.fontSize / 2 < this.chart.bounds.y1 ? k.y = this.chart.bounds.y1 + k.fontSize / 2 + 2 : k.y + k.measureText().height - k.fontSize / 2 > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.measureText().height + k.fontSize / 2);
              "left" === this.parent._position ? k.x = this.parent.lineCoordinates.x2 - k.measureText().width : "right" === this.parent._position && (k.x = this.parent.lineCoordinates.x2);
            }
            m = null;
            if ("bottom" === this.parent._position || "top" === this.parent._position)
              "top" === this.parent._position && k.y - k.fontSize / 2 < this.chart.bounds.y1 && (k.y = this.chart.bounds.y1 + k.fontSize / 2), "bottom" === this.parent._position && this.parent.lineCoordinates.y2 - k.fontSize / 2 + k.measureText().height > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.height + k.fontSize / 2 + 2), b >= this.parent.convertValueToPixel(this.parent.reversed ? this.parent.viewportMaximum : this.parent.viewportMinimum) && e <= this.parent.convertValueToPixel(this.parent.reversed ? this.parent.viewportMinimum : this.parent.viewportMaximum) && (0 < p && (q.moveTo(b, f), q.lineTo(e, h2), q.stroke(), this._hidden = false), q.restore());
            if ("left" === this.parent._position || "right" === this.parent._position)
              "left" === this.parent._position && k.x < this.chart.bounds.x1 && (k.x = this.chart.bounds.x1), "right" === this.parent._position && k.x + k.measureText().width > this.chart.bounds.x2 && (k.x = this.chart.bounds.x2 - k.measureText().width), h2 >= this.parent.convertValueToPixel(this.parent.reversed ? this.parent.viewportMinimum : this.parent.viewportMaximum) && f <= this.parent.convertValueToPixel(this.parent.reversed ? this.parent.viewportMaximum : this.parent.viewportMinimum) && (0 < p && (q.moveTo(b, f), q.lineTo(
                e,
                h2
              ), q.stroke(), this._hidden = false), q.restore());
          } else {
            if ("bottom" === this.parent._position || "top" === this.parent._position)
              b = e = n2 = 1 === q.lineWidth % 2 ? (a << 0) + 0.5 : a << 0, f = this.chart.plotArea.y1, h2 = this.chart.plotArea.y2, this.bounds = { x1: b - p / 2, y1: f, x2: e + p / 2, y2: h2 };
            else if ("left" === this.parent._position || "right" === this.parent._position)
              f = h2 = w2 = 1 === q.lineWidth % 2 ? (d << 0) + 0.5 : d << 0, b = this.chart.plotArea.x1, e = this.chart.plotArea.x2, this.bounds = { x1: b, y1: f - p / 2, x2: e, y2: h2 + p / 2 };
            if ("xySwapped" === this.chart.plotInfo.axisPlacement)
              if ("left" === this.parent._position || "right" === this.parent._position) {
                z = false;
                if (this.parent.labels)
                  for (m = Math.ceil(this.parent.interval), r = 0; r < this.parent.viewportMaximum; r += m)
                    if (this.parent.labels[r])
                      z = true;
                    else {
                      z = false;
                      break;
                    }
                if (z) {
                  if ("axisX" === this.parent.type)
                    for (r = this.parent.convertPixelToValue({ y: d }), v3 = null, B3 = 0; B3 < this.parent.dataSeries.length; B3++)
                      (v3 = this.parent.dataSeries[B3].getDataPointAtX(r, true)) && 0 <= v3.index && (k.text = this.labelFormatter ? this.labelFormatter({
                        chart: this.chart,
                        axis: this.parent.options,
                        crosshair: this.options,
                        value: s(c) ? this.parent.convertPixelToValue(a) : c
                      }) : s(this.options.label) ? v3.dataPoint.label : this.label);
                } else
                  k.text = "dateTime" !== this.parent.valueType || this.parent.logarithmic ? this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: s(c) ? this.parent.convertPixelToValue(d) : c }) : s(this.options.label) ? da(s(c) ? this.parent.convertPixelToValue(d) : c, this.valueFormatString, this.chart._cultureInfo) : this.label : this.labelFormatter ? this.labelFormatter({
                    chart: this.chart,
                    axis: this.parent.options,
                    crosshair: this.options,
                    value: s(c) ? this.parent.convertPixelToValue(d) : c
                  }) : s(this.options.label) ? Ba(s(c) ? this.parent.convertPixelToValue(d) : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
                k.y = d + k.fontSize / 2 - k.measureText().height / 2 + 2;
                k.y - k.fontSize / 2 < this.chart.bounds.y1 ? k.y = this.chart.bounds.y1 + k.fontSize / 2 + 2 : k.y + k.measureText().height - k.fontSize / 2 > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.measureText().height + k.fontSize / 2);
                "left" === this.parent._position ? k.x = this.parent.lineCoordinates.x1 - k.measureText().width : "right" === this.parent._position && (k.x = this.parent.lineCoordinates.x2);
              } else {
                if ("bottom" === this.parent._position || "top" === this.parent._position)
                  k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: s(c) ? this.parent.convertPixelToValue(a) : c }) : s(this.options.label) ? da(s(c) ? this.parent.convertPixelToValue(a) : c, this.valueFormatString, this.chart._cultureInfo) : this.label, k.x = b - k.measureText().width / 2, k.x + k.width > this.chart.bounds.x2 && (k.x = this.chart.bounds.x2 - k.width), k.x < this.chart.bounds.x1 && (k.x = this.chart.bounds.x1), "bottom" === this.parent._position ? k.y = this.parent.lineCoordinates.y2 + k.fontSize / 2 + 2 : "top" === this.parent._position && (k.y = this.parent.lineCoordinates.y1 - k.height + k.fontSize / 2 + 2);
              }
            else if ("bottom" === this.parent._position || "top" === this.parent._position) {
              z = false;
              m = "";
              if (this.parent.labels)
                for (m = Math.ceil(this.parent.interval), r = 0; r < this.parent.viewportMaximum; r += m)
                  if (this.parent.labels[r])
                    z = true;
                  else {
                    z = false;
                    break;
                  }
              if (z) {
                if ("axisX" === this.parent.type)
                  for (r = this.parent.convertPixelToValue({ x: a }), v3 = null, B3 = 0; B3 < this.parent.dataSeries.length; B3++)
                    (v3 = this.parent.dataSeries[B3].getDataPointAtX(r, true)) && 0 <= v3.index && (k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: s(c) ? this.parent.convertPixelToValue(a) : c }) : s(this.options.label) ? s(c) ? v3.dataPoint.label : c : this.label);
              } else
                k.text = "dateTime" !== this.parent.valueType || this.parent.logarithmic ? this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: s(c) ? 0 < this.parent.dataSeries.length ? this.parent.convertPixelToValue(a) : "" : c }) : s(this.options.label) ? da(s(c) ? this.parent.convertPixelToValue(a) : c, this.valueFormatString, this.chart._cultureInfo) : this.label : this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: s(c) ? this.parent.convertPixelToValue(a) : c }) : s(this.options.label) ? Ba(s(c) ? this.parent.convertPixelToValue(a) : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
              k.x = b - k.measureText().width / 2;
              k.x + k.width > this.chart.bounds.x2 && (k.x = this.chart.bounds.x2 - k.width);
              k.x < this.chart.bounds.x1 && (k.x = this.chart.bounds.x1);
              "bottom" === this.parent._position ? k.y = this.parent.lineCoordinates.y2 + k.fontSize / 2 + 2 : "top" === this.parent._position && (k.y = this.parent.lineCoordinates.y1 - k.height + k.fontSize / 2 + 2);
            } else if ("left" === this.parent._position || "right" === this.parent._position)
              k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: s(c) ? this.parent.convertPixelToValue(d) : c }) : s(this.options.label) ? da(s(c) ? this.parent.convertPixelToValue(d) : c, this.valueFormatString, this.chart._cultureInfo) : this.label, k.y = d + k.fontSize / 2 - k.measureText().height / 2 + 2, k.y - k.fontSize / 2 < this.chart.bounds.y1 ? k.y = this.chart.bounds.y1 + k.fontSize / 2 + 2 : k.y + k.measureText().height - k.fontSize / 2 > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.measureText().height + k.fontSize / 2), "left" === this.parent._position ? k.x = this.parent.lineCoordinates.x2 - k.measureText().width : "right" === this.parent._position && (k.x = this.parent.lineCoordinates.x2);
            "left" === this.parent._position && k.x < this.chart.bounds.x1 ? k.x = this.chart.bounds.x1 : "right" === this.parent._position && k.x + k.measureText().width > this.chart.bounds.x2 ? k.x = this.chart.bounds.x2 - k.measureText().width : "top" === this.parent._position && k.y - k.fontSize / 2 < this.chart.bounds.y1 ? k.y = this.chart.bounds.y1 + k.fontSize / 2 : "bottom" === this.parent._position && this.parent.lineCoordinates.y2 - k.fontSize / 2 + k.measureText().height > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.height + k.fontSize / 2 + 2);
            0 < p && (q.moveTo(b, f), q.lineTo(e, h2), q.stroke(), this._hidden = false);
            q.restore();
            this.value = "bottom" === this.parent._position || "top" === this.parent._position ? this.parent.convertPixelToValue(a) : this.parent.convertPixelToValue(d);
          }
          if ("bottom" === this.parent._position || "top" === this.parent._position)
            this._updatedValue = this.parent.convertPixelToValue(n2);
          if ("left" === this.parent._position || "right" === this.parent._position)
            this._updatedValue = this.parent.convertPixelToValue(w2);
          this._textBlock = k;
          this._label = c;
          s(c) || this.renderLabel();
          q.globalAlpha = g;
        };
        ca2.prototype.renderLabel = function() {
          s(this._textBlock) || (s(this._textBlock.text) || !("number" === typeof this._textBlock.text.valueOf() || 0 < this._textBlock.text.length) || this._hidden) || this._textBlock.render(true);
          s(this._label) && this.dispatchEvent("updated", { chart: this.chart, crosshair: this.options, axis: this.parent, value: this.value }, this.parent);
        };
        oa(U2, G);
        U2.prototype._initialize = function() {
          this.updateOption("updated");
          this.updateOption("hidden");
          if (this.enabled) {
            this.container = document.createElement("div");
            this.container.setAttribute("class", "canvasjs-chart-tooltip");
            this.container.style.position = "absolute";
            this.container.style.height = "auto";
            this.container.style.boxShadow = "1px 1px 2px 2px rgba(0,0,0,0.1)";
            this.container.style.zIndex = "1000";
            this.container.style.pointerEvents = "none";
            this.container.style.display = "none";
            var a = document.createElement("div");
            a.style.width = "auto";
            a.style.height = "auto";
            a.style.minWidth = "50px";
            a.style.lineHeight = "normal";
            a.style.margin = "0px 0px 0px 0px";
            a.style.padding = "5px";
            a.style.fontFamily = "Calibri, Arial, Georgia, serif";
            a.style.fontWeight = "normal";
            a.style.fontStyle = w ? "italic" : "normal";
            a.style.fontSize = "14px";
            a.style.color = "#000000";
            a.style.textShadow = "1px 1px 1px rgba(0, 0, 0, 0.1)";
            a.style.textAlign = "left";
            a.style.border = "2px solid gray";
            a.style.background = w ? "rgba(255,255,255,.9)" : "rgb(255,255,255)";
            a.style.textIndent = "0px";
            a.style.whiteSpace = "nowrap";
            a.style.borderRadius = "5px";
            a.style.MozUserSelect = "none";
            a.style.WebkitUserSelect = "none";
            a.style.msUserSelect = "none";
            a.style.userSelect = "none";
            w || (a.style.filter = "alpha(opacity = 90)", a.style.filter = "progid:DXImageTransform.Microsoft.Shadow(Strength=3, Direction=135, Color='#666666')");
            a.innerText = "Sample Tooltip";
            this.container.appendChild(a);
            this.contentDiv = this.container.firstChild;
            this.container.style.borderRadius = this.contentDiv.style.borderRadius;
            this.chart._canvasJSContainer.appendChild(this.container);
          }
        };
        U2.prototype.mouseMoveHandler = function(a, d) {
          this._lastUpdated && 4 > (/* @__PURE__ */ new Date()).getTime() - this._lastUpdated || (this._lastUpdated = (/* @__PURE__ */ new Date()).getTime(), this.chart.resetOverlayedCanvas(), this._updateToolTip(a, d), !this._updatedEventParameters || (isNaN(this._prevX) || isNaN(this._prevY)) || this.dispatchEvent("updated", this._updatedEventParameters, this));
        };
        U2.prototype._updateToolTip = function(a, d, c) {
          c = "undefined" === typeof c ? true : c;
          this.container || this._initialize();
          this.enabled || this.hide();
          if (!this.chart.disableToolTip) {
            if ("undefined" === typeof a || "undefined" === typeof d) {
              if (isNaN(this._prevX) || isNaN(this._prevY))
                return;
              a = this._prevX;
              d = this._prevY;
            } else
              this._prevX = a, this._prevY = d;
            var b = null, e = null, f = [], h2 = 0;
            if (this.shared && this.enabled && "none" !== this.chart.plotInfo.axisPlacement) {
              var n2 = [];
              if (this.chart.axisX)
                for (var v3 = 0; v3 < this.chart.axisX.length; v3++) {
                  for (var h2 = "xySwapped" === this.chart.plotInfo.axisPlacement ? this.chart.axisX[v3].convertPixelToValue({ y: d }) : this.chart.axisX[v3].convertPixelToValue({ x: a }), k = null, b = 0; b < this.chart.axisX[v3].dataSeries.length; b++)
                    (k = this.chart.axisX[v3].dataSeries[b].getDataPointAtX(h2, c)) && 0 <= k.index && (k.dataSeries = this.chart.axisX[v3].dataSeries[b], null !== k.dataPoint.y && k.dataSeries.visible && n2.push(k));
                  k = null;
                }
              if (this.chart.axisX2)
                for (v3 = 0; v3 < this.chart.axisX2.length; v3++) {
                  h2 = "xySwapped" === this.chart.plotInfo.axisPlacement ? this.chart.axisX2[v3].convertPixelToValue({ y: d }) : this.chart.axisX2[v3].convertPixelToValue({ x: a });
                  k = null;
                  for (b = 0; b < this.chart.axisX2[v3].dataSeries.length; b++)
                    (k = this.chart.axisX2[v3].dataSeries[b].getDataPointAtX(
                      h2,
                      c
                    )) && 0 <= k.index && (k.dataSeries = this.chart.axisX2[v3].dataSeries[b], null !== k.dataPoint.y && k.dataSeries.visible && n2.push(k));
                  k = null;
                }
              if (0 === n2.length)
                return;
              n2.sort(function(a2, b2) {
                return a2.distance - b2.distance;
              });
              c = n2[0];
              for (b = 0; b < n2.length; b++)
                n2[b].dataPoint.x.valueOf() === c.dataPoint.x.valueOf() && f.push(n2[b]);
              n2 = null;
            } else {
              if (b = this.chart.getDataPointAtXY(a, d, c))
                this.currentDataPointIndex = b.dataPointIndex, this.currentSeriesIndex = b.dataSeries.index;
              else if (w)
                if (b = $a(a, d, this.chart._eventManager.ghostCtx), 0 < b && "undefined" !== typeof this.chart._eventManager.objectMap[b]) {
                  b = this.chart._eventManager.objectMap[b];
                  if ("legendItem" === b.objectType)
                    return;
                  this.currentSeriesIndex = b.dataSeriesIndex;
                  this.currentDataPointIndex = 0 <= b.dataPointIndex ? b.dataPointIndex : -1;
                } else
                  this.currentDataPointIndex = -1;
              else
                this.currentDataPointIndex = -1;
              if (0 <= this.currentSeriesIndex) {
                e = this.chart.data[this.currentSeriesIndex];
                k = {};
                if (0 <= this.currentDataPointIndex)
                  b = e.dataPoints[this.currentDataPointIndex], k.dataSeries = e, k.dataPoint = b, k.index = this.currentDataPointIndex, k.distance = Math.abs(b.x - h2), "waterfall" === e.type && (k.cumulativeSumYStartValue = e.dataPointEOs[this.currentDataPointIndex].cumulativeSumYStartValue, k.cumulativeSum = e.dataPointEOs[this.currentDataPointIndex].cumulativeSum);
                else {
                  if (!this.enabled || "line" !== e.type && "stepLine" !== e.type && "spline" !== e.type && "area" !== e.type && "stepArea" !== e.type && "splineArea" !== e.type && "stackedArea" !== e.type && "stackedArea100" !== e.type && "rangeArea" !== e.type && "rangeSplineArea" !== e.type && "candlestick" !== e.type && "ohlc" !== e.type && "boxAndWhisker" !== e.type)
                    return;
                  h2 = e.axisX.convertPixelToValue({ x: a });
                  k = e.getDataPointAtX(h2, c);
                  s(k) || (k.dataSeries = e, this.currentDataPointIndex = k.index, b = k.dataPoint);
                }
                if (!s(k) && !s(k.dataPoint) && !s(k.dataPoint.y))
                  if (k.dataSeries.axisY)
                    if (0 < k.dataPoint.y.length) {
                      for (b = c = 0; b < k.dataPoint.y.length; b++)
                        k.dataPoint.y[b] < k.dataSeries.axisY.viewportMinimum ? c-- : k.dataPoint.y[b] > k.dataSeries.axisY.viewportMaximum && c++;
                      c < k.dataPoint.y.length && c > -k.dataPoint.y.length && f.push(k);
                    } else
                      "column" === e.type || "bar" === e.type ? 0 > k.dataPoint.y ? 0 > k.dataSeries.axisY.viewportMinimum && k.dataSeries.axisY.viewportMaximum >= k.dataPoint.y && f.push(k) : k.dataSeries.axisY.viewportMinimum <= k.dataPoint.y && 0 <= k.dataSeries.axisY.viewportMaximum && f.push(k) : "bubble" === e.type ? (c = this.chart._eventManager.objectMap[e.dataPointIds[k.index]].size / 2, k.dataPoint.y >= k.dataSeries.axisY.viewportMinimum - c && k.dataPoint.y <= k.dataSeries.axisY.viewportMaximum + c && f.push(k)) : "waterfall" === e.type ? (c = 0, k.cumulativeSumYStartValue < k.dataSeries.axisY.viewportMinimum ? c-- : k.cumulativeSumYStartValue > k.dataSeries.axisY.viewportMaximum && c++, k.cumulativeSum < k.dataSeries.axisY.viewportMinimum ? c-- : k.cumulativeSum > k.dataSeries.axisY.viewportMaximum && c++, 2 > c && -2 < c && f.push(k)) : (0 <= k.dataSeries.type.indexOf("100") || "stackedColumn" === e.type || "stackedBar" === e.type || k.dataPoint.y >= k.dataSeries.axisY.viewportMinimum && k.dataPoint.y <= k.dataSeries.axisY.viewportMaximum) && f.push(k);
                  else
                    f.push(k);
              }
            }
            if (0 < f.length) {
              if (this.highlightObjects(f), this.enabled) {
                c = "";
                c = this.getToolTipInnerHTML({ entries: f });
                if (null !== c) {
                  this.contentDiv.innerHTML = c;
                  if (this.isToolTipDefinedInData && s(this.options.content) && s(this.options.contentFormatter))
                    for (h2 = this.contentDiv.getElementsByTagName("span"), b = 0; b < h2.length; b++)
                      h2[b] && (h2[b].style.color = h2[b].getAttribute("data-color"));
                  h2 = false;
                  "none" === this.container.style.display && (h2 = true, this.container.style.display = "block");
                  try {
                    this.contentDiv.style.background = this.backgroundColor ? this.backgroundColor : w ? "rgba(255,255,255,.9)" : "rgb(255,255,255)", this.borderColor = "waterfall" === f[0].dataSeries.type ? this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : f[0].dataPoint.color ? f[0].dataPoint.color : 0 < f[0].dataPoint.y ? f[0].dataSeries.risingColor : f[0].dataSeries.fallingColor : "error" === f[0].dataSeries.type ? this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : f[0].dataSeries.color ? f[0].dataSeries.color : f[0].dataSeries._colorSet[e.index % f[0].dataSeries._colorSet.length] : this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : f[0].dataPoint.color ? f[0].dataPoint.color : f[0].dataSeries.color ? f[0].dataSeries.color : f[0].dataSeries._colorSet[f[0].index % f[0].dataSeries._colorSet.length], this.contentDiv.style.borderWidth = this.borderThickness || 0 === this.borderThickness ? this.borderThickness + "px" : "2px", this.contentDiv.style.borderRadius = this.cornerRadius || 0 === this.cornerRadius ? this.cornerRadius + "px" : "5px", this.container.style.borderRadius = this.contentDiv.style.borderRadius, this.contentDiv.style.fontSize = this.fontSize || 0 === this.fontSize ? this.fontSize + "px" : "14px", this.contentDiv.style.color = this.fontColor ? this.fontColor : "#000000", this.contentDiv.style.fontFamily = this.fontFamily ? this.fontFamily : "Calibri, Arial, Georgia, serif;", this.contentDiv.style.fontWeight = this.fontWeight ? this.fontWeight : "normal", this.contentDiv.style.fontStyle = this.fontStyle ? this.fontStyle : w ? "italic" : "normal";
                  } catch (m) {
                  }
                  "pie" === f[0].dataSeries.type || "doughnut" === f[0].dataSeries.type || "funnel" === f[0].dataSeries.type || "pyramid" === f[0].dataSeries.type || "bar" === f[0].dataSeries.type || "rangeBar" === f[0].dataSeries.type || "stackedBar" === f[0].dataSeries.type || "stackedBar100" === f[0].dataSeries.type ? a = a - 10 - this.container.clientWidth : (a = f[0].dataSeries.axisX.convertValueToPixel(f[0].dataPoint.x) - this.container.clientWidth << 0, a -= 10);
                  0 > a && (a += this.container.clientWidth + 20);
                  a + this.container.clientWidth > Math.max(this.chart.container.clientWidth, this.chart.width) && (a = Math.max(0, Math.max(this.chart.container.clientWidth, this.chart.width) - this.container.clientWidth));
                  d = 1 !== f.length || this.shared || "line" !== f[0].dataSeries.type && "stepLine" !== f[0].dataSeries.type && "spline" !== f[0].dataSeries.type && "area" !== f[0].dataSeries.type && "stepArea" !== f[0].dataSeries.type && "splineArea" !== f[0].dataSeries.type ? "bar" === f[0].dataSeries.type || "rangeBar" === f[0].dataSeries.type || "stackedBar" === f[0].dataSeries.type || "stackedBar100" === f[0].dataSeries.type ? f[0].dataSeries.axisX.convertValueToPixel(f[0].dataPoint.x) : d : f[0].dataSeries.axisY.convertValueToPixel(f[0].dataPoint.y);
                  d = -d + 10;
                  0 < d + this.container.clientHeight + 5 && (d -= d + this.container.clientHeight + 5 - 0);
                  this.fixMozTransitionDelay(a, d);
                  !this.animationEnabled || h2 ? this.disableAnimation() : (this.enableAnimation(), this.container.style.MozTransition = this.mozContainerTransition);
                  this.positionLeft = a;
                  this.positionBottom = d;
                  this.container.style.left = a + "px";
                  this.container.style.bottom = d + "px";
                } else
                  this.hide(false), this.enabled && this.dispatchEvent("hidden", { chart: this.chart, toolTip: this }, this);
                d = [];
                for (b = 0; b < f.length; b++)
                  d.push({ xValue: f[b].dataPoint.x, dataPoint: f[b].dataPoint, dataSeries: f[b].dataSeries, dataPointIndex: f[b].index, dataSeriesIndex: f[b].dataSeries._index });
                this._updatedEventParameters = { chart: this.chart, toolTip: this.options, content: c, entries: d };
                this._entries = f;
              }
            } else
              this.hide(), this.enabled && this.dispatchEvent("hidden", {
                chart: this.chart,
                toolTip: this
              }, this);
          }
        };
        U2.prototype.highlightObjects = function(a) {
          var d = this.chart.overlaidCanvasCtx;
          if (s(this.chart.clearedOverlayedCanvas) || "toolTip" === this.chart.clearedOverlayedCanvas)
            this.chart.resetOverlayedCanvas(), d.clearRect(0, 0, this.chart.width, this.chart.height), this.chart.clearedOverlayedCanvas = "toolTip";
          d.save();
          var c = this.chart.plotArea, b = 0;
          d.beginPath();
          d.rect(c.x1, c.y1, c.x2 - c.x1, c.y2 - c.y1);
          d.clip();
          for (c = 0; c < a.length; c++) {
            var e = a[c];
            if ((e = this.chart._eventManager.objectMap[e.dataSeries.dataPointIds[e.index]]) && e.objectType && "dataPoint" === e.objectType) {
              var b = this.chart.data[e.dataSeriesIndex], f = b.dataPoints[e.dataPointIndex], h2 = e.dataPointIndex;
              false === f.highlightEnabled || true !== b.highlightEnabled && true !== f.highlightEnabled || ("line" === b.type || "stepLine" === b.type || "spline" === b.type || "scatter" === b.type || "area" === b.type || "stepArea" === b.type || "splineArea" === b.type || "stackedArea" === b.type || "stackedArea100" === b.type || "rangeArea" === b.type || "rangeSplineArea" === b.type ? (f = b.getMarkerProperties(h2, e.x1, e.y1, this.chart.overlaidCanvasCtx), f.size = Math.max(1.5 * f.size << 0, 10), f.borderColor = f.borderColor || "#FFFFFF", f.borderThickness = f.borderThickness || Math.ceil(0.1 * f.size), W.drawMarkers([f]), "undefined" !== typeof e.y2 && (f = b.getMarkerProperties(h2, e.x1, e.y2, this.chart.overlaidCanvasCtx), f.size = Math.max(1.5 * f.size << 0, 10), f.borderColor = f.borderColor || "#FFFFFF", f.borderThickness = f.borderThickness || Math.ceil(0.1 * f.size), W.drawMarkers([f]))) : "bubble" === b.type ? (f = b.getMarkerProperties(h2, e.x1, e.y1, this.chart.overlaidCanvasCtx), f.size = e.size, f.color = "white", f.borderColor = "white", d.globalAlpha = 0.3, W.drawMarkers([f]), d.globalAlpha = 1) : "column" === b.type || "stackedColumn" === b.type || "stackedColumn100" === b.type || "bar" === b.type || "rangeBar" === b.type || "stackedBar" === b.type || "stackedBar100" === b.type || "rangeColumn" === b.type || "waterfall" === b.type ? Y(d, e.x1, e.y1, e.x2, e.y2, "white", 0, null, false, false, false, false, 0.3) : "pie" === b.type || "doughnut" === b.type ? pa2(d, e.center, e.radius, "white", b.type, e.startAngle, e.endAngle, 0.3, e.percentInnerRadius) : "funnel" === b.type || "pyramid" === b.type ? ra2(d, e.funnelSection, 0.3, "white") : "candlestick" === b.type ? (d.globalAlpha = 1, d.strokeStyle = e.color, d.lineWidth = 2 * e.borderThickness, b = 0 === d.lineWidth % 2 ? 0 : 0.5, d.beginPath(), d.moveTo(e.x3 - b, Math.min(e.y2, e.y3)), d.lineTo(e.x3 - b, Math.min(e.y1, e.y4)), d.stroke(), d.beginPath(), d.moveTo(e.x3 - b, Math.max(e.y1, e.y4)), d.lineTo(e.x3 - b, Math.max(e.y2, e.y3)), d.stroke(), Y(d, e.x1, Math.min(e.y1, e.y4), e.x2, Math.max(e.y1, e.y4), "transparent", 2 * e.borderThickness, e.color, false, false, false, false), d.globalAlpha = 1) : "ohlc" === b.type ? (d.globalAlpha = 1, d.strokeStyle = e.color, d.lineWidth = 2 * e.borderThickness, b = 0 === d.lineWidth % 2 ? 0 : 0.5, d.beginPath(), d.moveTo(e.x3 - b, e.y2), d.lineTo(e.x3 - b, e.y3), d.stroke(), d.beginPath(), d.moveTo(e.x3, e.y1), d.lineTo(e.x1, e.y1), d.stroke(), d.beginPath(), d.moveTo(e.x3, e.y4), d.lineTo(e.x2, e.y4), d.stroke(), d.globalAlpha = 1) : "boxAndWhisker" === b.type ? (d.save(), d.globalAlpha = 1, d.strokeStyle = e.stemColor, d.lineWidth = 2 * e.stemThickness, 0 < e.stemThickness && (d.beginPath(), d.moveTo(e.x3, e.y2 + e.borderThickness / 2), d.lineTo(e.x3, e.y1 + e.whiskerThickness / 2), d.stroke(), d.beginPath(), d.moveTo(e.x3, e.y4 - e.whiskerThickness / 2), d.lineTo(e.x3, e.y3 - e.borderThickness / 2), d.stroke()), d.beginPath(), Y(d, e.x1 - e.borderThickness / 2, Math.max(e.y2 + e.borderThickness / 2, e.y3 + e.borderThickness / 2), e.x2 + e.borderThickness / 2, Math.min(e.y2 - e.borderThickness / 2, e.y3 - e.borderThickness / 2), "transparent", e.borderThickness, e.color, false, false, false, false), d.globalAlpha = 1, d.strokeStyle = e.whiskerColor, d.lineWidth = 2 * e.whiskerThickness, 0 < e.whiskerThickness && (d.beginPath(), d.moveTo(Math.floor(e.x3 - e.whiskerLength / 2), e.y4), d.lineTo(Math.ceil(e.x3 + e.whiskerLength / 2), e.y4), d.stroke(), d.beginPath(), d.moveTo(Math.floor(e.x3 - e.whiskerLength / 2), e.y1), d.lineTo(Math.ceil(e.x3 + e.whiskerLength / 2), e.y1), d.stroke()), d.globalAlpha = 1, d.strokeStyle = e.lineColor, d.lineWidth = 2 * e.lineThickness, 0 < e.lineThickness && (d.beginPath(), d.moveTo(e.x1, e.y5), d.lineTo(e.x2, e.y5), d.stroke()), d.restore(), d.globalAlpha = 1) : "error" === b.type && B2(d, e.x1, e.y1, e.x2, e.y2, "white", e.whiskerProperties, e.stemProperties, e.isXYSwapped, 0.3));
            }
          }
          d.restore();
          d.globalAlpha = 1;
          d.beginPath();
        };
        U2.prototype.getToolTipInnerHTML = function(a) {
          a = a.entries;
          var d = null, c = null, b = null, e = 0, f = "";
          this.isToolTipDefinedInData = true;
          for (var h2 = 0; h2 < a.length; h2++)
            if (a[h2].dataSeries.toolTipContent || a[h2].dataPoint.toolTipContent) {
              this.isToolTipDefinedInData = false;
              break;
            }
          if (this.isToolTipDefinedInData && (this.content && "function" === typeof this.content || this.contentFormatter))
            a = { chart: this.chart, toolTip: this.options, entries: a }, d = this.contentFormatter ? this.contentFormatter(a) : this.content(a);
          else if (this.shared && "none" !== this.chart.plotInfo.axisPlacement) {
            for (var n2 = null, s2 = "", h2 = 0; h2 < a.length; h2++) {
              c = a[h2].dataSeries;
              b = a[h2].dataPoint;
              e = a[h2].index;
              f = "";
              if (0 === h2 && this.isToolTipDefinedInData && !this.content) {
                this.chart.axisX && 0 < this.chart.axisX.length ? s2 += "undefined" !== typeof this.chart.axisX[0].labels[b.x] ? this.chart.axisX[0].labels[b.x] : "{x}" : this.chart.axisX2 && 0 < this.chart.axisX2.length && (s2 += "undefined" !== typeof this.chart.axisX2[0].labels[b.x] ? this.chart.axisX2[0].labels[b.x] : "{x}");
                s2 += "</br>";
                if (!c.visible)
                  continue;
                s2 = this.chart.replaceKeywordsWithValue(s2, b, c, e);
              }
              null === b.toolTipContent || "undefined" === typeof b.toolTipContent && null === c.options.toolTipContent || ("line" === c.type || "stepLine" === c.type || "spline" === c.type || "area" === c.type || "stepArea" === c.type || "splineArea" === c.type || "column" === c.type || "bar" === c.type || "scatter" === c.type || "stackedColumn" === c.type || "stackedColumn100" === c.type || "stackedBar" === c.type || "stackedBar100" === c.type || "stackedArea" === c.type || "stackedArea100" === c.type || "waterfall" === c.type ? (this.chart.axisX && 1 < this.chart.axisX.length && (f += n2 != c.axisXIndex ? c.axisX.title ? c.axisX.title + "<br/>" : "X:{axisXIndex}<br/>" : ""), f += b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>{name}:</span>&nbsp;&nbsp;{y}`, n2 = c.axisXIndex) : "bubble" === c.type ? (this.chart.axisX && 1 < this.chart.axisX.length && (f += n2 != c.axisXIndex ? c.axisX.title ? c.axisX.title + "<br/>" : "X:{axisXIndex}<br/>" : ""), f += b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>{name}:</span>&nbsp;&nbsp;{y}, &nbsp;&nbsp;{z}`) : "rangeColumn" === c.type || "rangeBar" === c.type || "rangeArea" === c.type || "rangeSplineArea" === c.type || "error" === c.type ? (this.chart.axisX && 1 < this.chart.axisX.length && (f += n2 != c.axisXIndex ? c.axisX.title ? c.axisX.title + "<br/>" : "X:{axisXIndex}<br/>" : ""), f += b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>{name}:</span>&nbsp;&nbsp;{y[0]},&nbsp;{y[1]}`) : "candlestick" === c.type || "ohlc" === c.type ? (this.chart.axisX && 1 < this.chart.axisX.length && (f += n2 != c.axisXIndex ? c.axisX.title ? c.axisX.title + "<br/>" : "X:{axisXIndex}<br/>" : ""), f += b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>{name}:</span><br/>Open: &nbsp;&nbsp;{y[0]}<br/>High: &nbsp;&nbsp;&nbsp;{y[1]}<br/>Low:&nbsp;&nbsp;&nbsp;{y[2]}<br/>Close: &nbsp;&nbsp;{y[3]}`) : "boxAndWhisker" === c.type && (this.chart.axisX && 1 < this.chart.axisX.length && (f += n2 != c.axisXIndex ? c.axisX.title ? c.axisX.title + "<br/>" : "X:{axisXIndex}<br/>" : ""), f += b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>{name}:</span><br/>Minimum: &nbsp;{y[0]}<br/>Q1:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[1]}<br/>Q2:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[4]}<br/>Q3:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[2]}<br/>Maximum: &nbsp;{y[3]}`), null === d && (d = ""), c.visible && (true === this.reversed ? (d = this.chart.replaceKeywordsWithValue(
                f,
                b,
                c,
                e
              ) + d, h2 < a.length - 1 && (d = "</br>" + d)) : (d += this.chart.replaceKeywordsWithValue(f, b, c, e), h2 < a.length - 1 && (d += "</br>"))));
            }
            null !== d && (d = s2 + d);
          } else {
            c = a[0].dataSeries;
            b = a[0].dataPoint;
            e = a[0].index;
            if (null === b.toolTipContent || "undefined" === typeof b.toolTipContent && null === c.options.toolTipContent)
              return null;
            "line" === c.type || "stepLine" === c.type || "spline" === c.type || "area" === c.type || "stepArea" === c.type || "splineArea" === c.type || "column" === c.type || "bar" === c.type || "scatter" === c.type || "stackedColumn" === c.type || "stackedColumn100" === c.type || "stackedBar" === c.type || "stackedBar100" === c.type || "stackedArea" === c.type || "stackedArea100" === c.type || "waterfall" === c.type ? f = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.label ? "{label}" : "{x}") + ":</span>&nbsp;&nbsp;{y}" : "bubble" === c.type ? f = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.label ? "{label}" : "{x}") + ":</span>&nbsp;&nbsp;{y}, &nbsp;&nbsp;{z}" : "pie" === c.type || "doughnut" === c.type || "funnel" === c.type || "pyramid" === c.type ? f = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.name ? "{name}:</span>&nbsp;&nbsp;" : b.label ? "{label}:</span>&nbsp;&nbsp;" : "</span>") + "{y}" : "rangeColumn" === c.type || "rangeBar" === c.type || "rangeArea" === c.type || "rangeSplineArea" === c.type || "error" === c.type ? f = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.label ? "{label}" : "{x}") + " :</span>&nbsp;&nbsp;{y[0]}, &nbsp;{y[1]}" : "candlestick" === c.type || "ohlc" === c.type ? f = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.label ? "{label}" : "{x}") + "</span><br/>Open: &nbsp;&nbsp;{y[0]}<br/>High: &nbsp;&nbsp;&nbsp;{y[1]}<br/>Low: &nbsp;&nbsp;&nbsp;&nbsp;{y[2]}<br/>Close: &nbsp;&nbsp;{y[3]}" : "boxAndWhisker" === c.type && (f = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.label ? "{label}" : "{x}") + "</span><br/>Minimum: &nbsp;{y[0]}<br/>Q1:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[1]}<br/>Q2:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[4]}<br/>Q3:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[2]}<br/>Maximum: &nbsp;{y[3]}");
            null === d && (d = "");
            d += this.chart.replaceKeywordsWithValue(f, b, c, e);
          }
          return d;
        };
        U2.prototype.enableAnimation = function() {
          if (!this.container.style.WebkitTransition) {
            var a = this.getContainerTransition(this.containerTransitionDuration);
            this.container.style.WebkitTransition = a;
            this.container.style.MsTransition = a;
            this.container.style.transition = a;
            this.container.style.MozTransition = this.mozContainerTransition;
          }
        };
        U2.prototype.disableAnimation = function() {
          this.container.style.WebkitTransition && (this.container.style.WebkitTransition = "", this.container.style.MozTransition = "", this.container.style.MsTransition = "", this.container.style.transition = "");
        };
        U2.prototype.hide = function(a) {
          this.container && (this.container.style.display = "none", this.currentSeriesIndex = -1, this._prevY = this._prevX = NaN, ("undefined" === typeof a || a) && this.chart.resetOverlayedCanvas());
        };
        U2.prototype.show = function(a, d, c) {
          this._updateToolTip(a, d, "undefined" === typeof c ? false : c);
        };
        U2.prototype.showAtIndex = function(a, d) {
        };
        U2.prototype.showAtX = function(a, d) {
          if (!this.enabled)
            return false;
          this.chart.clearedOverlayedCanvas = null;
          var c, b, e, f = [];
          e = false;
          d = !s(d) && 0 <= d && d < this.chart.data.length ? d : 0;
          if (this.shared)
            for (var h2 = 0; h2 < this.chart.data.length; h2++)
              c = this.chart.data[h2], (b = c.getDataPointAtX(a, false)) && (b.dataPoint && !s(b.dataPoint.y) && c.visible) && (b.dataSeries = c, f.push(b));
          else
            c = this.chart.data[d], (b = c.getDataPointAtX(a, false)) && (b.dataPoint && !s(b.dataPoint.y) && c.visible) && (b.dataSeries = c, f.push(b));
          if (0 < f.length) {
            for (h2 = 0; h2 < f.length; h2++)
              if (b = f[h2], (this.shared || 0 <= b.dataSeries.type.indexOf("100")) && b.dataPoint.x >= b.dataSeries.axisX.viewportMinimum && b.dataPoint.x <= b.dataSeries.axisX.viewportMaximum) {
                e = false;
                break;
              } else if (b.dataPoint.x < b.dataSeries.axisX.viewportMinimum || b.dataPoint.x > b.dataSeries.axisX.viewportMaximum || b.dataPoint.y < b.dataSeries.axisY.viewportMinimum || b.dataPoint.y > b.dataSeries.axisY.viewportMaximum)
                e = true;
              else {
                e = false;
                break;
              }
            if (e)
              return this.hide(), false;
            this.highlightObjects(f);
            this._entries = f;
            h2 = "";
            h2 = this.getToolTipInnerHTML({ entries: f });
            if (null !== h2) {
              this.contentDiv.innerHTML = h2;
              if (this.isToolTipDefinedInData && s(this.options.content) && s(this.options.contentFormatter))
                for (b = this.contentDiv.getElementsByTagName("span"), h2 = 0; h2 < b.length; h2++)
                  b[h2] && (b[h2].style.color = b[h2].getAttribute("data-color"));
              h2 = false;
              "none" === this.container.style.display && (h2 = true, this.container.style.display = "block");
              try {
                this.contentDiv.style.background = this.backgroundColor ? this.backgroundColor : w ? "rgba(255,255,255,.9)" : "rgb(255,255,255)", this.borderColor = "waterfall" === f[0].dataSeries.type ? this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : f[0].dataPoint.color ? f[0].dataPoint.color : 0 < f[0].dataPoint.y ? f[0].dataSeries.risingColor : f[0].dataSeries.fallingColor : "error" === f[0].dataSeries.type ? this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : f[0].dataSeries.color ? f[0].dataSeries.color : f[0].dataSeries._colorSet[c.index % f[0].dataSeries._colorSet.length] : this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : f[0].dataPoint.color ? f[0].dataPoint.color : f[0].dataSeries.color ? f[0].dataSeries.color : f[0].dataSeries._colorSet[f[0].index % f[0].dataSeries._colorSet.length], this.contentDiv.style.borderWidth = this.borderThickness || 0 === this.borderThickness ? this.borderThickness + "px" : "2px", this.contentDiv.style.borderRadius = this.cornerRadius || 0 === this.cornerRadius ? this.cornerRadius + "px" : "5px", this.container.style.borderRadius = this.contentDiv.style.borderRadius, this.contentDiv.style.fontSize = this.fontSize || 0 === this.fontSize ? this.fontSize + "px" : "14px", this.contentDiv.style.color = this.fontColor ? this.fontColor : "#000000", this.contentDiv.style.fontFamily = this.fontFamily ? this.fontFamily : "Calibri, Arial, Georgia, serif;", this.contentDiv.style.fontWeight = this.fontWeight ? this.fontWeight : "normal", this.contentDiv.style.fontStyle = this.fontStyle ? this.fontStyle : w ? "italic" : "normal";
              } catch (n2) {
              }
              "pie" === f[0].dataSeries.type || "doughnut" === f[0].dataSeries.type || "funnel" === f[0].dataSeries.type || "pyramid" === f[0].dataSeries.type ? c = mouseX - 10 - this.container.clientWidth : (c = "bar" === f[0].dataSeries.type || "rangeBar" === f[0].dataSeries.type || "stackedBar" === f[0].dataSeries.type || "stackedBar100" === f[0].dataSeries.type ? f[0].dataSeries.axisY.convertValueToPixel(f[0].dataPoint.y) - this.container.clientWidth << 0 : f[0].dataSeries.axisX.convertValueToPixel(f[0].dataPoint.x) - this.container.clientWidth << 0, c -= 10);
              0 > c && (c += this.container.clientWidth + 20);
              c + this.container.clientWidth > Math.max(this.chart.container.clientWidth, this.chart.width) && (c = Math.max(0, Math.max(this.chart.container.clientWidth, this.chart.width) - this.container.clientWidth));
              f = 1 !== f.length || this.shared || "line" !== f[0].dataSeries.type && "stepLine" !== f[0].dataSeries.type && "spline" !== f[0].dataSeries.type && "area" !== f[0].dataSeries.type && "stepArea" !== f[0].dataSeries.type && "splineArea" !== f[0].dataSeries.type ? "bar" === f[0].dataSeries.type || "rangeBar" === f[0].dataSeries.type || "stackedBar" === f[0].dataSeries.type || "stackedBar100" === f[0].dataSeries.type ? f[0].dataSeries.axisX.convertValueToPixel(f[0].dataPoint.x) : f[0].dataSeries.axisY.convertValueToPixel(f[0].dataPoint.y) : f[0].dataSeries.axisY.convertValueToPixel(f[0].dataPoint.y);
              f = -f + 10;
              0 < f + this.container.clientHeight + 5 && (f -= f + this.container.clientHeight + 5 - 0);
              this.fixMozTransitionDelay(c, f);
              !this.animationEnabled || h2 ? this.disableAnimation() : (this.enableAnimation(), this.container.style.MozTransition = this.mozContainerTransition);
              this.container.style.left = c + "px";
              this.container.style.bottom = f + "px";
            } else
              return this.hide(false), false;
          } else
            return this.hide(), false;
          return true;
        };
        U2.prototype.fixMozTransitionDelay = function(a, d) {
          if (20 < this.chart._eventManager.lastObjectId)
            this.mozContainerTransition = this.getContainerTransition(0);
          else {
            var c = parseFloat(this.container.style.left), c = isNaN(c) ? 0 : c, b = parseFloat(this.container.style.bottom), b = isNaN(b) ? 0 : b;
            10 < Math.sqrt(Math.pow(c - a, 2) + Math.pow(b - d, 2)) ? this.mozContainerTransition = this.getContainerTransition(0.1) : this.mozContainerTransition = this.getContainerTransition(0);
          }
        };
        U2.prototype.getContainerTransition = function(a) {
          return "left " + a + "s ease-out 0s, bottom " + a + "s ease-out 0s";
        };
        Z2.prototype.reset = function() {
          this.lastObjectId = 0;
          this.objectMap = [];
          this.rectangularRegionEventSubscriptions = [];
          this.previousDataPointEventObject = null;
          this.eventObjects = [];
          w && (this.ghostCtx.clearRect(0, 0, this.chart.width, this.chart.height), this.ghostCtx.beginPath());
        };
        Z2.prototype.getNewObjectTrackingId = function() {
          return ++this.lastObjectId;
        };
        Z2.prototype.mouseEventHandler = function(a) {
          if ("mousemove" === a.type || "click" === a.type) {
            var d = [], c = Pa(a), b = null;
            if ((b = this.chart.getObjectAtXY(c.x, c.y, false)) && "undefined" !== typeof this.objectMap[b])
              if (b = this.objectMap[b], "dataPoint" === b.objectType) {
                var e = this.chart.data[b.dataSeriesIndex], f = e.dataPoints[b.dataPointIndex], h2 = b.dataPointIndex;
                b.eventParameter = { x: c.x, y: c.y, dataPoint: f, dataSeries: e.options, dataPointIndex: h2, dataSeriesIndex: e.index, chart: this.chart };
                b.eventContext = { context: f, userContext: f, mouseover: "mouseover", mousemove: "mousemove", mouseout: "mouseout", click: "click" };
                d.push(b);
                b = this.objectMap[e.id];
                b.eventParameter = { x: c.x, y: c.y, dataPoint: f, dataSeries: e.options, dataPointIndex: h2, dataSeriesIndex: e.index, chart: this.chart };
                b.eventContext = { context: e, userContext: e.options, mouseover: "mouseover", mousemove: "mousemove", mouseout: "mouseout", click: "click" };
                d.push(this.objectMap[e.id]);
              } else
                "legendItem" === b.objectType && (e = this.chart.data[b.dataSeriesIndex], f = null !== b.dataPointIndex ? e.dataPoints[b.dataPointIndex] : null, b.eventParameter = {
                  x: c.x,
                  y: c.y,
                  dataSeries: e.options,
                  dataPoint: f,
                  dataPointIndex: b.dataPointIndex,
                  dataSeriesIndex: b.dataSeriesIndex,
                  chart: this.chart
                }, b.eventContext = { context: this.chart.legend, userContext: this.chart.legend.options, mouseover: "itemmouseover", mousemove: "itemmousemove", mouseout: "itemmouseout", click: "itemclick" }, d.push(b));
            e = [];
            for (c = 0; c < this.mouseoveredObjectMaps.length; c++) {
              f = true;
              for (b = 0; b < d.length; b++)
                if (d[b].id === this.mouseoveredObjectMaps[c].id) {
                  f = false;
                  break;
                }
              f ? this.fireEvent(this.mouseoveredObjectMaps[c], "mouseout", a) : e.push(this.mouseoveredObjectMaps[c]);
            }
            this.mouseoveredObjectMaps = e;
            for (c = 0; c < d.length; c++) {
              e = false;
              for (b = 0; b < this.mouseoveredObjectMaps.length; b++)
                if (d[c].id === this.mouseoveredObjectMaps[b].id) {
                  e = true;
                  break;
                }
              e || (this.fireEvent(d[c], "mouseover", a), this.mouseoveredObjectMaps.push(d[c]));
              "click" === a.type ? this.fireEvent(d[c], "click", a) : "mousemove" === a.type && this.fireEvent(d[c], "mousemove", a);
            }
          }
        };
        Z2.prototype.fireEvent = function(a, d, c) {
          if (a && d) {
            var b = a.eventParameter, e = a.eventContext, f = a.eventContext.userContext;
            f && (e && f[e[d]]) && f[e[d]].call(f, b);
            "mouseout" !== d ? f.cursor && f.cursor !== c.target.style.cursor && (c.target.style.cursor = f.cursor) : (c.target.style.cursor = this.chart._defaultCursor, delete a.eventParameter, delete a.eventContext);
            "click" === d && ("dataPoint" === a.objectType && this.chart.pieDoughnutClickHandler) && this.chart.pieDoughnutClickHandler.call(this.chart.data[a.dataSeriesIndex], b);
            "click" === d && ("dataPoint" === a.objectType && this.chart.funnelPyramidClickHandler) && this.chart.funnelPyramidClickHandler.call(this.chart.data[a.dataSeriesIndex], b);
          }
        };
        ia2.prototype.animate = function(a, d, c, b, e) {
          var f = this;
          this.chart.isAnimating = true;
          e = e || M.easing.linear;
          c && this.animations.push({ startTime: (/* @__PURE__ */ new Date()).getTime() + (a ? a : 0), duration: d, animationCallback: c, onComplete: b });
          for (a = []; 0 < this.animations.length; )
            if (d = this.animations.shift(), c = (/* @__PURE__ */ new Date()).getTime(), b = 0, d.startTime <= c && (b = e(Math.min(c - d.startTime, d.duration), 0, 1, d.duration), b = Math.min(b, 1), isNaN(b) || !isFinite(b)) && (b = 1), 1 > b && a.push(d), d.animationCallback(b), 1 <= b && d.onComplete)
              d.onComplete();
          this.animations = a;
          0 < this.animations.length ? this.animationRequestId = this.chart.requestAnimFrame.call(window, function() {
            f.animate.call(f);
          }) : this.chart.isAnimating = false;
        };
        ia2.prototype.cancelAllAnimations = function() {
          this.animations = [];
          this.animationRequestId && this.chart.cancelRequestAnimFrame.call(window, this.animationRequestId);
          this.animationRequestId = null;
          this.chart.isAnimating = false;
        };
        var M = { yScaleAnimation: function(a, d) {
          if (0 !== a) {
            var c = d.dest, b = d.source.canvas, e = d.animationBase;
            c.drawImage(b, 0, 0, b.width, b.height, 0, e - e * a, c.canvas.width / la, a * c.canvas.height / la);
          }
        }, xScaleAnimation: function(a, d) {
          if (0 !== a) {
            var c = d.dest, b = d.source.canvas, e = d.animationBase;
            c.drawImage(b, 0, 0, b.width, b.height, e - e * a, 0, a * c.canvas.width / la, c.canvas.height / la);
          }
        }, xClipAnimation: function(a, d) {
          if (0 !== a) {
            var c = d.dest, b = d.source.canvas;
            c.save();
            0 < a && c.drawImage(b, 0, 0, b.width * a, b.height, 0, 0, b.width * a / la, b.height / la);
            c.restore();
          }
        }, fadeInAnimation: function(a, d) {
          if (0 !== a) {
            var c = d.dest, b = d.source.canvas;
            c.save();
            c.globalAlpha = a;
            c.drawImage(b, 0, 0, b.width, b.height, 0, 0, c.canvas.width / la, c.canvas.height / la);
            c.restore();
          }
        }, easing: { linear: function(a, d, c, b) {
          return c * a / b + d;
        }, easeOutQuad: function(a, d, c, b) {
          return -c * (a /= b) * (a - 2) + d;
        }, easeOutQuart: function(a, d, c, b) {
          return -c * ((a = a / b - 1) * a * a * a - 1) + d;
        }, easeInQuad: function(a, d, c, b) {
          return c * (a /= b) * a + d;
        }, easeInQuart: function(a, d, c, b) {
          return c * (a /= b) * a * a * a + d;
        } } }, W = { drawMarker: function(a, d, c, b, e, f, h2, n2) {
          if (c) {
            var s2 = 1;
            c.fillStyle = f ? f : "#000000";
            c.strokeStyle = h2 ? h2 : "#000000";
            c.lineWidth = n2 ? n2 : 0;
            c.setLineDash && c.setLineDash(J("solid", n2));
            "circle" === b ? (c.moveTo(a, d), c.beginPath(), c.arc(a, d, e / 2, 0, 2 * Math.PI, false), f && c.fill(), n2 && (h2 ? c.stroke() : (s2 = c.globalAlpha, c.globalAlpha = 0.15, c.strokeStyle = "black", c.stroke(), c.globalAlpha = s2))) : "square" === b ? (c.beginPath(), c.rect(a - e / 2, d - e / 2, e, e), f && c.fill(), n2 && (h2 ? c.stroke() : (s2 = c.globalAlpha, c.globalAlpha = 0.15, c.strokeStyle = "black", c.stroke(), c.globalAlpha = s2))) : "triangle" === b ? (c.beginPath(), c.moveTo(a - e / 2, d + e / 2), c.lineTo(a + e / 2, d + e / 2), c.lineTo(a, d - e / 2), c.closePath(), f && c.fill(), n2 && (h2 ? c.stroke() : (s2 = c.globalAlpha, c.globalAlpha = 0.15, c.strokeStyle = "black", c.stroke(), c.globalAlpha = s2)), c.beginPath()) : "cross" === b && (c.strokeStyle = f, c.lineWidth = e / 4, c.beginPath(), c.moveTo(a - e / 2, d - e / 2), c.lineTo(a + e / 2, d + e / 2), c.stroke(), c.moveTo(a + e / 2, d - e / 2), c.lineTo(a - e / 2, d + e / 2), c.stroke());
          }
        }, drawMarkers: function(a) {
          for (var d = 0; d < a.length; d++) {
            var c = a[d];
            W.drawMarker(c.x, c.y, c.ctx, c.type, c.size, c.color, c.borderColor, c.borderThickness);
          }
        } };
        return n;
      }();
      B.version = "v3.7.32 GA";
      window.CanvasJS && (B && !window.CanvasJS.Chart) && (window.CanvasJS.Chart = B);
    })();
    document.createElement("canvas").getContext || function() {
      function V() {
        return this.context_ || (this.context_ = new C(this));
      }
      function W(a, b, c) {
        var g = M.call(arguments, 2);
        return function() {
          return a.apply(b, g.concat(M.call(arguments)));
        };
      }
      function N(a) {
        return String(a).replace(/&/g, "&amp;").replace(/"/g, "&quot;");
      }
      function O(a) {
        a.namespaces.g_vml_ || a.namespaces.add("g_vml_", "urn:schemas-microsoft-com:vml", "#default#VML");
        a.namespaces.g_o_ || a.namespaces.add("g_o_", "urn:schemas-microsoft-com:office:office", "#default#VML");
        a.styleSheets.ex_canvas_ || (a = a.createStyleSheet(), a.owningElement.id = "ex_canvas_", a.cssText = "canvas{display:inline-block;overflow:hidden;text-align:left;width:300px;height:150px}");
      }
      function X(a) {
        var b = a.srcElement;
        switch (a.propertyName) {
          case "width":
            b.getContext().clearRect();
            b.style.width = b.attributes.width.nodeValue + "px";
            b.firstChild.style.width = b.clientWidth + "px";
            break;
          case "height":
            b.getContext().clearRect(), b.style.height = b.attributes.height.nodeValue + "px", b.firstChild.style.height = b.clientHeight + "px";
        }
      }
      function Y(a) {
        a = a.srcElement;
        a.firstChild && (a.firstChild.style.width = a.clientWidth + "px", a.firstChild.style.height = a.clientHeight + "px");
      }
      function D() {
        return [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
      }
      function t(a, b) {
        for (var c = D(), g = 0; 3 > g; g++)
          for (var e = 0; 3 > e; e++) {
            for (var f = 0, d2 = 0; 3 > d2; d2++)
              f += a[g][d2] * b[d2][e];
            c[g][e] = f;
          }
        return c;
      }
      function P(a, b) {
        b.fillStyle = a.fillStyle;
        b.lineCap = a.lineCap;
        b.lineJoin = a.lineJoin;
        b.lineWidth = a.lineWidth;
        b.miterLimit = a.miterLimit;
        b.shadowBlur = a.shadowBlur;
        b.shadowColor = a.shadowColor;
        b.shadowOffsetX = a.shadowOffsetX;
        b.shadowOffsetY = a.shadowOffsetY;
        b.strokeStyle = a.strokeStyle;
        b.globalAlpha = a.globalAlpha;
        b.font = a.font;
        b.textAlign = a.textAlign;
        b.textBaseline = a.textBaseline;
        b.arcScaleX_ = a.arcScaleX_;
        b.arcScaleY_ = a.arcScaleY_;
        b.lineScale_ = a.lineScale_;
      }
      function Q(a) {
        var b = a.indexOf("(", 3), c = a.indexOf(")", b + 1), b = a.substring(b + 1, c).split(",");
        if (4 != b.length || "a" != a.charAt(3))
          b[3] = 1;
        return b;
      }
      function E(a, b, c) {
        return Math.min(c, Math.max(b, a));
      }
      function F(a, b, c) {
        0 > c && c++;
        1 < c && c--;
        return 1 > 6 * c ? a + 6 * (b - a) * c : 1 > 2 * c ? b : 2 > 3 * c ? a + 6 * (b - a) * (2 / 3 - c) : a;
      }
      function G(a) {
        if (a in H)
          return H[a];
        var b, c = 1;
        a = String(a);
        if ("#" == a.charAt(0))
          b = a;
        else if (/^rgb/.test(a)) {
          c = Q(a);
          b = "#";
          for (var g, e = 0; 3 > e; e++)
            g = -1 != c[e].indexOf("%") ? Math.floor(255 * (parseFloat(c[e]) / 100)) : +c[e], b += v[E(g, 0, 255)];
          c = +c[3];
        } else if (/^hsl/.test(a)) {
          e = c = Q(a);
          b = parseFloat(e[0]) / 360 % 360;
          0 > b && b++;
          g = E(parseFloat(e[1]) / 100, 0, 1);
          e = E(parseFloat(e[2]) / 100, 0, 1);
          if (0 == g)
            g = e = b = e;
          else {
            var f = 0.5 > e ? e * (1 + g) : e + g - e * g, d2 = 2 * e - f;
            g = F(d2, f, b + 1 / 3);
            e = F(d2, f, b);
            b = F(d2, f, b - 1 / 3);
          }
          b = "#" + v[Math.floor(255 * g)] + v[Math.floor(255 * e)] + v[Math.floor(255 * b)];
          c = c[3];
        } else
          b = Z[a] || a;
        return H[a] = { color: b, alpha: c };
      }
      function C(a) {
        this.m_ = D();
        this.mStack_ = [];
        this.aStack_ = [];
        this.currentPath_ = [];
        this.fillStyle = this.strokeStyle = "#000";
        this.lineWidth = 1;
        this.lineJoin = "miter";
        this.lineCap = "butt";
        this.miterLimit = 1 * q;
        this.globalAlpha = 1;
        this.font = "10px sans-serif";
        this.textAlign = "left";
        this.textBaseline = "alphabetic";
        this.canvas = a;
        var b = "width:" + a.clientWidth + "px;height:" + a.clientHeight + "px;overflow:hidden;position:absolute", c = a.ownerDocument.createElement("div");
        c.style.cssText = b;
        a.appendChild(c);
        b = c.cloneNode(false);
        b.style.backgroundColor = "red";
        b.style.filter = "alpha(opacity=0)";
        a.appendChild(b);
        this.element_ = c;
        this.lineScale_ = this.arcScaleY_ = this.arcScaleX_ = 1;
      }
      function R(a, b, c, g) {
        a.currentPath_.push({ type: "bezierCurveTo", cp1x: b.x, cp1y: b.y, cp2x: c.x, cp2y: c.y, x: g.x, y: g.y });
        a.currentX_ = g.x;
        a.currentY_ = g.y;
      }
      function S(a, b) {
        var c = G(a.strokeStyle), g = c.color, c = c.alpha * a.globalAlpha, e = a.lineScale_ * a.lineWidth;
        1 > e && (c *= e);
        b.push(
          "<g_vml_:stroke",
          ' opacity="',
          c,
          '"',
          ' joinstyle="',
          a.lineJoin,
          '"',
          ' miterlimit="',
          a.miterLimit,
          '"',
          ' endcap="',
          $[a.lineCap] || "square",
          '"',
          ' weight="',
          e,
          'px"',
          ' color="',
          g,
          '" />'
        );
      }
      function T(a, b, c, g) {
        var e = a.fillStyle, f = a.arcScaleX_, d2 = a.arcScaleY_, k2 = g.x - c.x, n = g.y - c.y;
        if (e instanceof w) {
          var h = 0, l = g = 0, u = 0, m = 1;
          if ("gradient" == e.type_) {
            h = e.x1_ / f;
            c = e.y1_ / d2;
            var p = s(a, e.x0_ / f, e.y0_ / d2), h = s(a, h, c), h = 180 * Math.atan2(h.x - p.x, h.y - p.y) / Math.PI;
            0 > h && (h += 360);
            1e-6 > h && (h = 0);
          } else
            p = s(a, e.x0_, e.y0_), g = (p.x - c.x) / k2, l = (p.y - c.y) / n, k2 /= f * q, n /= d2 * q, m = x.max(k2, n), u = 2 * e.r0_ / m, m = 2 * e.r1_ / m - u;
          f = e.colors_;
          f.sort(function(a2, b2) {
            return a2.offset - b2.offset;
          });
          d2 = f.length;
          p = f[0].color;
          c = f[d2 - 1].color;
          k2 = f[0].alpha * a.globalAlpha;
          a = f[d2 - 1].alpha * a.globalAlpha;
          for (var n = [], r2 = 0; r2 < d2; r2++) {
            var t2 = f[r2];
            n.push(t2.offset * m + u + " " + t2.color);
          }
          b.push('<g_vml_:fill type="', e.type_, '"', ' method="none" focus="100%"', ' color="', p, '"', ' color2="', c, '"', ' colors="', n.join(","), '"', ' opacity="', a, '"', ' g_o_:opacity2="', k2, '"', ' angle="', h, '"', ' focusposition="', g, ",", l, '" />');
        } else
          e instanceof I ? k2 && n && b.push("<g_vml_:fill", ' position="', -c.x / k2 * f * f, ",", -c.y / n * d2 * d2, '"', ' type="tile"', ' src="', e.src_, '" />') : (e = G(a.fillStyle), b.push('<g_vml_:fill color="', e.color, '" opacity="', e.alpha * a.globalAlpha, '" />'));
      }
      function s(a, b, c) {
        a = a.m_;
        return { x: q * (b * a[0][0] + c * a[1][0] + a[2][0]) - r, y: q * (b * a[0][1] + c * a[1][1] + a[2][1]) - r };
      }
      function z(a, b, c) {
        isFinite(b[0][0]) && (isFinite(b[0][1]) && isFinite(b[1][0]) && isFinite(b[1][1]) && isFinite(b[2][0]) && isFinite(b[2][1])) && (a.m_ = b, c && (a.lineScale_ = aa(ba(b[0][0] * b[1][1] - b[0][1] * b[1][0]))));
      }
      function w(a) {
        this.type_ = a;
        this.r1_ = this.y1_ = this.x1_ = this.r0_ = this.y0_ = this.x0_ = 0;
        this.colors_ = [];
      }
      function I(a, b) {
        if (!a || 1 != a.nodeType || "IMG" != a.tagName)
          throw new A("TYPE_MISMATCH_ERR");
        if ("complete" != a.readyState)
          throw new A("INVALID_STATE_ERR");
        switch (b) {
          case "repeat":
          case null:
          case "":
            this.repetition_ = "repeat";
            break;
          case "repeat-x":
          case "repeat-y":
          case "no-repeat":
            this.repetition_ = b;
            break;
          default:
            throw new A("SYNTAX_ERR");
        }
        this.src_ = a.src;
        this.width_ = a.width;
        this.height_ = a.height;
      }
      function A(a) {
        this.code = this[a];
        this.message = a + ": DOM Exception " + this.code;
      }
      var x = Math, k = x.round, J = x.sin, K = x.cos, ba = x.abs, aa = x.sqrt, q = 10, r = q / 2;
      navigator.userAgent.match(/MSIE ([\d.]+)?/);
      var M = Array.prototype.slice;
      O(document);
      var U = { init: function(a) {
        a = a || document;
        a.createElement("canvas");
        a.attachEvent("onreadystatechange", W(this.init_, this, a));
      }, init_: function(a) {
        a = a.getElementsByTagName("canvas");
        for (var b = 0; b < a.length; b++)
          this.initElement(a[b]);
      }, initElement: function(a) {
        if (!a.getContext) {
          a.getContext = V;
          O(a.ownerDocument);
          a.innerHTML = "";
          a.attachEvent("onpropertychange", X);
          a.attachEvent("onresize", Y);
          var b = a.attributes;
          b.width && b.width.specified ? a.style.width = b.width.nodeValue + "px" : a.width = a.clientWidth;
          b.height && b.height.specified ? a.style.height = b.height.nodeValue + "px" : a.height = a.clientHeight;
        }
        return a;
      } };
      U.init();
      for (var v = [], d = 0; 16 > d; d++)
        for (var B = 0; 16 > B; B++)
          v[16 * d + B] = d.toString(16) + B.toString(16);
      var Z = {
        aliceblue: "#F0F8FF",
        antiquewhite: "#FAEBD7",
        aquamarine: "#7FFFD4",
        azure: "#F0FFFF",
        beige: "#F5F5DC",
        bisque: "#FFE4C4",
        black: "#000000",
        blanchedalmond: "#FFEBCD",
        blueviolet: "#8A2BE2",
        brown: "#A52A2A",
        burlywood: "#DEB887",
        cadetblue: "#5F9EA0",
        chartreuse: "#7FFF00",
        chocolate: "#D2691E",
        coral: "#FF7F50",
        cornflowerblue: "#6495ED",
        cornsilk: "#FFF8DC",
        crimson: "#DC143C",
        cyan: "#00FFFF",
        darkblue: "#00008B",
        darkcyan: "#008B8B",
        darkgoldenrod: "#B8860B",
        darkgray: "#A9A9A9",
        darkgreen: "#006400",
        darkgrey: "#A9A9A9",
        darkkhaki: "#BDB76B",
        darkmagenta: "#8B008B",
        darkolivegreen: "#556B2F",
        darkorange: "#FF8C00",
        darkorchid: "#9932CC",
        darkred: "#8B0000",
        darksalmon: "#E9967A",
        darkseagreen: "#8FBC8F",
        darkslateblue: "#483D8B",
        darkslategray: "#2F4F4F",
        darkslategrey: "#2F4F4F",
        darkturquoise: "#00CED1",
        darkviolet: "#9400D3",
        deeppink: "#FF1493",
        deepskyblue: "#00BFFF",
        dimgray: "#696969",
        dimgrey: "#696969",
        dodgerblue: "#1E90FF",
        firebrick: "#B22222",
        floralwhite: "#FFFAF0",
        forestgreen: "#228B22",
        gainsboro: "#DCDCDC",
        ghostwhite: "#F8F8FF",
        gold: "#FFD700",
        goldenrod: "#DAA520",
        grey: "#808080",
        greenyellow: "#ADFF2F",
        honeydew: "#F0FFF0",
        hotpink: "#FF69B4",
        indianred: "#CD5C5C",
        indigo: "#4B0082",
        ivory: "#FFFFF0",
        khaki: "#F0E68C",
        lavender: "#E6E6FA",
        lavenderblush: "#FFF0F5",
        lawngreen: "#7CFC00",
        lemonchiffon: "#FFFACD",
        lightblue: "#ADD8E6",
        lightcoral: "#F08080",
        lightcyan: "#E0FFFF",
        lightgoldenrodyellow: "#FAFAD2",
        lightgreen: "#90EE90",
        lightgrey: "#D3D3D3",
        lightpink: "#FFB6C1",
        lightsalmon: "#FFA07A",
        lightseagreen: "#20B2AA",
        lightskyblue: "#87CEFA",
        lightslategray: "#778899",
        lightslategrey: "#778899",
        lightsteelblue: "#B0C4DE",
        lightyellow: "#FFFFE0",
        limegreen: "#32CD32",
        linen: "#FAF0E6",
        magenta: "#FF00FF",
        mediumaquamarine: "#66CDAA",
        mediumblue: "#0000CD",
        mediumorchid: "#BA55D3",
        mediumpurple: "#9370DB",
        mediumseagreen: "#3CB371",
        mediumslateblue: "#7B68EE",
        mediumspringgreen: "#00FA9A",
        mediumturquoise: "#48D1CC",
        mediumvioletred: "#C71585",
        midnightblue: "#191970",
        mintcream: "#F5FFFA",
        mistyrose: "#FFE4E1",
        moccasin: "#FFE4B5",
        navajowhite: "#FFDEAD",
        oldlace: "#FDF5E6",
        olivedrab: "#6B8E23",
        orange: "#FFA500",
        orangered: "#FF4500",
        orchid: "#DA70D6",
        palegoldenrod: "#EEE8AA",
        palegreen: "#98FB98",
        paleturquoise: "#AFEEEE",
        palevioletred: "#DB7093",
        papayawhip: "#FFEFD5",
        peachpuff: "#FFDAB9",
        peru: "#CD853F",
        pink: "#FFC0CB",
        plum: "#DDA0DD",
        powderblue: "#B0E0E6",
        rosybrown: "#BC8F8F",
        royalblue: "#4169E1",
        saddlebrown: "#8B4513",
        salmon: "#FA8072",
        sandybrown: "#F4A460",
        seagreen: "#2E8B57",
        seashell: "#FFF5EE",
        sienna: "#A0522D",
        skyblue: "#87CEEB",
        slateblue: "#6A5ACD",
        slategray: "#708090",
        slategrey: "#708090",
        snow: "#FFFAFA",
        springgreen: "#00FF7F",
        steelblue: "#4682B4",
        tan: "#D2B48C",
        thistle: "#D8BFD8",
        tomato: "#FF6347",
        turquoise: "#40E0D0",
        violet: "#EE82EE",
        wheat: "#F5DEB3",
        whitesmoke: "#F5F5F5",
        yellowgreen: "#9ACD32"
      }, H = {}, L = {}, $ = { butt: "flat", round: "round" }, d = C.prototype;
      d.clearRect = function() {
        this.textMeasureEl_ && (this.textMeasureEl_.removeNode(true), this.textMeasureEl_ = null);
        this.element_.innerHTML = "";
      };
      d.beginPath = function() {
        this.currentPath_ = [];
      };
      d.moveTo = function(a, b) {
        var c = s(this, a, b);
        this.currentPath_.push({ type: "moveTo", x: c.x, y: c.y });
        this.currentX_ = c.x;
        this.currentY_ = c.y;
      };
      d.lineTo = function(a, b) {
        var c = s(this, a, b);
        this.currentPath_.push({ type: "lineTo", x: c.x, y: c.y });
        this.currentX_ = c.x;
        this.currentY_ = c.y;
      };
      d.bezierCurveTo = function(a, b, c, g, e, f) {
        e = s(this, e, f);
        a = s(this, a, b);
        c = s(this, c, g);
        R(this, a, c, e);
      };
      d.quadraticCurveTo = function(a, b, c, g) {
        a = s(this, a, b);
        c = s(this, c, g);
        g = { x: this.currentX_ + 2 / 3 * (a.x - this.currentX_), y: this.currentY_ + 2 / 3 * (a.y - this.currentY_) };
        R(this, g, { x: g.x + (c.x - this.currentX_) / 3, y: g.y + (c.y - this.currentY_) / 3 }, c);
      };
      d.arc = function(a, b, c, g, e, f) {
        c *= q;
        var d2 = f ? "at" : "wa", k2 = a + K(g) * c - r, n = b + J(g) * c - r;
        g = a + K(e) * c - r;
        e = b + J(e) * c - r;
        k2 != g || f || (k2 += 0.125);
        a = s(this, a, b);
        k2 = s(this, k2, n);
        g = s(this, g, e);
        this.currentPath_.push({
          type: d2,
          x: a.x,
          y: a.y,
          radius: c,
          xStart: k2.x,
          yStart: k2.y,
          xEnd: g.x,
          yEnd: g.y
        });
      };
      d.rect = function(a, b, c, g) {
        this.moveTo(a, b);
        this.lineTo(a + c, b);
        this.lineTo(a + c, b + g);
        this.lineTo(a, b + g);
        this.closePath();
      };
      d.strokeRect = function(a, b, c, g) {
        var e = this.currentPath_;
        this.beginPath();
        this.moveTo(a, b);
        this.lineTo(a + c, b);
        this.lineTo(a + c, b + g);
        this.lineTo(a, b + g);
        this.closePath();
        this.stroke();
        this.currentPath_ = e;
      };
      d.fillRect = function(a, b, c, g) {
        var e = this.currentPath_;
        this.beginPath();
        this.moveTo(a, b);
        this.lineTo(a + c, b);
        this.lineTo(a + c, b + g);
        this.lineTo(a, b + g);
        this.closePath();
        this.fill();
        this.currentPath_ = e;
      };
      d.createLinearGradient = function(a, b, c, g) {
        var e = new w("gradient");
        e.x0_ = a;
        e.y0_ = b;
        e.x1_ = c;
        e.y1_ = g;
        return e;
      };
      d.createRadialGradient = function(a, b, c, g, e, f) {
        var d2 = new w("gradientradial");
        d2.x0_ = a;
        d2.y0_ = b;
        d2.r0_ = c;
        d2.x1_ = g;
        d2.y1_ = e;
        d2.r1_ = f;
        return d2;
      };
      d.drawImage = function(a, b) {
        var c, g, e, d2, r2, y, n, h;
        e = a.runtimeStyle.width;
        d2 = a.runtimeStyle.height;
        a.runtimeStyle.width = "auto";
        a.runtimeStyle.height = "auto";
        var l = a.width, u = a.height;
        a.runtimeStyle.width = e;
        a.runtimeStyle.height = d2;
        if (3 == arguments.length)
          c = arguments[1], g = arguments[2], r2 = y = 0, n = e = l, h = d2 = u;
        else if (5 == arguments.length)
          c = arguments[1], g = arguments[2], e = arguments[3], d2 = arguments[4], r2 = y = 0, n = l, h = u;
        else if (9 == arguments.length)
          r2 = arguments[1], y = arguments[2], n = arguments[3], h = arguments[4], c = arguments[5], g = arguments[6], e = arguments[7], d2 = arguments[8];
        else
          throw Error("Invalid number of arguments");
        var m = s(this, c, g), p = [];
        p.push(
          " <g_vml_:group",
          ' coordsize="',
          10 * q,
          ",",
          10 * q,
          '"',
          ' coordorigin="0,0"',
          ' style="width:',
          10,
          "px;height:",
          10,
          "px;position:absolute;"
        );
        if (1 != this.m_[0][0] || this.m_[0][1] || 1 != this.m_[1][1] || this.m_[1][0]) {
          var t2 = [];
          t2.push("M11=", this.m_[0][0], ",", "M12=", this.m_[1][0], ",", "M21=", this.m_[0][1], ",", "M22=", this.m_[1][1], ",", "Dx=", k(m.x / q), ",", "Dy=", k(m.y / q), "");
          var v2 = s(this, c + e, g), w2 = s(this, c, g + d2);
          c = s(this, c + e, g + d2);
          m.x = x.max(m.x, v2.x, w2.x, c.x);
          m.y = x.max(m.y, v2.y, w2.y, c.y);
          p.push("padding:0 ", k(m.x / q), "px ", k(m.y / q), "px 0;filter:progid:DXImageTransform.Microsoft.Matrix(", t2.join(""), ", sizingmethod='clip');");
        } else
          p.push(
            "top:",
            k(m.y / q),
            "px;left:",
            k(m.x / q),
            "px;"
          );
        p.push(' ">', '<g_vml_:image src="', a.src, '"', ' style="width:', q * e, "px;", " height:", q * d2, 'px"', ' cropleft="', r2 / l, '"', ' croptop="', y / u, '"', ' cropright="', (l - r2 - n) / l, '"', ' cropbottom="', (u - y - h) / u, '"', " />", "</g_vml_:group>");
        this.element_.insertAdjacentHTML("BeforeEnd", p.join(""));
      };
      d.stroke = function(a) {
        var b = [];
        b.push(
          "<g_vml_:shape",
          ' filled="',
          !!a,
          '"',
          ' style="position:absolute;width:',
          10,
          "px;height:",
          10,
          'px;"',
          ' coordorigin="0,0"',
          ' coordsize="',
          10 * q,
          ",",
          10 * q,
          '"',
          ' stroked="',
          !a,
          '"',
          ' path="'
        );
        for (var c = { x: null, y: null }, d2 = { x: null, y: null }, e = 0; e < this.currentPath_.length; e++) {
          var f = this.currentPath_[e];
          switch (f.type) {
            case "moveTo":
              b.push(" m ", k(f.x), ",", k(f.y));
              break;
            case "lineTo":
              b.push(" l ", k(f.x), ",", k(f.y));
              break;
            case "close":
              b.push(" x ");
              f = null;
              break;
            case "bezierCurveTo":
              b.push(" c ", k(f.cp1x), ",", k(f.cp1y), ",", k(f.cp2x), ",", k(f.cp2y), ",", k(f.x), ",", k(f.y));
              break;
            case "at":
            case "wa":
              b.push(" ", f.type, " ", k(f.x - this.arcScaleX_ * f.radius), ",", k(f.y - this.arcScaleY_ * f.radius), " ", k(f.x + this.arcScaleX_ * f.radius), ",", k(f.y + this.arcScaleY_ * f.radius), " ", k(f.xStart), ",", k(f.yStart), " ", k(f.xEnd), ",", k(f.yEnd));
          }
          if (f) {
            if (null == c.x || f.x < c.x)
              c.x = f.x;
            if (null == d2.x || f.x > d2.x)
              d2.x = f.x;
            if (null == c.y || f.y < c.y)
              c.y = f.y;
            if (null == d2.y || f.y > d2.y)
              d2.y = f.y;
          }
        }
        b.push(' ">');
        a ? T(this, b, c, d2) : S(this, b);
        b.push("</g_vml_:shape>");
        this.element_.insertAdjacentHTML("beforeEnd", b.join(""));
      };
      d.fill = function() {
        this.stroke(true);
      };
      d.closePath = function() {
        this.currentPath_.push({ type: "close" });
      };
      d.save = function() {
        var a = {};
        P(this, a);
        this.aStack_.push(a);
        this.mStack_.push(this.m_);
        this.m_ = t(D(), this.m_);
      };
      d.restore = function() {
        this.aStack_.length && (P(this.aStack_.pop(), this), this.m_ = this.mStack_.pop());
      };
      d.translate = function(a, b) {
        z(this, t([[1, 0, 0], [0, 1, 0], [a, b, 1]], this.m_), false);
      };
      d.rotate = function(a) {
        var b = K(a);
        a = J(a);
        z(this, t([[b, a, 0], [-a, b, 0], [0, 0, 1]], this.m_), false);
      };
      d.scale = function(a, b) {
        this.arcScaleX_ *= a;
        this.arcScaleY_ *= b;
        z(this, t([[a, 0, 0], [0, b, 0], [0, 0, 1]], this.m_), true);
      };
      d.transform = function(a, b, c, d2, e, f) {
        z(this, t([[
          a,
          b,
          0
        ], [c, d2, 0], [e, f, 1]], this.m_), true);
      };
      d.setTransform = function(a, b, c, d2, e, f) {
        z(this, [[a, b, 0], [c, d2, 0], [e, f, 1]], true);
      };
      d.drawText_ = function(a, b, c, d2, e) {
        var f = this.m_;
        d2 = 0;
        var r2 = 1e3, t2 = 0, n = [], h;
        h = this.font;
        if (L[h])
          h = L[h];
        else {
          var l = document.createElement("div").style;
          try {
            l.font = h;
          } catch (u) {
          }
          h = L[h] = { style: l.fontStyle || "normal", variant: l.fontVariant || "normal", weight: l.fontWeight || "normal", size: l.fontSize || 10, family: l.fontFamily || "sans-serif" };
        }
        var l = h, m = this.element_;
        h = {};
        for (var p in l)
          h[p] = l[p];
        p = parseFloat(m.currentStyle.fontSize);
        m = parseFloat(l.size);
        "number" == typeof l.size ? h.size = l.size : -1 != l.size.indexOf("px") ? h.size = m : -1 != l.size.indexOf("em") ? h.size = p * m : -1 != l.size.indexOf("%") ? h.size = p / 100 * m : -1 != l.size.indexOf("pt") ? h.size = m / 0.75 : h.size = p;
        h.size *= 0.981;
        p = h.style + " " + h.variant + " " + h.weight + " " + h.size + "px " + h.family;
        m = this.element_.currentStyle;
        l = this.textAlign.toLowerCase();
        switch (l) {
          case "left":
          case "center":
          case "right":
            break;
          case "end":
            l = "ltr" == m.direction ? "right" : "left";
            break;
          case "start":
            l = "rtl" == m.direction ? "right" : "left";
            break;
          default:
            l = "left";
        }
        switch (this.textBaseline) {
          case "hanging":
          case "top":
            t2 = h.size / 1.75;
            break;
          case "middle":
            break;
          default:
          case null:
          case "alphabetic":
          case "ideographic":
          case "bottom":
            t2 = -h.size / 2.25;
        }
        switch (l) {
          case "right":
            d2 = 1e3;
            r2 = 0.05;
            break;
          case "center":
            d2 = r2 = 500;
        }
        b = s(this, b + 0, c + t2);
        n.push('<g_vml_:line from="', -d2, ' 0" to="', r2, ' 0.05" ', ' coordsize="100 100" coordorigin="0 0"', ' filled="', !e, '" stroked="', !!e, '" style="position:absolute;width:1px;height:1px;">');
        e ? S(this, n) : T(
          this,
          n,
          { x: -d2, y: 0 },
          { x: r2, y: h.size }
        );
        e = f[0][0].toFixed(3) + "," + f[1][0].toFixed(3) + "," + f[0][1].toFixed(3) + "," + f[1][1].toFixed(3) + ",0,0";
        b = k(b.x / q) + "," + k(b.y / q);
        n.push('<g_vml_:skew on="t" matrix="', e, '" ', ' offset="', b, '" origin="', d2, ' 0" />', '<g_vml_:path textpathok="true" />', '<g_vml_:textpath on="true" string="', N(a), '" style="v-text-align:', l, ";font:", N(p), '" /></g_vml_:line>');
        this.element_.insertAdjacentHTML("beforeEnd", n.join(""));
      };
      d.fillText = function(a, b, c, d2) {
        this.drawText_(a, b, c, d2, false);
      };
      d.strokeText = function(a, b, c, d2) {
        this.drawText_(a, b, c, d2, true);
      };
      d.measureText = function(a) {
        this.textMeasureEl_ || (this.element_.insertAdjacentHTML("beforeEnd", '<span style="position:absolute;top:-20000px;left:0;padding:0;margin:0;border:none;white-space:pre;"></span>'), this.textMeasureEl_ = this.element_.lastChild);
        var b = this.element_.ownerDocument;
        this.textMeasureEl_.innerHTML = "";
        this.textMeasureEl_.style.font = this.font;
        this.textMeasureEl_.appendChild(b.createTextNode(a));
        return { width: this.textMeasureEl_.offsetWidth };
      };
      d.clip = function() {
      };
      d.arcTo = function() {
      };
      d.createPattern = function(a, b) {
        return new I(a, b);
      };
      w.prototype.addColorStop = function(a, b) {
        b = G(b);
        this.colors_.push({ offset: a, color: b.color, alpha: b.alpha });
      };
      d = A.prototype = Error();
      d.INDEX_SIZE_ERR = 1;
      d.DOMSTRING_SIZE_ERR = 2;
      d.HIERARCHY_REQUEST_ERR = 3;
      d.WRONG_DOCUMENT_ERR = 4;
      d.INVALID_CHARACTER_ERR = 5;
      d.NO_DATA_ALLOWED_ERR = 6;
      d.NO_MODIFICATION_ALLOWED_ERR = 7;
      d.NOT_FOUND_ERR = 8;
      d.NOT_SUPPORTED_ERR = 9;
      d.INUSE_ATTRIBUTE_ERR = 10;
      d.INVALID_STATE_ERR = 11;
      d.SYNTAX_ERR = 12;
      d.INVALID_MODIFICATION_ERR = 13;
      d.NAMESPACE_ERR = 14;
      d.INVALID_ACCESS_ERR = 15;
      d.VALIDATION_ERR = 16;
      d.TYPE_MISMATCH_ERR = 17;
      G_vmlCanvasManager = U;
      CanvasRenderingContext2D = C;
      CanvasGradient = w;
      CanvasPattern = I;
      DOMException = A;
    }();
  }
});

// node_modules/@canvasjs/angular-charts/fesm2015/canvasjs-angular-charts.js
var CanvasJS = require_canvasjs_min();
var CanvasJSChart = class _CanvasJSChart {
  constructor() {
    this.shouldUpdateChart = false;
    this.chartInstance = new EventEmitter();
    this.options = this.options ? this.options : {};
    this.styles = this.styles ? this.styles : {
      width: "100%",
      position: "relative"
    };
    this.styles.height = this.options.height ? this.options.height + "px" : "400px";
    this.chartContainerId = "canvasjs-angular-chart-container-" + _CanvasJSChart._cjsChartContainerId++;
  }
  ngDoCheck() {
    if (this.prevChartOptions != this.options) {
      this.shouldUpdateChart = true;
    }
  }
  ngOnChanges() {
    if (this.shouldUpdateChart && this.chart) {
      this.chart.options = this.options;
      this.chart.render();
      this.shouldUpdateChart = false;
      this.prevChartOptions = this.options;
    }
  }
  ngAfterViewInit() {
    this.chart = new CanvasJS.Chart(this.chartContainerId, this.options);
    this.chart.render();
    this.prevChartOptions = this.options;
    this.chartInstance.emit(this.chart);
  }
  ngOnDestroy() {
    if (this.chart)
      this.chart.destroy();
  }
};
CanvasJSChart._cjsChartContainerId = 0;
CanvasJSChart.ɵfac = function CanvasJSChart_Factory(t) {
  return new (t || CanvasJSChart)();
};
CanvasJSChart.ɵcmp = ɵɵdefineComponent({
  type: CanvasJSChart,
  selectors: [["canvasjs-chart"]],
  inputs: {
    options: "options",
    styles: "styles"
  },
  outputs: {
    chartInstance: "chartInstance"
  },
  features: [ɵɵNgOnChangesFeature],
  decls: 1,
  vars: 2,
  consts: [[3, "id", "ngStyle"]],
  template: function CanvasJSChart_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelement(0, "div", 0);
    }
    if (rf & 2) {
      ɵɵpropertyInterpolate("id", ctx.chartContainerId);
      ɵɵproperty("ngStyle", ctx.styles);
    }
  },
  dependencies: [NgStyle],
  encapsulation: 2
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CanvasJSChart, [{
    type: Component,
    args: [{
      selector: "canvasjs-chart",
      template: '<div id="{{chartContainerId}}" [ngStyle]="styles"></div>'
    }]
  }], function() {
    return [];
  }, {
    options: [{
      type: Input
    }],
    styles: [{
      type: Input
    }],
    chartInstance: [{
      type: Output
    }]
  });
})();
var CanvasJSAngularChartsModule = class {
};
CanvasJSAngularChartsModule.ɵfac = function CanvasJSAngularChartsModule_Factory(t) {
  return new (t || CanvasJSAngularChartsModule)();
};
CanvasJSAngularChartsModule.ɵmod = ɵɵdefineNgModule({
  type: CanvasJSAngularChartsModule,
  declarations: [CanvasJSChart],
  imports: [CommonModule],
  exports: [CanvasJSChart]
});
CanvasJSAngularChartsModule.ɵinj = ɵɵdefineInjector({
  imports: [[CommonModule]]
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CanvasJSAngularChartsModule, [{
    type: NgModule,
    args: [{
      declarations: [CanvasJSChart],
      imports: [CommonModule],
      exports: [CanvasJSChart]
    }]
  }], null, null);
})();
export {
  CanvasJS,
  CanvasJSAngularChartsModule,
  CanvasJSChart
};
//# sourceMappingURL=@canvasjs_angular-charts.js.map

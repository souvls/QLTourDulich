import {
  InputText,
  InputTextModule
} from "./chunk-H3E7V55B.js";
import "./chunk-IDLSIQ2B.js";
import "./chunk-YZEMK44K.js";
import "./chunk-PA7AHZKQ.js";
import "./chunk-AFRS2OIU.js";
import "./chunk-J5XZNU7V.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map

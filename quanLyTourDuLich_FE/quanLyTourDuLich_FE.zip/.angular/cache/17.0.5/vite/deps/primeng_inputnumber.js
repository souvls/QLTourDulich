import {
  INPUTNUMBER_VALUE_ACCESSOR,
  InputNumber,
  InputNumberModule
} from "./chunk-LKJXVP6C.js";
import "./chunk-H3E7V55B.js";
import "./chunk-XUOBOL6S.js";
import "./chunk-IDLSIQ2B.js";
import "./chunk-EZTW7KX4.js";
import "./chunk-JT6O4I5J.js";
import "./chunk-5KXMCARW.js";
import "./chunk-MRLHSI7V.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-VEQSBVUE.js";
import "./chunk-YZEMK44K.js";
import "./chunk-PA7AHZKQ.js";
import "./chunk-AFRS2OIU.js";
import "./chunk-J5XZNU7V.js";
export {
  INPUTNUMBER_VALUE_ACCESSOR,
  InputNumber,
  InputNumberModule
};
//# sourceMappingURL=primeng_inputnumber.js.map
